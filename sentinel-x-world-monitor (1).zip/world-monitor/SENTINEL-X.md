# SENTINEL-X — Final Scope & Verification (SIH26163)

SENTINEL-X is the security-assessment engine inside World Monitor. It runs a
fixed, authoritative set of **15 attacks** — each executed for real in a
**vulnerable** and a **fixed** build, with the verdict **computed from the
actual outcome**, never hard-coded — plus one **defensive** capability:
**real-time SMS fraud detection**.

```
                    SENTINEL-X
          ┌─────────────┴─────────────┐
 SECURITY ASSESSMENT             SMS FRAUD
      ENGINE                      DETECTOR
   15 attacks                 live message analysis
 real execution              explainable risk score
 VULNERABLE / SECURE         SAFE / SUSPICIOUS / HIGH_RISK
 runtime evidence            explainable reasons
          └─────────────┬─────────────┘
                 SENTINEL-X DASHBOARD
              Evidence + Remediation
```

## The 15 approved attacks (the only ones that exist)

The single source of truth is [`public/assessments/registry.js`](public/assessments/registry.js).
The backend, frontend, validation and tests all derive their list from it.

| # | Section 1 — Individual | Section 2 — Employee & Manager | Section 3 — Organization |
|---|------------------------|--------------------------------|--------------------------|
| 1 | IND-06 Stored XSS | EMP-04 IDOR (real production route) | ORG-06 SQL Injection |
| 2 | IND-10 Sensitive Data Over-Exposed | EMP-09 Mass Assignment (real route) | ORG-09 Path Traversal |
| 3 | IND-03 Session Valid After Logout | EMP-02 Vertical Privilege Escalation | ORG-15 No Rate Limiting |
| 4 | IND-01 Account Enumeration | EMP-08 Forged JWT (alg=none) | ORG-16 PII in Cleartext |
| 5 | IND-04 Password Reset Token Reusable | EMP-12 No Idle Session Timeout | ORG-11 Vulnerable Dependencies |

**+ SMS Fraud Detection** — a *defensive capability* in Section 1. It is **not**
an attack, is **not** numbered, and is **not** part of the count of 15.

Every other attack that used to exist has been **removed** — backend handlers,
frontend cards, live-I/O registrations and tests. A request to a retired route
returns **HTTP 404 `UNSUPPORTED`**; it never executes old code.

## What makes each verdict real

- **IND-06** stores the payload in SQLite and serves it back raw (vulnerable) or
  sanitised (fixed); `GET /comment/:id?render=1` serves it as real `text/html`.
- **EMP-04 / EMP-09** mint a **real employee session** via the auth service and
  send a **real HTTP request** to the production route (fixed) or its vulnerable
  lab twin, then read the **real SQLite row** back to prove what persisted.
- **EMP-08** runs the real HS256 verification path; **EMP-12** uses a controlled
  test clock (no 60-minute wait).
- **ORG-06 / ORG-09** run against sandboxed synthetic data (no real DB/FS).
- **ORG-15** uses a real SQLite-backed counter and returns genuine HTTP 429.
- **ORG-11** runs a **real `npm audit --json`**: fixed audits the project's
  actual clean lockfile; vulnerable audits a deliberately-outdated lockfile
  fixture (`scanner/vuln-fixture/`). Package names, versions and CVEs come from
  the **live npm advisory database** — nothing is hard-coded. (An offline
  advisory snapshot is used only if the registry is unreachable, and is labelled
  as such in the response.)
- A check that cannot execute returns **`ASSESSMENT_ERROR`** — a failure is
  never converted into a false `SECURE`.

## SMS Fraud Detection (defensive)

`POST /api/sms/analyze` — body `{ message, sender?, claimedCompany?, userName? }`.
Implemented in [`lib/sms-fraud.js`](lib/sms-fraud.js). It distinguishes a normal
**OTP notification** ("your OTP is 1234, do not share") from a fraudulent **OTP
disclosure request** ("tell the OTP to our executive"), combines multiple weak
signals (never trusting one alone), and returns an explainable result:

```
classification : SAFE | SUSPICIOUS | HIGH_RISK | ANALYSIS_ERROR
riskScore      : 0–100 (computed from detected signals)
otpDisclosureRequest, phishingLink, senderMismatch, transactionAlert,
urgentLanguage, companyDomainMismatch, impersonation, …  (booleans)
reasons[]      : human-readable explanation
otpValue       : [REDACTED]   ← the secret is never stored or echoed
```

`SAFE` means "no known suspicious indicators detected by the configured checks"
— **not** a guarantee of legitimacy. A lone unfamiliar sender or a name mismatch
never equals fraud on its own.

## Reproduce the evidence

```bash
npm install
npm run db:init          # seed synthetic data (SQLite)
npm run validate         # scope gate: exactly 15, 0 unapproved, all wired
npm start                # dashboard + API on http://localhost:5175
npm run verify           # boots the server, runs all 15 + SMS over real HTTP
npm run verify:ui        # headless-browser check of the dashboard (5+5+5 + SMS)
npm test                 # full suite (runs the scope gate first, then 98 tests)
```

`npm run verify` prints a per-attack table (vulnerable→VULNERABLE,
fixed→SECURE), the SMS scenarios, and confirmation that retired routes are
blocked, then exits non-zero if anything fails.

## Section reports

Each section's dashboard report is generated from its 5 attacks. The SMS
detector is reported **separately** as a defensive capability, e.g.:

```
SECTION 1 — INDIVIDUAL
  IND-06  Stored XSS                     ✅ Fixed
  IND-10  Sensitive Data Over-Exposed    ✅ Fixed
  IND-03  Session Valid After Logout     ✅ Fixed
  IND-01  Account Enumeration            ✅ Fixed
  IND-04  Password Reset Token Reusable  ✅ Fixed

  Defensive Capability:
  SMS Fraud Detection                    ✅ Operational
```

## Final validation checklist

```
Approved attack count      = 15
Unapproved attack count    = 0
Retired attack routes      = 0 (return 404 UNSUPPORTED)
Duplicate IDs              = 0
Section split              = 5 / 5 / 5
Hard-coded verdicts        = 0 (every verdict computed at runtime)
Fake package-lock findings = 0 (real npm audit)
SMS Fraud Detection        = operational (not counted as an attack)
```
