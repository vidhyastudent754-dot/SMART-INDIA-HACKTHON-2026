#!/usr/bin/env python3
"""
ml/train.py — trains the two small text classifiers used by World Monitor's
email/SMS analyzer and exports them as plain JSON so the Node server can score
them in-process (lib/ml.js) with no ML runtime dependency.

Model:   TF-IDF (unigrams + bigrams, sublinear tf, l2 norm)  →  logistic regression
Data:    see ML.md.  Fetch with `bash ml/fetch-data.sh` first.
Output:  models/email-model.json, models/sms-model.json, ml/metrics.json,
         test/fixtures/ml-parity.json  (vectors used by the JS parity test)

The tokenizer below is the SPEC. lib/ml.js re-implements it character-for-
character; test/ml.test.js proves the two agree on real inputs.
"""
import json, re, sys, os, datetime, hashlib
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score, confusion_matrix)

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, 'ml', 'data')
SEED = 42
TOKENIZER_VERSION = 'wm-tok-1'

# ---------------------------------------------------------------- tokenizer
WS = r'[ \t\n\r\f\v]'
NWS = r'[^ \t\n\r\f\v]'
RE_TAG = re.compile(r'<[^>]*>')
RE_URL = re.compile(r'(?:https?://|www\.)' + NWS + '+')
RE_EMAIL = re.compile(NWS + '+@' + NWS + '+')
RE_MONEY = re.compile(r'[$£€₹]')
RE_NUM = re.compile(r'[0-9]+')
RE_TOK = re.compile(r'[a-z]+')

def tokenize(text):
    t = str(text).lower()
    t = RE_TAG.sub(' ', t)
    t = RE_URL.sub(' zzurl ', t)
    t = RE_EMAIL.sub(' zzemail ', t)
    t = RE_MONEY.sub(' zzmoney ', t)
    t = RE_NUM.sub(' zznum ', t)
    toks = [w for w in RE_TOK.findall(t) if len(w) >= 2]
    return toks + [toks[i] + ' ' + toks[i + 1] for i in range(len(toks) - 1)]

# ---------------------------------------------------------------- data
def load_sms():
    df = pd.read_csv(os.path.join(DATA, 'sms_spam_collection.tsv'), sep='\t',
                     header=None, names=['label', 'text'], quoting=3)
    df['y'] = (df['label'] == 'spam').astype(int)
    return df[['text', 'y']].dropna(), 'UCI SMS Spam Collection v.1 (Almeida & Hidalgo, 2011)'

# Corpus artifacts that identify the SOURCE list rather than phishing-ness
# (mailing-list footers, feed headers). Left in, the model learns "came from
# the spamassassin-sightings list" instead of "looks like phishing".
RE_ARTIFACT = re.compile(r'^.*(mailing list|mailing-list|listinfo|sightings|sourceforge\.net/lists|'
                         r'unsubscribe|^url:|^date:|^-{2,}|^_{5,}).*$', re.I | re.M)

RE_LIST_TAG = re.compile(r'\[[^\]\n]{1,40}\]')   # "[ILUG]", "[SAtalk]" subject tags

# Tokens that identify WHICH corpus a message came from (company, list and
# frequent-correspondent names). Removed from training text only, so the model
# can't score "is this Enron?" instead of "is this phishing/spam?".
CORPUS_IDENTITY = ['enron', 'ect', 'hou', 'houston', 'vince', 'kaminski', 'louise', 'kitchen',
                   'daren', 'farmer', 'dave', 'delainey', 'jeff', 'dasovich', 'sally', 'beck',
                   'steve', 'jim', 'mark', 'chris', 'john', 'kay', 'mann', 'shirley', 'crenshaw',
                   'spamassassin', 'ilug', 'satalk', 'razor', 'zzzzteana', 'exmh', 'zdnet', 'cnet',
                   'paliourg', 'lokay', 'eol', 'fork', 'xent', 'linux', 'redhat', 'rpm', 'apt', 'cvs', 'sourceforge']
RE_IDENTITY = re.compile(r'\b(' + '|'.join(CORPUS_IDENTITY) + r')\b', re.I)

def clean_email(t):
    return RE_IDENTITY.sub(' ', RE_LIST_TAG.sub(' ', RE_ARTIFACT.sub(' ', t)))

def load_email():
    parts = []
    for f in ('Nazario.csv', 'SpamAssasin.csv', 'Enron.csv'):
        d = pd.read_csv(os.path.join(DATA, f))
        d['text'] = (d['subject'].fillna('').astype(str) + '\n' + d['body'].fillna('').astype(str)).map(clean_email)
        d['y'] = d['label'].astype(int)
        d['source'] = f
        parts.append(d[['text', 'y', 'source']])
    df = pd.concat(parts, ignore_index=True)
    df['text'] = df['text'].str.slice(0, 20000)   # same cap as the API
    df = df.drop_duplicates(subset='text')
    return df, ('Nazario phishing corpus + SpamAssassin public corpus + Enron-Spam corpus, as curated in '
                'Al-Subaiey et al. 2024 "Novel Interpretable and Robust Web-based AI Platform '
                'for Phishing Email Detection" (CC BY-SA 4.0)')

# ---------------------------------------------------------------- train
def train(name, df, dataset_desc):
    X_tr, X_te, y_tr, y_te = train_test_split(df['text'], df['y'], test_size=0.2,
                                              stratify=df['y'], random_state=SEED)
    vec = TfidfVectorizer(analyzer=tokenize, sublinear_tf=True, min_df=3,
                          max_features=5000, norm='l2', smooth_idf=True)
    Xtr = vec.fit_transform(X_tr)
    Xte = vec.transform(X_te)
    grid = GridSearchCV(LogisticRegression(max_iter=4000, class_weight='balanced', solver='liblinear'),
                        {'C': [0.5, 1, 2, 4, 8, 16]}, scoring='f1',
                        cv=StratifiedKFold(5, shuffle=True, random_state=SEED))
    grid.fit(Xtr, y_tr)
    clf = grid.best_estimator_
    p = clf.predict_proba(Xte)[:, 1]
    pred = (p >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, pred).ravel()
    m = {
        'model': name, 'dataset': dataset_desc,
        'n_total': int(len(df)), 'n_train': int(len(X_tr)), 'n_test': int(len(X_te)),
        'positive_rate': round(float(df['y'].mean()), 4),
        'best_C': grid.best_params_['C'], 'cv_f1_mean': round(float(grid.best_score_), 4),
        'test': {
            'accuracy': round(accuracy_score(y_te, pred), 4),
            'precision': round(precision_score(y_te, pred), 4),
            'recall': round(recall_score(y_te, pred), 4),
            'f1': round(f1_score(y_te, pred), 4),
            'roc_auc': round(roc_auc_score(y_te, p), 4),
            'confusion': {'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)},
        },
        'n_features': int(len(vec.vocabulary_)),
    }
    if 'source' in df.columns:   # per-source breakdown on the held-out split
        src = df.loc[X_te.index, 'source']
        m['test_by_source'] = {}
        for s in sorted(src.unique()):
            mask = (src == s).values
            m['test_by_source'][s] = {
                'n': int(mask.sum()),
                'accuracy': round(accuracy_score(y_te[mask], pred[mask]), 4),
            }

    terms = vec.get_feature_names_out()
    coef = clf.coef_[0]
    vocab = [[str(t), round(float(vec.idf_[vec.vocabulary_[t]]), 6), round(float(coef[vec.vocabulary_[t]]), 6)]
             for t in terms]
    order = np.argsort(coef)
    model = {
        'name': name, 'version': 1, 'tokenizer': TOKENIZER_VERSION,
        'trainedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'),
        'dataset': dataset_desc,
        'config': {'ngram': [1, 2], 'sublinear_tf': True, 'norm': 'l2', 'min_df': 3,
                   'max_features': 5000, 'C': grid.best_params_['C'], 'class_weight': 'balanced'},
        'intercept': round(float(clf.intercept_[0]), 6),
        'metrics': m['test'],
        'vocab': vocab,
    }
    m['top_positive_terms'] = [str(terms[i]) for i in order[::-1][:25]]
    m['top_negative_terms'] = [str(terms[i]) for i in order[:25]]

    # parity vectors: raw texts + the probability sklearn computes. The JS
    # scorer must reproduce these (test/ml.test.js), which proves lib/ml.js
    # is the same model, not an approximation of it.
    rng = np.random.RandomState(SEED)
    idx = rng.choice(len(X_te), size=min(40, len(X_te)), replace=False)
    samples = [str(X_te.iloc[i])[:3000] for i in idx]
    # the rounded exported weights are what JS uses, so recompute from them
    probs = clf.predict_proba(vec.transform(samples))[:, 1]
    parity = [{'text': s, 'p': round(float(pp), 6)} for s, pp in zip(samples, probs)]
    return model, m, parity

def main():
    os.makedirs(os.path.join(ROOT, 'models'), exist_ok=True)
    os.makedirs(os.path.join(ROOT, 'test', 'fixtures'), exist_ok=True)
    all_metrics, all_parity = {}, {}
    for name, loader in (('email', load_email), ('sms', load_sms)):
        df, desc = loader()
        model, m, parity = train(name, df, desc)
        path = os.path.join(ROOT, 'models', f'{name}-model.json')
        with open(path, 'w') as f:
            json.dump(model, f, separators=(',', ':'), ensure_ascii=False)
        all_metrics[name] = m
        all_parity[name] = parity
        t = m['test']
        print(f"[{name}] n={m['n_total']} C={m['best_C']} acc={t['accuracy']} prec={t['precision']} "
              f"rec={t['recall']} f1={t['f1']} auc={t['roc_auc']} → {os.path.relpath(path, ROOT)} "
              f"({os.path.getsize(path)//1024} KB)")
    with open(os.path.join(ROOT, 'ml', 'metrics.json'), 'w') as f:
        json.dump(all_metrics, f, indent=2)
    with open(os.path.join(ROOT, 'test', 'fixtures', 'ml-parity.json'), 'w') as f:
        json.dump(all_parity, f, ensure_ascii=False)

if __name__ == '__main__':
    main()
