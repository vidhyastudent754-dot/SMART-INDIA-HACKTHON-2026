#!/usr/bin/env bash
# Downloads the public training corpora into ml/data/ (git-ignored, ~70 MB).
# Only needed to re-train; the trained weights are committed in models/.
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p data
curl -fsSL -o data/sms_spam_collection.tsv \
  https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv
BASE=https://raw.githubusercontent.com/rokibulroni/Phishing-Email-Dataset/main
for f in Nazario.csv SpamAssasin.csv Enron.csv; do
  echo "fetching $f"; curl -fsSL -o "data/$f" "$BASE/$f"
done
ls -lh data
