# World Monitor — Security Assessment Console (SIH26163 / NTRO)

World Monitor (codename SENTINEL-X) includes three white-hat **security-assessment
sections**. Every check sends a **real HTTP request** to the World Monitor backend
(`/api/assess`), which runs a vulnerable and a fixed implementation of the same
code path and computes the verdict from the real outcome. State lives in SQLite and
survives restarts. **EMP-04 (IDOR) and EMP-09 (mass assignment) run against the
app's own production routes** with a real employee session. Dangerous classes (SQLi,
path traversal, SSRF, open redirect, XSS) stay sandboxed on synthetic data — **no
network egress** to third parties and no real accounts are touched. Each check shows
the weakness on the *vulnerable build*, then the **same attack blocked after the
fix**, with evidence, CVSS, full classification, and a downloadable report.
See [ASSESSMENT-REALTIME.md](ASSESSMENT-REALTIME.md) for the wiring.

## Run it

```bash
npm install
npm run db:init    # creates data/worldmonitor.db and prints the admin/viewer passwords
npm start          # serves http://localhost:5175 — sign in as admin
```

Employee & Manager and Company & Organization checks require the **admin** role;
a **viewer** can run the Individual checks only (the server returns 403 otherwise).

Open the app and use the top tab bar:

| Tab | Section | Checks |
|-----|---------|--------|
| 01 — Individual Security Assessment | single user account / browser / user data | 5 |
| 02 — Employee & Manager Security Assessment | authz, authn, session, business logic | 5 |
| 03 — Company & Organization Security Assessment | data layer, file handling, throttling, data protection, dependencies | 5 |
| 04 — Cyber Awareness | (unchanged, existing content) | — |

- **Section 1** lives inside the existing Phishing/Forensics console → left nav
  **"Vulnerability Assessment"**. All original Section-1 features are kept.
- **Section 2** replaces the old A1–A10 "Advanced" engine entirely.
- **Section 3** is new. The former *Cyber Awareness* tab was **not deleted** — it
  moved to position **04**.

## How to demo each check

1. Expand a check card.
2. Press **▶ Run test (vulnerable build)** — the console types out the attack step
   by step and shows the request/response evidence + a red **VULNERABLE** verdict
   (status → **Confirmed**).
3. Press **🛡 Apply fix & re-test** — the same attack is now blocked, green
   **SECURE** verdict (status → **Not Found**). The exact remediation code is under
   *"Remediation & secure code"*.
4. **Run all tests** / **Apply all fixes** drive the whole section at once.
5. **⭳ Report (.md)** and **⭳ Evidence (.json)** export a findings report in the
   required field format (ID, category, CVSS, PoC, technical + business impact,
   remediation, retest).

## Files added

```
public/assessments/engine.js            shared engine (UI, classification, report, downloads)
public/assessments/live-io.js           LIVE I/O layer — typed-payload block for every check (merged by id)
public/assessments/individual.js        Section 1 — 5 attacks + SMS fraud card
public/assessments/employee-manager.js  Section 2 — 5 attacks + role hierarchy
public/assessments/company-org.js       Section 3 — 5 attacks + org-asset map
public/assessments/assessments.css      styling
```

Nothing else in the original project was removed except the A1–A10 engine, as
requested. The existing automated black-box scanner (`scanner/security-scan.js`)
and its endpoints are untouched.

## Safety scope

Authorized test identities (`Test User A/B`, `Test Employee/Manager/Administrator`)
and synthetic data only. Dangerous classes (SQLi, SSRF, path traversal, file
upload) are **detection-only** and never touch real infrastructure, exactly per the
SIH26163 / NTRO constraints already stated in the app's report.

## Live input/output (this build)

Each attack runs **on demand against the running server**: pressing run (or typing,
with *Run as I type* on) sends a real HTTP request and shows the real response.
**All 15 attacks** accept a **typed payload** so a judge can drive every attack with
their own input. (This is about the attack console; external threat data is
periodically refreshed — see README → Data freshness.)

**Persistent server-side state.** Sessions, reset tokens, the employee directory,
records, stored comments and rate-limit buckets live in the server's SQLite store
(`db/schema.sql`). Stop and restart the server mid-assessment and a used reset
token is still used, a revoked session is still revoked, and a rate-limit window
keeps counting. `npm run db:reset` returns the demo data to its seed state.

**Streamed output.** Every run (single card, live payload, and *Run all*) prints
the real request and response to the console line by line (about 18 ms apart) with
per-line `[HH:MM:SS.mmm]` timestamps. The lines are the actual HTTP exchange; the
short gap only keeps their order readable.

**Typed input (LIVE I/O cards).** Every card shows a payload box (a single field
or a small set of fields, with preset chips). Type an input, then press **▶ Send
to vulnerable build** or **🛡 Send same input to fixed build** — the backend
computes the response from *your exact input* both ways. Every card also
runs unattended on sensible defaults, so **Run all** / **Apply all fixes** complete
with no typing. Examples of the live input per section:

| Check | Live input → observable difference |
|-------|-----------------------------------|
| IND-03 | `sid` → replay after logout: still valid (vuln) vs 401 revoked (fixed) |
| IND-04 | reset `token` + `elapsedMinutes` + reuse → accepted always vs TTL/single-use |
| IND-06 | comment body → stored XSS executes vs sanitised + escaped |
| IND-10 | account → full internal record vs allow-listed projection |
| EMP-04 | `recordId` → IDOR reads any owner vs 403 ownership check |
| EMP-09 | JSON body incl. `role` → mass-assign to admin vs allow-list |
| ORG-09 | path (`../../etc/passwd`) → escapes BASE vs normalised + blocked |
| ORG-10 | URL (`169.254.169.254`) → internal reach (simulated) vs blocked |
| ORG-11 | package name → real CVE + CVSS lookup vs patched (cve: null) |
| ORG-15 | `requestCount` / `windowSeconds` → unlimited vs 429 after 5 |

**Report / export upgrade.** Both the `.md` report and the `.json` evidence now
capture, per finding: the **exact input tested**, separate **vulnerable** and
**fixed** evidence (request / response / streamed log), **verdict before / after**,
CVSS `{vector, score, severity}`, **references** (OWASP + CWE), a structured
**remediation** `{summary, code}`, and a **retest** line confirming the fixed
build's behaviour on the same input.

Only `public/assessments/*` and the one `<script>` tag for `live-io.js` in
`public/index.html` were touched; the three section files, the server, and the
scanner remain as-is.
