/* =============================================================================
 * db/world-seed.js - seed the World Monitor reference data + migrate the REAL,
 * already-sourced figures from db/observatory.json into the provenance tables.
 *
 * NOTHING here is a fabricated statistic. Sources carry their real official
 * URLs; countries/states are ISO reference data; every migrated metric keeps
 * its source URL, publication note and retrieval date. Missing data is simply
 * not inserted (never a fabricated zero).
 *
 *   node db/world-seed.js            # apply (idempotent)
 * ===========================================================================*/
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { openDb } = require('../lib/db');

/* ---- 10 international + 10 India sources (real official URLs) ------------- */
const SOURCES = [
  // Tier A - international official / law enforcement
  { id: 'cisa', name: 'CISA', tier: 'A', scope: 'global', url: 'https://www.cisa.gov', feed_type: 'periodic', covers: 'advisories, KEV catalog, alerts' },
  { id: 'nvd', name: 'NIST / NVD', tier: 'A', scope: 'global', url: 'https://nvd.nist.gov', feed_type: 'near_live', covers: 'CVE vulnerability database' },
  { id: 'mitre_attack', name: 'MITRE ATT&CK', tier: 'A', scope: 'global', url: 'https://attack.mitre.org', feed_type: 'periodic', covers: 'adversary techniques' },
  { id: 'enisa', name: 'ENISA', tier: 'A', scope: 'global', url: 'https://www.enisa.europa.eu', feed_type: 'periodic', covers: 'EU threat landscape' },
  { id: 'interpol', name: 'INTERPOL Cybercrime', tier: 'A', scope: 'global', url: 'https://www.interpol.int/Crimes/Cybercrime', feed_type: 'periodic', covers: 'international operations' },
  { id: 'europol', name: 'Europol / EC3', tier: 'A', scope: 'global', url: 'https://www.europol.europa.eu', feed_type: 'periodic', covers: 'IOCTA, operations' },
  { id: 'fbi_ic3', name: 'FBI IC3', tier: 'A', scope: 'US', url: 'https://www.ic3.gov', feed_type: 'periodic', covers: 'US complaints & losses (annual)' },
  // Tier B - authoritative security intelligence
  { id: 'verizon_dbir', name: 'Verizon DBIR', tier: 'B', scope: 'global', url: 'https://www.verizon.com/business/resources/reports/dbir', feed_type: 'periodic', covers: 'breach investigations (annual)' },
  { id: 'ms_mddr', name: 'Microsoft Threat Intelligence / MDDR', tier: 'B', scope: 'global', url: 'https://www.microsoft.com/en-us/security/business/security-intelligence-report', feed_type: 'periodic', covers: 'threat intelligence' },
  { id: 'cisco_talos', name: 'Cisco Talos', tier: 'B', scope: 'global', url: 'https://talosintelligence.com', feed_type: 'near_live', covers: 'threat research & reputation' },
  { id: 'ibm_xforce', name: 'IBM X-Force', tier: 'B', scope: 'global', url: 'https://www.ibm.com/reports/threat-intelligence', feed_type: 'periodic', covers: 'threat intelligence index' },
  { id: 'cloudflare_radar', name: 'Cloudflare Radar', tier: 'B', scope: 'global', url: 'https://radar.cloudflare.com', feed_type: 'near_live', covers: 'internet & attack trends' },

  // Tier A - India national
  { id: 'cert_in', name: 'CERT-In', tier: 'A', scope: 'IN', url: 'https://www.cert-in.org.in', feed_type: 'periodic', covers: 'incidents, advisories, vulnerability notes' },
  { id: 'i4c', name: 'Indian Cyber Crime Coordination Centre (I4C)', tier: 'A', scope: 'IN', url: 'https://i4c.mha.gov.in', feed_type: 'periodic', covers: 'NCRP, CFCFRMS, suspect registry' },
  { id: 'ncrb', name: 'National Crime Records Bureau', tier: 'A', scope: 'IN', url: 'https://ncrb.gov.in', feed_type: 'periodic', covers: 'Crime in India (annual)' },
  { id: 'mha', name: 'Ministry of Home Affairs', tier: 'A', scope: 'IN', url: 'https://www.mha.gov.in', feed_type: 'periodic', covers: 'Parliament replies, NCRP/CFCFRMS' },
  { id: 'meity', name: 'MeitY', tier: 'A', scope: 'IN', url: 'https://www.meity.gov.in', feed_type: 'periodic', covers: 'IT policy, advisories' },
  { id: 'rbi', name: 'Reserve Bank of India', tier: 'A', scope: 'IN', url: 'https://www.rbi.org.in', feed_type: 'periodic', covers: 'banking fraud statistics' },
  { id: 'nciipc', name: 'NCIIPC', tier: 'A', scope: 'IN', url: 'https://www.nciipc.gov.in', feed_type: 'periodic', covers: 'critical information infrastructure' },
  { id: 'csk', name: 'Cyber Swachhta Kendra', tier: 'A', scope: 'IN', url: 'https://www.csk.gov.in', feed_type: 'periodic', covers: 'botnet cleaning, advisories' },
  { id: 'npci', name: 'NPCI', tier: 'A', scope: 'IN', url: 'https://www.npci.org.in', feed_type: 'periodic', covers: 'UPI/retail payments statistics' },
  { id: 'data_gov_in', name: 'Government of India Open Data (data.gov.in)', tier: 'A', scope: 'IN', url: 'https://www.data.gov.in', feed_type: 'periodic', covers: 'open datasets' },
  { id: 'pib', name: 'Press Information Bureau', tier: 'A', scope: 'IN', url: 'https://www.pib.gov.in', feed_type: 'periodic', covers: 'official press releases' },
];

/* ---- countries (ISO alpha-2) - reference data; presets from the spec ------ */
const PRESET = 'IN US CN RU IR IQ PK AF JP KR SG AU NZ GB PT ES FR DE IT NL SE NO FI PL UA IL SA AE TR BR AR ZA NG EG'.split(' ');
const EXTRA = { CA: 'Canada', MX: 'Mexico', ID: 'Indonesia', MY: 'Malaysia', TH: 'Thailand', VN: 'Vietnam', PH: 'Philippines', BD: 'Bangladesh', LK: 'Sri Lanka', NP: 'Nepal', KE: 'Kenya', GH: 'Ghana', CH: 'Switzerland', BE: 'Belgium', AT: 'Austria', IE: 'Ireland', DK: 'Denmark', CZ: 'Czechia', RO: 'Romania', GR: 'Greece', QA: 'Qatar', KW: 'Kuwait' };
const NAMES = { IN: 'India', US: 'United States', CN: 'China', RU: 'Russia', IR: 'Iran', IQ: 'Iraq', PK: 'Pakistan', AF: 'Afghanistan', JP: 'Japan', KR: 'South Korea', SG: 'Singapore', AU: 'Australia', NZ: 'New Zealand', GB: 'United Kingdom', PT: 'Portugal', ES: 'Spain', FR: 'France', DE: 'Germany', IT: 'Italy', NL: 'Netherlands', SE: 'Sweden', NO: 'Norway', FI: 'Finland', PL: 'Poland', UA: 'Ukraine', IL: 'Israel', SA: 'Saudi Arabia', AE: 'United Arab Emirates', TR: 'Turkey', BR: 'Brazil', AR: 'Argentina', ZA: 'South Africa', NG: 'Nigeria', EG: 'Egypt' };
const REGION = { IN: 'Asia', PK: 'Asia', CN: 'Asia', JP: 'Asia', KR: 'Asia', SG: 'Asia', BD: 'Asia', LK: 'Asia', NP: 'Asia', ID: 'Asia', MY: 'Asia', TH: 'Asia', VN: 'Asia', PH: 'Asia', AF: 'Asia', IR: 'Middle East', IQ: 'Middle East', IL: 'Middle East', SA: 'Middle East', AE: 'Middle East', TR: 'Middle East', QA: 'Middle East', KW: 'Middle East', US: 'Americas', CA: 'Americas', MX: 'Americas', BR: 'Americas', AR: 'Americas', GB: 'Europe', PT: 'Europe', ES: 'Europe', FR: 'Europe', DE: 'Europe', IT: 'Europe', NL: 'Europe', SE: 'Europe', NO: 'Europe', FI: 'Europe', PL: 'Europe', UA: 'Europe', RU: 'Europe', CH: 'Europe', BE: 'Europe', AT: 'Europe', IE: 'Europe', DK: 'Europe', CZ: 'Europe', RO: 'Europe', GR: 'Europe', ZA: 'Africa', NG: 'Africa', EG: 'Africa', KE: 'Africa', GH: 'Africa', AU: 'Oceania', NZ: 'Oceania' };

/* ---- India states/UTs (ISO 3166-2:IN) ------------------------------------ */
const STATES = [
  ['IN-AP', 'Andhra Pradesh', 'state'], ['IN-AR', 'Arunachal Pradesh', 'state'], ['IN-AS', 'Assam', 'state'],
  ['IN-BR', 'Bihar', 'state'], ['IN-CT', 'Chhattisgarh', 'state'], ['IN-GA', 'Goa', 'state'],
  ['IN-GJ', 'Gujarat', 'state'], ['IN-HR', 'Haryana', 'state'], ['IN-HP', 'Himachal Pradesh', 'state'],
  ['IN-JH', 'Jharkhand', 'state'], ['IN-KA', 'Karnataka', 'state'], ['IN-KL', 'Kerala', 'state'],
  ['IN-MP', 'Madhya Pradesh', 'state'], ['IN-MH', 'Maharashtra', 'state'], ['IN-MN', 'Manipur', 'state'],
  ['IN-ML', 'Meghalaya', 'state'], ['IN-MZ', 'Mizoram', 'state'], ['IN-NL', 'Nagaland', 'state'],
  ['IN-OR', 'Odisha', 'state'], ['IN-PB', 'Punjab', 'state'], ['IN-RJ', 'Rajasthan', 'state'],
  ['IN-SK', 'Sikkim', 'state'], ['IN-TN', 'Tamil Nadu', 'state'], ['IN-TG', 'Telangana', 'state'],
  ['IN-TR', 'Tripura', 'state'], ['IN-UP', 'Uttar Pradesh', 'state'], ['IN-UT', 'Uttarakhand', 'state'],
  ['IN-WB', 'West Bengal', 'state'],
  ['IN-AN', 'Andaman and Nicobar Islands', 'ut'], ['IN-CH', 'Chandigarh', 'ut'],
  ['IN-DH', 'Dadra and Nagar Haveli and Daman and Diu', 'ut'], ['IN-DL', 'Delhi', 'ut'],
  ['IN-JK', 'Jammu and Kashmir', 'ut'], ['IN-LA', 'Ladakh', 'ut'],
  ['IN-LD', 'Lakshadweep', 'ut'], ['IN-PY', 'Puducherry', 'ut'],
];

/* ---- attack taxonomy: the 15 approved + extensible future families -------- */
const REGISTRY = require('../public/assessments/registry.js');
const FUTURE_FAMILIES = [
  'ransomware', 'phishing', 'bec', 'credential_stuffing', 'password_spraying', 'brute_force', 'ddos',
  'botnet', 'malware', 'infostealer', 'spyware', 'zero_day', 'known_exploited_vuln', 'supply_chain',
  'cloud_attack', 'api_abuse', 'identity_attack', 'oauth_abuse', 'container_k8s', 'cicd_attack',
  'dependency_attack', 'dns_bgp', 'iot', 'mobile', 'ot_ics_scada', 'critical_infra', 'data_exfiltration',
  'data_extortion', 'insider_threat', 'sim_swap', 'qr_phishing', 'deepfake_fraud', 'ai_social_engineering',
  'adversarial_ai', 'cryptojacking',
];

/* ---- real research datasets used by the ML models (honest, sourced) ------- */
const RESEARCH = [
  { id: 'uci_sms_spam', title: 'SMS Spam Collection', authors: 'Almeida, Hidalgo et al.', publisher: 'UCI ML Repository', year: 2012, repository: 'uci', license: 'CC BY 4.0', url: 'https://archive.ics.uci.edu/dataset/228/sms+spam+collection', methodology: 'Labelled ham/spam SMS corpus', sample_size: 5574, country_scope: 'global', attack_type: 'smishing', limitations: 'English SMS; not India-specific; dated', quality_notes: 'Widely used research benchmark' },
];

/* ---- real official public social handles (registered, not scraped) -------- */
const SOCIAL = [
  { id: 'x_indiancert', platform: 'x', handle: '@IndianCERT', authorized: 1, url: 'https://twitter.com/IndianCERT', notes: 'Official CERT-In account (public)' },
  { id: 'x_cyberdost', platform: 'x', handle: '@Cyberdost', authorized: 1, url: 'https://twitter.com/Cyberdost', notes: 'MHA cyber-safety awareness account (public)' },
  { id: 'x_cisagov', platform: 'x', handle: '@CISAgov', authorized: 1, url: 'https://twitter.com/CISAgov', notes: 'Official CISA account (public)' },
];

const now = () => Date.now();
const mid = (s) => s.replace(/[^A-Za-z0-9]+/g, '.').replace(/\.+/g, '.').replace(/^\.|\.$/g, '');

function seedWorld(db) {
  const tx = db.transaction(() => {
    /* sources */
    const upSrc = db.prepare(`INSERT INTO wm_sources (id,name,tier,scope,url,feed_type,covers,status)
      VALUES (@id,@name,@tier,@scope,@url,@feed_type,@covers,'NOT_SUPPORTED')
      ON CONFLICT(id) DO UPDATE SET name=@name,tier=@tier,scope=@scope,url=@url,feed_type=@feed_type,covers=@covers`);
    for (const s of SOURCES) upSrc.run(Object.assign({ covers: null }, s));

    /* countries */
    const upC = db.prepare(`INSERT INTO wm_countries (code,name,region,is_preset) VALUES (?,?,?,?)
      ON CONFLICT(code) DO UPDATE SET name=excluded.name,region=excluded.region,is_preset=excluded.is_preset`);
    const allC = {};
    PRESET.forEach((c) => { allC[c] = { name: NAMES[c] || c, preset: 1 }; });
    Object.entries(EXTRA).forEach(([c, n]) => { allC[c] = { name: n, preset: 0 }; });
    for (const [code, v] of Object.entries(allC)) upC.run(code, v.name, REGION[code] || null, v.preset);

    /* india states */
    const upS = db.prepare(`INSERT INTO wm_india_states (code,name,kind) VALUES (?,?,?)
      ON CONFLICT(code) DO UPDATE SET name=excluded.name,kind=excluded.kind`);
    for (const [code, name, kind] of STATES) upS.run(code, name, kind);

    /* taxonomy */
    const upT = db.prepare(`INSERT INTO wm_attack_taxonomy (id,kind,section,title,cwe,approved,future,notes)
      VALUES (@id,@kind,@section,@title,@cwe,@approved,@future,@notes)
      ON CONFLICT(id) DO UPDATE SET kind=@kind,section=@section,title=@title,cwe=@cwe,approved=@approved,future=@future,notes=@notes`);
    for (const a of REGISTRY.ATTACKS) upT.run({ id: a.id, kind: 'sentinelx', section: a.section, title: a.title, cwe: a.cwe || null, approved: 1, future: 0, notes: null });
    for (const f of FUTURE_FAMILIES) upT.run({ id: 'fam:' + f, kind: 'family', section: null, title: f.replace(/_/g, ' '), cwe: null, approved: 0, future: 1, notes: 'future taxonomy family (extensible)' });

    /* research datasets */
    const upR = db.prepare(`INSERT INTO wm_research_datasets (id,title,authors,publisher,year,version,repository,license,url,methodology,sample_size,country_scope,time_period,attack_type,limitations,quality_notes)
      VALUES (@id,@title,@authors,@publisher,@year,@version,@repository,@license,@url,@methodology,@sample_size,@country_scope,@time_period,@attack_type,@limitations,@quality_notes)
      ON CONFLICT(id) DO UPDATE SET title=@title,url=@url,limitations=@limitations`);
    for (const r of RESEARCH) upR.run(Object.assign({ version: null, time_period: null }, r));

    /* social sources (registered public official handles) */
    const upSoc = db.prepare(`INSERT INTO wm_social_sources (id,platform,handle,authorized,url,notes)
      VALUES (@id,@platform,@handle,@authorized,@url,@notes)
      ON CONFLICT(id) DO UPDATE SET handle=@handle,url=@url,notes=@notes`);
    for (const s of SOCIAL) upSoc.run(s);

    /* -------- migrate REAL sourced metrics from observatory.json ---------- */
    const obs = JSON.parse(fs.readFileSync(path.join(__dirname, 'observatory.json'), 'utf8'));
    const upM = db.prepare(`INSERT INTO wm_metrics (metric_id,name,value,original_value,unit,period,country,state_code,attack_category,evidence_type,confidence,updated_at)
      VALUES (@metric_id,@name,@value,@original_value,@unit,@period,@country,@state_code,@attack_category,@evidence_type,@confidence,@updated_at)
      ON CONFLICT(metric_id) DO UPDATE SET value=@value,original_value=@original_value,unit=@unit,period=@period,evidence_type=@evidence_type,updated_at=@updated_at`);
    const upP = db.prepare(`INSERT INTO wm_metric_provenance (metric_id,source_id,source_url,source_pub_date,retrieved_at,calculation,transformation,inputs,notes)
      VALUES (@metric_id,@source_id,@source_url,@source_pub_date,@retrieved_at,@calculation,@transformation,@inputs,@notes)
      ON CONFLICT(metric_id) DO UPDATE SET source_url=@source_url,notes=@notes`);

    const SRC_BY_HINT = [
      [/ncrb/i, 'ncrb'], [/i4c|ncrp|cfcfrms|mha|lok sabha|rajya sabha/i, 'mha'], [/cert-?in/i, 'cert_in'],
      [/ic3|fbi/i, 'fbi_ic3'], [/dbir|verizon/i, 'verizon_dbir'], [/interpol/i, 'interpol'],
      [/europol/i, 'europol'], [/enisa/i, 'enisa'], [/rbi|reserve bank/i, 'rbi'], [/npci/i, 'npci'],
    ];
    const guessSource = (s) => { for (const [re, id] of SRC_BY_HINT) if (re.test(String(s || ''))) return id; return null; };
    let migrated = 0;
    function isLeaf(o) { return o && typeof o === 'object' && !Array.isArray(o) && ('value' in o) && ('sourceUrl' in o || 'source' in o); }
    function walk(node, prefix, country) {
      if (Array.isArray(node)) {
        node.forEach((v, i) => walk(v, prefix + '.' + (v && (v.year || v.asOf) ? (v.year || v.asOf) : i), country));
        return;
      }
      if (isLeaf(node)) {
        const metric_id = mid(prefix);
        const num = typeof node.value === 'number' ? node.value : (parseFloat(String(node.value).replace(/[^0-9.\-]/g, '')) || null);
        upM.run({ metric_id, name: prefix, value: num, original_value: String(node.value), unit: node.unit || null,
          period: String(node.year || node.asOf || ''), country: country || null, state_code: null, attack_category: null,
          evidence_type: 'VERIFIED_PRIMARY', confidence: 'high', updated_at: now() });
        upP.run({ metric_id, source_id: guessSource(node.source), source_url: node.sourceUrl || null,
          source_pub_date: node.year ? String(node.year) : (node.asOf || null), retrieved_at: node.retrievedAt ? Date.parse(node.retrievedAt) || null : null,
          calculation: null, transformation: null, inputs: null, notes: node.source || node.notes || null });
        migrated++;
        return;
      }
      if (node && typeof node === 'object') for (const [k, v] of Object.entries(node)) walk(v, prefix + '.' + k, country);
    }
    if (obs.india) walk(obs.india, 'IN', 'IN');
    if (obs.global) walk(obs.global, 'GLOBAL', null);
    if (obs.enforcement) walk(obs.enforcement, 'ENF', null);

    /* -------- ingest the curated REAL dataset (db/world-data.json) --------- */
    let curated = 0;
    try {
      const wd = JSON.parse(fs.readFileSync(path.join(__dirname, 'world-data.json'), 'utf8'));
      const rAt = wd.retrievedAt ? (Date.parse(wd.retrievedAt) || now()) : now();
      const putMetric = (metric_id, name, value, unit, opts) => {
        opts = opts || {};
        upM.run({ metric_id, name, value: (typeof value === 'number' ? value : null), original_value: String(value),
          unit: unit || null, period: opts.period || '', country: opts.country || null, state_code: opts.state || null,
          attack_category: opts.attack || null, evidence_type: opts.evidence || 'AUTHORITATIVE_INTELLIGENCE',
          confidence: opts.confidence || 'high', updated_at: now() });
        upP.run({ metric_id, source_id: opts.sourceId || null, source_url: opts.sourceUrl || null,
          source_pub_date: opts.period || null, retrieved_at: rAt, calculation: null,
          transformation: opts.crosswalk || null, inputs: null, notes: opts.note || null });
        curated++;
      };

      // per-attack real-world prevalence (OWASP/HackerOne), crosswalked
      for (const [id, p] of Object.entries(wd.attackPrevalence || {})) {
        const base = { attack: id, evidence: 'CROSSWALKED', sourceUrl: p.sourceUrl, crosswalk: p.crosswalk, note: p.owasp };
        if (typeof p.maxIncidencePct === 'number') putMetric('A.' + id + '.maxIncidencePct', id + ' max incidence rate (% of apps)', p.maxIncidencePct, '%', base);
        if (typeof p.avgIncidencePct === 'number') putMetric('A.' + id + '.avgIncidencePct', id + ' avg incidence rate (% of apps)', p.avgIncidencePct, '%', base);
        if (typeof p.occurrences === 'number') putMetric('A.' + id + '.occurrences', id + ' occurrences (OWASP dataset)', p.occurrences, 'occurrences', base);
        if (typeof p.cves === 'number') putMetric('A.' + id + '.cves', id + ' CVEs (OWASP dataset)', p.cves, 'CVEs', base);
        if (typeof p.hackerOneRank === 'number') putMetric('A.' + id + '.hackerOneRank', id + ' HackerOne Top-10 rank (' + (p.hackerOneType || '') + ')', p.hackerOneRank, 'rank', Object.assign({}, base, { sourceUrl: p.sourceUrl2 || p.sourceUrl }));
      }

      // per-country comparison metrics
      for (const c of wd.countries || []) {
        const cc = { country: c.code, sourceUrl: c.sourceUrl, note: c.note, evidence: 'AUTHORITATIVE_INTELLIGENCE' };
        if (typeof c.wciRank === 'number') putMetric('C.' + c.code + '.wciRank', c.name + ' - World Cybercrime Index 2024 rank', c.wciRank, 'rank', cc);
        if (typeof c.ic3Complaints2024 === 'number') putMetric('C.' + c.code + '.ic3Complaints', c.name + ' - IC3 2024 complaints', c.ic3Complaints2024, 'complaints', Object.assign({}, cc, { sourceUrl: c.ic3SourceUrl, evidence: 'VERIFIED_PRIMARY', period: '2024' }));
        if (typeof c.ic3LossesUsd2024 === 'number') putMetric('C.' + c.code + '.ic3LossesUsd', c.name + ' - IC3 2024 losses (USD)', c.ic3LossesUsd2024, 'USD', Object.assign({}, cc, { sourceUrl: c.ic3SourceUrl, evidence: 'VERIFIED_PRIMARY', period: '2024' }));
        if (typeof c.casesRegistered2022 === 'number') putMetric('C.' + c.code + '.casesRegistered', c.name + ' - cyber cases registered 2022', c.casesRegistered2022, 'cases', Object.assign({}, cc, { sourceUrl: c.ncrbSourceUrl || c.sourceUrl, evidence: 'VERIFIED_PRIMARY', period: '2022' }));
        if (typeof c.complaints2024 === 'number') putMetric('C.' + c.code + '.complaints', c.name + ' - cyber complaints 2024', c.complaints2024, 'complaints', Object.assign({}, cc, { evidence: 'VERIFIED_PRIMARY', period: '2024' }));
        if (typeof c.reportedLossCrore2024 === 'number') putMetric('C.' + c.code + '.reportedLossCrore', c.name + ' - reported loss 2024 (INR crore)', c.reportedLossCrore2024, 'INR crore', Object.assign({}, cc, { evidence: 'VERIFIED_PRIMARY', period: '2024' }));
        if (typeof c.convictionRatePct === 'number') putMetric('C.' + c.code + '.convictionRatePct', c.name + ' - cyber conviction rate', c.convictionRatePct, '%', cc);
      }

      // India per-state real cases
      for (const s of wd.indiaStates || []) {
        putMetric('S.' + s.code + '.cybercrimeCases.' + (s.period || ''), s.name + ' - cyber crime cases registered', s.value, 'cases',
          { country: 'IN', state: s.code, period: s.period, sourceUrl: s.sourceUrl, note: s.note, evidence: 'VERIFIED_PRIMARY' });
      }

      // India case lifecycle
      const upCase = db.prepare(`INSERT INTO wm_case_lifecycle (scope_kind,scope_id,stage,value,period,source_id,source_url,retrieved_at)
        VALUES ('country','IN',@stage,@value,@period,NULL,@source_url,@retrieved_at)`);
      for (const cl of wd.indiaCaseLifecycle || []) upCase.run({ stage: cl.stage, value: cl.value, period: cl.period, source_url: cl.sourceUrl, retrieved_at: rAt });

      // research datasets
      const upRes = db.prepare(`INSERT INTO wm_research_datasets (id,title,repository,url,attack_type,limitations)
        VALUES (@id,@title,@repository,@url,@attack_type,@limitations)
        ON CONFLICT(id) DO UPDATE SET title=@title,url=@url,limitations=@limitations`);
      for (const r of wd.research || []) upRes.run({ id: r.id, title: r.title, repository: r.repository, url: r.url, attack_type: r.attackType, limitations: r.limitations });

      // future-scope critical attacks → incidents (evidence-linked)
      const upInc = db.prepare(`INSERT INTO wm_incidents (id,title,reported_at,attack_id,crosswalk_note,evidence_type,confidence,summary)
        VALUES (@id,@title,@reported_at,@attack_id,@crosswalk_note,'VERIFIED_SECONDARY','medium',@summary)
        ON CONFLICT(id) DO UPDATE SET title=@title,summary=@summary`);
      const upIncSrc = db.prepare(`INSERT INTO wm_incident_sources (incident_id,source_id,source_url) VALUES (?,?,?)
        ON CONFLICT(incident_id,source_id) DO UPDATE SET source_url=excluded.source_url`);
      (wd.futureScope || []).forEach((f, i) => {
        const id = 'future-' + (f.family || 'x').replace('fam:', '') + '-' + i;
        upInc.run({ id, title: f.title, reported_at: rAt, attack_id: f.family, crosswalk_note: f.note, summary: f.note });
        upIncSrc.run(id, 'cisa', f.sourceUrl);
      });
    } catch (e) { /* curated dataset optional */ curated = -1; }

    /* audit */
    db.prepare('INSERT INTO wm_audit_log (ts,action,detail,actor) VALUES (?,?,?,?)')
      .run(now(), 'world-seed', JSON.stringify({ sources: SOURCES.length, countries: Object.keys(allC).length, states: STATES.length, metricsMigrated: migrated, curatedIngested: curated }), 'seed');
    return migrated;
  });
  const migrated = tx();
  return {
    sources: db.prepare('SELECT COUNT(*) n FROM wm_sources').get().n,
    countries: db.prepare('SELECT COUNT(*) n FROM wm_countries').get().n,
    states: db.prepare('SELECT COUNT(*) n FROM wm_india_states').get().n,
    taxonomy: db.prepare('SELECT COUNT(*) n FROM wm_attack_taxonomy').get().n,
    metrics: db.prepare('SELECT COUNT(*) n FROM wm_metrics').get().n,
    provenance: db.prepare('SELECT COUNT(*) n FROM wm_metric_provenance').get().n,
    migrated,
  };
}

module.exports = { seedWorld, SOURCES, STATES };

if (require.main === module) {
  const db = openDb();
  const r = seedWorld(db);
  console.log('World Monitor seed complete:', JSON.stringify(r));
  db.close();
}
