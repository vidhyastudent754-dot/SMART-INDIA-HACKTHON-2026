#!/usr/bin/env node
/**
 * db/seed.js - demo dataset for World Monitor.
 *
 *   npm run db:init                 create schema + seed (idempotent; never
 *                                   overwrites existing login passwords)
 *   npm run db:init -- --reset-passwords   # or just delete data/*.db and npm start   re-issue admin/viewer passwords
 *   npm run db:reset                clear assessment state (sessions, tokens,
 *                                   rate buckets, comments) and restore the
 *                                   employee directory to its seed values
 *
 * Login passwords come from ADMIN_PASSWORD / VIEWER_PASSWORD if set; otherwise
 * strong random ones are generated and printed ONCE. They are stored only as
 * scrypt hashes. All people/records here are synthetic (SIH/NTRO scope).
 */
'use strict';

const crypto = require('crypto');
const { hashPassword, randomPassword } = require('../lib/passwords');

const EMPLOYEES = [
  { id: 'EMP-A', owner: 'U-A', name: 'Test Employee A', email: 'emp.a@wm.local', role: 'employee', salary: 68000, review: 'meets expectations', internal_note: 'flight-risk: low' },
  { id: 'EMP-B', owner: 'U-B', name: 'Test Employee B', email: 'emp.b@wm.local', role: 'employee', salary: 72000, review: 'exceeds', internal_note: 'promotion candidate' },
  { id: 'MGR-1', owner: 'U-M', name: 'Test Manager', email: 'mgr@wm.local', role: 'manager', salary: 110000, review: 'n/a', internal_note: 'manages A,B' },
  { id: 'ADM-1', owner: 'U-Z', name: 'Test Administrator', email: 'admin@wm.local', role: 'admin', salary: 150000, review: 'n/a', internal_note: 'root' },
];

const RECORDS = [
  { id: '1001', owner: 'EMP-A', kind: 'expense', amount: 220, status: 'pending' },
  { id: '1002', owner: 'EMP-B', kind: 'expense', amount: 640, status: 'pending' },
  { id: '1003', owner: 'EMP-B', kind: 'medical', amount: 130, status: 'approved' },
];

// Employee self-service logins, one per directory entry. Their passwords are
// random and never shown: the assessment harness obtains sessions for them
// through the auth service, the same way a successful login would.
const EMPLOYEE_LOGINS = [
  { username: 'emp.a', employee_id: 'EMP-A', display_name: 'Test Employee A' },
  { username: 'emp.b', employee_id: 'EMP-B', display_name: 'Test Employee B' },
  { username: 'mgr.1', employee_id: 'MGR-1', display_name: 'Test Manager' },
  { username: 'adm.1', employee_id: 'ADM-1', display_name: 'Test Administrator' },
];

function restoreDirectory(db) {
  const now = Date.now();
  const upEmp = db.prepare(`INSERT INTO employees (id, owner, name, email, role, salary, review, internal_note, updated_at)
    VALUES (@id, @owner, @name, @email, @role, @salary, @review, @internal_note, @now)
    ON CONFLICT(id) DO UPDATE SET owner=excluded.owner, name=excluded.name, email=excluded.email,
      role=excluded.role, salary=excluded.salary, review=excluded.review,
      internal_note=excluded.internal_note, updated_at=excluded.updated_at`);
  const upRec = db.prepare(`INSERT INTO records (id, owner, kind, amount, status) VALUES (@id, @owner, @kind, @amount, @status)
    ON CONFLICT(id) DO UPDATE SET owner=excluded.owner, kind=excluded.kind, amount=excluded.amount, status=excluded.status`);
  for (const e of EMPLOYEES) upEmp.run({ ...e, now });
  // temp rows left behind by an interrupted EMP-07 run
  db.prepare("DELETE FROM employees WHERE id LIKE 'MGR-T-%'").run();
  for (const r of RECORDS) upRec.run(r);
}

/**
 * @returns {Array<{username, password, role}>} credentials that were newly
 *          generated (empty if everything already existed / came from env)
 */
function seed(db, opts = {}) {
  const env = opts.env || process.env;
  const generated = [];
  const tx = db.transaction(() => {
    restoreDirectory(db);

    const now = Date.now();
    const getUser = db.prepare('SELECT id FROM users WHERE username = ?');
    const insUser = db.prepare(`INSERT INTO users (id, username, display_name, role, password_hash, employee_id, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)`);
    const setPw = db.prepare('UPDATE users SET password_hash = ? WHERE username = ?');

    for (const [username, role, envKey, display] of [
      ['admin', 'admin', 'ADMIN_PASSWORD', 'Administrator'],
      ['viewer', 'viewer', 'VIEWER_PASSWORD', 'Read-only Viewer'],
    ]) {
      const exists = getUser.get(username);
      if (exists && !opts.resetPasswords) continue;
      const fromEnv = env[envKey] && String(env[envKey]);
      if (fromEnv && fromEnv.length < 6) {
        throw new Error(`${envKey} must be at least 6 characters`);
      }
      const pw = fromEnv || randomPassword();
      if (exists) setPw.run(hashPassword(pw), username);
      else insUser.run('usr-' + crypto.randomBytes(6).toString('hex'), username, display, role, hashPassword(pw), null, now);
      if (!fromEnv) generated.push({ username, password: pw, role });
    }

    for (const l of EMPLOYEE_LOGINS) {
      if (getUser.get(l.username)) continue;
      insUser.run('usr-' + crypto.randomBytes(6).toString('hex'), l.username, l.display_name, 'employee',
        hashPassword(crypto.randomBytes(24).toString('hex')), l.employee_id, now);
    }
  });
  tx();
  return generated;
}

/** Clear assessment state; keep logins, dashboard sessions and activity history. */
function resetAssessmentState(db) {
  db.transaction(() => {
    db.prepare("DELETE FROM sessions WHERE kind IN ('assess','app')").run();
    db.prepare('DELETE FROM reset_tokens').run();
    db.prepare('DELETE FROM rate_buckets').run();
    db.prepare('DELETE FROM assess_comments').run();
    restoreDirectory(db);
  })();
}

function printCredentials(creds, log = console.log) {
  if (!creds.length) return;
  log('\n  ┌─ Generated login credentials (shown once - store them now) ─────────');
  for (const c of creds) log(`  │  ${c.role.padEnd(6)}  username: ${c.username.padEnd(7)} password: ${c.password}`);
  log('  │  Set ADMIN_PASSWORD / VIEWER_PASSWORD to choose your own, or re-issue');
  log('  │  with: npm run db:init -- --reset-passwords   # or just delete data/*.db and npm start');
  log('  └──────────────────────────────────────────────────────────────────────\n');
}

module.exports = { seed, resetAssessmentState, restoreDirectory, printCredentials, EMPLOYEES, RECORDS };

if (require.main === module) {
  require('dotenv').config();
  const { openDb } = require('../lib/db');
  const db = openDb();
  // World Monitor reference data + provenance migration is idempotent, so seed
  // it on every init/reset (never fabricated - see db/world-seed.js).
  let world = null;
  try { world = require('./world-seed').seedWorld(db); } catch (e) { console.warn('[world-seed] skipped:', e.message); }
  if (process.argv.includes('--reset')) {
    resetAssessmentState(db);
    console.log(`Assessment state reset in ${db.file}`);
    if (world) console.log(`World Monitor: sources=${world.sources}, countries=${world.countries}, states=${world.states}, metrics=${world.metrics}`);
  } else {
    const creds = seed(db, { resetPasswords: process.argv.includes('--reset-passwords') });
    const counts = db.prepare(`SELECT (SELECT COUNT(*) FROM users) u, (SELECT COUNT(*) FROM employees) e,
      (SELECT COUNT(*) FROM records) r`).get();
    console.log(`Database ready: ${db.file}  (users=${counts.u}, employees=${counts.e}, records=${counts.r})`);
    if (world) console.log(`World Monitor: sources=${world.sources}, countries=${world.countries}, states=${world.states}, metrics=${world.metrics}, provenance=${world.provenance}`);
    printCredentials(creds);
  }
  db.close();
}
