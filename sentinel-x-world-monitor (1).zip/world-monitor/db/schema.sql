-- World Monitor — SQLite schema. Applied idempotently on every start (lib/db.js)
-- and by `npm run db:init`. One file on disk (DB_PATH, default data/worldmonitor.db).

PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_meta (
  key   TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

-- Organisation directory used by the Employee & Manager assessment (EMP-*)
-- and by the real employee self-service API (/api/records, /api/profile).
CREATE TABLE IF NOT EXISTS employees (
  id            TEXT PRIMARY KEY,
  owner         TEXT NOT NULL,
  name          TEXT NOT NULL,
  email         TEXT,
  role          TEXT NOT NULL CHECK (role IN ('employee','manager','admin')),
  salary        INTEGER,
  review        TEXT,
  internal_note TEXT,
  updated_at    INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS records (
  id     TEXT PRIMARY KEY,
  owner  TEXT NOT NULL REFERENCES employees(id),
  kind   TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT NOT NULL
);

-- Login accounts. admin/viewer log into the dashboard; 'employee' accounts
-- exist only for the employee self-service API and cannot use /api/auth/login.
CREATE TABLE IF NOT EXISTS users (
  id            TEXT PRIMARY KEY,
  username      TEXT NOT NULL UNIQUE,
  display_name  TEXT NOT NULL,
  role          TEXT NOT NULL CHECK (role IN ('admin','viewer','employee')),
  password_hash TEXT NOT NULL,
  employee_id   TEXT REFERENCES employees(id),
  disabled      INTEGER NOT NULL DEFAULT 0,
  created_at    INTEGER NOT NULL
);

-- kind='dashboard' : real login sessions (id = sha256 of the cookie token,
--                    so a DB leak does not leak usable cookies)
-- kind='app'       : short-lived employee API sessions minted by the
--                    assessment harness for EMP-04 / EMP-09
-- kind='assess'    : synthetic sessions used by IND-03 / EMP-07 demos
CREATE TABLE IF NOT EXISTS sessions (
  id         TEXT PRIMARY KEY,
  kind       TEXT NOT NULL CHECK (kind IN ('dashboard','app','assess')),
  user_id    TEXT NOT NULL,
  role       TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  last_seen  INTEGER NOT NULL,
  expires_at INTEGER NOT NULL,
  revoked    INTEGER NOT NULL DEFAULT 0,
  ip         TEXT,
  user_agent TEXT
);
CREATE INDEX IF NOT EXISTS idx_sessions_user ON sessions(user_id);

CREATE TABLE IF NOT EXISTS reset_tokens (
  token      TEXT PRIMARY KEY,
  email      TEXT NOT NULL,
  created_at INTEGER NOT NULL,
  used       INTEGER NOT NULL DEFAULT 0,
  used_at    INTEGER
);

CREATE TABLE IF NOT EXISTS rate_buckets (
  key          TEXT PRIMARY KEY,
  count        INTEGER NOT NULL,
  window_start INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS assess_comments (
  id         TEXT PRIMARY KEY,
  raw        TEXT NOT NULL,
  created_at INTEGER NOT NULL
);

-- Live activity: one row per real check run through this instance.
-- Deliberately stores NO message content or URL — only what kind of check
-- ran, the verdict, and where the verdict came from.
CREATE TABLE IF NOT EXISTS activity_events (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  ts      INTEGER NOT NULL,
  kind    TEXT NOT NULL,   -- url | email | sms | assessment
  verdict TEXT NOT NULL,
  source  TEXT,            -- api | heuristic_fallback | hybrid | vulnerable | fixed
  actor   TEXT             -- username (never content)
);
CREATE INDEX IF NOT EXISTS idx_activity_ts ON activity_events(ts);

CREATE TABLE IF NOT EXISTS login_attempts (
  id       INTEGER PRIMARY KEY AUTOINCREMENT,
  ts       INTEGER NOT NULL,
  username TEXT,
  ip       TEXT,
  success  INTEGER NOT NULL,
  reason   TEXT
);
CREATE INDEX IF NOT EXISTS idx_login_attempts ON login_attempts(username, ts);
CREATE INDEX IF NOT EXISTS idx_login_attempts_ip ON login_attempts(ip, ts);

-- =============================================================================
-- WORLD MONITOR — Global Cyber Intelligence data model (added on top of the
-- SENTINEL-X assessment tables above). Applied idempotently; existing data is
-- preserved. Every metric is provenance-backed; missing data is represented by
-- the ABSENCE of a row (never a fabricated zero). See WORLD-MONITOR-*.md.
-- =============================================================================

-- Source registry — official/intelligence/social/research feeds with real URLs.
CREATE TABLE IF NOT EXISTS wm_sources (
  id            TEXT PRIMARY KEY,
  name          TEXT NOT NULL,
  tier          TEXT NOT NULL CHECK (tier IN ('A','B','C','D')), -- A=official B=intel C=social D=research
  scope         TEXT NOT NULL DEFAULT 'global',                  -- 'IN' | 'global' | region
  url           TEXT NOT NULL,
  feed_type     TEXT NOT NULL DEFAULT 'periodic',                -- live | near_live | periodic | research | social
  covers        TEXT,
  license       TEXT,
  methodology   TEXT,
  status        TEXT NOT NULL DEFAULT 'NOT_SUPPORTED',           -- see freshness statuses
  last_fetch_at INTEGER,
  last_pub_at   INTEGER,
  enabled       INTEGER NOT NULL DEFAULT 1
);

-- One row per fetch/refresh attempt against a source (real HTTP or dry-run).
CREATE TABLE IF NOT EXISTS wm_source_runs (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id     TEXT NOT NULL REFERENCES wm_sources(id),
  started_at    INTEGER NOT NULL,
  finished_at   INTEGER,
  http_status   INTEGER,
  fetch_ms      INTEGER,
  parser_status TEXT,          -- OK | PARSE_ERROR | SKIPPED
  validation    TEXT,          -- OK | INVALID | PARTIAL
  record_count  INTEGER,
  status        TEXT NOT NULL, -- LIVE | RECENT | CACHED | STALE | UNAVAILABLE | PARSE_ERROR | AUTH_REQUIRED | RATE_LIMITED | NOT_SUPPORTED | NOT_PUBLISHED
  error         TEXT,
  dry           INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_wm_runs_src ON wm_source_runs(source_id, started_at);

-- Raw-response receipts (checksum + metadata) for auditability. No secrets.
CREATE TABLE IF NOT EXISTS wm_source_receipts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id       INTEGER NOT NULL REFERENCES wm_source_runs(id),
  source_id    TEXT NOT NULL REFERENCES wm_sources(id),
  fetched_at   INTEGER NOT NULL,
  content_type TEXT,
  byte_length  INTEGER,
  checksum     TEXT,          -- sha256 of the raw body
  url          TEXT
);

-- Countries (ISO-3166 alpha-2) — reference data, not statistics.
CREATE TABLE IF NOT EXISTS wm_countries (
  code    TEXT PRIMARY KEY,   -- ISO alpha-2
  name    TEXT NOT NULL,
  region  TEXT,
  is_preset INTEGER NOT NULL DEFAULT 0
);

-- India states/UTs — reference data.
CREATE TABLE IF NOT EXISTS wm_india_states (
  code       TEXT PRIMARY KEY, -- ISO 3166-2:IN style, e.g. IN-MH
  name       TEXT NOT NULL,
  kind       TEXT NOT NULL DEFAULT 'state', -- state | ut
  population INTEGER            -- documented census denominator, nullable
);

-- Attack taxonomy — the 15 approved SENTINEL-X attacks + extensible future
-- families. `approved`=1 marks the fixed 15; others are future categories.
CREATE TABLE IF NOT EXISTS wm_attack_taxonomy (
  id         TEXT PRIMARY KEY,   -- e.g. IND-06, or family key e.g. fam:ransomware
  kind       TEXT NOT NULL,      -- sentinelx | family
  section    INTEGER,            -- 1|2|3 for sentinelx attacks
  title      TEXT NOT NULL,
  cwe        TEXT,
  approved   INTEGER NOT NULL DEFAULT 0,
  future     INTEGER NOT NULL DEFAULT 0,
  notes      TEXT
);

-- Incidents — evidence-backed reported incidents (never fabricated). Empty is fine.
CREATE TABLE IF NOT EXISTS wm_incidents (
  id            TEXT PRIMARY KEY,
  title         TEXT NOT NULL,
  occurred_at   INTEGER,
  reported_at   INTEGER,
  attack_id     TEXT REFERENCES wm_attack_taxonomy(id),
  crosswalk_note TEXT,          -- rationale when crosswalked to a SENTINEL-X id
  evidence_type TEXT NOT NULL,  -- see data-quality states
  confidence    TEXT,
  summary       TEXT
);
CREATE TABLE IF NOT EXISTS wm_incident_sources (
  incident_id TEXT NOT NULL REFERENCES wm_incidents(id),
  source_id   TEXT NOT NULL REFERENCES wm_sources(id),
  source_url  TEXT NOT NULL,
  PRIMARY KEY (incident_id, source_id)
);
CREATE TABLE IF NOT EXISTS wm_incident_country (
  incident_id TEXT NOT NULL REFERENCES wm_incidents(id),
  country     TEXT NOT NULL REFERENCES wm_countries(code),
  PRIMARY KEY (incident_id, country)
);
CREATE TABLE IF NOT EXISTS wm_incident_state (
  incident_id TEXT NOT NULL REFERENCES wm_incidents(id),
  state_code  TEXT NOT NULL REFERENCES wm_india_states(code),
  PRIMARY KEY (incident_id, state_code)
);

-- Financial impact — separated measures (never inferred from each other).
CREATE TABLE IF NOT EXISTS wm_financial_impacts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  scope_kind   TEXT NOT NULL,   -- country | state | incident
  scope_id     TEXT NOT NULL,
  measure      TEXT NOT NULL,   -- reported_loss|amount_stolen|amount_blocked|amount_liened|amount_saved|amount_recovered|amount_refunded|estimated_loss
  value        REAL NOT NULL,
  currency     TEXT NOT NULL DEFAULT 'INR',
  unit         TEXT,            -- e.g. 'crore' preserved from source
  period       TEXT,
  source_id    TEXT REFERENCES wm_sources(id),
  source_url   TEXT,
  conversion_rate REAL,
  conversion_src  TEXT,
  retrieved_at INTEGER
);

-- Case lifecycle stages — each stage explicit; missing = NOT PUBLISHED (no row).
CREATE TABLE IF NOT EXISTS wm_case_lifecycle (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  scope_kind  TEXT NOT NULL,    -- country | state
  scope_id    TEXT NOT NULL,
  stage       TEXT NOT NULL,    -- complaint|reported|case_registered|fir|investigation|charge_sheeted|trial|convicted|resolved|closed|money_blocked|money_recovered|money_refunded|money_saved
  value       INTEGER NOT NULL,
  period      TEXT,
  source_id   TEXT REFERENCES wm_sources(id),
  source_url  TEXT,
  retrieved_at INTEGER
);

CREATE TABLE IF NOT EXISTS wm_threat_actors (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  attribution_source TEXT,
  confidence  TEXT,
  techniques  TEXT,
  observed_from TEXT,
  observed_to   TEXT,
  source_url  TEXT
);
CREATE TABLE IF NOT EXISTS wm_campaigns (
  id          TEXT PRIMARY KEY,
  name        TEXT NOT NULL,
  actor_id    TEXT REFERENCES wm_threat_actors(id),
  motivation  TEXT,            -- only when sourced
  source_url  TEXT
);
CREATE TABLE IF NOT EXISTS wm_vulnerabilities (
  id          TEXT PRIMARY KEY, -- CVE id
  cvss        REAL,
  published   TEXT,
  attack_id   TEXT REFERENCES wm_attack_taxonomy(id),
  source_url  TEXT
);
CREATE TABLE IF NOT EXISTS wm_incident_vulnerabilities (
  incident_id TEXT NOT NULL REFERENCES wm_incidents(id),
  cve_id      TEXT NOT NULL REFERENCES wm_vulnerabilities(id),
  PRIMARY KEY (incident_id, cve_id)
);

-- Research data lab — Kaggle/Scholar/academic. Kept SEPARATE from official.
CREATE TABLE IF NOT EXISTS wm_research_datasets (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  authors     TEXT,
  publisher   TEXT,
  year        INTEGER,
  version     TEXT,
  repository  TEXT,            -- kaggle | scholar | repo name
  license     TEXT,
  url         TEXT NOT NULL,
  methodology TEXT,
  sample_size INTEGER,
  country_scope TEXT,
  time_period TEXT,
  attack_type TEXT,
  limitations TEXT,
  quality_notes TEXT
);
CREATE TABLE IF NOT EXISTS wm_research_records (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  dataset_id  TEXT NOT NULL REFERENCES wm_research_datasets(id),
  metric      TEXT NOT NULL,
  value       REAL,
  unit        TEXT,
  notes       TEXT
);

-- Public social / awareness signals — separated; never confirmed incidents.
CREATE TABLE IF NOT EXISTS wm_social_sources (
  id          TEXT PRIMARY KEY,
  platform    TEXT NOT NULL,   -- x|youtube|facebook|instagram|snapchat|reddit|telegram|whatsapp_business
  handle      TEXT,
  authorized  INTEGER NOT NULL DEFAULT 0,
  url         TEXT,
  notes       TEXT
);
CREATE TABLE IF NOT EXISTS wm_social_posts (
  id          TEXT PRIMARY KEY,
  social_source_id TEXT REFERENCES wm_social_sources(id),
  posted_at   INTEGER,
  metric      TEXT,            -- mentions|views|likes|shares|comments|sentiment
  value       REAL,
  url         TEXT,
  notes       TEXT
);
CREATE TABLE IF NOT EXISTS wm_awareness_events (
  id          TEXT PRIMARY KEY,
  title       TEXT NOT NULL,
  kind        TEXT,            -- campaign|training|advisory|survey|research
  period      TEXT,
  source_id   TEXT REFERENCES wm_sources(id),
  source_url  TEXT,
  reach_note  TEXT
);

-- Generic provenance-backed metric store + field-level provenance.
CREATE TABLE IF NOT EXISTS wm_metrics (
  metric_id       TEXT PRIMARY KEY,
  name            TEXT NOT NULL,
  value           REAL,
  original_value  TEXT,        -- verbatim as published (e.g. "7.4 lakh crore")
  unit            TEXT,
  period          TEXT,
  country         TEXT,
  state_code      TEXT,
  attack_category TEXT,
  evidence_type   TEXT NOT NULL, -- VERIFIED_PRIMARY|VERIFIED_SECONDARY|AUTHORITATIVE_INTELLIGENCE|RESEARCH|DERIVED|CROSSWALKED|ESTIMATED|INCOMPLETE|UNAVAILABLE|ERROR
  confidence      TEXT,
  updated_at      INTEGER
);
CREATE TABLE IF NOT EXISTS wm_metric_provenance (
  metric_id        TEXT PRIMARY KEY REFERENCES wm_metrics(metric_id),
  source_id        TEXT REFERENCES wm_sources(id),
  source_url       TEXT NOT NULL,
  source_pub_date  TEXT,
  retrieved_at     INTEGER,
  dataset_version  TEXT,
  calculation      TEXT,        -- formula when derived
  transformation   TEXT,
  inputs           TEXT,        -- JSON of source input metric_ids
  notes            TEXT
);

CREATE TABLE IF NOT EXISTS wm_comparison_snapshots (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at  INTEGER NOT NULL,
  countries   TEXT NOT NULL,    -- JSON list of country codes
  metrics     TEXT NOT NULL,    -- JSON payload (raw measures, no 'winner')
  note        TEXT
);

-- Early-warning / anomaly signals (future scope; empty until real detections).
CREATE TABLE IF NOT EXISTS wm_alerts (
  id          TEXT PRIMARY KEY,
  created_at  INTEGER NOT NULL,
  kind        TEXT NOT NULL,    -- EARLY_SIGNAL | CONFIRMED
  subject     TEXT,
  baseline    REAL,
  observed    REAL,
  change_pct  REAL,
  source_id   TEXT REFERENCES wm_sources(id),
  confidence  TEXT,
  note        TEXT
);

CREATE TABLE IF NOT EXISTS wm_audit_log (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  ts          INTEGER NOT NULL,
  action      TEXT NOT NULL,
  detail      TEXT,
  actor       TEXT
);
CREATE INDEX IF NOT EXISTS idx_wm_audit_ts ON wm_audit_log(ts);
