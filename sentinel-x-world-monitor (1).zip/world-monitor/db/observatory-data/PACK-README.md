# Cybersecurity Evidence Dataset Pack

This pack is a **source-curated evidence layer**, not a single merged incident database. It preserves the units, denominators, dates, geography, qualifiers, and limitations reported by each primary source. It intentionally does not fabricate missing values or harmonize incompatible concepts.

## Contents

- `source_catalog.csv`: one row per successful source (11 sources), with provenance, access paths, supported mappings, and source-specific limitations.
- `verified_facts.csv`: one row per quantitative fact explicitly present in the supplied verified source results. Values are copied as stated; no estimates or cross-source arithmetic were added.
- `attack_taxonomy.csv`: requested attack categories with cautious CWE/CAPEC/source mappings, observable labels, and the evidence needed for ground truth.
- `data_dictionary.csv`: definitions for every field in the three CSV tables plus controlled labels used in this pack.
- `limitations_and_gaps.md`: detailed non-coverage and a safe extension schema.

## Data model and inclusion rules

1. **Source-first provenance.** Every fact has a `source_id` and exact `source_url`; source records retain their official landing/download/API URLs. The source catalog is the provenance spine.
2. **One fact, one row.** A fact is one explicit metric from a supplied source result, preserving source period, geography, unit, denominator/scope, and qualifiers. A percentage is not converted to a count; “more than,” “approximately,” “millions,” “amount involved,” “saved,” “prevented,” “profit,” and “reported loss” retain their original meaning.
3. **No synthetic rows.** Blank means the supplied evidence did not provide the field. Zero is used only where a source explicitly reported zero (for example, the exact NVD CWE filters for CWE-1104 and CWE-1395 at retrieval).
4. **No incompatible merges.** NVD/CISA vulnerability records, MITRE taxonomies, DBIR incidents/breaches, IC3/FTC complaints, NCRB police-recorded cases, CERT-In handled incidents, RBI bank-reported frauds, Europol operation callouts, and UCI message labels remain separate source units.
5. **Attack labels require evidence.** A CWE/CAPEC or source category is a mapping cue, not proof of a live attack, victimization, exploitation, loss, or enforcement outcome. `attack_taxonomy.csv` states the appropriate ground truth for each requested category.
6. **Time and geography are source-native.** Calendar year, fiscal year, occurrence year, reporting year, catalog date, publication date, and dataset-release period are not silently substituted for one another. “Global,” “international complainant coverage,” “India,” and contributor samples are not interchangeable.
7. **Reproducibility.** NVD totals are live snapshots and must be re-queried with the recorded filter and retrieval date; feed/report editions can change. Use the exact source URLs and source notes before refreshing.

## Provenance and numbered references

The following primary URLs are preserved exactly in the catalog and are the recommended citation targets:

[1] NIST NVD: https://nvd.nist.gov/ ; API https://services.nvd.nist.gov/rest/json/cves/2.0 ; documentation https://nvd.nist.gov/developers/vulnerabilities ; feeds https://nvd.nist.gov/vuln/data-feeds

[2] CISA KEV catalog: https://www.cisa.gov/known-exploited-vulnerabilities-catalog ; JSON https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json ; schema https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities_schema.json

[3] MITRE CWE/CAPEC: https://cwe.mitre.org/ ; https://capec.mitre.org/ ; CWE downloads https://cwe.mitre.org/data/downloads.html ; CAPEC downloads https://capec.mitre.org/data/downloads.html

[4] Verizon DBIR archive: https://www.verizon.com/business/resources/reports/dbir/ ; 2024 PDF https://www.verizon.com/business/resources/reports/2024-dbir-data-breach-investigations-report.pdf ; 2025 PDF https://www.verizon.com/business/resources/reports/2025-dbir-data-breach-investigations-report.pdf

[5] FBI IC3 annual reports: https://www.ic3.gov/annualreport/reports ; 2024 PDF https://www.ic3.gov/AnnualReport/Reports/2024_IC3Report.pdf ; 2025 PDF https://www.ic3.gov/AnnualReport/Reports/2025_IC3Report.pdf

[6] FTC Consumer Sentinel 2024: https://www.ftc.gov/reports/consumer-sentinel-network-data-book-2024 ; PDF https://www.ftc.gov/system/files/ftc_gov/pdf/csn-annual-data-book-2024.pdf ; CSV ZIP https://www.ftc.gov/system/files/ftc_gov/data/csn-data-book-2024-csv.zip

[7] India NCRP/I4C/NCRB: https://cybercrime.gov.in/ ; https://i4c.mha.gov.in/ncrp.aspx ; MHA annexure https://www.mha.gov.in/MHA1/Par2017/pdfs/par2025-pdfs/LS02122025/452.pdf ; NCRB report https://ncrb.gov.in/uploads/nationalcrimerecordsbureau/custom/1701607577CrimeinIndia2022Book1.pdf

[8] CERT-In: https://www.cert-in.org.in/s2cMainServlet?pageid=PUBANULREPRT ; 2024 report https://www.cert-in.org.in/Downloader?pageid=22&type=2&fileName=ANUAL-2025-0001.pdf ; advisory index https://www.cert-in.org.in/s2cMainServlet?pageid=PUBADVLIST

[9] RBI: https://rbi.org.in/scripts/PublicationsView.aspx?Id=23075 ; PDF https://rbidocs.rbi.org.in/rdocs/Publications/PDFs/06OPERATIONS2612243AA56D31B20244688A4C99E91D57A247.PDF

[10] Europol IOCTA 2024: https://www.europol.europa.eu/publication-events/main-reports/internet-organised-crime-threat-assessment-iocta-2024 ; PDF https://www.europol.europa.eu/cms/sites/default/files/documents/Internet%20Organised%20Crime%20Threat%20Assessment%20IOCTA%202024.pdf

[11] UCI SMS Spam Collection: https://archive.ics.uci.edu/dataset/228/sms+spam+collection ; DOI https://doi.org/10.24432/C5CC84 ; paper https://doi.org/10.1145/2034691.2034742

## Comparability guide

**Directly comparable only within a source's own defined series** (same metric, unit, denominator, period convention, geography, and edition). Examples: IC3 2024 crime-type complaint rows against other IC3 2024 crime-type rows; NCRB all-India registered-case years; CERT-In 2023/2024 incident-type tables; RBI Card/Internet reporting-year rows when the table convention is held constant; DBIR incident and breach counts only within the DBIR edition definitions.

**Not directly comparable:**

- NVD CVE/CWE result totals vs CISA KEV entries: vulnerable records vs known exploited entries.
- CWE/CAPEC taxonomy sizes vs incidents, complaints, or attacks.
- DBIR incidents vs confirmed breaches vs IC3/FTC complaints vs NCRB registered cases vs CERT-In handled incidents.
- IC3/FTC reported losses, RBI amount involved, Europol ransom paid/illicit profit/prevented loss, and CFCFRMS saved amount. These are different financial concepts.
- RBI reporting year vs occurrence year; NVD publication/modified dates vs CISA `dateAdded`; NCRP intake vs NCRB police registration; DBIR edition/caseload periods vs calendar years.
- UCI spam/ham messages vs phishing/smishing incidents or victims.
- “Arrested,” “charge-sheeted,” “trials completed,” “convicted,” “investigated,” and “pending” are distinct states and cannot be summed or inferred from one another.

## Ethical, legal, and analytical limitations

Use these data for defensive research, measurement, and prevention—not for identifying, targeting, profiling, or accusing people or organizations. Complaint and report data may contain duplicates, errors, under-reporting, or unverified allegations. Vulnerability labels do not prove exploitation; exploit labels do not identify victims; attack-pattern mappings do not establish intent. Do not publish sensitive personal data, credentials, exploit payloads, or unredacted victim details. Follow applicable law, authorization boundaries, responsible disclosure practices, data-protection rules, and terms of use. Do not infer age targeting, attacker identity/team membership, guilt, prosecution, conviction, or financial harm from a category label or aggregate total.

For exact label semantics and the distinction between `reported`, `confirmed`, `exploited`, `investigated`, `prosecuted`, `convicted`, `pending`, and `loss_amount`, see `data_dictionary.csv` and `limitations_and_gaps.md`.
