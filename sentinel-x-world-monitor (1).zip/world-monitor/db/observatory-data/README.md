# Global & India Cyber Threat Observatory — Evidence Dataset

This folder is the data behind the **Global & India Cyber Threat Observatory** page (`/observatory.html`, API `/api/gio/*`).

| file | rows | what it is |
|---|---|---|
| `verified_facts.csv` | 109 | Your supplied dataset pack (NVD, CISA KEV, MITRE, DBIR, FBI IC3, FTC, NCRB/NCRP, CERT-In, RBI, Europol, UCI) — unchanged |
| `extra_verified_facts.csv` | 270 | Facts researched and verified on 2026-09-26 (same schema) |
| `source_catalog.csv` + `extra_source_catalog.csv` | 11 + 31 | Every source with official URL, coverage and limitations |
| `attack_taxonomy.csv` | 20 | Ground-truth rules per attack category (from your pack) |
| `all_facts.csv` / `all_facts.json` | 379 | Combined export (generated) |
| `export_attacks-scams.csv`, `export_attacks-application.csv`, `export_countries.csv`, `export_sources.csv` | — | The tables shown on the page, with a source URL per value |
| `PACK-README.md`, `limitations_and_gaps.md`, `data_dictionary.csv` | — | Your pack's methodology, limits and field definitions |

## What the researched facts add
- **Victim age bands** — FBI IC3 2024 complaints and losses for <20, 20-29, 30-39, 40-49, 50-59, 60+ (complainant age, not attacker intent); Singapore Police: 70.9% of victims under 50.
- **Country comparison** — IC3 2024 top-20 foreign countries (India 4,189; Pakistan 979; China 651; Japan 1,492; Italy 761 …); World Cybercrime Index 2024 ranks (Oxford/UNSW); ITU Global Cybersecurity Index 2024 tiers; Singapore police totals.
- **India** — NCRP complaints 2021–2024, reported loss 2022–2024 (MHA Lok Sabha reply 02-12-2025), SIM/IMEI blocks, convictions 2020–22, top states 2022.
- **Scam categories** — smishing (FTC $470M text-scam loss; Mendeley 5,971-SMS smishing corpus), vishing proxy (IC3 call-center scams 53,369 / $1.9B), prize scams (IC3 lottery 3,690 / $102M), malware/ransomware (IC3, Europol Operation Endgame arrests), phishing volume (APWG 2024 quarters and sectors), phishing URLs (UCI PhiUSIIL 235,795 URLs).
- **Awareness** — Yubico/Talker 2025 India survey (68% interacted with phishing) — a survey sample, labelled as such.
- **Application attacks (Sections 1–3)** — OWASP Top 10 2021 incidence rates and HackerOne Top-10 ranks, as class prevalence.
- **One forecast** — Cybersecurity Ventures $10.5T (fact_id `EST-…`, labelled forecast everywhere).

- **Country ranking** — GI-TOC Global Organized Crime Index 2025 cyber-dependent crime, financial crime and criminality scores for 30+ countries (India 7.5, China 8.5, Russia 9.0, Pakistan 5.0, Afghanistan 4.0; global average 4.65). This is the only measure scored the same way for every country, so the page ranks by it.
- **National police / regulator figures** — China MPS, Japan NPA, Korea FSS, Pakistan FIA, Malaysia PDRM, Thailand RTP, Indonesia OJK/IASC, Philippines PNP-ACG, Bangladesh tribunal, UAE Cyber Security Council, Singapore Police. Definitions and years differ; shown side by side, never summed. Vietnam's loss figure is a survey estimate (`EST-Vietnam-loss`).

## Rules (same as your pack)
1. One fact = one row, value copied as published, with unit, period, geography, scope and exact source URL.
2. Different units (complaints, cases, incidents, breaches, CVEs, messages) are never added together.
3. Missing = not published. Nothing is filled with zero or estimated.
4. The "deep research" text supplied in chat contained illustrative tables and generated sample rows; those were **not** imported. Only figures re-verified against a primary or cited source are included.

## What no authority publishes (shown as NOT PUBLISHED in the app)
Per-attack case counts by country · all-cybercrime pending cases · attacker-team counts · red-team formation · how attackers select victim age · fake-payment-screenshot counts · national awareness percentage · GCI 2024 tiers for China, Russia, Portugal, Argentina, Afghanistan, Iran (not found in reachable sources — check the primary ITU report).
