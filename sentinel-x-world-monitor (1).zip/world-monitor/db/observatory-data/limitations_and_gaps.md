# Limitations and gaps

## Why the requested uniform fields cannot be filled

### Global country-by-country counts
The sources use incompatible universes and denominators. DBIR is a changing contributed sample; IC3 and FTC are complaint/reporting systems with international contributors but no public case-level records; Europol is an analytical assessment with operation-specific geographies; NVD/CISA/CWE/CAPEC are vulnerability/taxonomy sources rather than victim-event censuses; CERT-In, NCRB and RBI are India-specific institutional series; UCI is a text corpus. A country label can mean complainant country, victim/target country, vendor/product geography, operation participant, reporting institution, or publication scope. No defensible global country-by-country total can be created by adding these sources.

### Arrests, cleared/pending cases, and dispositions
Only selected sources expose enforcement fields, and they are not uniform. The verified NCRB annexure provides charge-sheeted, trials completed, convicted, conviction rate and arrested fields for the **Fraud head**, not all cybercrime. Europol gives isolated operation callouts, not a comparable time series. IC3/FTC complaint referrals are not arrests or prosecutions. Absence of a disposition is not “pending,” and a registered case is not “cleared.”

### Attacker team counts
Public sources describe named groups, affiliates, actors, brokers, forums or operations inconsistently. Europol warns that ransomware brands splinter/rebrand; NVD/CISA identify products and vulnerabilities, not perpetrators; DBIR aggregates actor categories; complaint and police tables generally do not expose an attacker-team identifier. Counting names would double-count aliases and confuse service providers, affiliates, victims, and operations.

### Age targeting
IC3 and FTC publish some **complainant/consumer age** fields, not attacker targeting intent. UCI has no demographics; DBIR, NVD/CISA, CERT-In, RBI, NCRB and Europol do not provide a harmonized age-targeting denominator. Age bands are missing for many reports and cannot be generalized to all victims or the population.

### Red-team formation
No supplied public official dataset records how defensive red teams were formed, their staffing, authorization, membership, training, exercise design, or outcomes. Such information is organizational and often sensitive. It must not be inferred from attack taxonomies, incident counts, or attacker-group descriptions.

## Safe schema for future additions

Add new evidence as a separate source and event/observation table rather than altering the verified facts. Minimum fields:

| field | requirement |
|---|---|
| `record_id` | Stable source-native or locally assigned ID; never expose raw personal identifiers. |
| `source_id` | Foreign key to a source catalog row. |
| `source_url` | Exact primary URL, plus retrieval timestamp and edition/version. |
| `observation_period_start`, `observation_period_end` | ISO dates; retain reporting vs occurrence semantics in `period_type`. |
| `geography_name`, `geography_type`, `geography_role` | E.g., country / complainant, victim, target, reporting institution, operation participant. |
| `unit_type` | One of complaint, report, incident, breach, vulnerability, CVE, case, arrest, prosecution, conviction, message, operation, or other source-defined unit. |
| `metric`, `value`, `unit`, `denominator_or_scope` | Exact value and denominator; retain `qualifier` for more-than/approximately/range. |
| `attack_category`, `standard_mapping`, `evidence_type` | Separate observed behavior from taxonomy mapping; evidence type can be `source-explicit`, `analyst-coded`, or `not available`. |
| `status` | One of `reported`, `confirmed`, `exploited`, `investigated`, `prosecuted`, `convicted`, `pending`, `unknown`; never infer transitions. |
| `loss_amount`, `loss_currency`, `loss_type` | Keep reported loss, amount involved, ransom paid, prevented/saved, profit, recovery, and restitution distinct. |
| `victim_count`, `complaint_count`, `case_count`, `arrest_count` | Separate measures; do not use one as a proxy for another. |
| `privacy_review`, `legal_basis`, `retention_rule` | Required before adding personal, sensitive, or law-enforcement data. |
| `verification_note`, `provenance_hash` | Explain validation and preserve reproducibility. |

### Safe join rules

- Join NVD to CISA only on exact CVE IDs, retaining both source units and retrieval versions.
- Join CWE/CAPEC as reference mappings, never as event counts.
- Join complaint, police, breach, and incident records only with an explicit, documented crosswalk; do not deduplicate across sources by text similarity alone.
- Keep each source's original denominator and confidence/verification status. If a field is unavailable, leave it blank or use `unknown`; never encode “not observed” as zero.
