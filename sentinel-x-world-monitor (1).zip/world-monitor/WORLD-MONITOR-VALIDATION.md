# World Monitor — Validation & Commands

## Commands
| command | what it does |
|---|---|
| `npm run world:validate` | data-model + registry integrity gate (no network): 26 tables, ≥10 intl + ≥10 India sources with real URLs, 36 states, 15 approved + future taxonomy, and the provenance invariant. Exit 1 on failure. |
| `npm run world:refresh` | **real** HTTP source-health probes → writes `wm_source_runs` + receipts + updates status. |
| `npm run world:refresh -- --dry` | probe + report without writing. |
| `npm run world:coverage` | print the data-coverage report (not a country risk score). |
| `npm run world:provenance [metricId]` | provenance for one metric, or list all sourced metrics with URLs. |
| `npm run world:health` | source-run health summary + freshness breakdown. |
| `npm run world:export [json|csv]` | provenance-preserving export of all metrics. |

## Existing gates still pass (no SENTINEL-X regression)
`npm test` (118 tests, incl. `test/world.test.js`), `npm run validate`
(exactly-15 attack scope), `npm run verify` (15/15 attacks + SMS 6/6 over real
HTTP), `npm run verify:ui`, `npm run scan`.

## What the tests check (World Monitor)
Schema completeness; ≥10+10 sources with real URLs; 36 states; exactly 15 approved
attacks + future families; the provenance invariant (no un-sourced value); the
`/api/world/*` shapes; **honesty** (US comparison → `UNAVAILABLE` not 0; state
without data → coverage `NONE` not zero; unpublished lifecycle stage →
`NOT_PUBLISHED`); SSE endpoint; and auth (401 without a session).

## Acceptance highlights
15-attack verification passes; 5/5/5 split intact; SMS separate; India-vs-World is
first-class; manual country comparison works; ≥10 intl + ≥10 India sources
registered with exact URLs; every migrated metric has provenance; freshness is
visible; research/social/official are separated; unknown is never zero; no
hard-coded dashboard statistics; no fake LIVE labels; source outages are visible.
