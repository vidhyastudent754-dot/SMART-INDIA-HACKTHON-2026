# World Monitor — Provenance

Every important number answers three questions:
**What does it mean? Where did it come from? How fresh is it?**

## How provenance is stored
Each figure is a row in `wm_metrics` joined 1:1 to `wm_metric_provenance`:
- `value` + `original_value` (verbatim as published, e.g. INR "crore" preserved)
- `unit`, `period`, `country`, `state_code`, `attack_category`
- `evidence_type`, `confidence`
- provenance: `source_id`, `source_url`, `source_pub_date`, `retrieved_at`,
  `dataset_version`, `calculation` (formula when derived), `transformation`,
  `inputs` (JSON of source metric ids), `notes`.

## Invariant (enforced by tests + `npm run world:validate`)
> Every metric with a non-null value MUST have a non-empty `source_url`.

There is no path to display a number without a source. Missing data is the
**absence of a row**, surfaced as `UNAVAILABLE` / `NOT_PUBLISHED` — never zero.

## Derived metrics
A derived metric records its `calculation` and the `inputs` it was computed from,
and is tagged `evidence_type = DERIVED`. Year-over-year change in `/api/world/trends`
is computed at read time and each point carries its own source URL.

## "Why this number?"
`GET /api/world/provenance/:metricId` returns the full record. The observatory UI
renders it in a side drawer next to every important figure.

## Migrated data
The seed migrates the real, already-sourced figures in `db/observatory.json`
(NCRP, CFCFRMS, I4C, NCRB, CERT-In, FBI IC3, enforcement ops) into these tables,
preserving each source URL, publication note and retrieval date.
