'use strict';
/* A1: script-src must never allow inline script, and no page may contain one. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { startApp, login, api } = require('./helpers');

let t, cookie;
test.before(async () => { t = await startApp(); cookie = (await login(t.base, 'admin')).cookie; });
test.after(async () => { await t.close(); });

const scriptSrc = (h) => ((h || '').split(';').map((d) => d.trim()).find((d) => d.startsWith('script-src')) || '');

for (const p of ['/', '/index.html', '/observatory.html', '/login', '/api/health', '/js/login.js']) {
  test('CSP script-src has no unsafe-inline on ' + p, async () => {
    const r = await api(t.base, 'GET', p, { cookie: p === '/login' ? undefined : cookie });
    const csp = r.headers.get('content-security-policy');
    assert.ok(csp, 'CSP header missing on ' + p);
    const s = scriptSrc(csp);
    assert.ok(s, 'script-src missing on ' + p);
    assert.ok(!/unsafe-inline/.test(s), p + ' script-src allows unsafe-inline: ' + s);
    assert.ok(!/unsafe-eval/.test(s), p + ' script-src allows unsafe-eval: ' + s);
  });
}

test('no served HTML file contains an inline <script> or inline event handler', () => {
  const dir = path.join(__dirname, '..', 'public');
  for (const f of fs.readdirSync(dir).filter((x) => x.endsWith('.html'))) {
    const html = fs.readFileSync(path.join(dir, f), 'utf8');
    const tags = html.match(/<script\b[^>]*>/gi) || [];
    for (const tag of tags) assert.match(tag, /\ssrc=/i, f + ' has an inline script: ' + tag);
    assert.ok(!/<[a-z][^>]*\son[a-z]+\s*=\s*["']/i.test(html), f + ' has an inline event handler attribute');
  }
});
