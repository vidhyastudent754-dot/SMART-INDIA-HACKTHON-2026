'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { startApp, login, api } = require('./helpers');
const { createObservatoryCache, parseCertInNotes, SIGNALS } = require('../lib/observatory-cache');

const json = (o) => ({ ok: true, status: 200, json: async () => o, text: async () => JSON.stringify(o) });
// Mock of the outbound internet: NVD is DOWN, HIBP is UP. No real network in tests.
const nvdDown = async (url) => {
  if (url.includes('nvd.nist.gov')) throw new Error('ECONNRESET (mocked NVD outage)');
  if (url.includes('haveibeenpwned')) return json(Array.from({ length: 120 }, (_, i) => ({ Name: 'b' + i, Title: 'B' + i, PwnCount: 10, AddedDate: '2026-01-01' })));
  return { ok: false, status: 503, json: async () => ({}), text: async () => '' };
};

let t, admin;
test.before(async () => {
  t = await startApp({ config: { observatoryLive: true, observatoryFetch: nvdDown } });
  await t.wm.observatoryReady;                       // first live refresh finished
  admin = (await login(t.base, 'admin')).cookie;
});
test.after(async () => { await t.close(); });

test('GET /api/observatory/snapshot requires auth (401 without a cookie)', async () => {
  const r = await api(t.base, 'GET', '/api/observatory/snapshot');
  assert.equal(r.status, 401);
});

test('snapshot returns meta, data, data.india, data.global', async () => {
  const r = await api(t.base, 'GET', '/api/observatory/snapshot', { cookie: admin });
  assert.equal(r.status, 200);
  for (const k of ['cachedAt', 'nextRefreshAt', 'sources', 'liveSignals', 'signals']) assert.ok(k in r.json.meta, 'meta.' + k);
  for (const k of ['india', 'global', 'compare', 'kpis', 'feed']) assert.ok(r.json.data[k], 'data.' + k);
  assert.equal(r.json.data.kpis.filter((k) => !k.liveSignal).length, 6);
});

test('viewer can read the observatory', async () => {
  const { cookie } = await login(t.base, 'viewer');
  assert.equal((await api(t.base, 'GET', '/api/observatory/compare', { cookie })).status, 200);
});

test('section/1 returns attackTypes (≥3) linked to real check IDs with CVSS', async () => {
  const r = await api(t.base, 'GET', '/api/observatory/section/1', { cookie: admin });
  assert.equal(r.status, 200);
  assert.ok(r.json.data.attackTypes.length >= 3);
  const c = r.json.data.attackTypes[0].checks[0];
  assert.match(c.id, /^IND-\d\d$/);
  assert.equal(typeof c.cvss, 'number');
});

test('section/4 is 404', async () => {
  assert.equal((await api(t.base, 'GET', '/api/observatory/section/4', { cookie: admin })).status, 404);
});

test('cache is warm within 3 s of createApp() (reference data loads synchronously)', async () => {
  const t0 = Date.now();
  const cache = createObservatoryCache({ live: false });
  cache.start();
  assert.ok(cache.status().warm);
  assert.ok(Date.now() - t0 < 3000);
  cache.close();
});

test('NVD fetch failure → still 200, that signal is "cached"; HIBP success → "live"', async () => {
  const r = await api(t.base, 'GET', '/api/observatory/global', { cookie: admin });
  assert.equal(r.status, 200);
  assert.equal(r.json.data.live.cves.source, 'cached');
  assert.match(r.json.data.live.cves.error, /mocked NVD outage/);
  assert.equal(r.json.data.live.breaches.source, 'live');
  assert.equal(r.json.data.live.breaches.value, 120);
  assert.equal(r.json.meta.liveSignals, true);
  assert.equal(r.json.meta.signals.nvdCves7d.source, 'cached');
});

test('a garbage response is rejected, not turned into a number', async () => {
  const cache = createObservatoryCache({ live: true, fetchImpl: async () => json({ totalResults: 'lots' }), log: { warn() {}, error() {} } });
  await cache.start();
  assert.equal(cache.get().signals.nvdCves7d.source, 'cached');
  assert.equal(cache.get().signals.nvdCves7d.value, null);
  cache.close();
});

test('metrics expose observatory cache age and live-signal status', async () => {
  const m = (await api(t.base, 'GET', '/api/metrics', { cookie: admin })).json;
  assert.equal(typeof m.observatory.cacheAge, 'number');
  assert.equal(m.observatory.liveSignalsOk, true);
  assert.ok(m.observatory.sourcesLive.includes('Data breaches catalogued'));
});

test('derived figures are computed from the reference data', async () => {
  const d = (await api(t.base, 'GET', '/api/observatory/india', { cookie: admin })).json.data;
  const cum = d.ncrp.cumulative;
  assert.equal(d.conversion.firPerComplaintPct, +((cum.firsRegistered.value / cum.complaints.value) * 100).toFixed(2));
  const c = d.ncrp.complaints;
  assert.equal(c[3].yoyPct, +(((c[3].value - c[2].value) / c[2].value) * 100).toFixed(1));
});

test('data integrity: every reference figure has a source, link and period; estimates are labelled', () => {
  const ref = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'db', 'observatory.json'), 'utf8'));
  const bad = [];
  (function walk(o, p) {
    if (Array.isArray(o)) return o.forEach((x, i) => walk(x, `${p}[${i}]`));
    if (!o || typeof o !== 'object') return;
    if ('value' in o && typeof o.value === 'number' && p !== 'root.estimates') {
      if (!o.source || !/^https:\/\//.test(o.sourceUrl || '') || (o.year == null && !o.asOf)) bad.push(p);
    }
    for (const k of Object.keys(o)) if (k !== 'liveSignals') walk(o[k], `${p}.${k}`);
  })(ref, 'root');
  assert.deepEqual(bad, []);
  assert.match(ref.estimates.disclaimer, /not publish|Illustrative/i);
});

test('section-0 HTML contains no hard-coded statistics', () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
  const seg = html.slice(html.indexOf('<section id="section-0"'), html.indexOf('<section id="section-3"'))
    .replace(/<style>[\s\S]*?<\/style>/g, '')
    .replace(/<span data-nonstat="[^"]+">[^<]*<\/span>/g, ' ')   // explicit, reviewable exemptions (e.g. the 1930 helpline number)
    .replace(/<[^>]+>/g, ' ').replace(/&#?\w+;/g, ' ');
  const numbers = seg.match(/\d[\d,.]{2,}\d/g) || [];
  assert.deepEqual(numbers, [], 'numbers found in section-0 markup: ' + numbers.join(', '));
});

test('CERT-In: reads the per-year listing and the newest note (structure of the real page, Sep 2026)', () => {
  assert.match(SIGNALS.certInVulnNotes.url(2026), /pageid=VLNLIST02&year=2026$/);
  const html = '<table><tr><td><a href="s2cMainServlet?pageid=PUBVLNOTES01&VLCODE=CIVN-2026-0476">CERT-In Vulnerability Note CIVN-2026-0476</a></td></tr>' +
    '<tr><td>(September 24, 2026)</td></tr><tr><td>Multiple Vulnerabilities in Adobe Products</td></tr></table>' +
    '<table><tr><td><a>CERT-In Vulnerability Note CIVN-2026-0475</a></td></tr><tr><td>(September 24, 2026)</td></tr></table>';
  const r = parseCertInNotes(html, 2026, 'x');
  assert.equal(r.value, 476);
  assert.equal(r.extra.latestTitle, 'Multiple Vulnerabilities in Adobe Products');
  assert.equal(r.extra.latestDate, 'September 24, 2026');
  // the menu-only shell page (what the old URL returned) must fail, not report 0
  assert.throws(() => parseCertInNotes('<html><a>VulnerabilityNotes</a></html>', 2026, 'x'), /no CIVN-2026/);
});
