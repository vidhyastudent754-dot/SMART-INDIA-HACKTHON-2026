'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { heuristicCheckUrl } = require('../heuristics');

test('plain HTTPS domain is SAFE', () => {
  const r = heuristicCheckUrl('https://example.com/path');
  assert.equal(r.ok, true);
  assert.equal(r.verdict, 'SAFE');
  assert.equal(r.signals.length, 0);
});

test('missing HTTPS is flagged', () => {
  const r = heuristicCheckUrl('http://example.com');
  assert.ok(r.signals.some((s) => /No HTTPS/.test(s)));
  assert.equal(r.verdict, 'SUSPICIOUS');
});

test('scheme-less input is treated as https', () => {
  assert.equal(heuristicCheckUrl('example.com').verdict, 'SAFE');
});

test('raw IPv4 address over http is MALICIOUS', () => {
  const r = heuristicCheckUrl('http://192.168.10.5/login');
  assert.ok(r.signals.some((s) => /raw IP/.test(s)));
  assert.equal(r.verdict, 'MALICIOUS');
});

test('invalid dotted-quad hosts are rejected by the URL parser, not scored', () => {
  const r = heuristicCheckUrl('https://999.1.1.1/');
  assert.equal(r.ok, false);
});

test('raw IPv6 host is flagged', () => {
  // regression: URL.hostname keeps the brackets, which used to defeat the check
  const r = heuristicCheckUrl('http://[2001:db8::1]/');
  assert.ok(r.signals.some((s) => /raw IP/.test(s)));
  assert.equal(r.verdict, 'MALICIOUS');
});

test('link shortener is flagged', () => {
  const r = heuristicCheckUrl('https://bit.ly/3abcXYZ');
  assert.ok(r.signals.some((s) => /link-shortener/.test(s)));
});

test('brand keyword stuffed into a hyphenated domain is flagged as impersonation', () => {
  const r = heuristicCheckUrl('https://sbi-secure-verify.login-alert.xyz/netbanking');
  assert.ok(r.signals.some((s) => /"SBI"/.test(s)));
  assert.notEqual(r.verdict, 'SAFE');
});

test('the real brand domain does not collide with its own keyword', () => {
  const r = heuristicCheckUrl('https://www.paypal.com/signin');
  assert.equal(r.verdict, 'SAFE');
});

test('punycode host is flagged', () => {
  assert.ok(heuristicCheckUrl('https://xn--pypal-4ve.com').signals.some((s) => /Punycode/.test(s)));
});

test('non-http schemes and garbage are rejected', () => {
  assert.equal(heuristicCheckUrl('javascript:alert(1)').ok, false);
  assert.equal(heuristicCheckUrl('ftp://example.com').ok, false);
  assert.equal(heuristicCheckUrl('http://').ok, false);
});
