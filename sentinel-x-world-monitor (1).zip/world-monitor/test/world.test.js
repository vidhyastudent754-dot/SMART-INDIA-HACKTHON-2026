'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');
const { seedWorld } = require('../db/world-seed');

let t, admin;
test.before(async () => {
  t = await startApp();
  seedWorld(t.db);                 // idempotent World Monitor reference data + provenance migration
  admin = (await login(t.base, 'admin')).cookie;
});
test.after(async () => { await t.close(); });

const get = (p) => api(t.base, 'GET', p, { cookie: admin });

/* ---- data model + seed ---- */
test('schema has all 26 World Monitor tables', () => {
  const names = t.db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'wm_%'").all().map((r) => r.name);
  for (const req of ['wm_sources', 'wm_source_runs', 'wm_source_receipts', 'wm_countries', 'wm_india_states',
    'wm_attack_taxonomy', 'wm_incidents', 'wm_financial_impacts', 'wm_case_lifecycle', 'wm_threat_actors',
    'wm_campaigns', 'wm_vulnerabilities', 'wm_research_datasets', 'wm_research_records', 'wm_social_sources',
    'wm_social_posts', 'wm_awareness_events', 'wm_metrics', 'wm_metric_provenance', 'wm_comparison_snapshots',
    'wm_alerts', 'wm_audit_log']) {
    assert.ok(names.includes(req), 'missing ' + req);
  }
  assert.ok(names.length >= 26);
});

test('registry: >=10 international + >=10 India sources, all with real URLs', () => {
  const intl = t.db.prepare("SELECT COUNT(*) n FROM wm_sources WHERE scope != 'IN'").get().n;
  const india = t.db.prepare("SELECT COUNT(*) n FROM wm_sources WHERE scope = 'IN'").get().n;
  assert.ok(intl >= 10, 'intl=' + intl);
  assert.ok(india >= 10, 'india=' + india);
  const bad = t.db.prepare("SELECT COUNT(*) n FROM wm_sources WHERE url NOT LIKE 'http%'").get().n;
  assert.equal(bad, 0, 'all sources must have real http(s) URLs');
});

test('reference data: 36 India states/UTs and preset countries seeded', () => {
  assert.ok(t.db.prepare('SELECT COUNT(*) n FROM wm_india_states').get().n >= 36);
  assert.ok(t.db.prepare('SELECT COUNT(*) n FROM wm_countries').get().n >= 30);
  assert.ok(t.db.prepare("SELECT 1 x FROM wm_countries WHERE code='IN'").get());
});

test('taxonomy: exactly 15 approved SENTINEL-X attacks + extensible future families', () => {
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM wm_attack_taxonomy WHERE approved=1').get().n, 15);
  assert.ok(t.db.prepare('SELECT COUNT(*) n FROM wm_attack_taxonomy WHERE future=1').get().n >= 20);
});

test('honesty invariant: every metric with a value has a source URL (no un-sourced numbers)', () => {
  const bad = t.db.prepare(`SELECT COUNT(*) n FROM wm_metrics m LEFT JOIN wm_metric_provenance p USING(metric_id)
    WHERE m.value IS NOT NULL AND (p.source_url IS NULL OR p.source_url = '')`).get().n;
  assert.equal(bad, 0);
  assert.ok(t.db.prepare('SELECT COUNT(*) n FROM wm_metrics').get().n > 0, 'real observatory metrics migrated');
});

/* ---- API ---- */
test('GET /api/world/overview returns real India KPIs with provenance', async () => {
  const r = await get('/api/world/overview');
  assert.equal(r.status, 200);
  assert.equal(r.json.kpis.indiaReportedCases.available, true);
  assert.ok(r.json.kpis.indiaReportedCases.sourceUrl.startsWith('http'));
  // things we do NOT have real data for must be honest, never fabricated
  assert.equal(r.json.kpis.activeThreatSignals.available, false);
  assert.equal(r.json.kpis.activeThreatSignals.status, 'UNAVAILABLE');
});

test('GET /api/world/sources reports >=20 sources with freshness', async () => {
  const r = await get('/api/world/sources');
  assert.equal(r.status, 200);
  assert.ok(r.json.total >= 20);
  assert.ok(r.json.sources.every((s) => s.url.startsWith('http') && s.freshness && s.freshness.status));
});

test('GET /api/world/compare shows real WCI ranks + victim stats, no "winner"', async () => {
  const r = await get('/api/world/compare?countries=IN,US,CN,RU');
  assert.equal(r.status, 200);
  assert.equal(r.json.table.length, 4);
  const india = r.json.table.find((x) => x.code === 'IN');
  assert.equal(india.measures.wciRank.value, 10);           // real World Cybercrime Index 2024
  assert.ok(india.measures.casesRegistered.value > 0);      // real NCRB
  const us = r.json.table.find((x) => x.code === 'US');
  assert.equal(us.measures.ic3Complaints.value, 859532);    // real FBI IC3 2024
  assert.ok(us.measures.wciRank.sourceUrl.startsWith('http'));
  assert.match(r.json.methodology, /no single .{0,4}winner/i);
});

test('per-attack real-world prevalence is sourced (OWASP/HackerOne), not fabricated case counts', async () => {
  const r = await get('/api/world/sections/1');
  const xss = r.json.attacks.find((a) => a.id === 'IND-06');
  assert.equal(xss.prevalence.available, true);
  assert.equal(xss.prevalence.maxIncidencePct, 19.09);      // OWASP A03 2021
  assert.equal(xss.prevalence.hackerOneRank, 1);            // HackerOne #1
  assert.ok(xss.prevalence.sourceUrl.startsWith('http'));
});

test('India case lifecycle carries real NCRB registered + conviction figures with sources', async () => {
  const r = await get('/api/world/case-lifecycle');
  assert.ok(Array.isArray(r.json.india.case_registered));
  assert.ok(r.json.india.case_registered.some((x) => x.value === 65893));   // NCRB 2022
  assert.ok(Array.isArray(r.json.india.convicted));
  assert.ok(r.json.india.convicted.every((x) => x.sourceUrl.startsWith('http')));
});

test('GET /api/world/future lists evidence-linked critical families (source URLs)', async () => {
  const r = await get('/api/world/future');
  assert.equal(r.status, 200);
  assert.ok(r.json.trackedIncidents.length >= 3);
  assert.ok(r.json.trackedIncidents.every((i) => i.sources.length && i.sources[0].startsWith('http')));
});

test('real per-state NCRB data present; states without data stay NONE (never zero)', async () => {
  const tg = await get('/api/world/india/state/IN-TG');
  assert.equal(tg.json.coverage.level, 'PARTIAL');          // Telangana has real NCRB data
  assert.ok(tg.json.metrics.some((m) => m.value === 15297));
  const ar = await get('/api/world/india/state/IN-AR');
  assert.equal(ar.json.coverage.level, 'NONE');             // no data ≠ zero
});

test('GET /api/world/india/state/:code never fabricates zero for missing data', async () => {
  const r = await get('/api/world/india/state/IN-AR');   // Arunachal — no ingested data
  assert.equal(r.status, 200);
  assert.equal(r.json.coverage.level, 'NONE');
  assert.match(JSON.stringify(r.json.coverage), /never shown as zero/i);
});

test('GET /api/world/case-lifecycle marks unpublished stages NOT_PUBLISHED (not zero)', async () => {
  const r = await get('/api/world/case-lifecycle');
  assert.equal(r.status, 200);
  assert.equal(r.json.india.trial.status, 'NOT_PUBLISHED');   // trial stage is not published by sources
});

test('GET /api/world/sections/1 returns exactly 5 attacks with crosswalk', async () => {
  const r = await get('/api/world/sections/1');
  assert.equal(r.json.attacks.length, 5);
  assert.ok(r.json.attacks[0].realWorldCrosswalk.label === 'World Monitor crosswalk');
});

test('GET /api/world/provenance/:metricId returns full provenance', async () => {
  const r = await get('/api/world/provenance/IN.ncrp.complaints.2024');
  assert.equal(r.status, 200);
  assert.ok(r.json.provenance.sourceUrl.startsWith('http'));
  assert.equal(r.json.evidenceType, 'VERIFIED_PRIMARY');
});

test('GET /api/world/coverage is a coverage report, not a country risk score', async () => {
  const r = await get('/api/world/coverage');
  assert.equal(r.status, 200);
  assert.match(r.json.note, /NOT a country/i);
  assert.equal(r.json.provenance.pct, 100);   // every migrated metric is sourced
});

test('GET /api/world/research keeps research separate from official', async () => {
  const r = await get('/api/world/research');
  assert.ok(Array.isArray(r.json.datasets));
  assert.match(r.json.rule, /separate/i);
});

test('GET /api/world/stream is an SSE endpoint', async () => {
  const r = await fetch(t.base + '/api/world/stream', { headers: { Cookie: admin } });
  assert.equal(r.status, 200);
  assert.match(r.headers.get('content-type') || '', /event-stream/);
  await r.body.cancel();
});

test('world API requires auth (401 without a session)', async () => {
  const r = await fetch(t.base + '/api/world/overview');
  assert.equal(r.status, 401);
});
