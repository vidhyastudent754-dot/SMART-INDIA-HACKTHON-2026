'use strict';
/* Real links and emails must come back SECURE; phishing ones NOT SECURE.
 * Covers the "Check anything" auto-detect path used by the Phishing Analyzer. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');

let t, admin, viewer;
test.before(async () => { t = await startApp(); admin = (await login(t.base, 'admin')).cookie; viewer = (await login(t.base, 'viewer')).cookie; });
test.after(async () => { await t.close(); });
const auto = (text, cookie) => api(t.base, 'POST', '/api/scam/analyze', { cookie: cookie || admin, body: { type: 'auto', text } });

const REAL_LINKS = ['https://www.hdfcbank.com/personal', 'https://onlinesbi.sbi/personal/login', 'https://accounts.google.com/signin', 'https://www.amazon.in/gp/your-account/order-history',
  'https://github.com/login', 'https://incometax.gov.in/iec/foportal/', 'https://www.irctc.co.in/nget/train-search', 'https://www.wikipedia.org'];
const PHISH_LINKS = ['http://paypa1-secure-login.com/verify', 'https://sbi-kyc-update.xyz/login', 'https://amaz0n-refund.top/claim?id=77', 'https://secure-appleid.apple.com.verify-account.info/',
  'https://hdfc-netbanking-update.com/', 'http://onlinesbi.sbi@185.243.115.84/verify', 'https://download-yono.site/sbi.apk', 'https://icicl-netbanking.info/login'];

for (const u of REAL_LINKS) test('real link is secure: ' + u, async () => {
  const r = await auto(u); assert.equal(r.status, 200); assert.equal(r.json.detected, 'link'); assert.equal(r.json.verdict, 'SECURE', JSON.stringify(r.json.reasons));
});
for (const u of PHISH_LINKS) test('phishing link is not secure: ' + u, async () => {
  const r = await auto(u); assert.equal(r.json.verdict, 'INSECURE'); assert.equal(r.json.level, 'DANGEROUS');
});

const REAL_EMAILS = [
  'From: Google <no-reply@accounts.google.com>\nSubject: Security alert\n\nA new sign-in on Windows. If this was you, you don\'t need to do anything.\nhttps://myaccount.google.com/notifications',
  'From: GitHub <noreply@github.com>\nSubject: [GitHub] Please reset your password\n\nUse this link to reset your password: https://github.com/password_reset/abc123\nIf you don\'t use this link within 3 hours, it will expire.',
  'From: SBI <donotreply@sbi.co.in>\nSubject: Beware of fraudsters\n\nDear Customer, SBI never asks for your OTP, PIN or password over phone, SMS or email. Do not share these with anyone.',
  'Hi Balaji,\nCan we meet on Friday at 3pm to go over the SIH submission?\nThanks,\nPriya',
  'From: Coursera <no-reply@t.mail.coursera.org>\nSubject: Your weekly digest\n\nYou are 60% through Google Cybersecurity. Continue: https://www.coursera.org/learn/x',
];
const PHISH_EMAILS = [
  'From: PayPal Security <service@paypa1-support.com>\nSubject: Your account has been limited\n\nDear Customer,\nVerify within 24 hours or your account will be permanently suspended.\nhttp://paypa1-secure-login.com/verify',
  'From: HR Department <hr@company-payroll.co>\nSubject: Salary revision\n\nOpen the attachment Salary_Revision_2026.pdf.exe and sign in with your Office 365 credentials.',
  'From: SBI Alerts <sbi.alerts.kyc@gmail.com>\nSubject: KYC pending\n\nYour YONO account will be blocked today. Enter your net banking password and OTP to complete KYC.',
  'Authentication-Results: mx.example.in; spf=fail smtp.mailfrom=login-alert.xyz; dkim=none; dmarc=fail\nFrom: "State Bank of India" <alerts@login-alert.xyz>\nSubject: Unusual login\n\nConfirm your identity: https://sbi-secure-verify.login-alert.xyz/netbanking/auth',
];
REAL_EMAILS.forEach((e, i) => test('genuine email is secure #' + i, async () => {
  const r = await auto(e); assert.equal(r.json.detected, 'email'); assert.equal(r.json.verdict, 'SECURE', JSON.stringify(r.json.reasons));
}));
PHISH_EMAILS.forEach((e, i) => test('phishing email is not secure #' + i, async () => {
  const r = await auto(e); assert.equal(r.json.verdict, 'INSECURE', JSON.stringify(r.json));
}));

test('genuine bank OTP SMS is secure, scam SMS is not', async () => {
  assert.equal((await auto('482913 is your OTP for HDFC Bank NetBanking login. Do not share this OTP with anyone. -HDFC Bank')).json.verdict, 'SECURE');
  assert.equal((await auto('Dear customer your electricity connection will be disconnected tonight. Call officer 9876543210 immediately')).json.verdict, 'INSECURE');
});

test('viewer can use the analyzer (it is defensive, not an attack)', async () => {
  assert.equal((await auto('https://www.hdfcbank.com', viewer)).status, 200);
});

test('observatory is the front page and live status is reported in plain words', async () => {
  const home = await api(t.base, 'GET', '/', { cookie: viewer });
  assert.equal(home.status, 200);
  assert.match(home.text, /Cyber Threat Observatory/);
  const st = await api(t.base, 'GET', '/api/live/status', { cookie: viewer });
  assert.equal(st.status, 200);
  assert.ok(Array.isArray(st.json.sources) && Array.isArray(st.json.signals));
  assert.equal((await api(t.base, 'POST', '/api/live/refresh', { cookie: viewer, body: {} })).status, 403);
});

test('analyzer scores never-seen input live (not a lookup table) and says heuristic-only without a Safe Browsing key', async () => {
  const rnd = Math.random().toString(36).slice(2, 9);
  const bad = await auto(`https://hdfc-netbanking-${rnd}.xyz/login`);
  assert.equal(bad.json.verdict, 'INSECURE');
  assert.match(bad.json.engine, /heuristic-only/);
  const good = await auto(`https://www.hdfcbank.com/personal/${rnd}`);
  assert.equal(good.json.verdict, 'SECURE');
  const mail = await auto(`From: Priya <priya@${rnd}-college.edu.in>\nSubject: Notes ${rnd}\n\nHi, sharing the lab notes for ${rnd}. See you Monday.\nThanks`);
  assert.equal(mail.json.verdict, 'SECURE');
  assert.equal(mail.json.detected, 'email');
});
