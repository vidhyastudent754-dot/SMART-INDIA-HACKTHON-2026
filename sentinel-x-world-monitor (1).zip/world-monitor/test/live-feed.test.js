'use strict';
/* Live data feed: stored in SQLite, admin can feed, viewer can read, provenance required. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');

let t, admin, viewer;
test.before(async () => { t = await startApp(); admin = (await login(t.base, 'admin')).cookie; viewer = (await login(t.base, 'viewer')).cookie; });
test.after(async () => { await t.close(); });

test('admin feeds a data point; it is stored and readable by everyone', async () => {
  const r = await api(t.base, 'POST', '/api/feed', { cookie: admin, body: { title: 'NCRP complaints Jan–Jun 2026', value: '12,34,567', unit: 'complaints', geography: 'India', attackId: 'PA-01', sourceUrl: 'https://www.pib.gov.in/PressReleasePage.aspx?PRID=1' } });
  assert.equal(r.status, 201);
  assert.equal(r.json.item.value, 1234567);
  assert.equal(r.json.item.attackName, 'Email phishing');
  const list = await api(t.base, 'GET', '/api/feed?geography=India', { cookie: viewer });
  assert.equal(list.status, 200);
  assert.ok(list.json.items.some((i) => i.title === 'NCRP complaints Jan–Jun 2026'));
  const stats = await api(t.base, 'GET', '/api/feed/stats', { cookie: viewer });
  assert.ok(stats.json.total >= 1);
  const csv = await api(t.base, 'GET', '/api/feed/export.csv', { cookie: viewer });
  assert.match(csv.text, /NCRP complaints Jan–Jun 2026/);
});

test('a source link is required and viewers cannot feed or delete', async () => {
  assert.equal((await api(t.base, 'POST', '/api/feed', { cookie: admin, body: { title: 'No source here' } })).status, 400);
  assert.equal((await api(t.base, 'POST', '/api/feed', { cookie: viewer, body: { title: 'Viewer try', sourceUrl: 'https://example.gov.in/x' } })).status, 403);
  const id = (await api(t.base, 'GET', '/api/feed', { cookie: admin })).json.items[0].id;
  assert.equal((await api(t.base, 'DELETE', '/api/feed/' + id, { cookie: viewer, body: {} })).status, 403);
  assert.equal((await api(t.base, 'DELETE', '/api/feed/' + id, { cookie: admin, body: {} })).status, 200);
});

test('victim age, awareness and official sources endpoints', async () => {
  const age = (await api(t.base, 'GET', '/api/gio/victim-age', { cookie: viewer })).json;
  assert.equal(age.rows.filter((r) => /^(IND|EMP|ORG)-/.test(r.id)).length, 15);
  assert.ok(age.rows.find((r) => r.id === 'PA-01').panels.length > 0);
  assert.ok(age.rows.find((r) => r.id === 'EMP-04').note);
  const aw = (await api(t.base, 'GET', '/api/gio/awareness', { cookie: viewer })).json;
  assert.ok(aw.basic.india.length > 0 && aw.basic.world.length > 0 && aw.social.india.length > 0);
  const os = (await api(t.base, 'GET', '/api/gio/official-sources', { cookie: viewer })).json;
  assert.ok(os.india.length >= 12 && os.world.length >= 12);
});
