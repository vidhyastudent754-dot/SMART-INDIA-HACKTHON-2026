/* test/helpers.js — spin up isolated World Monitor instances on random ports. */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { openDb } = require('../lib/db');
const { seed } = require('../db/seed');
const { createApp } = require('../app');

const PASSWORDS = { admin: 'test-admin-password-1', viewer: 'test-viewer-password-1' };

function tmpDbFile() {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-test-'));
  return path.join(dir, 'test.db');
}

/** Start an app on an ephemeral port. Reuse `dbFile` to simulate a restart. */
async function startApp({ dbFile = tmpDbFile(), config = {} } = {}) {
  const db = openDb(dbFile);
  seed(db, { env: { ADMIN_PASSWORD: PASSWORDS.admin, VIEWER_PASSWORD: PASSWORDS.viewer } });
  const wm = createApp({ db, config: { checkRateMax: 1000, analyzeRateMax: 1000, ...config } });
  const server = await new Promise((resolve) => { const s = wm.app.listen(0, '127.0.0.1', () => resolve(s)); });
  wm.attach(server);
  const base = `http://127.0.0.1:${server.address().port}`;
  return {
    base, db, dbFile, wm,
    async close() {
      wm.close();
      server.closeAllConnections && server.closeAllConnections();
      await new Promise((r) => server.close(r));
      db.close();
    },
  };
}

async function login(base, username, password = PASSWORDS[username]) {
  const r = await fetch(base + '/api/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username, password }),
  });
  const setCookie = r.headers.get('set-cookie') || '';
  return { status: r.status, cookie: setCookie.split(';')[0], body: await r.json() };
}

/** fetch wrapper: JSON in/out, optional cookie + assessment mode. */
async function api(base, method, p, { cookie, body, mode, headers = {} } = {}) {
  const h = { ...headers };
  if (cookie) h.Cookie = cookie;
  if (mode) h['X-Assess-Mode'] = mode;
  const init = { method, headers: h, redirect: 'manual' };
  if (body !== undefined) { h['Content-Type'] = 'application/json'; init.body = JSON.stringify(body); }
  const r = await fetch(base + p, init);
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch { /* not json */ }
  return { status: r.status, json, text, headers: r.headers };
}

module.exports = { startApp, login, api, tmpDbFile, PASSWORDS };
