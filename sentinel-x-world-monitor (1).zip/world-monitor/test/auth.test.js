'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');

let t;
test.before(async () => { t = await startApp(); });
test.after(async () => { await t.close(); });

test('GET / without a session redirects to the login page', async () => {
  const r = await api(t.base, 'GET', '/');
  assert.equal(r.status, 302);
  assert.match(r.headers.get('location'), /^\/login\?next=/);
});

test('static dashboard assets are gated too', async () => {
  assert.equal((await api(t.base, 'GET', '/assessments/live-io.js')).status, 302);
  assert.equal((await api(t.base, 'GET', '/login')).status, 200);
  assert.equal((await api(t.base, 'GET', '/favicon.svg')).status, 200);
});

test('APIs return 401 without a session', async () => {
  assert.equal((await api(t.base, 'GET', '/api/assess/__ping')).status, 401);
  assert.equal((await api(t.base, 'POST', '/api/security/check-url', { body: { url: 'example.com' } })).status, 401);
  assert.equal((await api(t.base, 'GET', '/api/metrics')).status, 401);
});

test('wrong password → 401 with a generic message; employee accounts cannot sign in to the dashboard', async () => {
  const a = await login(t.base, 'admin', 'nope-nope-nope');
  assert.equal(a.status, 401);
  assert.equal(a.body.error, 'Invalid username or password.');
  const b = await login(t.base, 'ghost', 'whatever-password');
  assert.equal(b.body.error, a.body.error, 'unknown user indistinguishable from wrong password');
});

test('session cookie is HttpOnly + SameSite=Strict', async () => {
  const r = await fetch(t.base + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username: 'admin', password: 'test-admin-password-1' }) });
  const c = r.headers.get('set-cookie');
  assert.match(c, /HttpOnly/); assert.match(c, /SameSite=Strict/);
});

test('admin can load the dashboard and run org/employee assessments', async () => {
  const { cookie } = await login(t.base, 'admin');
  assert.equal((await api(t.base, 'GET', '/', { cookie })).status, 200);
  const r = await api(t.base, 'POST', '/api/assess/admin-action', { cookie, mode: 'fixed', body: {} });
  assert.equal(r.json.verdict, 'SECURE');
});

test('viewer: can open the dashboard but cannot run any attack (all assessment endpoints → 403)', async () => {
  const { cookie, body } = await login(t.base, 'viewer');
  assert.equal(body.user.role, 'viewer');
  assert.equal((await api(t.base, 'GET', '/', { cookie })).status, 200);
  for (const [m, p] of [['GET', '/api/assess/user-record?id=U-A'], ['POST', '/api/assess/store-comment'], ['POST', '/api/assess/login-probe'], ['POST', '/api/assess/reset-token'], ['POST', '/api/assess/session-replay'], ['GET', '/api/assess/record/1002'], ['POST', '/api/assess/update-profile'], ['GET', '/api/assess/data-protection'],
    ['POST', '/api/assess/rate-test'], ['POST', '/api/assess/search'], ['GET', '/api/records/1001'], ['GET', '/api/metrics.csv']]) {
    const r = await api(t.base, m, p, { cookie, mode: 'vulnerable', body: m === 'POST' ? {} : undefined });
    assert.equal(r.status, 403, `${m} ${p}`);
  }
});

test('logout revokes the session server-side (replayed cookie is rejected)', async () => {
  const { cookie } = await login(t.base, 'admin');
  assert.equal((await api(t.base, 'GET', '/api/auth/me', { cookie })).status, 200);
  await api(t.base, 'POST', '/api/auth/logout', { cookie, body: {} });
  const r = await api(t.base, 'GET', '/api/auth/me', { cookie });
  assert.equal(r.status, 401);
  assert.equal(r.json.reason, 'revoked');
});

test('repeated failures lock the username (and attempts are logged)', async () => {
  for (let i = 0; i < 5; i++) await login(t.base, 'viewer', 'bad-password-' + i);
  const locked = await login(t.base, 'viewer');         // correct password, still locked
  assert.equal(locked.status, 429);
  const n = t.db.prepare("SELECT COUNT(*) n FROM login_attempts WHERE username = 'viewer' AND success = 0").get().n;
  assert.ok(n >= 6);
});

test('CSRF: state-changing API calls must be JSON', async () => {
  const { cookie } = await login(t.base, 'admin');
  const r = await fetch(t.base + '/api/security/check-url', { method: 'POST',
    headers: { Cookie: cookie, 'Content-Type': 'application/x-www-form-urlencoded' }, body: 'url=example.com' });
  assert.equal(r.status, 415);
});

test('CORS: untrusted origin is rejected; same origin is allowed', async () => {
  const { cookie } = await login(t.base, 'admin');
  const evil = await api(t.base, 'POST', '/api/security/check-url', { cookie, body: { url: 'example.com' }, headers: { Origin: 'http://evil.invalid' } });
  assert.equal(evil.status, 403);
  const same = await api(t.base, 'POST', '/api/security/check-url', { cookie, body: { url: 'example.com' }, headers: { Origin: t.base } });
  assert.equal(same.status, 200);
});

test('lab twins are unreachable from outside the harness, even for an admin', async () => {
  const { cookie } = await login(t.base, 'admin');
  assert.equal((await api(t.base, 'GET', '/api/lab/vulnerable/records/1002', { cookie })).status, 404);
});
