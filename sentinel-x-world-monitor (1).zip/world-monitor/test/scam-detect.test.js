'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');

let t, admin;
test.before(async () => { t = await startApp(); admin = (await login(t.base, 'admin')).cookie; });
test.after(async () => { await t.close(); });
const scan = (type, text, extra) => api(t.base, 'POST', '/api/scam/analyze', { cookie: admin, body: Object.assign({ type, text }, extra || {}) });

const CASES = [
  ['smishing', 'Hi, your Amazon order #123 could not be delivered. Update address: amzn-delivery.top/u', 'INSECURE'],
  ['smishing', 'Hi mom, reached office. Will call at lunch.', 'SECURE'],
  ['vishing', 'Madam I am calling from Amazon, a refund of 4999 is pending, please install the refund app and enter your UPI pin', 'INSECURE'],
  ['vishing', 'Hi this is Ravi from HDFC bank, your credit card bill is due on 5th, you can pay via the app', 'SECURE'],
  ['investment', 'Earn ₹5000 daily from home by trading. Contact our mentor on WhatsApp', 'INSECURE'],
  ['investment', 'Invest 10,000 and get 50,000 in one week. 100% safe. DM now', 'INSECURE'],
  ['prize', 'Your mobile number won £500,000 in the UK National Lottery. Send your name, address and bank account to claim', 'INSECURE'],
  ['prize', 'Thanks for shopping at Amazon, rate your order', 'SECURE'],
  ['smishing', 'SBI: Your account will be blocked today. Share the OTP sent to you with our executive to cancel. bit.ly/sbi-kyc', 'INSECURE', { sender: 'VK-SBIINB' }],
  ['smishing', 'Rs.450.00 debited from a/c **1234 on 25-09-26 to VPA swiggy@icici. Not you? Call 18002586161.', 'SECURE', { sender: 'AD-HDFCBK' }],
  ['email', 'Dear Customer, your SBI account has been suspended due to incomplete KYC. Verify within 24 hours: http://sbi-kyc-update.xyz/verify', 'INSECURE', { sender: 'alerts@sbi-kyc-update.xyz' }],
  ['email', 'Hi team, the sprint review has moved to Thursday 3pm in the usual room. Agenda is in the shared drive. Thanks, Priya', 'SECURE', { sender: 'priya@yourcompany.com' }],
  ['vishing', 'This is Inspector Sharma from CBI cyber cell. You are under digital arrest. Stay on the video call. Transfer Rs 2,50,000 to the verification account.', 'INSECURE'],
  ['vishing', 'Hello, I have your Amazon parcel, I am near the gate. Should I leave it with security?', 'SECURE'],
  ['investment', 'Join our VIP Telegram group! Guaranteed 5% daily returns on crypto. Double your money in 20 days, zero risk.', 'INSECURE'],
  ['investment', 'Your SIP of ₹5,000 in XYZ Flexicap Fund (SEBI registered AMC) will be debited on 5 Oct.', 'SECURE'],
  ['prize', 'Congratulations! You won ₹25 lakh in KBC Lucky Draw. Pay processing fee ₹12,500 and send Aadhaar and bank details.', 'INSECURE'],
  ['prize', 'You earned 120 reward points on your purchase at DMart.', 'SECURE'],
  ['payment', 'PhonePe\nPayment Pending\n₹15,000\nUTR: 12345678\n27 Dec 2030, 10:75 AM', 'INSECURE', { expectedAmount: '15000' }],
  ['payment', 'Google Pay\nPayment successful\n₹1,250\nTo: ramesh.k@okaxis\nUPI transaction ID: 426912345871\n24 Sep 2026, 7:42 PM', 'SECURE'],
];
for (const [type, text, want, extra] of CASES) {
  test(`${type}: ${want} — ${text.slice(0, 40)}`, async () => {
    const r = await scan(type, text, extra);
    assert.equal(r.status, 200);
    assert.equal(r.json.verdict, want, JSON.stringify(r.json.reasons));
    assert.ok(r.json.advice);
    if (want === 'INSECURE') assert.ok(r.json.reasons.length > 0);
  });
}

async function upload(type, name, buf) {
  return (await api(t.base, 'POST', '/api/scam/file', { cookie: admin, body: { type, name, dataBase64: buf.toString('base64') } })).json;
}
test('attachment: disguised executable is INSECURE, plain text is SECURE', async () => {
  const bad = await upload('attachment', 'invoice.pdf.exe', Buffer.from('MZ\x90\x00' + 'x'.repeat(60), 'latin1'));
  assert.equal(bad.verdict, 'INSECURE'); assert.equal(bad.file.detectedType, 'windows-executable');
  assert.match(bad.file.sha256, /^[a-f0-9]{64}$/);
  const hidden = await upload('attachment', 'photo.jpg', Buffer.from('MZ\x90\x00' + 'x'.repeat(60), 'latin1'));
  assert.ok(hidden.reasons.some((r) => r.signal === 'hidden-executable'));
  const ok = await upload('attachment', 'notes.txt', Buffer.from('Meeting notes'));
  assert.equal(ok.verdict, 'SECURE');
});
test('payment screenshot: editing-app metadata is flagged', async () => {
  const png = Buffer.concat([Buffer.from('89504e470d0a1a0a0000000d49484452000002d0000005a0', 'hex'), Buffer.from('tEXtSoftware\x00Adobe Photoshop 25.0', 'latin1')]);
  const r = await upload('payment', 'shot.png', png);
  assert.ok(r.reasons.some((x) => x.signal === 'edited'));
  assert.equal(r.image.format, 'PNG');
});
test('scam API requires a session', async () => {
  const r = await fetch(t.base + '/api/scam/analyze', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{"type":"prize","text":"x"}' });
  assert.equal(r.status, 401);
});
test('smishing: electricity-disconnection scam is INSECURE', async () => {
  const r = await scan('smishing', 'Dear consumer, your electricity will be disconnected tonight at 9:30 PM as previous month bill was not updated. Please call our officer 9876543210 immediately.', { sender: '+91 98765 43210' });
  assert.equal(r.json.verdict, 'INSECURE');
});
