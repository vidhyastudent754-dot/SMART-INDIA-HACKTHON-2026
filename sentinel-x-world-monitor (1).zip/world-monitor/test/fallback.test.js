'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, api } = require('./helpers');

test('with auth disabled, EMP-04/EMP-09 use the simulated fallback and still disagree correctly', async () => {
  const t = await startApp({ config: { authDisabled: true } });
  try {
    const hdr = { 'X-Assess-User': 'EMP-A' };
    const v = await api(t.base, 'GET', '/api/assess/record/1002', { mode: 'vulnerable', headers: hdr });
    const f = await api(t.base, 'GET', '/api/assess/record/1002', { mode: 'fixed', headers: hdr });
    assert.equal(v.json.path, 'simulated');
    assert.equal(v.json.verdict, 'VULNERABLE'); assert.equal(f.json.verdict, 'SECURE');
    const m = await api(t.base, 'POST', '/api/assess/update-profile', { mode: 'vulnerable', body: { role: 'admin' } });
    assert.equal(m.json.path, 'simulated'); assert.equal(m.json.verdict, 'VULNERABLE');
  } finally { await t.close(); }
});
