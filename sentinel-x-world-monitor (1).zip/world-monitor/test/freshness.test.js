'use strict';
/* Observatory refresh interval: 30-min request, floored by NVD's 2-hour polling guidance. */
const test = require('node:test');
const assert = require('node:assert/strict');
const { refreshIntervalMs, DEFAULT_REFRESH_MS, MIN_REFRESH_MS, THIRTY_MIN, TWO_HOURS } = require('../lib/observatory-cache');
const quiet = { warn: () => {} };

test('default is the longest documented source limit (NVD, 2 h), not 30 min', () => {
  assert.equal(THIRTY_MIN, 30 * 60 * 1000);
  assert.equal(MIN_REFRESH_MS, TWO_HOURS);
  assert.equal(DEFAULT_REFRESH_MS, 7200000);
  assert.equal(refreshIntervalMs({}, quiet), 7200000);
});
test('OBSERVATORY_REFRESH_MS lengthens the interval but cannot go below 2 h', () => {
  assert.equal(refreshIntervalMs({ OBSERVATORY_REFRESH_MS: '10800000' }, quiet), 10800000);
  assert.equal(refreshIntervalMs({ OBSERVATORY_REFRESH_MS: String(THIRTY_MIN) }, quiet), TWO_HOURS);
  assert.equal(refreshIntervalMs({ OBSERVATORY_REFRESH_MS: 'abc' }, quiet), DEFAULT_REFRESH_MS);
});
test('README freshness table states the intervals the code uses', () => {
  const md = require('fs').readFileSync(require('path').join(__dirname, '..', 'README.md'), 'utf8');
  for (const s of ['7 200 000 ms (2 h)', '3600 s', '7200 s', '1800 s', '600 000 ms (10 min)', '4000 ms', '## Data freshness']) assert.ok(md.includes(s), 'README missing: ' + s);
  assert.equal(require('../lib/fabric/registry').SOURCES.find((x) => x.id === 'cisa-kev').pollIntervalSec, 3600);
  assert.equal(require('../lib/fabric/registry').SOURCES.find((x) => x.id === 'nvd-cve').pollIntervalSec, 7200);
  assert.equal(require('../lib/fabric/registry').SOURCES.find((x) => x.id === 'certin-vulnotes').pollIntervalSec, 1800);
});
