'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api, tmpDbFile } = require('./helpers');

test('state survives a server restart', async () => {
  const dbFile = tmpDbFile();

  // ---- first run
  let t = await startApp({ dbFile });
  const { cookie } = await login(t.base, 'admin');
  const tok = { token: 'reset-restart-test', elapsedMinutes: 0 };
  const first = await api(t.base, 'POST', '/api/assess/reset-token', { cookie, mode: 'fixed', body: tok });
  assert.equal(first.json.detail.firstUse.ok, true, 'fresh token accepted once');
  const rl1 = await api(t.base, 'POST', '/api/assess/rate-test', { cookie, mode: 'fixed', body: { requestCount: 3, windowSeconds: 600 } });
  assert.equal(rl1.json.detail.blocked, 0);
  await api(t.base, 'POST', '/api/security/analyze-sms', { cookie, body: { body: 'WINNER! claim your free prize now call 09061701461' } });
  const beforeChecks = (await api(t.base, 'GET', '/api/activity', { cookie })).json.totals.checks;
  const port1 = t.base;
  await t.close();

  // ---- restart on the same database file
  t = await startApp({ dbFile });
  assert.notEqual(t.base, port1);
  // 1. the login session is still valid
  const me = await api(t.base, 'GET', '/api/auth/me', { cookie });
  assert.equal(me.status, 200, 'dashboard session survived restart');
  // 2. the reset token is still marked used
  const again = await api(t.base, 'POST', '/api/assess/reset-token', { cookie, mode: 'fixed', body: tok });
  assert.equal(again.json.detail.issuedThisRequest, false);
  assert.equal(again.json.detail.firstUse.ok, false);
  assert.match(again.json.detail.firstUse.why, /already used/);
  // 3. the rate-limit window kept counting (3 before restart + 3 now → 1 blocked at limit 5)
  const rl2 = await api(t.base, 'POST', '/api/assess/rate-test', { cookie, mode: 'fixed', body: { requestCount: 3, windowSeconds: 600 } });
  assert.equal(rl2.json.detail.bucketCount, 6);
  assert.equal(rl2.json.detail.blocked, 1);
  // 4. live activity counters kept their history
  const after = (await api(t.base, 'GET', '/api/activity', { cookie })).json.totals.checks;
  assert.equal(after, beforeChecks);
  await t.close();
});
