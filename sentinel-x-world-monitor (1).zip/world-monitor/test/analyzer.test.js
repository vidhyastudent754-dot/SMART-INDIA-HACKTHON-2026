'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { analyzeEmail, analyzeSms } = require('../analyzer');
const hybrid = require('../lib/hybrid');

const SBI = 'Dear Customer,\nYour SBI Net Banking account has been suspended due to unauthorized access. ' +
  'You must verify your identity within 24 hours or your account will be permanently locked. ' +
  'Click here: https://sbi-secure-verify.login-alert.xyz/netbanking/auth and enter your password and OTP.';

test('urgency patterns are detected', () => {
  const r = analyzeEmail('Please respond immediately, this offer expires within 2 hours. Act now!');
  assert.ok(r.signals.some((s) => s.category === 'URGENCY'));
});

test('threat patterns are detected', () => {
  const r = analyzeEmail('We detected unauthorized access. Your account will be suspended.');
  assert.ok(r.signals.some((s) => s.category === 'THREAT'));
});

test('sensitive-data requests are detected', () => {
  const r = analyzeSms('Share your OTP and UPI PIN to receive the refund');
  assert.ok(r.signals.some((s) => s.category === 'DATA_REQUEST'));
});

test('brand + threat = impersonation; free-mail sender mismatch', () => {
  const r = analyzeEmail(SBI, 'sbi.security@gmail.com');
  const cats = r.signals.map((s) => s.category);
  assert.ok(cats.includes('BRAND_IMPERSONATION'));
  assert.ok(cats.includes('SENDER_MISMATCH'));
  assert.equal(r.verdict, 'PHISHING');
});

test('an ordinary message is LIKELY_SAFE', () => {
  const r = analyzeEmail('Hi team, attaching the minutes from today. Thanks, Priya');
  assert.equal(r.verdict, 'LIKELY_SAFE');
  assert.equal(r.riskScore, 0);
});

test('too-short input is rejected', () => {
  assert.equal(analyzeEmail('hi').ok, false);
  assert.equal(analyzeSms('').ok, false);
});

test('hybrid result exposes heuristicScore, mlScore and the documented 60/40 blend', () => {
  const r = hybrid.analyze('email', SBI);
  assert.equal(r.engine, 'hybrid');
  for (const k of ['heuristicScore', 'mlScore', 'combinedConfidence']) assert.equal(typeof r[k], 'number', k);
  assert.equal(r.combinedConfidence, Math.round(0.6 * r.heuristicScore + 0.4 * r.mlScore));
  assert.equal(r.verdict, 'PHISHING');
  assert.ok(r.ml.topSignals.length > 0);
});

test('ML alone can never produce the strongest verdict (heuristic 0 → max combined 40)', () => {
  // Commercial-sounding text with no rule hits: the model may score it high,
  // but the verdict must stay below PHISHING.
  const r = hybrid.analyze('email', 'Your Flipkart order of boAt earphones has been delivered. Rate your experience in the app.');
  assert.equal(r.heuristicScore, 0);
  assert.ok(r.combinedConfidence <= 40);
  assert.notEqual(r.verdict, 'PHISHING');
});

test('ML catches a scam the rules miss', () => {
  const r = hybrid.analyze('sms', 'Dear user your electricity bill is unpaid. Power will be disconnected tonight at 9.30pm. Contact officer 9123456780 immediately');
  assert.equal(r.heuristicVerdict, 'LIKELY_SAFE');
  assert.equal(r.verdict, 'SUSPICIOUS');
});
