'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const ml = require('../lib/ml');
const parity = require('./fixtures/ml-parity.json');

test('tokenizer: placeholders, lowercasing, bigrams', () => {
  const t = ml.tokenize('Visit https://x.io NOW, pay ₹500 to a@b.co');
  assert.deepEqual(t.slice(0, 7), ['visit', 'zzurl', 'now', 'pay', 'zzmoney', 'zznum', 'to']);
  assert.ok(t.includes('visit zzurl'));
  assert.ok(t.includes('zzemail'));
});

for (const name of ['email', 'sms']) {
  test(`${name} model: JS scorer reproduces sklearn probabilities (parity)`, () => {
    const model = ml.models()[name];
    assert.ok(model, 'model loaded');
    for (const { text, p } of parity[name]) {
      const got = ml.score(model, text).probability;
      assert.ok(Math.abs(got - p) < 1e-4, `|${got} - ${p}| too large for: ${text.slice(0, 60)}`);
    }
  });

  test(`${name} model: held-out metrics are recorded and meet the bar`, () => {
    const m = ml.models()[name].metrics;
    assert.ok(m.f1 >= 0.95 && m.precision >= 0.95 && m.recall >= 0.94, JSON.stringify(m));
  });
}

test('scores are explainable: top signals carry a signed contribution and label', () => {
  const r = ml.score(ml.models().sms, 'WINNER!! claim your free prize now, call 09061701461');
  assert.ok(r.score > 90);
  assert.ok(r.topSignals[0].label && typeof r.topSignals[0].contribution === 'number');
});
