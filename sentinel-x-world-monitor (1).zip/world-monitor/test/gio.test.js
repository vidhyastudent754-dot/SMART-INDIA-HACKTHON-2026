'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { startApp, login, api } = require('./helpers');
const { createGiObservatory, parseCsv } = require('../lib/gi-observatory');

let t, admin;
test.before(async () => { t = await startApp(); admin = (await login(t.base, 'admin')).cookie; });
test.after(async () => { await t.close(); });
const get = (p) => api(t.base, 'GET', p, { cookie: admin });

test('dataset integrity: every fact has an http source URL and a catalogued source', () => {
  const g = createGiObservatory();
  assert.ok(g.facts.length >= 200, 'facts=' + g.facts.length);
  assert.ok(g.sources.length >= 20, 'sources=' + g.sources.length);
  const ids = new Set(g.sources.map((s) => s.source_id));
  for (const f of g.facts) {
    assert.ok(/^https?:\/\//.test(f.source_url), f.fact_id + ' has no URL');
    assert.ok(ids.has(f.source_id), f.fact_id + ' source not catalogued: ' + f.source_id);
  }
  const uniq = new Set(g.facts.map((f) => f.fact_id));
  assert.equal(uniq.size, g.facts.length, 'duplicate fact_id');
});

test('no illustrative / estimated values slipped in as facts', () => {
  const g = createGiObservatory();
  for (const f of g.facts) {
    assert.ok(!/^~|illustrative|\?\s*$/i.test(f.value), f.fact_id + ' looks illustrative: ' + f.value);
    if (/forecast|estimate/i.test(f.verification_note)) assert.match(f.fact_id, /^EST-/, 'estimates must be EST- prefixed: ' + f.fact_id);
  }
});

test('csv parser handles quoted commas and escaped quotes', () => {
  const r = parseCsv('a,b\n"x, y","he said ""hi"""\n');
  assert.deepEqual(r, [{ a: 'x, y', b: 'he said "hi"' }]);
});

test('GET /api/gio/summary returns real India + world KPIs with sources', async () => {
  const r = await get('/api/gio/summary');
  assert.equal(r.status, 200);
  const india = r.json.india.find((k) => k.id === 'NCRP-complaints-2024');
  assert.equal(india.value, '2268346');
  assert.match(india.sourceUrl, /mha\.gov\.in/);
  assert.ok(r.json.global.find((k) => k.id === 'IC3-total').sourceUrl.includes('ic3.gov'));
});

test('categories: all 8 scam types + 15 SENTINEL-X attacks, each backed by real facts', async () => {
  const r = await get('/api/gio/categories');
  assert.equal(r.json.categories.length, 23);
  for (const c of r.json.categories) assert.ok(c.facts.length > 0, c.id + ' has no facts');
  const vish = r.json.categories.find((c) => c.id === 'vishing');
  assert.equal(vish.requestedFields['financial loss'].id, 'IC3-callcenter-loss');
  assert.equal(vish.requestedFields['attacker teams / red teams'].status, 'NOT_PUBLISHED');
});

test('India: lifecycle is real, pending is NOT_PUBLISHED (never zero)', async () => {
  const r = await get('/api/gio/india');
  assert.ok(r.json.fraudLifecycle2023.find((f) => f.id === 'NCRB-2023-Fraud persons arrested').value === '3650');
  assert.equal(r.json.pending.status, 'NOT_PUBLISHED');
  assert.equal(r.json.ncrpComplaints.length, 4);
});

test('compare: consistent per-column sources; absent countries are NOT_PUBLISHED not zero', async () => {
  const r = await get('/api/gio/compare');
  assert.equal(r.json.rows.length, 17);
  const india = r.json.rows.find((x) => x.country === 'India');
  assert.equal(india.ic3Complaints.value, '4189');
  assert.equal(india.wciRank.value, '10');
  const russia = r.json.rows.find((x) => x.country === 'Russia');
  assert.equal(russia.ic3Complaints.status, 'NOT_PUBLISHED');
  assert.equal(russia.wciRank.value, '1');
  assert.match(r.json.methodology, /NOT summed/);
});

test('age bands are complainant ages (labelled), enforcement exposes team gaps honestly', async () => {
  const a = await get('/api/gio/age');
  assert.equal(a.json.ic3.length, 12);
  assert.match(a.json.note, /not attacker targeting/i);
  const e = await get('/api/gio/enforcement');
  assert.equal(e.json.redTeams.status, 'NOT_PUBLISHED');
  assert.equal(e.json.attackerTeams.status, 'NOT_PUBLISHED');
});

test('facts.csv export keeps provenance columns', async () => {
  const r = await get('/api/gio/facts.csv');
  assert.equal(r.status, 200);
  assert.match(r.text.split('\n')[0], /fact_id,source_id,.*source_url,verification_note/);
});

test('observatory API requires a session', async () => {
  const r = await fetch(t.base + '/api/gio/summary');
  assert.equal(r.status, 401);
});

test('observatory page exists; old world-monitor page and Live Threat Feed tab are gone', () => {
  const pub = path.join(__dirname, '..', 'public');
  assert.ok(fs.existsSync(path.join(pub, 'observatory.html')));
  assert.ok(!fs.existsSync(path.join(pub, 'world-monitor.html')));
  const nav = fs.readFileSync(path.join(pub, 'index.html'), 'utf8').match(/<nav id="sx-tabbar"[\s\S]*?<\/nav>/)[0];
  assert.ok(nav.includes('/observatory.html'));
  assert.ok(!/Live Threat Feed|world-monitor\.html/.test(nav));
});

test('attack tables: 12 scam rows + 15 application attacks, gaps are NOT_PUBLISHED', async () => {
  const r = await get('/api/gio/attack-tables');
  assert.equal(r.json.scams.length, 12);
  assert.equal(r.json.application.length, 15);
  for (const row of r.json.application) assert.equal(row.realWorldCases.status, 'NOT_PUBLISHED');
  const all = r.json.scams.find((x) => x.arrests && x.arrests.value === '3650');
  assert.ok(all, 'India NCRB fraud arrests row present');
});

test('countries: ranked by GI-TOC cyber score with sources; India 7.5, Afghanistan 4.0', async () => {
  const r = await get('/api/gio/countries');
  const scored = r.json.countries.filter((c) => c.cyberScore && c.cyberScore.numeric != null);
  for (let i = 1; i < scored.length; i++) assert.ok(scored[i - 1].cyberScore.numeric >= scored[i].cyberScore.numeric);
  assert.equal(r.json.countries.find((c) => c.country === 'India').cyberScore.value, '7.5');
  assert.equal(r.json.countries.find((c) => c.country === 'Afghanistan').cyberScore.value, '4.0');
  for (const c of scored) assert.match(c.cyberScore.sourceUrl, /ocindex\.net/);
});

test('CSV exports download with provenance', async () => {
  for (const n of ['attacks-scams', 'attacks-application', 'countries', 'sources']) {
    const r = await fetch(t.base + '/api/gio/export/' + n + '.csv', { headers: { cookie: admin } });
    assert.equal(r.status, 200, n);
    assert.match(r.headers.get('content-disposition') || '', /attachment/);
    const txt = await r.text(); assert.ok(txt.split('\n').length > 10, n);
    assert.match(txt, /https?:\/\//);
  }
});

test('age targeting: every attack row states an age group; IC3 60+ shares are computed from real facts', async () => {
  const r = await get('/api/gio/attack-tables');
  for (const row of r.json.scams.concat(r.json.application)) assert.ok(row.ageTarget && row.ageTarget.group && row.ageTarget.summary, row.id);
  const prize = r.json.scams.find((x) => x.id === 'fake-prize');
  assert.equal(prize.ageTarget.share60Complaints, 46.4);
  assert.match(prize.ageTarget.sourceUrl, /ic3\.gov/);
  assert.equal(r.json.scams.find((x) => x.id === 'fake-payment-screenshot').ageTarget.group, 'Not published');
});
