'use strict';
/* Real-Time Verified Fabric — all data here is SYNTHETIC (environment=synthetic,
 * CVE-2099-* identifiers) or the recorded CERT-In fixture. No network access. */
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const { startApp, login, api } = require('./helpers');
const { assertFetchAllowed, SOURCES, validateRegistry } = require('../lib/fabric/registry');

const T0 = Date.parse('2026-09-25T10:00:00Z');
let clock = T0;
const routes = {};                                     // host -> () => ({ status, body })
const mockFetch = async (url) => {
  const h = new URL(url).hostname;
  if (!routes[h]) throw new Error('ECONNREFUSED (mock: no route)');
  const r = routes[h](url);
  if (r.throw) throw new Error(r.throw);
  return { ok: r.status >= 200 && r.status < 300, status: r.status, text: async () => r.body };
};
const entry = (n, dateAdded, extra = {}) => ({ cveID: `CVE-2099-${1000 + n}`, vendorProject: 'SyntheticVendor', product: `SyntheticProduct${n}`,
  vulnerabilityName: `Synthetic test entry ${n}`, dateAdded, shortDescription: 'SYNTHETIC TEST FIXTURE', requiredAction: 'n/a', dueDate: '2099-01-01',
  knownRansomwareCampaignUse: 'Unknown', notes: '', cwes: ['CWE-79'], ...extra });
const kev = (entries, count) => JSON.stringify({ title: 'SYNTHETIC', catalogVersion: '2099.01.01', dateReleased: '2026-09-25T00:00:00Z', count: count == null ? entries.length : count, vulnerabilities: entries });
const OLD = Array.from({ length: 40 }, (_, i) => entry(i, '2025-0' + (1 + (i % 9)) + '-10'));
const FIX = (f) => fs.readFileSync(path.join(__dirname, '..', 'db', 'fabric', 'fixtures', f), 'utf8');

let t, admin, viewer;
const run = (sourceId, extra = {}) => api(t.base, 'POST', '/api/v1/admin/ingestion/run', { cookie: admin, body: { sourceId, ...extra } });
test.before(async () => {
  t = await startApp({ config: { fabric: { environment: 'synthetic', fetchImpl: mockFetch, now: () => clock, retries: 0, retryBaseMs: 0, pageDelayMs: 0 } } });
  admin = (await login(t.base, 'admin')).cookie;
  viewer = (await login(t.base, 'viewer')).cookie;
});
test.after(async () => { await t.close(); });

test('registry is valid and the SSRF guard refuses non-HTTPS and unapproved hosts', () => {
  assert.deepEqual(validateRegistry(), []);
  const kevSrc = SOURCES.find((s) => s.id === 'cisa-kev');
  assert.throws(() => assertFetchAllowed(kevSrc, 'http://www.cisa.gov/x'), /not HTTPS/);
  assert.throws(() => assertFetchAllowed(kevSrc, 'https://evil.example/x'), /not approved/);
  assert.throws(() => assertFetchAllowed(kevSrc, 'https://user:pw@www.cisa.gov/x'), /credentials/);
  assert.ok(assertFetchAllowed(kevSrc, 'https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json'));
});

test('no fabrication: before any retrieval the feed is empty and every source is "unavailable"', async () => {
  const feed = await api(t.base, 'GET', '/api/v1/observatory/feed', { cookie: viewer });
  assert.equal(feed.json.data.length, 0);
  const srcs = (await api(t.base, 'GET', '/api/v1/observatory/sources', { cookie: viewer })).json.data;
  assert.equal(srcs.find((s) => s.id === 'cisa-kev').freshness.state, 'unavailable');
  assert.equal(srcs.find((s) => s.id === 'mha-lsusq-452').freshness.state, 'periodic');
});

test('ingestion: viewer 403, unknown 404, candidate source 409', async () => {
  assert.equal((await api(t.base, 'POST', '/api/v1/admin/ingestion/run', { cookie: viewer, body: { sourceId: 'cisa-kev' } })).status, 403);
  assert.equal((await run('nope')).status, 404);
  assert.equal((await run('certin-advisories')).status, 409);
});

test('KEV baseline ingestion: receipt hashed and stored, events marked backfill, only recent entries alert', async () => {
  const recent = entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] });
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, recent]) });
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.outcome, 'validated');
  assert.equal(r.created, 41);
  assert.equal(r.backfill, true);
  const rec = t.db.prepare('SELECT * FROM fabric_receipts WHERE id = ?').get(r.receiptId);
  assert.match(rec.content_hash, /^[0-9a-f]{64}$/);
  assert.ok(rec.raw_gz.length > 0);
  const alerts = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((a) => a.ruleId === 'kev_new_exploited');
  assert.equal(alerts.length, 1, 'only the entry added within 72 h alerts during backfill');
  assert.equal(alerts[0].level, 'critical');                       // known ransomware use
  assert.match(alerts[0].explanation, /not an incident report/);
  assert.deepEqual(alerts[0].sections, [3]);                        // CWE-89 → Section 3 (exact)
  assert.ok(alerts[0].evidence.events[0].contentHash);
});

test('idempotency: an identical response is "unchanged" and creates nothing', async () => {
  const before = t.db.prepare('SELECT COUNT(*) n FROM fabric_events').get().n;
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.outcome, 'unchanged');
  assert.equal(t.db.prepare('SELECT COUNT(*) n FROM fabric_events').get().n, before);
});

test('corrections are versioned, never overwritten', async () => {
  const changed = OLD.map((e, i) => (i === 3 ? { ...e, vulnerabilityName: 'Synthetic test entry 3 (corrected)' } : e));
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...changed, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] })]) });
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.corrected, 1);
  const versions = t.db.prepare("SELECT version, superseded_by FROM fabric_events WHERE native_id = 'CVE-2099-1003' ORDER BY version").all();
  assert.equal(versions.length, 2);
  assert.ok(versions[0].superseded_by);
  assert.equal(versions[1].superseded_by, null);
  assert.ok(t.db.prepare("SELECT 1 FROM fabric_audit WHERE action = 'event.corrected'").get());
});

test('a new entry after the baseline raises a deduplicated, evidence-linked alert', async () => {
  const fresh = entry(901, '2026-09-25', { cwes: ['CWE-639'] });
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), fresh]) });
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.created, 1);
  assert.equal(r.backfill, false);
  let a = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((x) => x.title.includes('CVE-2099-1901'));
  assert.equal(a.length, 1);
  assert.equal(a[0].level, 'high');
  assert.deepEqual(a[0].sections, [2]);                             // CWE-639 (IDOR) → Section 2, exact via EMP-01/EMP-04
  await run('cisa-kev', { force: true });                          // same content again
  a = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((x) => x.title.includes('CVE-2099-1901'));
  assert.equal(a.length, 1, 'deduplicated');
});

test('record-level quality gates quarantine bad records instead of dropping them', async () => {
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), entry(901, '2026-09-25', { cwes: ['CWE-639'] }),
    entry(902, '2031-01-01'), { ...entry(903, '2026-09-20'), cveID: 'not-a-cve' }]) });
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.quarantined, 2);
  const q = (await api(t.base, 'GET', '/api/v1/admin/quarantine', { cookie: admin })).json.data;
  assert.ok(q.some((x) => /future event time/.test(x.reason)));
  assert.ok(q.some((x) => /malformed cveID/.test(x.reason)));
  assert.equal(t.db.prepare("SELECT COUNT(*) n FROM fabric_events WHERE native_id = 'CVE-2099-1902'").get().n, 0);
});

test('an unexplained catalogue shrink is quarantined until an admin releases it with a note', async () => {
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev(OLD.slice(0, 20)) });
  const r = (await run('cisa-kev')).json.data;
  assert.equal(r.outcome, 'quarantined');
  assert.match(r.error, /count decrease/);
  const item = (await api(t.base, 'GET', '/api/v1/admin/quarantine', { cookie: admin })).json.data.find((x) => /count decrease/.test(x.reason));
  assert.equal((await api(t.base, 'POST', `/api/v1/admin/quarantine/${item.id}`, { cookie: admin, body: { action: 'release' } })).status, 400, 'note required');
  assert.equal((await api(t.base, 'POST', `/api/v1/admin/quarantine/${item.id}`, { cookie: admin, body: { action: 'release', note: 'Confirmed on cisa.gov' } })).status, 200);
  assert.equal((await run('cisa-kev', { force: true })).json.data.outcome, 'validated');
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), entry(901, '2026-09-25', { cwes: ['CWE-639'] })]) });
  await run('cisa-kev', { force: true });
});

test('freshness states: live → cached after a failure → stale past the maximum age', async () => {
  const state = async () => (await api(t.base, 'GET', '/api/v1/observatory/sources', { cookie: viewer })).json.data.find((s) => s.id === 'cisa-kev').freshness;
  assert.equal((await state()).state, 'live');
  routes['www.cisa.gov'] = () => ({ status: 200, body: '{not json' });
  assert.equal((await run('cisa-kev', { force: true })).json.data.outcome, 'quarantined');
  assert.equal((await state()).state, 'cached');
  clock += 25 * 3600e3;
  assert.equal((await state()).state, 'stale');
  clock = T0 + 60e3;
});

test('source outage raises a data-availability alert and auto-resolves on recovery', async () => {
  routes['www.cisa.gov'] = () => ({ throw: 'ECONNRESET' });
  for (let i = 0; i < 3; i++) await run('cisa-kev', { force: true });
  let open = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((a) => a.ruleId === 'source_health' && a.state === 'new');
  assert.equal(open.length, 1);
  assert.match(open[0].explanation, /not a security incident/);
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), entry(901, '2026-09-25', { cwes: ['CWE-639'] }), entry(904, '2026-09-25')]) });
  await run('cisa-kev', { force: true });
  const all = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((a) => a.ruleId === 'source_health');
  assert.equal(all[0].state, 'resolved');
});

test('CERT-In recorded replay: step 1 backfills, step 2 delivers the 4 newest notes as new events', async () => {
  let step = 1;
  routes['www.cert-in.org.in'] = () => ({ status: 200, body: FIX(`certin-vulnotes-2026-09-25.step${step}.html`) });
  const a = (await run('certin-vulnotes')).json.data;
  assert.equal(a.created, 16);
  step = 2;
  const b = (await run('certin-vulnotes')).json.data;
  assert.equal(b.created, 4);
  assert.equal(b.backfill, false);
  const note = t.db.prepare("SELECT * FROM fabric_events WHERE native_id = 'CIVN-2026-0473'").get();
  assert.equal(note.event_time, '2026-09-24');
  assert.match(note.source_timezone, /Asia\/Kolkata/);
  assert.equal(JSON.parse(note.sections_json).status, 'partial');     // title-based, never exact
  const alerts = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((x) => x.ruleId === 'certin_high_impact_note');
  assert.ok(alerts.some((x) => x.title.includes('CIVN-2026-0473')));   // "Command Injection" → elevated
  assert.ok(alerts.every((x) => /not a report that an attack occurred/.test(x.explanation)));
});

test('overview: bySection splits real-time signals into India (CERT-In) vs World (CISA/NVD), never merged', async () => {
  const r = await api(t.base, 'GET', '/api/v1/observatory/overview', { cookie: viewer });
  assert.equal(r.status, 200);
  assert.ok(Array.isArray(r.json.data.bySection) && r.json.data.bySection.length === 3);
  for (const row of r.json.data.bySection) {
    assert.ok([1, 2, 3].includes(row.section));
    assert.deepEqual(row.india.sources, ['certin-vulnotes']);
    assert.deepEqual(row.world.sources.slice().sort(), ['cisa-kev', 'nvd-cve']);
    assert.equal(row.signals7d, row.india.signals7d + row.world.signals7d, 'the split must add back up to the unlabelled total');
  }
  // Both feeds already ingested earlier in this file: India (CERT-In) and World (CISA KEV) each contributed
  // recent, in-window events, so both sides of the split are non-zero — this is not a placeholder shape.
  const withIndiaSignal = r.json.data.bySection.filter((x) => x.india.signals7d > 0);
  const withWorldSignal = r.json.data.bySection.filter((x) => x.world.signals7d > 0);
  assert.ok(withIndiaSignal.length > 0, 'India (CERT-In) should show at least one section with real-time signals');
  assert.ok(withWorldSignal.length > 0, 'World (CISA/NVD) should show at least one section with real-time signals');
  assert.ok(withIndiaSignal[0].india.lastSignalAt, 'a non-zero count must carry a last-signal timestamp');
  assert.match(r.json.meta.warnings.join(' '), /India vs World signal counts/);
});

test('feed: section filter, pagination, provenance and meta envelope', async () => {
  const r = await api(t.base, 'GET', '/api/v1/observatory/feed?section=1&pageSize=5&page=1', { cookie: viewer });
  assert.equal(r.status, 200);
  for (const k of ['mode', 'environment', 'queryTimestamp', 'filters', 'sourceCoverage', 'cacheState', 'warnings', 'pagination']) assert.ok(k in r.json.meta, k);
  assert.equal(r.json.meta.filters.section, 1);
  assert.ok(r.json.data.length <= 5);
  assert.ok(r.json.data.every((e) => e.mapping.sections.includes(1)));
  assert.ok(r.json.data[0].provenance.contentHash && r.json.data[0].provenance.retrievedAt);
  assert.equal(r.json.data[0].geography.attacker, null);
  const ev = await api(t.base, 'GET', `/api/v1/observatory/events/${r.json.data[0].id}`, { cookie: viewer });
  assert.ok(ev.json.data.versions.length >= 1);
});

test('SSE: live delivery, then resume with Last-Event-ID delivers only what was missed', async () => {
  const read = async (headers, until) => {
    const ctl = new AbortController();
    const res = await fetch(t.base + '/api/v1/stream', { headers: { Cookie: admin, ...headers }, signal: ctl.signal });
    const reader = res.body.getReader(); const dec = new TextDecoder(); let buf = '';
    const deadline = Date.now() + 4000;
    while (Date.now() < deadline && !until(buf)) { const { value, done } = await reader.read(); if (done) break; buf += dec.decode(value); }
    ctl.abort();
    return buf;
  };
  const head = t.wm.fabric.maxSeq();
  const p = read({}, (b) => /event: ingestion\.batch/.test(b));
  await new Promise((r) => setTimeout(r, 150));
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), entry(901, '2026-09-25', { cwes: ['CWE-639'] }), entry(904, '2026-09-25'), entry(905, '2026-09-25')]) });
  await run('cisa-kev', { force: true });
  const live = await p;
  assert.match(live, /event: hello/);
  assert.match(live, /event: event\.new/);
  const resumed = await read({ 'Last-Event-ID': String(head) }, (b) => /event: ingestion\.batch/.test(b));
  const ids = [...resumed.matchAll(/^id: (\d+)/gm)].map((m) => Number(m[1]));
  assert.ok(ids.length > 0 && ids.every((i) => i > head), 'only events after the given id');
  assert.equal(new Set(ids).size, ids.length, 'no duplicates');
});

test('alert lifecycle: RBAC, valid/invalid transitions, tamper-evident audit', async () => {
  const a = (await api(t.base, 'GET', '/api/v1/alerts?state=new', { cookie: viewer })).json.data[0];
  assert.equal((await api(t.base, 'POST', `/api/v1/alerts/${a.id}/state`, { cookie: viewer, body: { state: 'acknowledged' } })).status, 403);
  assert.equal((await api(t.base, 'POST', `/api/v1/alerts/${a.id}/state`, { cookie: admin, body: { state: 'acknowledged', note: 'triage' } })).status, 200);
  assert.equal((await api(t.base, 'POST', `/api/v1/alerts/${a.id}/state`, { cookie: admin, body: { state: 'resolved' } })).status, 200);
  assert.equal((await api(t.base, 'POST', `/api/v1/alerts/${a.id}/state`, { cookie: admin, body: { state: 'acknowledged' } })).status, 409);
  const au = (await api(t.base, 'GET', '/api/v1/admin/audit', { cookie: admin })).json.data;
  assert.equal(au.chain.ok, true);
  t.db.prepare("UPDATE fabric_audit SET detail_json = '{\"tampered\":true}' WHERE id = (SELECT MIN(id) FROM fabric_audit)").run();
  assert.equal(t.wm.fabric.verifyAudit().ok, false);
});

test('alert rules: validated thresholds and mutes', async () => {
  assert.equal((await api(t.base, 'PUT', '/api/v1/alerts/rules/section_surge', { cookie: admin, body: { params: { factor: 'x' } } })).status, 400);
  assert.equal((await api(t.base, 'PUT', '/api/v1/alerts/rules/section_surge', { cookie: admin, body: { params: { bogus: 1 } } })).status, 400);
  const r = await api(t.base, 'PUT', '/api/v1/alerts/rules/kev_new_exploited', { cookie: admin, body: { muteHours: 2 } });
  assert.ok(r.json.data.mutedUntil);
  routes['www.cisa.gov'] = () => ({ status: 200, body: kev([...OLD, entry(900, '2026-09-24', { knownRansomwareCampaignUse: 'Known', cwes: ['CWE-89'] }), entry(901, '2026-09-25', { cwes: ['CWE-639'] }), entry(904, '2026-09-25'), entry(905, '2026-09-25'), entry(906, '2026-09-25')]) });
  await run('cisa-kev', { force: true });
  const a = (await api(t.base, 'GET', '/api/v1/alerts', { cookie: viewer })).json.data.filter((x) => x.title.includes('CVE-2099-1906'));
  assert.equal(a.length, 0, 'muted rule raises nothing');
  await api(t.base, 'PUT', '/api/v1/alerts/rules/kev_new_exploited', { cookie: admin, body: { muteHours: 0 } });
});

test('exports carry provenance, are admin-only and audited', async () => {
  assert.equal((await api(t.base, 'GET', '/api/v1/export/events.csv', { cookie: viewer })).status, 403);
  const csv = await api(t.base, 'GET', '/api/v1/export/events.csv', { cookie: admin });
  const header = csv.text.split('\n')[1];
  for (const col of ['sourceClass', 'mappingStatus', 'crosswalkVersion', 'contentHash', 'retrievedAt', 'environment']) assert.ok(header.includes(col), col);
  assert.match(csv.text, /signals are not confirmed incidents/);
  assert.ok(t.db.prepare("SELECT 1 FROM fabric_audit WHERE action = 'export.events'").get());
});

test('India State/UT: reconciled data, null ≠ 0, not-published levels, small-cell suppression by view', async () => {
  const a = (await api(t.base, 'GET', '/api/v1/observatory/india?year=2023&view=analyst', { cookie: admin })).json.data;
  assert.equal(a.rows.length, 36);
  assert.equal(a.rows.reduce((n, r) => n + (r.casesRegistered.value || 0), 0), a.totals.all);
  assert.equal(a.totals.all, 86420);
  const y19 = (await api(t.base, 'GET', '/api/v1/observatory/india?year=2019&view=analyst', { cookie: admin })).json.data;
  const ladakh = y19.rows.find((r) => r.iso === 'IN-LA');
  assert.equal(ladakh.casesRegistered.value, null);
  assert.equal(ladakh.casesRegistered.availability, 'not_published');
  const pub = (await api(t.base, 'GET', '/api/v1/observatory/india?year=2023', { cookie: viewer })).json.data;
  assert.equal(pub.view, 'public');
  const nagaland = pub.rows.find((r) => r.iso === 'IN-NL');                 // 2 cases in 2023
  assert.equal(nagaland.casesRegistered.suppressed, true);
  assert.equal(nagaland.casesRegistered.value, null);
  assert.equal((await api(t.base, 'GET', '/api/v1/observatory/india?view=analyst', { cookie: viewer })).status, 403);
  const pin = (await api(t.base, 'GET', '/api/v1/observatory/india?level=pin', { cookie: viewer })).json;
  assert.equal(pin.data.availability, 'not_published');
  assert.match(pin.meta.warnings[0], /PIN-code/);
});

test('the official import refuses a tampered extract', () => {
  const src = path.join(__dirname, '..', 'db', 'fabric', 'sources', 'mha-lsusq-452-2025-12-02.annexures.txt');
  const bad = fs.readFileSync(src, 'utf8').replace('11 Karnataka 12020 10741 8136 12556 21889', '11 Karnataka 12020 10741 8136 12556 21880');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'wm-q452-'));
  fs.writeFileSync(path.join(dir, 'x.txt'), bad);
  assert.throws(() => execFileSync(process.execPath, [path.join(__dirname, '..', 'scripts', 'import-mha-q452.js'), path.join(dir, 'x.txt'), path.join(dir, 'o.json')], { stdio: 'pipe' }),
    (e) => /states sum 85594 ≠ TOTAL STATE\(S\) 85603/.test(String(e.stderr)));
  assert.equal(fs.existsSync(path.join(dir, 'o.json')), false);
});

test('environments are isolated: a production instance never sees synthetic rows', async () => {
  const prod = await startApp({ dbFile: t.dbFile, config: { fabric: { environment: 'production', fetchImpl: mockFetch } } });
  try {
    const c = (await login(prod.base, 'admin')).cookie;
    const feed = await api(prod.base, 'GET', '/api/v1/observatory/feed', { cookie: c });
    assert.equal(feed.json.data.length, 0);
    assert.equal(feed.json.meta.environment, 'production');
    assert.equal((await api(prod.base, 'GET', '/api/v1/alerts', { cookie: c })).json.data.length, 0);
  } finally { await prod.close(); }
});

test('Data Trust Center: coverage matrix, not-published metrics, quality score disclaimer, OpenAPI behind auth', async () => {
  const d = (await api(t.base, 'GET', '/api/v1/observatory/data-quality', { cookie: viewer })).json.data;
  assert.ok(d.coverageMatrix.find((r) => r.sourceId === 'ncrp-fraud-ogd').decision.includes('excluded until verified'));
  assert.ok(d.notPublished.some((n) => /PIN-code/.test(n.metric)));
  assert.ok(d.notPublished.some((n) => /real-time, worldwide, PIN-code-level/.test(n.reason)));
  assert.match(d.qualityScoreNote, /not an official rating/);
  assert.equal((await api(t.base, 'GET', '/api/v1/openapi.json')).status, 401);
  assert.ok((await api(t.base, 'GET', '/api/v1/openapi.json', { cookie: viewer })).json.paths['/api/v1/stream']);
});
