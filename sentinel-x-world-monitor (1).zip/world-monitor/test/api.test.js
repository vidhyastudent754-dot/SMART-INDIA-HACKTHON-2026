'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { startApp, login, api } = require('./helpers');

let t, admin;
test.before(async () => { t = await startApp(); admin = (await login(t.base, 'admin')).cookie; });
test.after(async () => { await t.close(); });

const post = (p, body, mode) => api(t.base, 'POST', p, { cookie: admin, body, mode });
const get = (p, mode) => api(t.base, 'GET', p, { cookie: admin, mode });

/* ---- phishing APIs ---- */
test('check-url: verdicts differ correctly for safe vs malicious URLs', async () => {
  const safe = await post('/api/security/check-url', { url: 'https://example.com' });
  const bad = await post('/api/security/check-url', { url: 'http://192.168.1.10/sbi-login' });
  assert.equal(safe.json.verdict, 'SAFE');
  assert.equal(bad.json.verdict, 'MALICIOUS');
  assert.equal(bad.json.source, 'heuristic');   // no GSB key in tests
});

test('check-url: input validation', async () => {
  assert.equal((await post('/api/security/check-url', {})).status, 400);
  assert.equal((await post('/api/security/check-url', { url: 'https://a.com/' + 'x'.repeat(3000) })).status, 400);
  assert.equal((await post('/api/security/analyze-sms', { body: 'a'.repeat(2500) })).status, 400);
});

test('analyze-email returns heuristicScore, mlScore, combinedConfidence', async () => {
  const r = await post('/api/security/analyze-email', {
    body: 'Dear Customer, your account will be suspended within 24 hours. Verify your password and OTP here: http://sbi-kyc-update.top/login',
  });
  assert.equal(r.status, 200);
  for (const k of ['heuristicScore', 'mlScore', 'combinedConfidence']) assert.equal(typeof r.json[k], 'number', k);
  assert.deepEqual(r.json.blend, { heuristic: 0.6, ml: 0.4 });
  assert.equal(r.json.verdict, 'PHISHING');
});

test('every check is counted in the live activity feed (no content stored)', async () => {
  const before = (await get('/api/activity')).json.totals.checks;
  await post('/api/security/analyze-sms', { body: 'hey, reached home, will call after dinner' });
  const after = (await get('/api/activity')).json;
  assert.equal(after.totals.checks, before + 1);
  assert.equal(after.recent[0].kind, 'sms');
  const cols = Object.keys(t.db.prepare('SELECT * FROM activity_events LIMIT 1').get());
  assert.deepEqual(cols.sort(), ['actor', 'id', 'kind', 'source', 'ts', 'verdict']);
});

test('metrics: uptime, DB, GSB status, rate-limit headroom — and no secrets', async () => {
  const m = (await get('/api/metrics')).json;
  assert.equal(m.database.ok, true);
  assert.equal(typeof m.uptime.seconds, 'number');
  assert.equal(m.threatIntel.googleSafeBrowsing.configured, false);
  assert.ok(m.rateLimit['check-url'].remaining <= m.rateLimit['check-url'].limitPerMinute);
  assert.equal(m.assessment.realAppPath, true);
  const csv = await get('/api/metrics.csv');
  assert.match(csv.text, /^metric,value\n/);
});

/* ---- assessments: vulnerable vs fixed must disagree ---- */
async function both(method, p, body, headers) {
  const v = await api(t.base, method, p, { cookie: admin, body, mode: 'vulnerable', headers });
  const f = await api(t.base, method, p, { cookie: admin, body, mode: 'fixed', headers });
  return { v: v.json, f: f.json, vs: v.status, fs: f.status };
}

test('IND-04 reset token: vulnerable reusable, fixed single-use', async () => {
  const r = await both('POST', '/api/assess/reset-token', { token: 'tok-both-' + Date.now() });
  assert.equal(r.v.verdict, 'VULNERABLE');
  assert.equal(r.f.verdict, 'SECURE');
});

test('IND-03 session replay after logout', async () => {
  const r = await both('POST', '/api/assess/session-replay', { sid: 'sid-test' });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.vs, 200);
  assert.equal(r.f.verdict, 'SECURE'); assert.equal(r.fs, 401);
});

test('EMP-04 IDOR runs against the REAL app routes over HTTP', async () => {
  const r = await both('GET', '/api/assess/record/1002', undefined, { 'X-Assess-User': 'EMP-A' });
  assert.equal(r.v.path, 'real'); assert.equal(r.f.path, 'real');
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.vs, 200);
  assert.equal(r.f.verdict, 'SECURE'); assert.equal(r.fs, 403);
  assert.match(r.f.detail.target, /^\/api\/records\/1002$/);
  // own record is fine in both modes
  const own = await both('GET', '/api/assess/record/1001', undefined, { 'X-Assess-User': 'EMP-A' });
  assert.equal(own.v.verdict, 'SECURE'); assert.equal(own.f.verdict, 'SECURE');
  // harness sessions are revoked after use
  const live = t.db.prepare("SELECT COUNT(*) n FROM sessions WHERE kind='app' AND revoked=0").get().n;
  assert.equal(live, 0);
});

test('EMP-09 mass assignment runs against the REAL app and the DB row is restored', async () => {
  const r = await both('POST', '/api/assess/update-profile', { name: 'A. Employee', role: 'admin' });
  assert.equal(r.v.path, 'real');
  assert.equal(r.v.verdict, 'VULNERABLE');
  assert.equal(r.v.detail.persisted.role, 'admin');     // really written to SQLite by the lab twin…
  assert.equal(r.f.verdict, 'SECURE');
  assert.equal(r.f.detail.persisted.role, 'employee');  // …and ignored by the production route
  const row = t.db.prepare("SELECT role, name FROM employees WHERE id = 'EMP-A'").get();
  assert.deepEqual(row, { role: 'employee', name: 'Test Employee A' }, 'row restored after the check');
});

test('IND-06 stored XSS: vulnerable serves raw, fixed sanitises', async () => {
  const r = await both('POST', '/api/assess/store-comment', { body: '<script>document.title="xss"</script>' });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('IND-10 sensitive data over-exposure', async () => {
  const r = await both('GET', '/api/assess/user-record?id=U-A');
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
  assert.ok(r.f.detail.leakedSensitiveFields.length === 0);
});

test('IND-01 account enumeration', async () => {
  const r = await both('POST', '/api/assess/login-probe', { email: 'testa@wm.local' });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('EMP-02 vertical privilege escalation', async () => {
  const r = await both('POST', '/api/assess/admin-action', { op: 'deleteAllLogs' }, { 'X-Assess-User': 'EMP-A' });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE'); assert.equal(r.fs, 403);
});

test('ORG-09 path traversal (virtual FS)', async () => {
  const r = await both('GET', '/api/assess/file?path=' + encodeURIComponent('../../etc/passwd'));
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('ORG-16 PII in cleartext', async () => {
  const r = await both('GET', '/api/assess/data-protection');
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('ORG-11 vulnerable dependencies via REAL npm audit', async () => {
  const r = await both('GET', '/api/assess/deps');
  assert.equal(r.v.verdict, 'VULNERABLE');            // outdated fixture lockfile
  assert.equal(r.f.verdict, 'SECURE');                // real project lockfile is clean
  assert.ok(Array.isArray(r.v.detail.findings) && r.v.detail.findings.length > 0);
});

test('retired attacks are removed: old routes return 404 UNSUPPORTED', async () => {
  for (const [m, p] of [['GET', '/api/assess/headers'], ['GET', '/api/assess/org-endpoint'],
    ['POST', '/api/assess/reflect'], ['POST', '/api/assess/rbac-check'], ['POST', '/api/assess/role-change']]) {
    const r = await api(t.base, m, p, { cookie: admin, body: m === 'POST' ? {} : undefined });
    assert.equal(r.status, 404, `${m} ${p} should be 404`);
    assert.equal(r.json.verdict, 'UNSUPPORTED');
    assert.ok(r.json.verdict !== 'VULNERABLE' && r.json.verdict !== 'SECURE', 'retired route must not execute');
  }
});

test('registry: exactly 15 approved attacks, valid, 5/5/5', async () => {
  const ping = (await get('/api/assess/__ping')).json;
  assert.equal(ping.checks, 15);
  assert.equal(ping.registryValid, true);
  assert.deepEqual(ping.sectionCounts, { 1: 5, 2: 5, 3: 5 });
});

test('SMS fraud detection (defensive): OTP notification vs disclosure request', async () => {
  const safe = await post('/api/sms/analyze', { message: 'EXAMPLEBANK: Your OTP is 445566. Do not share this OTP with anyone.' });
  assert.equal(safe.json.classification, 'SAFE');
  assert.equal(safe.json.otpDetected, true);
  assert.equal(safe.json.otpDisclosureRequest, false);
  const fraud = await post('/api/sms/analyze', {
    message: 'EXAMPLEBANK SECURITY: Your account will be blocked. Tell the OTP to our support executive to cancel the transaction.',
    sender: 'UNKNOWN-98321', claimedCompany: 'Example Bank' });
  assert.equal(fraud.json.classification, 'HIGH_RISK');
  assert.equal(fraud.json.otpDisclosureRequest, true);
  assert.equal(fraud.json.otpValue, '[REDACTED]');   // secret never returned
});

test('ORG-15 rate limiting: fixed returns 429 past the limit', async () => {
  const body = { requestCount: 8, windowSeconds: 60 };
  const v = await post('/api/assess/rate-test', body, 'vulnerable');
  const f = await api(t.base, 'POST', '/api/assess/rate-test', { cookie: admin, body, mode: 'fixed', headers: { 'X-Assess-Session': 'fresh' } });
  assert.equal(v.json.verdict, 'VULNERABLE');
  assert.equal(f.status, 429); assert.equal(f.json.verdict, 'SECURE');
});

test('EMP-08 forged alg=none JWT', async () => {
  const r = await both('POST', '/api/assess/jwt-verify', { jwt: '' });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('ORG-06 SQL injection on the synthetic table', async () => {
  const r = await both('POST', '/api/assess/search', { q: "' OR '1'='1" });
  assert.equal(r.v.verdict, 'VULNERABLE'); assert.equal(r.f.verdict, 'SECURE');
});

test('assessment runs are counted as live activity', async () => {
  const s = (await get('/api/activity')).json;
  assert.ok(s.assessment.VULNERABLE > 0 && s.assessment.SECURE > 0);
});

test('EMP-12 idle timeout: vulnerable keeps a 60-min idle session, fixed expires it (real HTTP)', async () => {
  const r = await both('POST', '/api/assess/idle-check', { idleMinutes: 60 });
  assert.equal(r.vs, 200); assert.equal(r.v.verdict, 'VULNERABLE');
  assert.equal(r.fs, 401); assert.equal(r.f.verdict, 'SECURE');
  const short = await both('POST', '/api/assess/idle-check', { idleMinutes: 5 });   // input changes the outcome
  assert.equal(short.v.verdict, 'SECURE'); assert.equal(short.fs, 200);
});
