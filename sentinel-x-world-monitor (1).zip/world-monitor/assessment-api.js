/* =============================================================================
 * assessment-api.js - REAL backend for the SENTINEL-X security assessment
 * console. Mounted by app.js:
 *   app.use('/api/assess', createAssessRouter({ db, activity, harness, requireRole }))
 *
 * FINAL SCOPE - EXACTLY 15 attacks (see public/assessments/registry.js, the one
 * authoritative source of truth). Every retired attack has been removed from
 * this router; a request for a retired/unknown attack route returns 404
 * "unsupported" rather than executing an old implementation.
 *
 *   SECTION 1 INDIVIDUAL : IND-06 IND-10 IND-03 IND-01 IND-04
 *   SECTION 2 EMP/MANAGER: EMP-04 EMP-09 EMP-02 EMP-08 EMP-12
 *   SECTION 3 ORGANIZATION: ORG-06 ORG-09 ORG-15 ORG-16 ORG-11
 *
 * (SMS Fraud Detection is a DEFENSIVE capability served at /api/sms/analyze -
 *  it is NOT an attack and is NOT part of this router or the count of 15.)
 *
 * Every endpoint accepts a mode selector - header `X-Assess-Mode:
 * vulnerable|fixed` (or `?mode=`) - and runs the SAME code path in two real
 * implementations. Verdicts are COMPUTED from the actual outcome of the
 * request, never hard-coded. If a check cannot execute, the verdict is
 * ASSESSMENT_ERROR - a failure is never converted into a false SECURE.
 *
 * SAFETY (detection-only scope): the genuinely dangerous classes operate on
 * SANDBOXED, SYNTHETIC resources and never touch real infrastructure:
 *   - ORG-06 SQLi        → an in-memory synthetic table, no real DB engine.
 *   - ORG-09 traversal   → an in-memory VIRTUAL filesystem map, no real fs.
 * Everything else (authz/IDOR/JWT/session/token/rate-limit/deps/PII) is
 * genuinely exercised against the app's own state.
 *
 * PERSISTENCE: sessions (IND-03), reset tokens (IND-04), the employee directory
 * + records (EMP-*), stored comments (IND-06) and rate-limit buckets (ORG-15)
 * live in SQLite (db/schema.sql). State survives a restart.
 *
 * REAL-APP PATH: EMP-04 (IDOR) and EMP-09 (mass assignment) mint a real
 * employee session via the auth service and send a real HTTP request to the
 * app's production routes (fixed) or their vulnerable lab twins (lib/app-
 * routes.js), then read the real DB back. The simulated fallback is used only
 * when auth is disabled or the harness can't reach the server.
 * ===========================================================================*/
'use strict';

const express = require('express');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const REGISTRY = require('./public/assessments/registry.js');

module.exports = function createAssessRouter({ db, activity, harness, requireRole } = {}) {
if (!db) throw new Error('createAssessRouter requires { db }');
const router = express.Router();
router.use(express.json({ limit: '256kb' }));

/* ---- RBAC: running any attack is admin-only. Viewers can read every card in
 * the dashboard, but the server refuses to execute a test for them. */
if (requireRole) {
  const adminOnly = requireRole('admin');
  router.use((req, res, next) => {
    const p = req.path.replace(/\/+$/, '') || '/';
    if (p === '/__ping') return requireRole('admin', 'viewer')(req, res, next);
    return adminOnly(req, res, next);
  });
}

/* ---- every computed verdict is also a live-activity event ---- */
if (activity) {
  router.use((req, res, next) => {
    const json = res.json.bind(res);
    res.json = (body) => {
      if (body && (body.verdict === 'VULNERABLE' || body.verdict === 'SECURE') && body.mode) {
        activity.record('assessment', body.verdict, body.mode, req.user && req.user.username);
      }
      return json(body);
    };
    next();
  });
}

/* ---- SQLite-backed state (see db/schema.sql) ---- */
const Q = {
  sessGet: db.prepare("SELECT * FROM sessions WHERE id = ? AND kind = 'assess'"),
  sessPut: db.prepare(`INSERT INTO sessions (id, kind, user_id, role, created_at, last_seen, expires_at, revoked)
    VALUES (?, 'assess', ?, ?, ?, ?, ?, 0)
    ON CONFLICT(id) DO UPDATE SET user_id = excluded.user_id, role = excluded.role, created_at = excluded.created_at,
      last_seen = excluded.last_seen, expires_at = excluded.expires_at, revoked = 0 WHERE sessions.kind = 'assess'`),
  sessRevoke: db.prepare("UPDATE sessions SET revoked = 1 WHERE id = ? AND kind = 'assess'"),
  tokGet: db.prepare('SELECT * FROM reset_tokens WHERE token = ?'),
  tokPut: db.prepare('INSERT INTO reset_tokens (token, email, created_at, used) VALUES (?, ?, ?, 0)'),
  tokUse: db.prepare('UPDATE reset_tokens SET used = 1, used_at = ? WHERE token = ?'),
  empGet: db.prepare('SELECT * FROM employees WHERE id = ?'),
  empRole: db.prepare('SELECT role FROM employees WHERE id = ?'),
  empRestore: db.prepare(`UPDATE employees SET owner = @owner, name = @name, email = @email, role = @role, salary = @salary,
    review = @review, internal_note = @internal_note, updated_at = @updated_at WHERE id = @id`),
  recGet: db.prepare('SELECT * FROM records WHERE id = ?'),
  comPut: db.prepare('INSERT INTO assess_comments (id, raw, created_at) VALUES (?, ?, ?)'),
  comGet: db.prepare('SELECT * FROM assess_comments WHERE id = ?'),
  comTrim: db.prepare('DELETE FROM assess_comments WHERE id NOT IN (SELECT id FROM assess_comments ORDER BY created_at DESC LIMIT 500)'),
  rbGet: db.prepare('SELECT * FROM rate_buckets WHERE key = ?'),
  rbPut: db.prepare(`INSERT INTO rate_buckets (key, count, window_start) VALUES (?, ?, ?)
    ON CONFLICT(key) DO UPDATE SET count = excluded.count, window_start = excluded.window_start`),
};
// public shape of an employees row (snake_case columns → the fields the checks use)
const empView = (r) => r && ({ id: r.id, owner: r.owner, name: r.name, email: r.email, role: r.role,
  salary: r.salary, review: r.review, internalNote: r.internal_note });

/* ============================ state ======================================== */
// JWT signing secret for EMP-08, generated once and kept in the DB so tokens
// signed before a restart still verify after it.
const SECRET = (() => {
  const row = db.prepare("SELECT value FROM schema_meta WHERE key = 'assess_jwt_secret'").get();
  if (row) return Buffer.from(row.value, 'hex');
  const s = crypto.randomBytes(32);
  db.prepare("INSERT INTO schema_meta (key, value) VALUES ('assess_jwt_secret', ?)").run(s.toString('hex'));
  return s;
})();

const now = () => Date.now();
const sha = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');

const store = {
  // synthetic user records for IND-01 (enumeration) and IND-10 (over-exposure)
  users: {
    'U-A': { id: 'U-A', email: 'testa@wm.local', name: 'Test User A', role: 'user',
      passwordHash: sha('Str0ng-Passphrase-A!'), internalId: 90431, ssn: '***-**-1042',
      mfaSeed: 'JBSWY3DPEHPK3PXP' },
    'U-B': { id: 'U-B', email: 'testb@wm.local', name: 'Test User B', role: 'user',
      passwordHash: sha('Str0ng-Passphrase-B!'), internalId: 90432, ssn: '***-**-2087',
      mfaSeed: 'KRSXG5CTMVRXEZLU' },
  },
  // synthetic "users" table for the ORG-06 SQLi demo - NOT real data, NOT a real DB
  sqlTable: [
    { id: 1, user: 'alice', role: 'user', note: 'synthetic row' },
    { id: 2, user: 'bob', role: 'user', note: 'synthetic row' },
    { id: 3, user: 'carol', role: 'manager', note: 'synthetic row' },
    { id: 4, user: 'root', role: 'admin', note: 'synthetic secret row' },
  ],
  // virtual filesystem for the ORG-09 path-traversal demo - purely in memory
  vfs: {
    'public/index.html': '<!doctype html><title>World Monitor</title>',
    'public/app.js': 'console.log("world monitor");',
    'reports/q3.txt': 'Q3 assessment summary (synthetic).',
    '../../etc/passwd': 'root:x:0:0:SYNTHETIC-DEMO-ONLY:/root:/bin/bash\n(daemon...)',
    '../config/secrets.env': 'SYNTHETIC_API_KEY=sk_demo_do_not_use_0000',
  },
};

/* ORG-11 offline fallback - used ONLY when the live npm advisory registry is
 * unreachable. These are REAL, public GitHub/CVE advisory IDs for the fixture
 * packages, kept as a clearly-labelled offline snapshot (not fabricated, and
 * not the primary path - the primary path is a live `npm audit`).           */
const OFFLINE_ADVISORIES = {
  lodash:   { fixedIn: '4.17.21', ghsa: 'GHSA-35jh-r3h4-6jhm', cve: 'CVE-2021-23337', sev: 'high',     title: 'Command injection in lodash' },
  minimist: { fixedIn: '1.2.6',  ghsa: 'GHSA-xvch-5gv4-984h', cve: 'CVE-2021-44906', sev: 'critical', title: 'Prototype pollution in minimist' },
  axios:    { fixedIn: '0.21.1', ghsa: 'GHSA-4w2v-q235-vp99', cve: 'CVE-2020-28168', sev: 'moderate', title: 'SSRF in axios' },
};

/* ============================ helpers ===================================== */

function mode(req) {
  const m = String(req.get('x-assess-mode') || req.query.mode || 'vulnerable').toLowerCase();
  return m === 'fixed' ? 'fixed' : 'vulnerable';
}

// Standard envelope. `httpStatus` becomes both the real transport status AND a
// field the client can read. `verdict` is computed by each handler.
function reply(res, httpStatus, body) {
  return res.status(httpStatus).json(Object.assign({ httpStatus }, body));
}

// Wrap a handler so any thrown error becomes ASSESSMENT_ERROR (never a false
// SECURE). Async-aware.
function guarded(id, fn) {
  return async (req, res) => {
    try { await fn(req, res); }
    catch (e) {
      const m = mode(req);
      if (!res.headersSent) {
        reply(res, 500, { mode: m, verdict: 'ASSESSMENT_ERROR', attackId: id,
          request: `${req.method} ${req.originalUrl}`,
          response: 'assessment execution failed',
          error: e && e.message ? e.message : String(e),
          serverLog: [`ASSESSMENT_ERROR while running ${id}: ${e && e.message}`,
            'a failed assessment is reported as ASSESSMENT_ERROR, never as SECURE'] });
      }
    }
  };
}

function b64url(buf) {
  return Buffer.from(buf).toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function b64urlDecode(str) {
  str = String(str).replace(/-/g, '+').replace(/_/g, '/');
  while (str.length % 4) str += '=';
  return Buffer.from(str, 'base64');
}
function jwtSign(payload, alg) {
  const header = { alg: alg || 'HS256', typ: 'JWT' };
  const h = b64url(JSON.stringify(header));
  const p = b64url(JSON.stringify(payload));
  if ((alg || 'HS256') === 'none') return `${h}.${p}.`;
  const sig = crypto.createHmac('sha256', SECRET).update(`${h}.${p}`).digest();
  return `${h}.${p}.${b64url(sig)}`;
}

function clientKey(req) {
  return (req.ip || 'local') + '|' + (req.get('x-assess-session') || 'anon');
}

/* =============================================================================
 * SECTION 1 - INDIVIDUAL (IND-06, IND-10, IND-03, IND-01, IND-04)
 * ===========================================================================*/

/* IND-06 - Stored XSS. Stores raw, then "serves" it as data (raw vs sanitised).
 * Stateful via SQLite (assess_comments). */
router.post('/store-comment', guarded('IND-06', (req, res) => {
  const m = mode(req);
  const body = String((req.body && req.body.body) || '');
  const id = 'c-' + crypto.randomBytes(3).toString('hex');
  Q.comPut.run(id, body.slice(0, 5000), now());
  Q.comTrim.run();
  const sanitize = (s) => s.replace(/<[^>]*>/g, '').replace(/[&<>"']/g, (c) =>
    ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const served = m === 'fixed' ? sanitize(body) : body;
  const active = /<\s*script|on\w+\s*=|javascript:/i.test(body);
  const verdict = (m !== 'fixed' && active) ? 'VULNERABLE' : 'SECURE';
  reply(res, 200, {
    mode: m, verdict, attackId: 'IND-06', commentId: id,
    request: `POST /api/assess/store-comment { body: ${JSON.stringify(body).slice(0, 120)} } → GET /comment/${id}`,
    response: `stored id=${id}; served back as: ${served}`,
    detail: { stored: body, served, sanitisedOnServe: m === 'fixed', renderTarget: `GET /api/assess/comment/${id} (text/html when ?render=1)` },
    serverLog: [
      `comment ${id} stored (raw value persisted in SQLite)`,
      m === 'fixed' ? 'on retrieval, stored value is sanitised + escaped' : 'on retrieval, stored value is served RAW',
      (m !== 'fixed' && active) ? 'stored active payload served to every viewer → stored XSS' : 'served value is inert → no stored XSS',
    ],
  });
}));
/* Retrieval of a stored comment. With ?render=1 it serves the value as real
 * text/html so the browser-executability difference is genuine (vulnerable =
 * script runs; fixed = tags stripped → inert). Without it, JSON for the console. */
router.get('/comment/:id', guarded('IND-06', (req, res) => {
  const m = mode(req);
  const rec = Q.comGet.get(String(req.params.id));
  if (!rec) return reply(res, 404, { mode: m, verdict: 'SECURE', attackId: 'IND-06', response: '404 not found', serverLog: ['no such comment'] });
  const sanitize = (s) => s.replace(/<[^>]*>/g, '');
  const served = m === 'fixed' ? sanitize(rec.raw) : rec.raw;
  if (String(req.query.render || '') === '1') {
    // real browser-facing context: vulnerable serves raw (executes), fixed strips tags (inert)
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.setHeader('Content-Security-Policy', "default-src 'none'; style-src 'unsafe-inline'");
    return res.status(200).send(`<!doctype html><meta charset="utf-8"><title>comment ${rec.id}</title><body><div id="c">${served}</div></body>`);
  }
  reply(res, 200, { mode: m, verdict: m === 'fixed' ? 'SECURE' : 'VULNERABLE', attackId: 'IND-06',
    request: `GET /api/assess/comment/${req.params.id}`, response: served,
    detail: { served, browserRenderUrl: `/api/assess/comment/${rec.id}?render=1&mode=${m}` },
    serverLog: [`served comment ${req.params.id} (${m})`] });
}));

/* IND-10 - Excessive data exposure. Vuln returns the full internal record. */
router.get('/user-record', guarded('IND-10', (req, res) => {
  const m = mode(req);
  const id = String(req.query.id || 'U-A');
  const u = store.users[id] || store.users['U-A'];
  const sensitive = ['passwordHash', 'internalId', 'ssn', 'mfaSeed'];
  const full = Object.assign({}, u);
  const projection = { id: u.id, name: u.name, email: u.email };
  const bodyOut = m === 'fixed' ? projection : full;
  const leaked = sensitive.filter((k) => k in bodyOut);
  const verdict = leaked.length ? 'VULNERABLE' : 'SECURE';
  reply(res, 200, {
    mode: m, verdict, attackId: 'IND-10',
    request: `GET /api/assess/user-record?id=${id}`,
    response: JSON.stringify(bodyOut).slice(0, 300),
    detail: { returned: Object.keys(bodyOut), leakedSensitiveFields: leaked, safeProjection: Object.keys(projection) },
    serverLog: [
      `fields returned: ${Object.keys(bodyOut).join(', ')}`,
      leaked.length ? `SENSITIVE fields exposed: ${leaked.join(', ')}` : 'only allow-listed fields returned',
      leaked.length ? 'internal fields over-exposed → VULNERABLE' : 'response is a safe projection → SECURE',
    ],
  });
}));

/* IND-03 - Insecure session + logout invalidation. Creates a session, logs it
 * out, then replays the sid. Fixed revokes server-side; vuln does not. */
router.post('/session-replay', guarded('IND-03', (req, res) => {
  const m = mode(req);
  const sid = String((req.body && req.body.sid) || 'sid-' + crypto.randomBytes(4).toString('hex')).slice(0, 128);
  const key = 'assess:' + sid;               // namespaced: can never collide with a real login session
  Q.sessPut.run(key, 'U-A', 'user', now(), now(), now() + 30 * 60000);   // login
  if (m === 'fixed') Q.sessRevoke.run(key);  // server-side invalidation (row updated in SQLite)
  const sess = Q.sessGet.get(key);           // replay after logout - re-read from the DB
  const stillValid = m === 'fixed' ? !sess.revoked : true;
  const status = stillValid ? 200 : 401;
  const flags = m === 'fixed' ? 'HttpOnly; Secure; SameSite=Strict' : '(none)';
  const verdict = stillValid ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'IND-03',
    request: `POST /api/assess/session-replay { sid: "${sid}" }  (create → logout → replay)`,
    response: `replay → ${status} ${stillValid ? 'session still authenticated' : 'session revoked'}  · cookie flags: ${flags}`,
    detail: { cookieFlags: flags, revokedOnLogout: m === 'fixed', storage: 'sqlite:sessions', revokedInDb: !!sess.revoked },
    serverLog: [
      `session ${sid} created (row written to SQLite sessions table)`,
      m === 'fixed' ? 'logout → server marked session revoked' : 'logout → client cookie cleared only (server session kept)',
      `replay old sid → ${status} ${stillValid ? '(STILL VALID)' : '(revoked)'}`,
      `Set-Cookie flags = ${flags}`,
    ],
  });
}));

/* IND-01 - Account enumeration. Probes the given email AND a control address,
 * then compares the two real responses. Distinguishable => enumerable. */
router.post('/login-probe', guarded('IND-01', (req, res) => {
  const m = mode(req);
  const email = String((req.body && req.body.email) || '').trim().toLowerCase();
  const exists = (e) => Object.values(store.users).some((u) => u.email === e);
  const probe = (e) => {
    if (m === 'fixed') return { status: 200, body: 'If an account exists, a reset link has been sent.' };
    return exists(e)
      ? { status: 200, body: 'Reset link sent to your email.' }
      : { status: 404, body: 'No account found for that email.' };
  };
  const target = probe(email);
  const control = probe('definitely-not-a-user@wm.local');
  const distinguishable = target.status !== control.status || target.body !== control.body;
  const verdict = distinguishable ? 'VULNERABLE' : 'SECURE';
  reply(res, target.status, {
    mode: m, verdict, attackId: 'IND-01',
    request: `POST /api/assess/login-probe { email: "${email}" }`,
    response: `${target.status} "${target.body}"  |  control(unknown): ${control.status} "${control.body}"`,
    detail: { targetExists: exists(email), distinguishable, comparedFields: ['status', 'body'] },
    serverLog: [
      `probe(target)  → ${target.status} "${target.body}"`,
      `probe(control) → ${control.status} "${control.body}"`,
      distinguishable
        ? 'responses DIFFER by status/body → account existence is observable'
        : 'responses IDENTICAL → account existence is not observable',
    ],
  });
}));

/* IND-04 - Password-reset token: real TTL (15m) + single-use. Genuinely
 * stateful: the same token is attempted twice; the 2nd must fail when fixed. */
router.post('/reset-token', guarded('IND-04', (req, res) => {
  const m = mode(req);
  const token = String((req.body && req.body.token) || 'tok-' + crypto.randomBytes(4).toString('hex')).slice(0, 128);
  const elapsed = Math.max(0, Math.min(7 * 24 * 60, Number((req.body && req.body.elapsedMinutes) || 0) || 0));
  let row = Q.tokGet.get(token);
  const issuedNow = !row;
  if (issuedNow) {
    Q.tokPut.run(token, 'testa@wm.local', now() - elapsed * 60000);
    row = Q.tokGet.get(token);
  }
  const rec = { createdAt: row.created_at, used: !!row.used };
  const ttlMin = 15;
  const ageMin = (now() - rec.createdAt) / 60000;
  function attempt() {
    if (m === 'fixed') {
      if (ageMin > ttlMin) return { ok: false, why: `expired (age ${ageMin.toFixed(1)}m > ${ttlMin}m TTL)` };
      if (rec.used) return { ok: false, why: 'token already used (single-use enforced)' };
      Q.tokUse.run(now(), token);   // persisted: stays used across restarts
      rec.used = true;
      return { ok: true, why: 'accepted (within TTL, first use)' };
    }
    return { ok: true, why: 'accepted (no TTL, no single-use check)' };
  }
  const first = attempt();
  const second = attempt(); // immediate reuse
  const reusable = first.ok && second.ok;
  const status = first.ok ? 200 : 400;
  const verdict = reusable ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'IND-04',
    request: `POST /api/assess/reset-token { token: "${token}", elapsedMinutes: ${elapsed} }`,
    response: `1st use → ${first.ok ? 200 : 400} ${first.why}  ·  2nd use → ${second.ok ? 200 : 400} ${second.why}`,
    detail: { ageMinutes: +ageMin.toFixed(2), ttlMinutes: ttlMin, firstUse: first, secondUse: second,
      storage: 'sqlite:reset_tokens', issuedThisRequest: issuedNow, issuedAt: new Date(row.created_at).toISOString(),
      usedInDb: !!Q.tokGet.get(token).used },
    serverLog: [
      issuedNow
        ? `token issued and stored in SQLite (reset_tokens)`
        : `token loaded from SQLite - issued ${new Date(row.created_at).toISOString()}, used=${!!row.used} (state survived since issuance)`,
      `token age = ${ageMin.toFixed(1)}m (TTL ${ttlMin}m)`,
      `use #1 → ${first.ok ? 'ACCEPTED' : 'REJECTED'} - ${first.why}`,
      `use #2 → ${second.ok ? 'ACCEPTED' : 'REJECTED'} - ${second.why}`,
      reusable ? 'token is reusable / never expires → VULNERABLE' : 'token is single-use and TTL-bound → SECURE',
    ],
  });
}));

/* =============================================================================
 * SECTION 2 - EMPLOYEE & MANAGER (EMP-04, EMP-09, EMP-02, EMP-08, EMP-12)
 * Caller identity comes from X-Assess-User (EMP-A|EMP-B|MGR-1|ADM-1).
 * ===========================================================================*/
const ROLE_OF = (uid) => { const r = Q.empRole.get(String(uid)); return (r && r.role) || 'employee'; };
const caller = (req) => String(req.get('x-assess-user') || (req.body && req.body.as) || 'EMP-A');

/* EMP-04 - IDOR on a real production route. REAL path (default when auth is
 * configured): a genuine employee session is minted and a real HTTP GET is
 * sent to /api/records/:id (fixed) or its lab twin (vulnerable). SIMULATED
 * fallback when auth is disabled or the harness is offline. */
router.get('/record/:id', guarded('EMP-04', async (req, res) => {
  const m = mode(req);
  const who = caller(req);
  const id = String(req.params.id);
  const rec = Q.recGet.get(id);
  const owns = !!rec && (rec.owner === who || ['manager', 'admin'].includes(ROLE_OF(who)));
  const wantSimulated = String(req.query.path || req.get('x-assess-path') || '').toLowerCase() === 'simulated';
  const login = (!wantSimulated && harness && harness.available()) ? harness.sessionFor(who) : null;

  if (login) {
    const target = (m === 'fixed' ? '/api/records/' : '/api/lab/vulnerable/records/') + encodeURIComponent(id);
    try {
      const r = await harness.request('GET', target, { token: login.token });
      const allowed = r.status === 200;
      const verdict = (allowed && rec && !owns) ? 'VULNERABLE' : 'SECURE';
      return reply(res, r.status, {
        mode: m, verdict, attackId: 'EMP-04', path: 'real',
        request: `GET ${target}  [Cookie: wm_sid=<live session for ${login.username}>]`,
        response: `${r.status} ${r.text.slice(0, 240)}`,
        detail: { caller: who, login: login.username, owner: rec ? rec.owner : null, allowed, target, realHttp: true },
        serverLog: [
          `harness: minted a real session for ${login.username} (${who}, role ${ROLE_OF(who)}) via the auth service`,
          `→ GET ${harness.baseUrl()}${target}  (real HTTP, full middleware stack)`,
          `← ${r.status} from ${m === 'fixed' ? 'the PRODUCTION route (ownership enforced in lib/app-routes.js)' : 'the lab twin (ownership check removed)'}`,
          (allowed && rec && !owns) ? `IDOR: ${who} read record ${id} owned by ${rec.owner} → VULNERABLE`
            : 'reference is authorised or refused → SECURE',
          'harness: session revoked',
        ],
      });
    } catch (e) {
      req.harnessError = e.message;
    } finally {
      harness.revoke(login.token);
    }
  }

  if (!rec) return reply(res, 404, { mode: m, verdict: 'SECURE', attackId: 'EMP-04', path: 'simulated', response: '404 no such record', serverLog: ['not found'] });
  const allowed = m === 'fixed' ? owns : true;
  const status = allowed ? 200 : 403;
  const verdict = (allowed && !owns) ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'EMP-04', path: 'simulated',
    request: `GET /api/assess/record/${id}  [X-Assess-User: ${who}]`,
    response: allowed ? `200 ${JSON.stringify(rec)}` : '403 forbidden',
    detail: { caller: who, owner: rec.owner, allowed },
    note: req.harnessError ? `Real-app path failed (${req.harnessError}); simulated fallback used.`
      : (wantSimulated ? 'Simulated path requested explicitly.' : 'Auth not configured - simulated fallback. Real-app path runs when auth is enabled.'),
    serverLog: [
      `${who} requests record ${rec.id} (owner ${rec.owner})  [simulated]`,
      m === 'fixed' ? 'ownership enforced' : 'object reference used directly, no ownership check',
      (allowed && !owns) ? 'IDOR: any id is readable → VULNERABLE' : 'reference is authorised → SECURE',
    ],
  });
}));

/* EMP-09 - Mass assignment on a real production route. REAL path: PATCH
 * /api/profile (production, allow-list [name,email]) vs the lab twin that
 * assigns the whole body - sent over real HTTP with a real employee session.
 * The row is READ BACK from SQLite to prove what persisted, then restored. */
router.post('/update-profile', guarded('EMP-09', async (req, res) => {
  const m = mode(req);
  const b = (req.body && typeof req.body === 'object') ? req.body : {};
  const who = caller(req);
  const wantSimulated = String(req.query.path || req.get('x-assess-path') || '').toLowerCase() === 'simulated';
  const login = (!wantSimulated && harness && harness.available()) ? harness.sessionFor(who) : null;
  const payload = Object.assign({}, b); delete payload.as;

  if (login) {
    const original = Q.empGet.get(who);
    const target = m === 'fixed' ? '/api/profile' : '/api/lab/vulnerable/profile';
    try {
      const r = await harness.request('PATCH', target, { token: login.token, body: payload });
      const persisted = Q.empGet.get(who);                      // what is really in the DB now
      const escalated = persisted.role !== original.role;
      const verdict = escalated ? 'VULNERABLE' : 'SECURE';
      return reply(res, r.status, {
        mode: m, verdict, attackId: 'EMP-09', path: 'real',
        request: `PATCH ${target} ${JSON.stringify(payload).slice(0, 160)}  [Cookie: wm_sid=<live session for ${login.username}>]`,
        response: `${r.status} ${r.text.slice(0, 200)}  ·  DB row role now "${persisted.role}"`,
        detail: { before: empView(original), persisted: empView(persisted), allowListed: m === 'fixed', realHttp: true },
        serverLog: [
          `harness: minted a real session for ${login.username} (${who}) via the auth service`,
          `→ PATCH ${harness.baseUrl()}${target}  body ${JSON.stringify(payload).slice(0, 120)}`,
          `← ${r.status} from ${m === 'fixed' ? 'the PRODUCTION route (allow-list [name,email])' : 'the lab twin (Object.assign of the whole body)'}`,
          `SELECT role FROM employees WHERE id='${who}' → "${persisted.role}" (was "${original.role}")`,
          escalated ? 'attacker-supplied role persisted to the database → mass assignment → VULNERABLE'
            : 'protected fields untouched in the database → SECURE',
          'harness: row restored to its previous values, session revoked',
        ],
      });
    } catch (e) {
      req.harnessError = e.message;
    } finally {
      if (original) Q.empRestore.run(Object.assign({}, original, { updated_at: now() }));
      harness.revoke(login.token);
    }
  }

  const before = { name: 'Test Employee A', email: 'empA@wm.local', role: 'employee' };
  let after;
  if (m === 'fixed') {
    const allow = ['name', 'email'];
    after = Object.assign({}, before);
    allow.forEach((k) => { if (k in payload) after[k] = payload[k]; }); // role can never be set
  } else {
    after = Object.assign({}, before, payload); // whole body assigned → role too
  }
  const escalated = after.role === 'admin' && before.role !== 'admin';
  const verdict = escalated ? 'VULNERABLE' : 'SECURE';
  reply(res, 200, {
    mode: m, verdict, attackId: 'EMP-09', path: 'simulated',
    request: `POST /api/assess/update-profile ${JSON.stringify(payload).slice(0, 160)}`,
    response: `role after update = "${after.role}"`,
    detail: { before, after, allowListed: m === 'fixed' },
    note: req.harnessError ? `Real-app path failed (${req.harnessError}); simulated fallback used.`
      : 'Auth not configured - simulated fallback. Real-app path runs when auth is enabled.',
    serverLog: [
      `submitted body: ${JSON.stringify(payload)}  [simulated]`,
      m === 'fixed' ? 'server allow-lists [name,email]; role stripped' : 'server assigns the entire body onto the record',
      escalated ? 'attacker-supplied role:"admin" persisted → mass assignment' : 'protected fields untouched → SECURE',
    ],
  });
}));

/* EMP-02 - Vertical privilege escalation to an admin-only action. Role comes
 * from trusted server-side directory state, never from the caller's claim. */
router.post('/admin-action', guarded('EMP-02', (req, res) => {
  const m = mode(req);
  const who = caller(req);
  const isAdmin = ROLE_OF(who) === 'admin';   // trusted server-side role lookup
  const allowed = m === 'fixed' ? isAdmin : true;
  const status = allowed ? 200 : 403;
  const verdict = (allowed && !isAdmin) ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'EMP-02',
    request: `POST /api/assess/admin-action { op:"deleteAllLogs" }  [X-Assess-User: ${who}]`,
    response: allowed ? '200 admin action executed' : '403 admin role required',
    detail: { caller: who, role: ROLE_OF(who), allowed, roleSource: 'server-side employees table' },
    serverLog: [
      `${who} has role ${ROLE_OF(who)} (looked up server-side, not trusted from the request)`,
      m === 'fixed' ? 'endpoint requires role=admin' : 'endpoint does NOT verify role',
      (allowed && !isAdmin) ? 'non-admin executed admin action → vertical escalation' : 'role correctly enforced → SECURE',
    ],
  });
}));

/* EMP-08 - JWT alg=none / unverified role claim. Real HS256 verification. */
router.post('/jwt-verify', guarded('EMP-08', (req, res) => {
  const m = mode(req);
  let tokenIn = String((req.body && req.body.jwt) || '').trim();
  // If the user didn't paste one, forge an alg=none admin token to demonstrate.
  if (!tokenIn) tokenIn = jwtSign({ sub: 'U-A', role: 'admin' }, 'none');
  const parts = tokenIn.split('.');
  let header = {}, payload = {}, parseOk = true;
  try { header = JSON.parse(b64urlDecode(parts[0]).toString()); payload = JSON.parse(b64urlDecode(parts[1]).toString()); }
  catch (e) { parseOk = false; }
  const alg = (header && header.alg) || 'unknown';
  let signatureValid = false;
  if (parseOk && alg === 'HS256' && parts[2]) {
    const expect = b64url(crypto.createHmac('sha256', SECRET).update(`${parts[0]}.${parts[1]}`).digest());
    try { signatureValid = crypto.timingSafeEqual(Buffer.from(expect), Buffer.from(parts[2])); } catch (e) { signatureValid = false; }
  }
  let accepted, effectiveRole;
  if (m === 'fixed') {
    accepted = parseOk && alg === 'HS256' && signatureValid;   // pin alg + verify signature
    effectiveRole = accepted ? payload.role : null;
  } else {
    accepted = parseOk; // trusts the claim regardless of alg/signature
    effectiveRole = payload.role;
  }
  const status = accepted ? 200 : 401;
  const forged = accepted && (alg === 'none' || !signatureValid);
  const verdict = forged ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'EMP-08',
    request: `POST /api/assess/jwt-verify { jwt: "${tokenIn.slice(0, 24)}…" }`,
    response: accepted ? `200 authenticated as role="${effectiveRole}"` : '401 token rejected',
    detail: { alg, signatureValid, claimedRole: payload.role, effectiveRole, accepted },
    serverLog: [
      `header.alg = ${alg}; signature valid = ${signatureValid}`,
      m === 'fixed' ? 'server pins alg=HS256 and verifies the signature' : 'server trusts the payload without verifying signature/alg',
      forged ? `forged/unsigned token accepted as role="${effectiveRole}" → VULNERABLE` : 'only correctly-signed tokens accepted → SECURE',
    ],
  });
}));

/* EMP-12 - No idle timeout. Uses a controlled/testable clock (idleMinutes
 * supplied) rather than waiting for a real 60-minute delay. */
router.post('/idle-check', guarded('EMP-12', (req, res) => {
  const m = mode(req);
  const idle = Math.max(0, Number((req.body && req.body.idleMinutes) || 60) || 0);
  const limit = 15;
  const stillValid = m === 'fixed' ? idle <= limit : true;
  const status = stillValid ? 200 : 401;
  const verdict = (m !== 'fixed' && idle > limit) ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'EMP-12',
    request: `POST /api/assess/idle-check { idleMinutes: ${idle} }  (controlled clock)`,
    response: stillValid ? '200 session still active' : `401 session expired (idle > ${limit}m)`,
    detail: { idleMinutes: idle, idleLimit: limit, stillValid, clock: 'test-controlled (idleMinutes), no real-time wait' },
    serverLog: [
      `simulated idle time = ${idle}m (limit ${limit}m) via a controlled clock`,
      m === 'fixed' ? 'server enforces idle timeout and revokes on logout' : 'server keeps the API session alive indefinitely',
      (m !== 'fixed' && idle > limit) ? 'idle session never expires → session-fixation window' : 'idle timeout enforced → SECURE',
    ],
  });
}));

/* =============================================================================
 * SECTION 3 - ORGANIZATION (ORG-06, ORG-09, ORG-15, ORG-16, ORG-11)
 * ===========================================================================*/

/* ORG-06 - SQL injection against a SYNTHETIC in-memory table (no real DB). */
router.post('/search', guarded('ORG-06', (req, res) => {
  const m = mode(req);
  const q = String((req.body && req.body.q) || '');
  let rows, query, injected = false;
  if (m === 'fixed') {
    query = 'SELECT id,user,role FROM users WHERE user = ?   -- params: [' + JSON.stringify(q) + ']';
    rows = store.sqlTable.filter((r) => r.user === q);
  } else {
    query = "SELECT id,user,role FROM users WHERE user = '" + q + "'";
    const tautology = /'\s*or\s*'?1'?\s*=\s*'?1|'\s*or\s*1\s*=\s*1|--|#|'\s*or\s*'a'\s*=\s*'a/i.test(q);
    if (tautology) { rows = store.sqlTable.slice(); injected = true; }
    else rows = store.sqlTable.filter((r) => r.user === q);
  }
  const expected = store.sqlTable.filter((r) => r.user === q).length; // legitimate match count
  const verdict = (injected && rows.length > expected) ? 'VULNERABLE' : 'SECURE';
  reply(res, 200, {
    mode: m, verdict, attackId: 'ORG-06',
    request: `POST /api/assess/search { q: ${JSON.stringify(q)} }`,
    response: `${rows.length} row(s): ${JSON.stringify(rows.map((r) => ({ id: r.id, user: r.user, role: r.role }))).slice(0, 240)}`,
    detail: { query, rowsReturned: rows.length, legitimateMatches: expected, injected, engine: 'synthetic in-memory table (no real DB)' },
    serverLog: [
      `executed (synthetic): ${query}`,
      `rows returned = ${rows.length} (legitimate match count = ${expected})`,
      m === 'fixed' ? 'parameterised query - input is data, not code' : 'input concatenated into SQL string',
      verdict === 'VULNERABLE' ? 'injection collapsed the WHERE clause → full table dumped → VULNERABLE' : 'input treated as data → SECURE',
    ],
  });
}));

/* ORG-09 - Path traversal against a VIRTUAL filesystem (no real fs access). */
router.get('/file', guarded('ORG-09', (req, res) => {
  const m = mode(req);
  const BASE = 'public';
  const requested = String(req.query.path || 'index.html');
  let key, escaped = false, content = null, status = 200;
  if (m === 'fixed') {
    const norm = path.posix.normalize('/' + requested).replace(/^\/+/, '');
    key = BASE + '/' + norm;
    if (norm.startsWith('..') || key.indexOf(BASE + '/') !== 0) { status = 403; }
    else content = store.vfs[key] != null ? store.vfs[key] : null;
    if (content == null && status === 200) status = 404;
  } else {
    const joined = BASE + '/' + requested;
    key = requested.startsWith('../') ? requested : joined;
    if (requested.indexOf('..') !== -1) escaped = true;
    content = store.vfs[key] != null ? store.vfs[key]
      : (store.vfs[requested] != null ? store.vfs[requested] : null);
    if (content == null) status = 404;
  }
  const verdict = (m !== 'fixed' && escaped && content != null) ? 'VULNERABLE' : 'SECURE';
  reply(res, status, {
    mode: m, verdict, attackId: 'ORG-09',
    request: `GET /api/assess/file?path=${encodeURIComponent(requested)}`,
    response: status === 200 ? `200 ${String(content).slice(0, 160)}` : (status === 403 ? '403 traversal blocked' : '404 not found'),
    detail: { requested, resolvedKey: key, escapedBase: escaped, note: 'virtual in-memory filesystem; no real files are read' },
    serverLog: [
      `requested path: ${requested}`,
      m === 'fixed' ? `normalised + confined to "${BASE}/"` : `naive join → "${key}"`,
      (m !== 'fixed' && escaped && content != null)
        ? 'path escaped the base dir and returned out-of-tree content → VULNERABLE'
        : (status === 403 ? 'traversal normalised and blocked → SECURE' : 'no escape → SECURE'),
    ],
  });
}));

/* ORG-15 - Rate limiting. REAL stateful counter → real 429 after the limit. */
router.post('/rate-test', guarded('ORG-15', (req, res) => {
  const m = mode(req);
  const b = req.body || {};
  const count = Math.max(1, Math.min(50, Number(b.requestCount || 8)));
  const windowSec = Math.max(1, Math.min(3600, Number(b.windowSeconds || 60)));
  const limit = 5;
  const key = clientKey(req) + '|' + windowSec;
  const row = Q.rbGet.get(key);
  let bucket = row ? { count: row.count, windowStart: row.window_start } : null;
  if (!bucket || (now() - bucket.windowStart) > windowSec * 1000) {
    bucket = { count: 0, windowStart: now() };
  }
  const results = [];
  let allowedN = 0, blockedN = 0;
  for (let i = 1; i <= count; i++) {
    bucket.count++;
    let ok = m === 'fixed' ? bucket.count <= limit : true;
    if (ok) allowedN++; else blockedN++;
    results.push(ok ? 200 : 429);
  }
  Q.rbPut.run(key, bucket.count, bucket.windowStart);   // persisted: a restart doesn't reset the window
  const verdict = (m !== 'fixed') ? 'VULNERABLE' : (blockedN > 0 ? 'SECURE' : (count <= limit ? 'SECURE' : 'VULNERABLE'));
  reply(res, blockedN > 0 ? 429 : 200, {
    mode: m, verdict, attackId: 'ORG-15',
    request: `POST /api/assess/rate-test { requestCount: ${count}, windowSeconds: ${windowSec} }`,
    response: `${allowedN}×200, ${blockedN}×429 (limit ${limit}/${windowSec}s)`,
    detail: { limit, windowSec, allowed: allowedN, blocked: blockedN, sequence: results, bucketCount: bucket.count,
      storage: 'sqlite:rate_buckets', windowStartedAt: new Date(bucket.windowStart).toISOString() },
    serverLog: [
      `fired ${count} requests into a ${windowSec}s window (limit ${limit})`,
      m === 'fixed' ? `middleware counts real hits → ${allowedN} allowed, ${blockedN} × HTTP 429` : 'no rate-limit middleware → all requests allowed',
      verdict === 'VULNERABLE' ? 'endpoint accepts unlimited requests → brute-force/DoS exposure → VULNERABLE' : 'excess requests throttled with 429 → SECURE',
    ],
  });
}));

/* ORG-16 - PII in cleartext (masking / protection at rest). Controlled test PII. */
router.get('/data-protection', guarded('ORG-16', (req, res) => {
  const m = mode(req);
  const record = { customer: 'Asha K.', card: '4111111111111111', ssn: '412-88-1042', dob: '1990-04-12' };
  const mask = (r) => ({ customer: r.customer, card: '**** **** **** ' + r.card.slice(-4), ssn: '***-**-' + r.ssn.slice(-4), dob: '19XX-XX-XX' });
  const out = m === 'fixed' ? mask(record) : record;
  const cleartext = m !== 'fixed';
  const verdict = cleartext ? 'VULNERABLE' : 'SECURE';
  reply(res, 200, {
    mode: m, verdict, attackId: 'ORG-16',
    request: 'GET /api/assess/data-protection',
    response: JSON.stringify(out).slice(0, 260),
    detail: { encryptedAtRest: m === 'fixed', masked: m === 'fixed', note: 'controlled synthetic PII - not real people' },
    serverLog: [
      m === 'fixed' ? 'PII masked in transit; encrypted at rest' : 'PII stored/returned in cleartext',
      cleartext ? 'full card/SSN returned in cleartext → VULNERABLE' : 'PII masked/encrypted → SECURE',
    ],
  });
}));

/* ORG-11 - Vulnerable dependencies. Runs a REAL `npm audit --json` against the
 * project's actual package-lock.json (fixed = the real, current, clean lock)
 * and against a deliberately-outdated lock fixture (vulnerable). Package names,
 * versions, counts and CVEs come from the live npm advisory database - nothing
 * is hard-coded. If the registry is unreachable, it falls back to a clearly-
 * labelled OFFLINE snapshot of real public advisories (never fabricated). */
function cmpVer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] || 0) - (pb[i] || 0); if (d) return d;
  }
  return 0;
}
function liveAudit(cwd) {
  // npm audit exits non-zero when it finds vulnerabilities; capture stdout either way.
  let out;
  try {
    out = execFileSync('npm', ['audit', '--json', '--audit-level=low'],
      { cwd, timeout: 25000, maxBuffer: 8 * 1024 * 1024, stdio: ['ignore', 'pipe', 'ignore'] }).toString();
  } catch (e) {
    if (e && e.stdout && e.stdout.length) out = e.stdout.toString();   // "vulns found" exit
    else throw e;
  }
  const data = JSON.parse(out);
  const findings = [];
  const vulns = data.vulnerabilities || {};
  for (const [name, v] of Object.entries(vulns)) {
    const advisories = (v.via || []).filter((x) => x && typeof x === 'object');
    for (const a of advisories) {
      findings.push({
        package: name, severity: a.severity || v.severity || 'unknown',
        title: a.title || 'advisory', advisory: a.url || null,
        cve: Array.isArray(a.cwe) ? undefined : undefined, ghsa: a.url && a.url.split('/').pop(),
        range: a.range || null, cvss: a.cvss ? a.cvss.score : null, cwe: a.cwe || [],
      });
    }
    if (!advisories.length) {
      findings.push({ package: name, severity: v.severity || 'unknown', title: 'vulnerable via dependency chain', range: v.range || null });
    }
  }
  return { source: 'npm audit (live advisory database)', findings,
    scanned: (data.metadata && data.metadata.dependencies && data.metadata.dependencies.total) || null,
    totals: (data.metadata && data.metadata.vulnerabilities) || null };
}
function offlineAudit(lockPath) {
  const lock = JSON.parse(fs.readFileSync(lockPath, 'utf8'));
  const deps = {};
  if (lock.packages) {
    for (const [p, meta] of Object.entries(lock.packages)) {
      if (!p) continue;
      const name = p.replace(/^node_modules\//, '').split('/node_modules/').pop();
      if (name && meta.version) deps[name] = meta.version;
    }
  } else if (lock.dependencies) {
    for (const [name, meta] of Object.entries(lock.dependencies)) deps[name] = meta.version;
  }
  const findings = [];
  for (const [name, adv] of Object.entries(OFFLINE_ADVISORIES)) {
    const v = deps[name];
    if (v && cmpVer(v, adv.fixedIn) < 0) {
      findings.push({ package: name, installed: v, fixedIn: adv.fixedIn, severity: adv.sev, title: adv.title, cve: adv.cve, ghsa: adv.ghsa });
    }
  }
  return { source: 'offline advisory snapshot (npm registry unreachable)', findings, scanned: Object.keys(deps).length, totals: null };
}
router.get('/deps', guarded('ORG-11', (req, res) => {
  const m = mode(req);
  const projectDir = __dirname;
  const vulnFixtureDir = path.join(__dirname, 'scanner', 'vuln-fixture');
  const cwd = m === 'fixed' ? projectDir : vulnFixtureDir;
  const lockPath = path.join(cwd, 'package-lock.json');
  let scan, offline = false;
  try {
    scan = liveAudit(cwd);
  } catch (e) {
    offline = true;
    scan = offlineAudit(lockPath);
  }
  const findings = scan.findings;
  const verdict = findings.length ? 'VULNERABLE' : 'SECURE';
  const summarise = (f) => `${f.package}${f.installed ? '@' + f.installed : ''} - ${f.severity} - ${f.title}${f.ghsa ? ' (' + f.ghsa + ')' : ''}`;
  reply(res, 200, {
    mode: m, verdict, attackId: 'ORG-11',
    request: `GET /api/assess/deps  (real npm audit of ${m === 'fixed' ? 'the project package-lock.json' : 'the outdated dependency fixture'})`,
    response: findings.length ? `${findings.length} vulnerable-dependency finding(s)` : 'no known-vulnerable dependencies in scope',
    detail: { mode: m, lockfile: path.relative(projectDir, lockPath) || 'package-lock.json',
      source: scan.source, offlineFallback: offline, scanned: scan.scanned, totals: scan.totals,
      findings },
    serverLog: [
      `scanning ${m === 'fixed' ? 'the real project lockfile' : 'the deliberately-outdated fixture lockfile'}: ${path.relative(projectDir, lockPath) || 'package-lock.json'}`,
      offline ? 'live npm registry unreachable → using offline advisory snapshot (real public advisories)' : `ran: npm audit --json  (source: ${scan.source})`,
      findings.length ? findings.slice(0, 6).map(summarise).join(' · ') : 'no advisory matches',
      verdict === 'VULNERABLE' ? 'known-vulnerable dependency present → VULNERABLE' : 'dependencies clean against the live advisory DB → SECURE',
    ],
  });
}));

/* ---- health for the assess router - derived from the registry ---- */
router.get('/__ping', (_req, res) => {
  const v = REGISTRY.validate();
  res.json({ ok: true, checks: REGISTRY.EXPECTED_COUNT, attackIds: REGISTRY.ids(),
    registryValid: v.ok, sectionCounts: v.sectionCounts, defensive: ['SMS-FRAUD'],
    note: 'assessment-api live - exactly 15 attacks', storage: 'sqlite',
    realAppPath: !!(harness && harness.available()) });
});

/* ---- catch-all: any retired/unknown assess route returns 404 "unsupported"
 * rather than executing a removed implementation. ---- */
router.use((req, res) => {
  reply(res, 404, {
    verdict: 'UNSUPPORTED',
    error: 'Unsupported or retired assessment route.',
    request: `${req.method} /api/assess${req.path}`,
    note: 'SENTINEL-X supports exactly 15 attacks. Retired attacks have been removed.',
    approvedAttackIds: REGISTRY.ids(),
  });
});

return router;
};
