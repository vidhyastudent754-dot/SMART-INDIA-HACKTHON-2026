#!/usr/bin/env node
/**
 * security-scan.js - automated security scanner for World Monitor (codename SENTINEL-X)
 *
 * Runs a fixed battery of black-box checks against a running instance of the
 * app and produces a report in the same format used by the manual
 * assessment (title / description / affected component / severity (CVSS) /
 * steps to reproduce / PoC / business impact / remediation).
 *
 * This exists to satisfy the "Smart Automation" angle of the assignment:
 * instead of re-running curl commands by hand after every change, this
 * script re-verifies the whole checklist in a few seconds and writes a
 * timestamped Markdown + JSON report you can attach as evidence.
 *
 * USAGE
 *   node scanner/security-scan.js [--target http://localhost:5175] [--json]
 *   npm run scan               (defaults to http://localhost:5175)
 *   npm run scan -- --target http://localhost:5176
 *
 * AUTH: the dashboard and its APIs require a session. Provide credentials via
 *   SCAN_USER / SCAN_PASS                (admin - used for the API checks)
 *   SCAN_VIEWER_USER / SCAN_VIEWER_PASS  (optional - enables the RBAC check)
 * Without SCAN_USER the authenticated checks are reported as FAIL, because a
 * scan that cannot reach the API proves nothing about it.
 *
 * IMPORTANT: only ever point this at a system you own/are authorized to
 * test, running locally or in a controlled test environment. This tool
 * makes real HTTP requests (including a short rate-limit burst and
 * oversized-payload probes); do not run it against third-party or
 * production infrastructure you do not control.
 */

'use strict';

const fs   = require('fs');
const path = require('path');

/* ── CLI args ───────────────────────────────────────────────────── */
const args = process.argv.slice(2);
function argVal(flag, fallback) {
  const i = args.indexOf(flag);
  return i !== -1 && args[i + 1] ? args[i + 1] : fallback;
}
const TARGET     = (argVal('--target', process.env.SCAN_TARGET || 'http://localhost:5175')).replace(/\/$/, '');
const JSON_ONLY  = args.includes('--json');
const OUT_DIR    = path.join(__dirname, 'reports');
const CREDS = { user: process.env.SCAN_USER, pass: process.env.SCAN_PASS,
  viewerUser: process.env.SCAN_VIEWER_USER, viewerPass: process.env.SCAN_VIEWER_PASS };
let SESSION = '';          // "wm_sid=…" once logged in
let LOGIN_SET_COOKIE = ''; // raw Set-Cookie of the admin login, for flag checks

async function loginAs(user, pass) {
  const r = await safeFetch(`${TARGET}/api/auth/login`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: user, password: pass }),
  });
  if (!r.ok || r.res.status !== 200) return { ok: false, status: r.ok ? r.res.status : r.error };
  const sc = r.res.headers.get('set-cookie') || '';
  return { ok: true, cookie: sc.split(';')[0], setCookie: sc };
}
const authed = (headers = {}) => (SESSION ? { ...headers, Cookie: SESSION } : headers);

/* ── tiny fetch helpers (Node 18+ has global fetch) ────────────── */
async function safeFetch(url, opts = {}) {
  try {
    const res = await fetch(url, { redirect: 'manual', ...opts });
    return { ok: true, res };
  } catch (err) {
    return { ok: false, error: err.message };
  }
}

/* ── finding catalog: static text kept separate from the dynamic
 *    evidence each check gathers, so the report reads the same way
 *    the manual assessment report does. ─────────────────────────── */
const CATALOG = {
  SEC_HEADERS: {
    title: 'Missing HTTP Security Headers',
    cwe: 'CWE-693 (Protection Mechanism Failure)',
    severity: 'Medium - 5.4 (CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:C/C:L/I:L/A:N)',
    affected: 'HTTP response headers (server entry point)',
    description: 'The application did not send Content-Security-Policy, X-Frame-Options, X-Content-Type-Options, or Referrer-Policy headers, and/or still discloses the backend framework via X-Powered-By.',
    businessImpact: 'Without frame protection the app can be embedded in an invisible iframe for clickjacking; without CSP, any future injection bug has an easier path to executing attacker script; X-Powered-By gives an attacker a head start fingerprinting the stack.',
    remediation: 'Add a headers middleware setting X-Content-Type-Options: nosniff, X-Frame-Options: DENY, Referrer-Policy: no-referrer, and a restrictive Content-Security-Policy; call app.disable(\'x-powered-by\').',
  },
  CORS_POLICY: {
    title: 'Permissive CORS Policy',
    cwe: 'CWE-942 (Permissive Cross-domain Policy)',
    severity: 'Medium - 5.3 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:L)',
    affected: 'server.js - CORS middleware',
    description: 'A cross-origin POST from an untrusted Origin was accepted (or the Origin was reflected back in Access-Control-Allow-Origin) instead of being rejected.',
    businessImpact: 'Any external website can silently call the API from a visitor\'s browser, consuming rate-limit budget or a paid third-party quota (Safe Browsing) on the app owner\'s behalf, and could embed the tool\'s output to lend false legitimacy to a phishing page.',
    remediation: 'Replace app.use(cors()) with an explicit allow-list of trusted origins (env-configurable), rejecting any other browser-originated cross-origin request.',
  },
  RATE_LIMIT: {
    title: 'Missing or Ineffective Rate Limiting',
    cwe: 'CWE-770 (Allocation of Resources Without Limits or Throttling)',
    severity: 'Medium - 5.3 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L)',
    affected: 'API endpoints (server.js)',
    description: 'A burst of rapid requests from a single client was not throttled - no 429 response was observed within the burst window.',
    businessImpact: 'Leaves the API (and any paid third-party lookups it triggers) open to abuse, credential-stuffing-style bursts, or basic denial-of-service amplification.',
    remediation: 'Apply express-rate-limit (or equivalent) per route, tuned separately for lightweight vs. heavier (regex-processing) endpoints.',
  },
  INPUT_LENGTH: {
    title: 'Unbounded Request Body Accepted',
    cwe: 'CWE-400 (Uncontrolled Resource Consumption)',
    severity: 'Low - 3.7 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L)',
    affected: 'server.js, analyzer.js',
    description: 'An oversized request body was accepted and processed instead of being rejected with 400.',
    businessImpact: 'Unnecessary CPU spent on regex-heavy analysis of arbitrarily large input; low-effort DoS amplification vector.',
    remediation: 'Reject bodies over a sane per-field character cap before running any analysis (URL, email, SMS each have different realistic limits).',
  },
  SOURCE_DISCLOSURE: {
    title: 'Server-Side Source Code / Config Disclosure via Static File Server',
    cwe: 'CWE-200 (Exposure of Sensitive Information), CWE-540 (Inclusion of Sensitive Information in Source Code)',
    severity: 'High - 7.5 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N)',
    affected: 'server.js - static file middleware',
    description: 'One or more server-side implementation files (application logic, dependency manifests, or config) were downloadable directly over HTTP because the static file middleware was pointed at the whole project directory instead of a dedicated public/ folder.',
    businessImpact: 'Disclosing analyzer/heuristics source lets an attacker read the exact scoring logic and regex patterns used to flag phishing content and craft messages engineered to evade detection - a direct defeat of the product\'s core function. Disclosing package.json/package-lock.json gives exact dependency versions for targeted CVE lookups.',
    remediation: 'Serve only a dedicated public/ (or dist/) directory containing client assets; never point express.static at the project root. Keep server-side .js files, package.json, and config outside any statically-served path.',
  },
  AUTH_REQUIRED: {
    title: 'Dashboard or API Reachable Without Authentication',
    cwe: 'CWE-306 (Missing Authentication for Critical Function)',
    severity: 'Critical - 9.1 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N)',
    affected: 'app.js - auth gate (lib/auth.js)',
    description: 'The dashboard page or an assessment/analysis API responded to a request that carried no session.',
    businessImpact: 'Anyone who can reach the host can use the console, run the assessment suite and read organisation data.',
    remediation: 'Place the session-auth middleware in front of the static dashboard and every /api route except /api/auth/login and /api/health.',
  },
  SESSION_COOKIE: {
    title: 'Session Cookie Missing Protective Flags',
    cwe: 'CWE-1004 (Sensitive Cookie Without HttpOnly), CWE-1275 (Cookie with Improper SameSite)',
    severity: 'Medium - 5.4 (CVSS:3.1/AV:N/AC:H/PR:N/UI:R/S:U/C:H/I:L/A:N)',
    affected: 'lib/auth.js - login response',
    description: 'The login response did not set the session cookie with HttpOnly and SameSite=Strict (or login failed).',
    businessImpact: 'Script access to the cookie enables session theft after any XSS; missing SameSite re-opens CSRF.',
    remediation: 'Set the session cookie with HttpOnly; SameSite=Strict; Secure (behind TLS).',
  },
  RBAC: {
    title: 'Read-only Role Can Run Organisation Assessments',
    cwe: 'CWE-285 (Improper Authorization)',
    severity: 'High - 8.1 (CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N)',
    affected: 'assessment-api.js - role gate',
    description: 'A viewer-role session was allowed to call an employee/organisation assessment endpoint.',
    businessImpact: 'Read-only users can read and modify the employee directory through the assessment suite.',
    remediation: 'Require role=admin for EMP-* and ORG-* endpoints; keep viewer to individual checks.',
  },
  DOTFILE_EXPOSURE: {
    title: 'Dotfile (.env / .git) Reachable via HTTP',
    cwe: 'CWE-538 (Insertion of Sensitive Information into Externally-Accessible File)',
    severity: 'Critical - 9.1 (CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N)',
    affected: 'server.js - static file middleware',
    description: 'A dotfile such as .env or .git/config was reachable over HTTP from the static file server.',
    businessImpact: 'Direct exposure of live secrets (API keys, DB credentials) to anyone who requests the path.',
    remediation: 'Confirm the static middleware keeps its default dotfile-ignore behavior, and additionally keep secrets entirely outside any statically-served directory as defense in depth.',
  },
};

/* ── checks ─────────────────────────────────────────────────────── */
async function checkSecurityHeaders() {
  const { ok, res, error } = await safeFetch(`${TARGET}/`);
  if (!ok) return fail('SEC_HEADERS', `Could not reach ${TARGET}/ (${error})`);
  const h = res.headers;
  const missing = [];
  if (!h.get('x-content-type-options')) missing.push('X-Content-Type-Options');
  if (!h.get('x-frame-options')) missing.push('X-Frame-Options');
  if (!h.get('content-security-policy')) missing.push('Content-Security-Policy');
  if (!h.get('referrer-policy')) missing.push('Referrer-Policy');
  if (h.get('x-powered-by')) missing.push('(X-Powered-By should be absent, found: ' + h.get('x-powered-by') + ')');
  const scriptSrc = String(h.get('content-security-policy') || '').split(';').map((d) => d.trim()).find((d) => d.startsWith('script-src')) || '';
  if (/unsafe-inline|unsafe-eval/.test(scriptSrc)) missing.push(`(CSP script-src must not allow inline/eval script, found: ${scriptSrc})`);
  if (missing.length) return fail('SEC_HEADERS', `Missing/present: ${missing.join(', ')}`);
  return pass('SEC_HEADERS', 'All required headers present; CSP script-src has no unsafe-inline/unsafe-eval; X-Powered-By absent.');
}

async function checkCorsPolicy() {
  const { ok, res, error } = await safeFetch(`${TARGET}/api/security/check-url`, {
    method: 'POST',
    headers: authed({ 'Content-Type': 'application/json', Origin: 'http://evil-scan-test.invalid' }),
    body: JSON.stringify({ url: 'http://example.com' }),
  });
  if (!ok) return fail('CORS_POLICY', `Request failed (${error})`);
  const allowOrigin = res.headers.get('access-control-allow-origin');
  if (allowOrigin === 'http://evil-scan-test.invalid' || allowOrigin === '*') {
    return fail('CORS_POLICY', `Server reflected untrusted Origin (Access-Control-Allow-Origin: ${allowOrigin})`);
  }
  if (res.status === 200) {
    return fail('CORS_POLICY', `Request from untrusted Origin returned ${res.status} instead of being rejected`);
  }
  return pass('CORS_POLICY', `Untrusted Origin correctly rejected (HTTP ${res.status}).`);
}

async function checkRateLimit() {
  const BURST = 70;
  let got429 = false;
  const requests = [];
  for (let i = 0; i < BURST; i++) {
    requests.push(safeFetch(`${TARGET}/api/security/check-url`, {
      method: 'POST',
      headers: authed({ 'Content-Type': 'application/json' }),
      body: JSON.stringify({ url: 'http://example.com' }),
    }));
  }
  const results = await Promise.all(requests);
  for (const r of results) {
    if (r.ok && r.res.status === 429) { got429 = true; break; }
  }
  if (!SESSION) return fail('RATE_LIMIT', 'No session (set SCAN_USER/SCAN_PASS) - requests were rejected with 401 before reaching the limiter.');
  if (!got429) return fail('RATE_LIMIT', `${BURST} rapid requests sent, none received HTTP 429`);
  return pass('RATE_LIMIT', `Rate limiting triggered within a ${BURST}-request burst.`);
}

async function checkInputLength() {
  const bigBody = 'a'.repeat(2500);
  if (!SESSION) return fail('INPUT_LENGTH', 'No session (set SCAN_USER/SCAN_PASS) - cannot exercise the analysis API.');
  const { ok, res, error } = await safeFetch(`${TARGET}/api/security/analyze-sms`, {
    method: 'POST',
    headers: authed({ 'Content-Type': 'application/json' }),
    body: JSON.stringify({ body: bigBody }),
  });
  if (!ok) return fail('INPUT_LENGTH', `Request failed (${error})`);
  if (res.status !== 400) return fail('INPUT_LENGTH', `2500-char SMS body returned HTTP ${res.status} instead of 400`);
  return pass('INPUT_LENGTH', 'Oversized SMS body correctly rejected with HTTP 400.');
}

async function checkSourceDisclosure() {
  const paths = ['/server.js', '/analyzer.js', '/heuristics.js', '/package.json', '/package-lock.json'];
  const exposed = [];
  for (const p of paths) {
    const { ok, res } = await safeFetch(`${TARGET}${p}`);
    if (ok && res.status === 200) exposed.push(p);
  }
  if (exposed.length) return fail('SOURCE_DISCLOSURE', `Reachable over HTTP: ${exposed.join(', ')}`);
  return pass('SOURCE_DISCLOSURE', 'No server-side source/config files reachable via the static file server.');
}

async function checkDotfileExposure() {
  const paths = ['/.env', '/.git/config', '/.env.local', '/.env.production'];
  const exposed = [];
  for (const p of paths) {
    const { ok, res } = await safeFetch(`${TARGET}${p}`);
    if (ok && res.status === 200) exposed.push(p);
  }
  if (exposed.length) return fail('DOTFILE_EXPOSURE', `Reachable over HTTP: ${exposed.join(', ')}`);
  return pass('DOTFILE_EXPOSURE', 'No dotfiles reachable via the static file server.');
}

async function checkAuthRequired() {
  const problems = [];
  const home = await safeFetch(`${TARGET}/`);
  if (!home.ok) return fail('AUTH_REQUIRED', `Could not reach ${TARGET}/ (${home.error})`);
  const loc = home.res.headers.get('location') || '';
  if (!(home.res.status === 302 && loc.startsWith('/login'))) problems.push(`GET / → ${home.res.status} (expected 302 to /login)`);
  for (const [m, p] of [['GET', '/api/assess/__ping'], ['GET', '/api/metrics'], ['POST', '/api/security/check-url'], ['GET', '/assessments/live-io.js']]) {
    const r = await safeFetch(`${TARGET}${p}`, { method: m, headers: { 'Content-Type': 'application/json' }, body: m === 'POST' ? '{"url":"example.com"}' : undefined });
    const st = r.ok ? r.res.status : r.error;
    const okStatus = p.startsWith('/api/') ? st === 401 : st === 302;
    if (!okStatus) problems.push(`${m} ${p} → ${st}`);
  }
  if (problems.length) return fail('AUTH_REQUIRED', problems.join('; '));
  return pass('AUTH_REQUIRED', 'Unauthenticated / → 302 /login; protected APIs → 401; dashboard assets gated.');
}

async function checkSessionCookie() {
  if (!LOGIN_SET_COOKIE) return fail('SESSION_COOKIE', 'Could not log in (set SCAN_USER/SCAN_PASS) - cookie flags not verifiable.');
  const miss = [];
  if (!/HttpOnly/i.test(LOGIN_SET_COOKIE)) miss.push('HttpOnly');
  if (!/SameSite=Strict/i.test(LOGIN_SET_COOKIE)) miss.push('SameSite=Strict');
  if (TARGET.startsWith('https:') && !/;\s*Secure/i.test(LOGIN_SET_COOKIE)) miss.push('Secure');
  if (miss.length) return fail('SESSION_COOKIE', `Session cookie missing: ${miss.join(', ')}`);
  return pass('SESSION_COOKIE', 'Session cookie is HttpOnly + SameSite=Strict' + (TARGET.startsWith('https:') ? ' + Secure.' : '.'));
}

async function checkRbac() {
  if (!CREDS.viewerUser) return pass('RBAC', 'Skipped - no SCAN_VIEWER_USER provided (RBAC is covered by npm test).');
  const v = await loginAs(CREDS.viewerUser, CREDS.viewerPass);
  if (!v.ok) return fail('RBAC', `Viewer login failed (${v.status})`);
  const r = await safeFetch(`${TARGET}/api/assess/org-endpoint`, { headers: { Cookie: v.cookie, 'X-Assess-Mode': 'fixed' } });
  const st = r.ok ? r.res.status : r.error;
  await safeFetch(`${TARGET}/api/auth/logout`, { method: 'POST', headers: { Cookie: v.cookie, 'Content-Type': 'application/json' }, body: '{}' });
  if (st !== 403) return fail('RBAC', `Viewer GET /api/assess/org-endpoint → ${st} (expected 403)`);
  return pass('RBAC', 'Viewer session receives 403 from organisation assessment endpoints.');
}

function pass(id, evidence) { return { id, passed: true, evidence }; }
function fail(id, evidence) { return { id, passed: false, evidence }; }

/* ── runner ─────────────────────────────────────────────────────── */
const CHECKS = [
  ['Authentication required', checkAuthRequired],
  ['Session cookie flags', checkSessionCookie],
  ['Role-based access control', checkRbac],
  ['Security headers', checkSecurityHeaders],
  ['CORS policy', checkCorsPolicy],
  ['Rate limiting', checkRateLimit],
  ['Input length validation', checkInputLength],
  ['Source code / config disclosure', checkSourceDisclosure],
  ['Dotfile exposure', checkDotfileExposure],
];

async function run() {
  console.log(`\nWorld Monitor automated security scan`);
  console.log(`Target: ${TARGET}`);
  console.log(`Authorized use only - do not point this at systems you do not own/control.\n`);
  if (CREDS.user) {
    const l = await loginAs(CREDS.user, CREDS.pass);
    if (l.ok) { SESSION = l.cookie; LOGIN_SET_COOKIE = l.setCookie; console.log(`  (authenticated as ${CREDS.user})\n`); }
    else console.log(`  ⚠ login as ${CREDS.user} failed (${l.status}) - authenticated checks will fail\n`);
  } else {
    console.log('  ⚠ SCAN_USER/SCAN_PASS not set - authenticated checks will fail\n');
  }

  const results = [];
  for (const [label, fn] of CHECKS) {
    process.stdout.write(`  • ${label} ... `);
    const r = await fn();
    console.log(r.passed ? 'PASS' : 'FAIL');
    results.push(r);
  }

  const failed = results.filter(r => !r.passed);
  const passed = results.filter(r => r.passed);

  console.log(`\n${passed.length} passed, ${failed.length} failed out of ${results.length} checks.\n`);

  fs.mkdirSync(OUT_DIR, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const jsonPath = path.join(OUT_DIR, `scan-${stamp}.json`);
  const mdPath   = path.join(OUT_DIR, `scan-${stamp}.md`);

  fs.writeFileSync(jsonPath, JSON.stringify({ target: TARGET, ranAt: new Date().toISOString(), results }, null, 2));
  fs.writeFileSync(mdPath, renderMarkdown(results));

  console.log(`Report written to:\n  ${jsonPath}\n  ${mdPath}\n`);

  if (!JSON_ONLY) console.log(renderMarkdown(results));

  process.exitCode = failed.length ? 1 : 0;
}

function renderMarkdown(results) {
  const failed = results.filter(r => !r.passed);
  const passed = results.filter(r => r.passed);
  let out = `# Automated Security Scan Report\n\n`;
  out += `**Target:** ${TARGET}\n**Run at:** ${new Date().toISOString()}\n**Result:** ${passed.length} passed / ${failed.length} failed / ${results.length} total\n\n---\n\n`;

  if (failed.length) {
    out += `## Findings\n\n`;
    for (const r of failed) {
      const c = CATALOG[r.id];
      out += `### ${c.title}\n\n`;
      out += `**Description:** ${c.description}\n\n`;
      out += `**Affected component:** ${c.affected}\n\n`;
      out += `**Severity:** ${c.severity} - ${c.cwe}\n\n`;
      out += `**Steps to reproduce / evidence from this run:**\n\`\`\`\n${r.evidence}\n\`\`\`\n\n`;
      out += `**Business impact:** ${c.businessImpact}\n\n`;
      out += `**Remediation:** ${c.remediation}\n\n---\n\n`;
    }
  } else {
    out += `## Findings\n\nNo failing checks in this run.\n\n---\n\n`;
  }

  out += `## Checks Passed\n\n`;
  for (const r of passed) {
    out += `- **${CATALOG[r.id].title}** - ${r.evidence}\n`;
  }
  out += `\n`;
  return out;
}

run().catch(err => {
  console.error('Scanner crashed:', err);
  process.exitCode = 2;
});
