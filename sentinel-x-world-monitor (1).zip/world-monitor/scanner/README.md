# Automated Security Scanner

A small black-box scanner that re-runs the checks from the manual security
assessment against a live instance of the app and writes a timestamped
report (Markdown + JSON) in the same format used in
`security-assessment-report.md`.

## Run it

```bash
npm start          # in one terminal, start the app (default port 5175)
SCAN_USER=admin SCAN_PASS='<admin password>' \
SCAN_VIEWER_USER=viewer SCAN_VIEWER_PASS='<viewer password>' \
npm run scan       # in another terminal, scan it
```

The dashboard and APIs require a session, so the scanner signs in with the
credentials above. CI runs this on every push (`.github/workflows/ci.yml`) and
fails the build on any finding.

Target a different port/host:

```bash
npm run scan -- --target http://localhost:5176
```

## What it checks

| Check | What it verifies |
|---|---|
| Authentication required | Unauthenticated `/` → 302 `/login`; protected APIs → 401; dashboard assets gated |
| Session cookie flags | Login sets `HttpOnly` + `SameSite=Strict` (+ `Secure` over HTTPS) |
| Role-based access control | A viewer session gets 403 from organisation assessment endpoints |
| Security headers | CSP, X-Frame-Options, X-Content-Type-Options, Referrer-Policy present; X-Powered-By absent |
| CORS policy | A request from an untrusted `Origin` is rejected, not reflected |
| Rate limiting | A burst of rapid requests eventually gets HTTP 429 |
| Input length validation | Oversized request bodies are rejected with HTTP 400 |
| Source code / config disclosure | `server.js`, `analyzer.js`, `heuristics.js`, `package.json`, `package-lock.json` are **not** downloadable over HTTP |
| Dotfile exposure | `.env`, `.git/config`, etc. are **not** downloadable over HTTP |

Output: `scanner/reports/scan-<timestamp>.md` and `.json`. Exit code is
non-zero if any check fails, so it can be wired into a CI pipeline as a
regression gate.

## Scope / safety

Only run this against an instance you own and are authorized to test
(default target is `http://localhost:5175`). The rate-limit check
deliberately sends ~70 requests in a burst; don't point it at shared or
production infrastructure.
