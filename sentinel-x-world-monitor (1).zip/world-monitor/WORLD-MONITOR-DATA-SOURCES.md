# World Monitor — Data Sources

## Source hierarchy
- **Tier A** — Primary official / government / law enforcement (CERT-In, MHA, I4C,
  NCRB, RBI, MeitY, NCIIPC, CISA, NIST/NVD, FBI IC3, INTERPOL, Europol, …).
- **Tier B** — Authoritative security intelligence (Microsoft Threat Intelligence,
  Cisco Talos, IBM X-Force, Verizon DBIR, Cloudflare Radar).
- **Tier C** — Public social / web signals (X, YouTube, Reddit, approved public
  Telegram, authorized WhatsApp Business/Channel) — public discussion only.
- **Tier D** — Research data (Kaggle, Google Scholar, academic repositories).

## Registered international sources (≥10)
CISA · NIST/NVD · MITRE ATT&CK · ENISA · INTERPOL Cybercrime · Europol/EC3 ·
FBI IC3 · Verizon DBIR · Microsoft Threat Intelligence/MDDR · Cisco Talos ·
IBM X-Force · Cloudflare Radar. (Exact official URLs in `db/world-seed.js` and
surfaced in `/api/world/sources`.)

## Registered India national sources (≥10)
CERT-In · I4C · NCRB · MHA · MeitY · RBI · NCIIPC · Cyber Swachhta Kendra ·
NPCI · data.gov.in · PIB.

## Real-time definition
`LIVE` is used **only** for `feed_type` of `live`/`near_live` fetched within
minutes. Official annual/periodic reports are never shown with a `LIVE` badge —
they display `RECENT`/`CACHED`/`STALE` reflecting the last successful fetch, and
the API labels them "official periodic statistic".

## Source status vocabulary
`LIVE, RECENT, CACHED, STALE, UNAVAILABLE, PARSE_ERROR, AUTH_REQUIRED,
RATE_LIMITED, NOT_SUPPORTED, NOT_PUBLISHED`.

## Health probing
`npm run world:refresh` does a real HTTP GET per source, records HTTP status,
fetch duration, a SHA-256 receipt of the body, and the resulting status. In an
air-gapped/egress-restricted environment sources honestly report `UNAVAILABLE` /
`AUTH_REQUIRED` rather than being faked as reachable.

## Real data collected & ingested (2026-09-25)
All figures below are ingested into `wm_metrics`/`wm_case_lifecycle`/`wm_incidents` with their exact source URL (see `db/world-data.json`), and surfaced in the observatory UI with clickable sources.

**Per-attack real-world prevalence** (the prevalence of each vulnerability *class*, crosswalked to the 15 — NOT a fabricated per-attack case count, which no source publishes):
- OWASP Top 10 2021 contributed dataset — incidence rates, occurrences, CVEs per category:
  A01 Broken Access Control 55.97% max / 318,487 occ / 19,013 CVE; A02 Cryptographic Failures 46.44% max; A03 Injection 19.09% max / 32,078 CVE; A06 Vulnerable Components 8.77% avg; A07 Auth Failures 14.84% max; A08 Software/Data Integrity 16.67% max (incl. CWE-915). Source: https://owasp.org/Top10/2021/
- HackerOne Top 10 most-rewarded vulnerability types (XSS #1, Improper Auth #2, Info Disclosure #3, Priv-Esc #4, SQLi #5, IDOR #8). Source: https://www.hackerone.com/blog/hackerone-top-10-most-impactful-and-rewarded-vulnerability-types

**Country comparison:**
- World Cybercrime Index 2024 (Oxford/UNSW, PLoS ONE) — rank per country (Russia 1 … India 10). Source: https://www.ox.ac.uk/news/2024-04-10-world-first-cybercrime-index-ranks-countries-cybercrime-threat-level
- FBI IC3 2024 — 859,532 complaints, >$16B losses. Source: https://www.fbi.gov/news/press-releases/fbi-releases-annual-internet-crime-report

**India:**
- NCRB Crime in India — cyber cases registered 2020 49,708 / 2021 52,974 / 2022 65,893; conviction rate ~1.6% (2020–22). Sources: https://www.drishtiias.com/daily-updates/daily-news-analysis/ncrbs-crime-in-india-2022-report , https://www.tribuneindia.com/news/india/only-1-6-conviction-rate-in-2-yrs-amid-surge-in-cybercrime-cases-2
- Top states 2022 (NCRB): Telangana 15,297; Karnataka 12,556; Uttar Pradesh 10,117. Source: https://www.business-standard.com/india-news/telangana-logs-15-297-cybercrime-cases-in-2022-highest-in-india-ncrb-123120501397_1.html
- NCRP complaints 2024 2.27M; reported loss ₹22,845 cr (migrated from observatory.json; MHA Parliament replies).

**Research datasets (Kaggle, real URLs):** intrusion detection, PhishTank URLs, web-page phishing — kept separate from official statistics.

**Future-scope critical families (evidence-linked):** ransomware (FBI IC3 2024), MOVEit supply-chain (CISA AA23-158A), CISA KEV catalog.

> Honesty note: public sources do NOT publish per-CWE case counts per country (e.g. "IDOR cases registered in India"). We therefore show the real *class prevalence* (OWASP/HackerOne) for each attack plus real *aggregate* national figures, and mark anything without a source as UNAVAILABLE / NOT PUBLISHED.
