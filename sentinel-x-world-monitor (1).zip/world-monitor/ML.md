# The ML layer — what it is, what it learned, how well it works

World Monitor's email and SMS analysis is **hybrid**: a rule engine (`analyzer.js`)
and a small learned model (`lib/ml.js`) score every message, and the verdict comes
from a documented blend of the two. Both scores are returned by the API and shown
in the UI; neither is hidden.

```
POST /api/security/analyze-email  →  { heuristicScore, mlScore, combinedConfidence, verdict, ml: { topSignals… }, signals… }
```

## 1. Model

| | |
|---|---|
| Features | TF-IDF over unigrams **and** bigrams, sublinear tf (`1 + ln tf`), smoothed idf, L2-normalised; top 5,000 terms with document frequency ≥ 3 |
| Classifier | Logistic regression (liblinear), `class_weight="balanced"`, regularisation `C` picked by 5-fold stratified CV on F1 from {0.5, 1, 2, 4, 8, 16} → **C = 8** for both models |
| Output | `P(phishing or spam)`; `mlScore = round(P × 100)` |
| Runtime | **No ML runtime.** `ml/train.py` exports `[term, idf, coef]` triples + intercept to `models/*.json` (≈150 KB each). `lib/ml.js` scores them in-process in well under a millisecond. |
| Explainability | Every score returns its top contributing terms with their signed contribution to the logit (shown in the UI as “model cues”). |

**Why this and not a neural model?** It trains in seconds, ships as a JSON file, runs
anywhere Node runs (air-gapped ministry servers included), and every prediction can be
explained term by term. For a detection-only awareness tool, that trade is worth more
than a few points of accuracy.

**Tokenizer.** Lower-case → strip HTML tags → replace URLs, email addresses, currency
signs and digit runs with placeholder tokens (`zzurl`, `zzemail`, `zzmoney`, `zznum`,
shown in the UI as `<link>`, `<number>`, …) → keep `[a-z]+` tokens of length ≥ 2 →
add bigrams. The Python and JavaScript implementations are line-for-line equivalents.

**Parity proof.** `ml/train.py` saves 40 held-out messages per model together with
the probability scikit-learn computed (`test/fixtures/ml-parity.json`).
`test/ml.test.js` re-scores them with `lib/ml.js` and fails if any differs by more than
1e-4. Observed maximum difference: **5 × 10⁻⁷**. The server runs *the same model*, not
an approximation of it.

## 2. Training data

All public, all cited, none written by us.

| Model | Corpus | Messages | Positive class | Licence / source |
|---|---|---|---|---|
| Email | **Nazario** phishing corpus | 1,565 | phishing | via Al-Subaiey et al. 2024 curated set¹ |
| Email | **SpamAssassin** public corpus | 5,809 | spam (1,718) vs ham (4,091) | via ¹ |
| Email | **Enron-Spam** | 29,767 | spam (13,976) vs ham (15,791) | via ¹ |
| SMS | **UCI SMS Spam Collection v.1** (Almeida & Hidalgo, 2011) | 5,574 | spam (747) vs ham (4,827) | UCI ML Repository |

¹ A. Al-Subaiey et al., *Novel Interpretable and Robust Web-based AI Platform for
Phishing Email Detection* (2024), CC BY-SA 4.0 — mirrored at
`github.com/rokibulroni/Phishing-Email-Dataset`.

After de-duplication the email set has **36,659** messages (47% positive).

**The positive class is “phishing or spam”, not phishing alone.** The public corpora
label unsolicited bulk mail and phishing together. So `mlScore` means “reads like
malicious/unsolicited mail”; the rule engine adds the phishing-specific knowledge
(credential requests, brand impersonation, KYC/UPI patterns, link structure).

### Data cleaning — and why the headline number went *down*

The first email model scored **98.9%** accuracy. Its most important features were
`sightings mailing`, `spamassassin sightings` and `url zzurl`. Those are mailing-list
footers and feed headers: the model had learned *which corpus a message came from*,
not whether it was phishing. We removed, **from training text only**:

1. lines containing list/footer artifacts (`mailing list`, `listinfo`, `unsubscribe`,
   `sightings`, `URL:` / `Date:` feed headers, separator lines);
2. bracketed subject tags such as `[ILUG]`, `[SAtalk]`;
3. corpus-identity tokens — company, list and frequent-correspondent names such as
   `enron`, `kaminski`, `houston`, `spamassassin`, `zzzzteana` (full list in
   `ml/train.py`, `CORPUS_IDENTITY`).

Accuracy fell to 96.5%, then rose to **97.0%** once Enron's business email was added.
Real phishing cues now dominate: `click here`, `your account`, `kindly`, `payment`,
`important`. Conversational business language pushes the other way: `wrote`, `thanks`,
`attached`, `forwarded`, `discuss`. We think a slightly lower but honest number is
the defensible one.

## 3. Results on a held-out split

80/20 stratified split, `random_state = 42`. The test split is never seen during
training or C selection.

| Model | Test messages | Accuracy | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|---|
| **Email** | 7,332 | **0.970** | **0.964** | **0.972** | **0.968** | 0.996 |
| **SMS** | 1,115 | **0.992** | **0.986** | **0.953** | **0.969** | 0.995 |

Confusion matrices (threshold 0.5):

| | Email: predicted ham | Email: predicted bad | SMS: predicted ham | SMS: predicted bad |
|---|---|---|---|---|
| **actually ham** | 3,760 | 126 | 964 | 2 |
| **actually bad** | 95 | 3,351 | 7 | 142 |

Email accuracy by source on the test split: Enron 97.9%, Nazario (phishing) 97.6%,
SpamAssassin 91.9%. SpamAssassin is the hardest because its ham is 2002-era technical
mailing lists and its spam is highly varied.

Full numbers, including 5-fold CV F1 and the top 25 terms each way, are in
`ml/metrics.json`.

## 4. The blend

```
combinedConfidence = 0.6 × heuristicScore + 0.4 × mlScore
```

| | Email | SMS |
|---|---|---|
| **PHISHING / SCAM** | combined ≥ 55 | combined ≥ 50 |
| **SUSPICIOUS** | combined ≥ 30 | combined ≥ 30 |
| **LIKELY SAFE** | below | below |

Why 60/40:

- **The rules carry India-specific knowledge the corpora don't have.** The training
  data is British/Singaporean SMS and US email from 2000–2012. It has no KYC, UPI,
  Aadhaar, IRCTC or PhonePe. The heuristics do.
- **The model catches wording nobody wrote a rule for** (see the electricity scam below).
- **At 40% weight the model alone cannot produce the strongest verdict.** With
  `heuristicScore = 0`, combined is at most 40. That is SUSPICIOUS at worst, never
  PHISHING. An auditable rule must agree before the app tells someone a message is
  definitely a scam. This is tested in `test/analyzer.test.js`.

### Out-of-distribution examples (Indian context, not in any training set)

| Type | Message | Heuristic | ML | Combined | Rules alone | **Hybrid** |
|---|---|---|---|---|---|---|
| email | SBI account suspension (app sample) | 100 | 100 | 100 | PHISHING | **PHISHING** |
| email | HDFC KYC update | 81 | 99 | 88 | PHISHING | **PHISHING** |
| email | Team meeting minutes | 0 | 2 | 1 | LIKELY SAFE | **LIKELY SAFE** |
| email | HR leave approval | 0 | 55 | 22 | LIKELY SAFE | **LIKELY SAFE** |
| email | Flipkart delivery notice | 0 | 99 | 40 | LIKELY SAFE | **SUSPICIOUS** ⚠ |
| sms | Amazon cancellation scam (app sample) | 45 | 98 | 66 | SUSPICIOUS | **SCAM** |
| sms | Electricity disconnection scam | 15 | 74 | 39 | LIKELY SAFE ✗ | **SUSPICIOUS** ✓ |
| sms | KBC lottery scam | 20 | 100 | 52 | SUSPICIOUS | **SCAM** |
| sms | Genuine bank OTP | 40 | 48 | 43 | SUSPICIOUS ⚠ | **SUSPICIOUS** ⚠ |
| sms | Personal message | 0 | 1 | 0 | LIKELY SAFE | **LIKELY SAFE** |
| sms | Swiggy delivery update | 0 | 71 | 28 | LIKELY SAFE | **LIKELY SAFE** |

What the table shows:

- **Where the ML adds value.** The electricity-disconnection scam contains no link,
  brand or credential request, so the rules miss it. The model recognises the
  pressure language and lifts it to SUSPICIOUS. It also firms up two scams the rules
  only called suspicious.
- **Known false positive (model).** Short e-commerce notifications (“your order has
  been delivered, rate your experience”) look like marketing spam to a model trained
  on 2000s corpora. The blend caps this at SUSPICIOUS.
- **Known false positive (rules).** A genuine OTP SMS mentions “OTP”, and the rule
  engine treats any OTP mention as a data request. A sender allow-list for registered
  bank sender IDs (e.g. `AX-HDFCBK`) would fix this and is a natural next step.

## 5. Limitations (said up front)

- The training corpora are old and mostly English/Western. Hinglish, regional-language
  and very recent lures are out of distribution. The rule engine and the 60/40 cap
  exist because of this.
- The positive class conflates spam and phishing (see §2).
- SMS ham contains `lt`/`gt` tokens from HTML-escaped placeholders in the original
  corpus. They are harmless but visible in the feature list.
- The model is static: it does not learn from user feedback. The path to a better
  model is a small labelled set of Indian messages (e.g. from NCRP-style reports),
  which would plug straight into `ml/train.py`.

## 6. Re-training

```bash
pip install -r ml/requirements.txt     # scikit-learn, pandas, numpy
bash ml/fetch-data.sh                  # downloads the corpora into ml/data/ (git-ignored, ~70 MB)
npm run ml:train                       # writes models/*.json, ml/metrics.json, test/fixtures/ml-parity.json
npm test                               # parity + metric-floor tests must still pass
```

Training is deterministic (`random_state = 42`) and takes about a minute on a laptop.
