/**
 * app.js - builds the World Monitor Express app. server.js starts it; the
 * test suite builds isolated instances against temporary databases.
 *
 *   createApp({ db, config }) → { app, attach(server), close() }
 */
'use strict';

const path = require('path');
const crypto = require('crypto');
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');

const { heuristicCheckUrl } = require('./heuristics');
const hybrid = require('./lib/hybrid');
const { createAuth } = require('./lib/auth');
const { createActivity } = require('./lib/activity');
const { createAppRoutes, createHarness } = require('./lib/app-routes');
const { createMetrics } = require('./lib/metrics');
const createAssessRouter = require('./assessment-api');
const smsFraud = require('./lib/sms-fraud');
const { createLiveFeed } = require('./lib/live-feed');
const { createWorldApi } = require('./lib/world-api');
const { createGiObservatory } = require('./lib/gi-observatory');
const { createObservatoryCache } = require('./lib/observatory-cache');
const { createObservatoryRouter } = require('./lib/observatory');
const { createFabric } = require('./lib/fabric');
const { createAlerts } = require('./lib/fabric/alerts');
const { createFabricApi } = require('./lib/fabric/api');

const PUBLIC_DIR = path.join(__dirname, 'public');
const MAX_URL_LENGTH = 2048;
const MAX_TEXT_LENGTH = 20000;
const MAX_SMS_LENGTH = 2000;

function createApp({ db, config = {} }) {
  const cfg = {
    port: config.port || 5175,
    gsbKey: config.gsbKey || '',
    forceHttps: !!config.forceHttps,
    authDisabled: !!config.authDisabled,
    assessLab: config.assessLab !== false,
    allowedOrigins: config.allowedOrigins || [],
    checkRateMax: config.checkRateMax || 60,
    analyzeRateMax: config.analyzeRateMax || 30,
    // Live observatory signals make outbound requests; server.js turns them on,
    // tests leave them off (or inject a mock fetch) so test runs never hit the internet.
    observatoryLive: !!config.observatoryLive,
    observatoryFetch: config.observatoryFetch,
    observatoryFile: config.observatoryFile,
    // Real-Time Verified Fabric (module). Polling is OFF unless explicitly enabled (server.js does;
    // tests inject fixtures), so a test run can never reach the internet.
    fabric: { enabled: true, poll: false, ...(config.fabric || {}) },
    smallCellK: config.smallCellK || 3,
  };

  const app = express();
  const startedAt = Date.now();
  let baseUrl = null;   // set by attach() once the server is listening

  app.disable('x-powered-by');
  app.set('trust proxy', 1);

  /* ── transport + security headers ─────────────────────────────── */
  app.use((req, res, next) => {
    if (cfg.forceHttps && !req.secure) return res.redirect(301, `https://${req.headers.host}${req.originalUrl}`);
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'DENY');
    res.setHeader('Referrer-Policy', 'no-referrer');
    res.setHeader('Permissions-Policy', 'geolocation=(), camera=(), microphone=()');
    res.setHeader('Content-Security-Policy',
      "default-src 'self'; script-src 'self'; object-src 'none'; " +
      "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; " +
      "img-src 'self' data: https://img.youtube.com; connect-src 'self'; " +
      "frame-ancestors 'none'; base-uri 'self'; form-action 'self'");
    if (req.secure || cfg.forceHttps) res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
    next();
  });

  /* ── CORS: same-origin + explicit allow-list only ──────────────────
   * Same-origin POSTs carry an Origin header too; those are always allowed
   * (previously they were rejected unless the deploy URL was also listed in
   * ALLOWED_ORIGINS, which broke every non-localhost deployment).        */
  app.use(cors((req, cb) => {
    const origin = req.header('Origin');
    const self = `${req.protocol}://${req.get('host')}`;
    if (!origin || origin === self || cfg.allowedOrigins.includes(origin)) {
      return cb(null, { origin: !!origin && origin !== self ? origin : false, credentials: true, methods: ['GET', 'POST', 'PATCH', 'OPTIONS'] });
    }
    return cb(new Error('CORS_NOT_ALLOWED'));
  }));

  const jsonSmall = express.json({ limit: '256kb' }), jsonFile = express.json({ limit: '14mb' });
  app.use((req, res, next) => (req.path === '/api/scam/file' ? jsonFile : jsonSmall)(req, res, next));

  /* ── CSRF defence for cookie auth ───────────────────────────────────
   * The session cookie is SameSite=Strict. In addition, state-changing API
   * calls must be JSON: an HTML form on another site cannot send
   * application/json without a CORS preflight, which the policy above fails. */
  app.use('/api', (req, res, next) => {
    if (['POST', 'PUT', 'PATCH', 'DELETE'].includes(req.method) && !req.is('application/json')) {
      return res.status(415).json({ error: 'State-changing API requests must use Content-Type: application/json.' });
    }
    next();
  });

  /* ── core services ─────────────────────────────────────────────── */
  const auth = createAuth(db, { authDisabled: cfg.authDisabled, forceSecureCookie: cfg.forceHttps });
  const activity = createActivity(db);
  const harnessSecret = crypto.randomBytes(24).toString('hex');
  const harness = createHarness(db, auth, { secret: harnessSecret, getBaseUrl: () => baseUrl });
  const gsbStatus = { configured: !!cfg.gsbKey, lastCallAt: null, lastOk: null, lastError: null, calls: 0, failures: 0 };

  app.use(auth.authenticate);

  /* ── public (unauthenticated) surface: login page, its assets, liveness ─ */
  const serveFile = (f) => (_req, res) => res.sendFile(path.join(PUBLIC_DIR, f));
  app.get(['/login', '/login.html'], (req, res) => {
    if (req.user && (req.user.role === 'admin' || req.user.role === 'viewer')) return res.redirect(302, '/');
    return serveFile('login.html')(req, res);
  });
  app.get('/favicon.svg', serveFile('favicon.svg'));
  app.get('/theme.css', serveFile('theme.css'));
  app.get('/theme-fx.js', serveFile('theme-fx.js'));
  app.get('/js/login.js', serveFile('js/login.js'));   // the sign-in page's script (public, no inline JS)
  app.get('/fonts/:file', (req, res, next) => {
    if (!/^[a-z0-9-]+\.(woff2|txt)$/.test(req.params.file)) return next();
    res.setHeader('Cache-Control', 'public, max-age=604800');
    res.sendFile(path.join(PUBLIC_DIR, 'fonts', req.params.file));
  });
  app.get('/favicon.ico', (_req, res) => res.redirect(301, '/favicon.svg'));
  app.use('/api/auth', auth.router);
  app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'world-monitor', uptime: Math.round(process.uptime()) }));

  /* ── everything below requires a signed-in user ────────────────── */
  const dashboardUser = auth.requireRole('admin', 'viewer');
  const checkLimiter = rateLimit({
    windowMs: 60 * 1000, max: cfg.checkRateMax, standardHeaders: true, legacyHeaders: false,
    keyGenerator: (req) => (req.user ? 'u:' + req.user.id : 'ip:' + req.ip),
    message: { error: 'Too many requests - please slow down.' },
  });
  const analyzeLimiter = rateLimit({
    windowMs: 60 * 1000, max: cfg.analyzeRateMax, standardHeaders: true, legacyHeaders: false,
    keyGenerator: (req) => (req.user ? 'u:' + req.user.id : 'ip:' + req.ip),
    message: { error: 'Too many requests - please slow down.' },
  });

  async function googleSafeBrowsingLookup(url) {
    if (!cfg.gsbKey) return null;
    const body = {
      client: { clientId: 'world-monitor', clientVersion: '2.0.0' },
      threatInfo: {
        threatTypes: ['MALWARE', 'SOCIAL_ENGINEERING', 'UNWANTED_SOFTWARE', 'POTENTIALLY_HARMFUL_APPLICATION'],
        platformTypes: ['ANY_PLATFORM'], threatEntryTypes: ['URL'], threatEntries: [{ url }],
      },
    };
    gsbStatus.calls++; gsbStatus.lastCallAt = new Date().toISOString();
    try {
      const res = await fetch(`https://safebrowsing.googleapis.com/v4/threatMatches:find?key=${encodeURIComponent(cfg.gsbKey)}`,
        { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body), signal: AbortSignal.timeout(5000) });
      if (!res.ok) throw new Error(`GSB HTTP ${res.status}`);
      const data = await res.json();
      gsbStatus.lastOk = true; gsbStatus.lastError = null;
      return (data.matches && data.matches.length > 0) ? data.matches.map((m) => m.threatType) : [];
    } catch (err) {
      gsbStatus.failures++; gsbStatus.lastOk = false; gsbStatus.lastError = err.message;
      throw err;
    }
  }

  app.post('/api/security/check-url', dashboardUser, checkLimiter, async (req, res) => {
    const { url } = req.body || {};
    if (!url || typeof url !== 'string' || !url.trim()) return res.status(400).json({ error: 'Missing "url".' });
    const rawUrl = url.trim();
    if (rawUrl.length > MAX_URL_LENGTH) return res.status(400).json({ error: `URL too long (max ${MAX_URL_LENGTH} characters).` });
    const h = heuristicCheckUrl(rawUrl);
    if (!h.ok) return res.status(400).json({ error: h.error });
    let source = 'heuristic', verdict = h.verdict, confidence = h.confidence, explanation = h.explanation;
    if (cfg.gsbKey) {
      try {
        const threats = await googleSafeBrowsingLookup(rawUrl);
        source = 'api';
        if (threats.length > 0) {
          verdict = 'MALICIOUS'; confidence = Math.max(confidence, 92);
          explanation = `Flagged by Google Safe Browsing (${threats.join(', ')}). ${explanation}`;
        }
      } catch { source = 'heuristic_fallback'; }
    }
    activity.record('url', verdict, source, req.user.username);
    res.json({ url: rawUrl, verdict, secure: verdict === 'SAFE', confidence, riskScore: h.score, explanation, signals: h.signals, good: h.good, host: h.host, officialBrand: h.officialBrand, imitates: h.imitates, source, checkedAt: new Date().toISOString() });
  });

  function analyzeHandler(type, maxLen, minLen) {
    return (req, res) => {
      const { body: text, sender } = req.body || {};
      if (!text || typeof text !== 'string' || text.trim().length < minLen) {
        return res.status(400).json({ error: `Paste the ${type === 'email' ? 'email' : 'SMS'} content in the "body" field.` });
      }
      if (text.length > maxLen) return res.status(400).json({ error: `${type === 'email' ? 'Email' : 'SMS'} body too long (max ${maxLen} characters).` });
      const result = hybrid.analyze(type, text, typeof sender === 'string' ? sender.slice(0, 320) : undefined);
      if (!result.ok) return res.status(400).json({ error: result.error });
      activity.record(type, result.verdict, result.engine, req.user.username);
      res.json(result);
    };
  }
  app.post('/api/security/analyze-email', dashboardUser, analyzeLimiter, analyzeHandler('email', MAX_TEXT_LENGTH, 5));
  app.post('/api/security/analyze-sms', dashboardUser, analyzeLimiter, analyzeHandler('sms', MAX_SMS_LENGTH, 3));

  app.use('/api/activity', dashboardUser, activity.router);

  /* cyber threat observatory (section-0) - reference data + live signals */
  const observatory = createObservatoryCache({ live: cfg.observatoryLive, fetchImpl: cfg.observatoryFetch, file: cfg.observatoryFile });
  const observatoryReady = observatory.start();
  app.use('/api/observatory', dashboardUser, createObservatoryRouter(observatory));

  const metrics = createMetrics({ db, startedAt, gsbStatus, activity, harness, auth, cfg, observatory,
    limiters: { 'check-url': { limiter: checkLimiter, max: cfg.checkRateMax }, analyze: { limiter: analyzeLimiter, max: cfg.analyzeRateMax } } });
  app.get('/api/metrics', dashboardUser, metrics.handler);
  app.get('/api/metrics.csv', auth.requireRole('admin'), metrics.csvHandler);

  /* Real-Time Verified Fabric + Alerts + Data Trust (independently switchable) */
  let fabric = null, fabricApi = null;
  if (cfg.fabric.enabled !== false) {
    fabric = createFabric({ db, config: cfg.fabric });
    const alerts = cfg.fabric.alerts !== false ? createAlerts(fabric) : null;
    if (alerts) fabric.attachAlerts(alerts);
    fabricApi = createFabricApi(fabric, alerts, { requireRole: auth.requireRole, smallCellK: cfg.smallCellK,
      estimatesEnabled: String(process.env.OBSERVATORY_ESTIMATES || 'on').toLowerCase() !== 'off' });
    app.use('/api/v1', fabricApi.router);
    fabric.start();
  }

  /* Live data feed: automatic collection from official sources + admin-fed data points, stored in SQLite */
  const liveFeed = createLiveFeed({ db, fabric, auto: !!cfg.observatoryLive, requireRole: auth.requireRole, fetchImpl: cfg.observatoryFetch || ((...a) => fetch(...a)) });
  app.use('/api/feed', dashboardUser, liveFeed.router);
  liveFeed.start();

  /* Live data: one plain status endpoint + a "Refresh now" button for admins.
   * Explains in words why a source is not updating (offline, firewall, blocked). */
  function whyFailed(err) {
    const e = String(err || '');
    if (!e) return '';
    if (/ENOTFOUND|EAI_AGAIN|getaddrinfo/i.test(e)) return 'No internet connection (the address could not be looked up).';
    if (/HTTP 403|HTTP 407/i.test(e)) return 'The request was refused (HTTP 403). A firewall, proxy or the source itself is blocking it.';
    if (/HTTP 429/i.test(e)) return 'The source asked us to slow down (HTTP 429). It will retry automatically.';
    if (/HTTP 5\d\d/i.test(e)) return 'The source\'s server had an error. It will retry automatically.';
    if (/abort|timeout|timed out/i.test(e)) return 'The source took too long to answer.';
    if (/ECONNREFUSED|ECONNRESET|fetch failed|network/i.test(e)) return 'Could not connect. Check your internet connection.';
    return e.slice(0, 160);
  }
  function liveStatus() {
    const sources = fabric ? fabric.SOURCES.filter((src) => src.adapter).map((src) => {
      const f = fabric.freshness(src);
      const n = db.prepare('SELECT COUNT(*) n FROM fabric_events WHERE environment = ? AND source_id = ? AND superseded_by IS NULL').get(fabric.ENV, src.id).n;
      return { id: src.id, name: src.organization || src.title || src.id, url: src.landing || src.url, enabled: fabric.enabledFor(src), state: f.state, label: f.label || f.state,
        lastSuccessAt: f.lastSuccessAt || null, lastAttemptAt: f.lastAttemptAt ? new Date(f.lastAttemptAt).toISOString() : (f.lastFailureAt || null), events: n, problem: whyFailed(f.lastError) };
    }) : [];
    const sig = Object.values((observatory.get() || {}).signals || {}).map((x) => ({ key: x.key, label: x.label, value: x.value, unit: x.unit, live: x.source === 'live',
      fetchedAt: x.fetchedAt || null, source: x.origin, sourceUrl: x.sourceUrl, problem: x.source === 'live' ? '' : whyFailed(x.error) }));
    for (const c of liveFeed.status()) if (c.id !== 'fabric') sources.push({ id: c.id, name: c.name, url: c.url, enabled: !!cfg.observatoryLive, state: c.lastOkAt ? 'live' : 'unavailable',
      label: c.lastOkAt ? 'Collected' : 'No response yet', lastSuccessAt: c.lastOkAt, lastAttemptAt: c.lastAttemptAt, events: db.prepare('SELECT COUNT(*) n FROM live_feed WHERE source_id = ?').get(c.id).n,
      problem: whyFailed(c.lastError), via: c.via });
    return { liveEnabled: !!cfg.observatoryLive, feedEnabled: !!fabric || !!cfg.observatoryLive, checkedAt: new Date().toISOString(), sources, signals: sig,
      howToEnable: !fabric || !cfg.observatoryLive ? 'Live data is switched off in .env. Remove LIVE_DATA=off (or set FABRIC=on and OBSERVATORY_LIVE=on) and restart npm start.' : null };
  }
  app.get('/api/live/status', dashboardUser, (_req, res) => res.json(liveStatus()));
  app.post('/api/live/refresh', auth.requireRole('admin'), async (req, res) => {
    const runs = [];
    if (fabric) for (const src of fabric.SOURCES.filter((x) => x.adapter && fabric.enabledFor(x))) {
      try { runs.push(await fabric.runSource(src.id, { trigger: 'manual', actor: req.user.username, force: true })); } catch (e) { runs.push({ sourceId: src.id, outcome: 'failed', error: e.message }); }
    }
    if (cfg.observatoryLive) { try { await observatory.refresh(); } catch (e) { /* reported per signal */ } }
    try { await liveFeed.collect(); } catch (e) { /* reported per collector */ }
    res.json(Object.assign(liveStatus(), { runs: runs.map((r) => ({ sourceId: r.sourceId, outcome: r.outcome || r.skipped, created: r.created || 0, problem: whyFailed(r.error) })) }));
  });

  /* real employee self-service API + lab twins */
  const appRoutes = createAppRoutes(db, { requireRole: auth.requireRole, harnessSecret });
  app.use('/api', appRoutes.prod);
  if (cfg.assessLab) app.use('/api/lab/vulnerable', appRoutes.lab);

  /* live security-assessment API */
  app.use('/api/assess', createAssessRouter({ db, activity, harness, requireRole: auth.requireRole }));

  /* ── SENTINEL-X SMS Fraud Detection (DEFENSIVE capability - not an attack) ──
   * Real-time smishing / OTP-disclosure / phishing analysis. The detector never
   * needs (and never stores) the real OTP/PIN/card - it reports the disclosure
   * REQUEST and redacts the secret. Verdicts are computed from the signals in
   * the supplied message, never predetermined.                               */
  app.post('/api/sms/analyze', dashboardUser, analyzeLimiter, (req, res) => {
    const b = req.body || {};
    const message = typeof b.message === 'string' ? b.message : (typeof b.body === 'string' ? b.body : '');
    if (!message || message.trim().length < 3) {
      return res.status(400).json({ ok: false, classification: 'ANALYSIS_ERROR',
        error: 'Provide the SMS text in the "message" field (min 3 characters).' });
    }
    if (message.length > MAX_SMS_LENGTH) {
      return res.status(400).json({ ok: false, classification: 'ANALYSIS_ERROR',
        error: `SMS too long (max ${MAX_SMS_LENGTH} characters).` });
    }
    const result = smsFraud.analyze({
      message: message,
      sender: typeof b.sender === 'string' ? b.sender.slice(0, 120) : undefined,
      claimedCompany: typeof b.claimedCompany === 'string' ? b.claimedCompany.slice(0, 120) : undefined,
      userName: typeof b.userName === 'string' ? b.userName.slice(0, 120) : undefined,
      userExpectedCompany: typeof b.userExpectedCompany === 'string' ? b.userExpectedCompany.slice(0, 120) : undefined,
    });
    // record as a defensive event (never an attack verdict); no secret is logged
    try { activity.record('sms-fraud', result.classification, 'sentinel-x', req.user && req.user.username); } catch (e) { /* non-fatal */ }
    res.status(result.classification === 'ANALYSIS_ERROR' ? 400 : 200).json(result);
  });


  /* ── Phishing Analyzer: unified scam detectors (defensive) ──
   * POST /api/scam/analyze  JSON {type, text, sender, ...}   type = smishing|email|vishing|investment|prize|payment
   * POST /api/scam/file  JSON {type: attachment|payment, name, dataBase64, ocr?, expected?}  (≤10 MB) */
  const scam = require('./lib/scam-detect');
  const emailVerdict = require('./lib/email-verdict');
  function unify(type, r) {
    if (type === 'smishing') {
      const extra = scam.smishingExtra(r._text).filter((x) => !(r.contributions || []).some((c) => /link/i.test(c.signal) && /link|domain/.test(x.signal)));
      const score = Math.min(100, (r.riskScore || 0) + extra.reduce((a, x) => a + x.weight, 0));
      return { ok: true, type, riskScore: score, verdict: score >= scam.INSECURE_AT ? 'INSECURE' : 'SECURE',
        level: r.classification === 'HIGH_RISK' || score >= scam.DANGEROUS_AT ? 'DANGEROUS' : score >= scam.INSECURE_AT ? 'CAUTION' : 'SAFE',
        reasons: (r.contributions || []).map((c, i) => ({ signal: c.signal, weight: c.weight, detail: (r.reasons || [])[i] || c.signal })).concat(extra),
        advice: score >= scam.INSECURE_AT && r.classification === 'SAFE' ? 'Treat as a scam. Do not call the number or tap links; check with the provider through its official app or website. Report at sancharsaathi.gov.in (Chakshu) or 1930.' : r.recommendedAction, engine: 'sms-fraud', classification: r.classification };
    }
    const score = r.riskScore != null ? r.riskScore : r.confidence;
    const bad = r.verdict === 'PHISHING' || r.verdict === 'MALICIOUS' || r.verdict === 'SUSPICIOUS';
    const w = { HIGH: 30, MEDIUM: 20, LOW: 10 };
    return { ok: true, type, riskScore: bad ? score : Math.min(score, 30), verdict: bad ? 'INSECURE' : 'SECURE',
      level: r.verdict === 'PHISHING' || r.verdict === 'MALICIOUS' ? 'DANGEROUS' : bad ? 'CAUTION' : 'SAFE',
      reasons: (r.signals || []).map((x) => ({ signal: x.category, weight: w[x.severity] || 10, detail: x.detail })),
      advice: bad ? 'Do not click links, open attachments or reply. Report the email (report.phishing@cert-in.org.in) and delete it.' : 'No phishing markers found. Still verify unexpected requests through the official website.',
      engine: 'hybrid (rules + ML model)', mlProbability: r.ml && r.ml.probability };
  }

  /* "Check anything": decide whether the pasted text is a link, an email or an SMS */
  function detectKind(text) {
    const t = text.trim();
    if (/^\S+$/.test(t) && (/^(https?|hxxps?):\/\//i.test(t) || /^(www\.)?[a-z0-9-]+(\.[a-z0-9-]+)+(\/\S*)?$/i.test(t))) return 'url';
    if (/^(from|subject|to|reply-to|return-path|received|date|delivered-to|authentication-results):/im.test(t)) return 'email';
    const lines = t.split(/\n/).filter((l) => l.trim()).length;
    if (lines >= 4 || t.length > 420 || /^(hi|hello|dear|greetings)\b[^\n]{0,40}\n/i.test(t) || /\n\s*(regards|thanks|sincerely|best|cheers)[,\s]/i.test(t)) return 'email';
    return 'smishing';
  }
  function runKind(kind, text, b) {
    if (kind === 'email') return emailVerdict.analyzeEmailText(text, typeof b.sender === 'string' ? b.sender : undefined);
    return unify('smishing', Object.assign({ _text: text }, smsFraud.analyze({ message: text.slice(0, MAX_SMS_LENGTH), sender: typeof b.sender === 'string' ? b.sender.slice(0, 120) : undefined })));
  }
  function urlUnified(u) {
    const h = heuristicCheckUrl(u);
    if (!h.ok) return { ok: false, error: h.error };
    const level = h.verdict === 'MALICIOUS' ? 'DANGEROUS' : h.verdict === 'SUSPICIOUS' ? 'CAUTION' : 'SAFE';
    const weights = h.signals.length ? Math.max(1, Math.round(h.score / h.signals.length)) : 0;
    return { ok: true, type: 'url', verdict: level === 'SAFE' ? 'SECURE' : 'INSECURE', level, riskScore: h.score,
      reasons: h.signals.map((d) => ({ signal: 'url', weight: weights, detail: d })), good: h.good, host: h.host,
      advice: level === 'DANGEROUS' ? 'Do not open this link or enter anything on it. If you already entered a password or card details, change the password and call your bank. Report it at cybercrime.gov.in or 1930.'
        : level === 'CAUTION' ? 'Do not trust this link yet. Type the company\'s address into your browser yourself instead of clicking.'
        : h.officialBrand ? 'This is the official ' + require('./heuristics').nameOf(h.officialBrand) + ' website.' : 'No warning signs in the link itself. Still, only enter passwords on sites you opened yourself.',
      engine: cfg.gsbKey ? 'URL rules (official domains, lookalikes, risky endings, shorteners); Google Safe Browsing is used by /api/security/check-url' : 'heuristic-only - URL rules (official domains, lookalikes, risky endings, shorteners); no GOOGLE_SAFE_BROWSING_KEY set' };
  }
  app.post('/api/scam/analyze', dashboardUser, analyzeLimiter, (req, res) => {
    const b = req.body || {}; const type = String(b.type || '');
    const text = typeof b.text === 'string' ? b.text.slice(0, MAX_TEXT_LENGTH) : '';
    if (!text.trim() && type !== 'payment') return res.status(400).json({ ok: false, error: 'Paste the message, email or call transcript first.' });
    let out;
    let kind = type;
    if (type === 'auto') kind = detectKind(text);
    if (kind === 'url') { out = urlUnified(text.trim().split(/\s+/)[0]); if (!out.ok) return res.status(400).json(out); if (type === 'auto') out.detected = 'link'; return res.json(out); }
    if (type === 'auto') { const r = runKind(kind, text, b); if (!r.ok) return res.status(400).json(r); r.detected = kind === 'email' ? 'email' : 'SMS / message'; r.type = kind; return res.json(r); }
    if (type === 'smishing') out = unify(type, Object.assign({ _text: text }, smsFraud.analyze({ message: text.slice(0, MAX_SMS_LENGTH), sender: typeof b.sender === 'string' ? b.sender.slice(0, 120) : undefined, claimedCompany: typeof b.claimedCompany === 'string' ? b.claimedCompany.slice(0, 120) : undefined })));
    else if (type === 'email') { const r = emailVerdict.analyzeEmailText(text, typeof b.sender === 'string' ? b.sender.slice(0, 320) : undefined); if (!r.ok) return res.status(400).json(r); out = r; }
    else if (type === 'vishing') out = scam.vishing({ transcript: text, caller: b.sender });
    else if (type === 'investment') out = scam.investment({ text });
    else if (type === 'prize') out = scam.prize({ text });
    else if (type === 'payment') out = scam.paymentScreenshot({ ocrText: text, expectedAmount: b.expectedAmount });
    else return res.status(400).json({ ok: false, error: 'Unknown type.' });
    try { activity.record('scam-' + type, out.verdict, out.engine || 'rules', req.user && req.user.username); } catch (e) { /* non-fatal */ }
    res.json(out);
  });
  app.post('/api/scam/file', dashboardUser, analyzeLimiter, (req, res) => {
    const b = req.body || {};
    const data = typeof b.dataBase64 === 'string' ? Buffer.from(b.dataBase64, 'base64') : Buffer.alloc(0);
    if (!data.length) return res.status(400).json({ ok: false, error: 'Choose a file first.' });
    if (data.length > 10 * 1024 * 1024) return res.status(413).json({ ok: false, error: 'File too large (max 10 MB).' });
    const name = String(b.name || 'file').slice(0, 255);
    const out = b.type === 'payment'
      ? scam.paymentScreenshot({ image: data, ocrText: String(b.ocr || '').slice(0, 4000), expectedAmount: b.expected })
      : scam.attachment({ name, data });
    try { activity.record('scam-' + (b.type === 'payment' ? 'payment' : 'attachment'), out.verdict, 'rules', req.user && req.user.username); } catch (e) { /* non-fatal */ }
    res.json(out);
  });

  /* World Monitor - Global Cyber Intelligence & India Threat Observatory API */
  app.use('/api/world', createWorldApi(db, { requireRole: auth.requireRole }));

  /* Global & India Cyber Threat Observatory - curated, source-cited evidence dataset */
  app.use('/api/gio', dashboardUser, createGiObservatory().router);

  app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found.' }));

  /* ── the dashboard itself (static files) - signed-in admin/viewer only ─ */
  // The observatory is the front page; the four assessment sections live at /index.html
  app.get(['/', '/observatory'], dashboardUser, serveFile('observatory.html'));
  app.use(dashboardUser, express.static(PUBLIC_DIR, { index: 'index.html', extensions: ['html'] }));

  /* ── errors ────────────────────────────────────────────────────── */
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, _next) => {
    if (err && err.message === 'CORS_NOT_ALLOWED') return res.status(403).json({ error: 'This origin is not allowed to call this API.' });
    if (err && err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed JSON body.' });
    if (err && err.type === 'entity.too.large') return res.status(413).json({ error: 'Request body too large.' });
    console.error('[error]', err);
    res.status(500).json({ error: 'Internal error.' });
  });

  return {
    app, auth, activity, harness, observatory, observatoryReady, fabric,
    /** Call with the http.Server once it is listening (enables the real-app harness). */
    attach(server) {
      const a = server.address();
      baseUrl = `http://127.0.0.1:${a.port}`;
    },
    close() { activity.close(); observatory.close(); if (fabric) fabric.stop(); if (fabricApi) fabricApi.close(); },
  };
}

module.exports = { createApp };
