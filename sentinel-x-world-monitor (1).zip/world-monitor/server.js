/**
 * server.js - World Monitor entry point (internal codename: SENTINEL-X).
 * Loads config, opens the SQLite store (creating + seeding it on first run),
 * builds the app (app.js) and starts listening.
 */
'use strict';

require('dotenv').config();

/* Make sure the admin and viewer logins printed at start-up are the ones that
 * actually work. If .env is missing or has no passwords, create/fill it once
 * with strong random ones; after that the database is synced to .env on every
 * start, so changing a password in .env and restarting is all it takes. */
(function ensureLoginEnv() {
  const fs = require('fs'), path = require('path');
  const { randomPassword } = require('./lib/passwords');
  const envFile = path.join(__dirname, '.env');
  let text = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : '';
  let changed = false;
  for (const key of ['ADMIN_PASSWORD', 'VIEWER_PASSWORD']) {
    if (process.env[key] && process.env[key].length >= 6) continue;
    const pw = randomPassword();
    process.env[key] = pw;
    if (new RegExp('^' + key + '=.*$', 'm').test(text)) text = text.replace(new RegExp('^' + key + '=.*$', 'm'), key + '=' + pw);
    else text += (text && !text.endsWith('\n') ? '\n' : '') + key + '=' + pw + '\n';
    changed = true;
  }
  // Live data is on by default. Older builds wrote OBSERVATORY_LIVE=off / FABRIC=off
  // into .env, which silently switched the live feed off; turn those back on once.
  // (Set LIVE_DATA=off in .env if you really want to work offline.)
  const liveOff = String(process.env.LIVE_DATA || '').toLowerCase() === 'off';
  if (!liveOff && !/^LIVE_DEFAULTS=2$/m.test(text)) {
    for (const key of ['OBSERVATORY_LIVE', 'FABRIC', 'FABRIC_POLL', 'FABRIC_ALERTS']) {
      if (new RegExp('^' + key + '=off$', 'mi').test(text)) { text = text.replace(new RegExp('^' + key + '=off$', 'mi'), key + '=on'); process.env[key] = 'on'; }
    }
    text += (text && !text.endsWith('\n') ? '\n' : '') + 'LIVE_DEFAULTS=2\n';
    changed = true;
  }
  if (liveOff) for (const key of ['OBSERVATORY_LIVE', 'FABRIC']) process.env[key] = 'off';
  if (changed) { try { fs.writeFileSync(envFile, text); } catch (e) { /* read-only disk: still works for this run */ } }
})();

/* Behind a proxy (office / college network)? Node's fetch ignores HTTPS_PROXY. */
require('./lib/proxy').enableProxyFromEnv();

const { openDb } = require('./lib/db');
const { seed, printCredentials } = require('./db/seed');
const { createApp } = require('./app');
const { modelInfo } = require('./lib/ml');

const PORT = parseInt(process.env.PORT, 10) || 5175;
const bool = (v) => String(v || '').toLowerCase() === 'true';

const authDisabled = bool(process.env.AUTH_DISABLED);
if (authDisabled && process.env.NODE_ENV === 'production') {
  console.error('Refusing to start: AUTH_DISABLED=true is not allowed when NODE_ENV=production.');
  process.exit(1);
}

if (process.env.NODE_ENV === 'production' && !bool(process.env.FORCE_HTTPS)) {
  console.warn('\n  ' + '!'.repeat(74) + '\n  WARNING: NODE_ENV=production but FORCE_HTTPS is not "true".\n' +
    '  Secure cookies and HSTS are OFF. Set FORCE_HTTPS=true for any non-localhost deployment.\n  ' + '!'.repeat(74) + '\n');
}

const db = openDb();
const creds = seed(db, { resetPasswords: true });   // sync admin/viewer to .env every start
// World Monitor reference data + provenance migration (idempotent) so the
// observatory always has its real sources/metrics even on a plain `npm start`.
try { require('./db/world-seed').seedWorld(db); } catch (e) { console.warn('[world-seed] skipped:', e.message); }

const allowedOrigins = (process.env.ALLOWED_ORIGINS || '').split(',').map((o) => o.trim()).filter(Boolean);
const gsbKey = process.env.GOOGLE_SAFE_BROWSING_KEY || '';

const wm = createApp({
  db,
  config: {
    port: PORT,
    gsbKey,
    forceHttps: bool(process.env.FORCE_HTTPS),
    authDisabled,
    assessLab: String(process.env.ASSESS_LAB || 'on').toLowerCase() !== 'off',
    allowedOrigins,
    observatoryLive: String(process.env.OBSERVATORY_LIVE || 'on').toLowerCase() !== 'off',
    fabric: {
      enabled: String(process.env.FABRIC || 'on').toLowerCase() !== 'off',
      mode: String(process.env.FABRIC_MODE || 'production').toLowerCase() === 'replay' ? 'replay' : 'production',
      poll: String(process.env.FABRIC_POLL || 'on').toLowerCase() !== 'off',
      hibp: String(process.env.FABRIC_HIBP || 'off').toLowerCase() === 'on',
      alerts: String(process.env.FABRIC_ALERTS || 'on').toLowerCase() !== 'off',
      ...(String(process.env.FABRIC_MODE || '').toLowerCase() === 'replay' ? { fetchImpl: require('./lib/fabric/replay').createReplayFetch() } : {}),
    },
  },
});

const server = wm.app.listen(PORT, () => {
  wm.attach(server);
  const models = modelInfo();
  console.log(`\n  World Monitor  (codename SENTINEL-X)  →  http://localhost:${PORT}`);
  console.log(`  Database      : ${db.file}`);
  console.log(`  Auth          : ${authDisabled ? '⚠ DISABLED (dev only) - assessments use the simulated fallback' : 'enabled (admin / viewer roles)'}`);
  console.log(`  Threat intel  : ${gsbKey ? 'Google Safe Browsing + heuristics' : 'heuristic-only (no GOOGLE_SAFE_BROWSING_KEY)'}`);
  console.log(`  ML models     : email ${models.email.loaded ? '✔' : '✘'}  sms ${models.sms.loaded ? '✔' : '✘'}`);
  const obsMs = require('./lib/observatory-cache').refreshIntervalMs(process.env, { warn: () => {} });
  console.log(`  Observatory   : reference data loaded; signals ${String(process.env.OBSERVATORY_LIVE || 'on').toLowerCase() === 'off' ? 'OFF (OBSERVATORY_LIVE=off)' : `polled at start, then every ${obsMs} ms (${obsMs / 60000} min)`}`);
  console.log(`  Live feed     : ${String(process.env.OBSERVATORY_LIVE || 'on').toLowerCase() === 'off' ? 'automatic collection OFF (admin entries still work)' : 'collected 3 s after start, then every 600000 ms (10 min); pushed to browsers instantly over SSE'}`);
  console.log(`  Fabric        : ${process.env.FABRIC === 'off' ? 'OFF' : (process.env.FABRIC_MODE === 'replay' ? 'REPLAY / DEMONSTRATION (recorded responses - not live)' : 'periodic polling - CISA KEV every 3600 s, NVD every 7200 s, CERT-In every 1800 s (backoff on failure)')}`);
  console.log(`  Extra origins : ${allowedOrigins.length ? allowedOrigins.join(', ') : '(same-origin only)'}`);
  void creds; void printCredentials;
  console.log('\n  ┌─ Sign in at http://localhost:' + PORT + ' ─────────────────────────────');
  console.log(`  │  Admin  (can run attacks)   username: admin    password: ${process.env.ADMIN_PASSWORD}`);
  console.log(`  │  Viewer (view only)         username: viewer   password: ${process.env.VIEWER_PASSWORD}`);
  console.log('  │  To change them, edit ADMIN_PASSWORD / VIEWER_PASSWORD in .env and restart.');
  console.log('  └──────────────────────────────────────────────────────────────────\n');
});

function shutdown(sig) {
  console.log(`\n  ${sig} received - closing.`);
  wm.close();
  server.close(() => { db.close(); process.exit(0); });
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
