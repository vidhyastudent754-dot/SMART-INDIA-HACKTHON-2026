-- Real-Time Verified World Monitor Fabric — schema contract (module-owned, idempotent).
-- environment: 'production' | 'replay' | 'synthetic'. Production views read ONLY 'production'.

CREATE TABLE IF NOT EXISTS fabric_sources (
  id TEXT PRIMARY KEY, organization TEXT NOT NULL, title TEXT NOT NULL, url TEXT NOT NULL,
  jurisdiction TEXT, source_class TEXT NOT NULL, registry_json TEXT NOT NULL,
  approved INTEGER NOT NULL DEFAULT 0, enabled INTEGER NOT NULL DEFAULT 0,
  last_verified_at TEXT, updated_at INTEGER NOT NULL
);

-- one row per retrieval: immutable raw receipt (gzip) + content hash
CREATE TABLE IF NOT EXISTS fabric_receipts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, source_id TEXT NOT NULL, environment TEXT NOT NULL,
  trigger TEXT NOT NULL, request_url TEXT, requested_at INTEGER NOT NULL, received_at INTEGER,
  http_status INTEGER, content_hash TEXT, bytes INTEGER, raw_gz BLOB,
  outcome TEXT NOT NULL,             -- validated | unchanged | quarantined | failed
  error TEXT, latency_ms INTEGER, records_seen INTEGER DEFAULT 0, records_new INTEGER DEFAULT 0,
  records_corrected INTEGER DEFAULT 0, records_quarantined INTEGER DEFAULT 0, attempts INTEGER DEFAULT 1
);
CREATE INDEX IF NOT EXISTS idx_fr_source ON fabric_receipts(source_id, environment, id);

CREATE TABLE IF NOT EXISTS fabric_events (
  id INTEGER PRIMARY KEY AUTOINCREMENT, environment TEXT NOT NULL,
  source_id TEXT NOT NULL, native_id TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1,
  record_hash TEXT NOT NULL, superseded_by INTEGER, receipt_id INTEGER NOT NULL,
  event_type TEXT NOT NULL, evidence_status TEXT NOT NULL, title TEXT NOT NULL, summary TEXT,
  sections_json TEXT NOT NULL, severity TEXT, cvss REAL, cwes_json TEXT,
  event_time TEXT, event_time_precision TEXT, source_timezone TEXT,
  ingested_at INTEGER NOT NULL, is_backfill INTEGER NOT NULL DEFAULT 0,
  geography_json TEXT NOT NULL, url TEXT, extra_json TEXT,
  UNIQUE (environment, source_id, native_id, version)
);
CREATE INDEX IF NOT EXISTS idx_fe_current ON fabric_events(environment, superseded_by, id);
CREATE INDEX IF NOT EXISTS idx_fe_time ON fabric_events(environment, event_time);

CREATE TABLE IF NOT EXISTS fabric_quarantine (
  id INTEGER PRIMARY KEY AUTOINCREMENT, environment TEXT NOT NULL, source_id TEXT NOT NULL,
  receipt_id INTEGER, native_id TEXT, reason TEXT NOT NULL, record_json TEXT,
  proposed_action TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open',   -- open | released | rejected
  created_at INTEGER NOT NULL, reviewed_by TEXT, reviewed_at INTEGER, review_note TEXT
);

CREATE TABLE IF NOT EXISTS fabric_feed_state (
  source_id TEXT NOT NULL, environment TEXT NOT NULL,
  first_success_at INTEGER, last_attempt_at INTEGER, last_success_at INTEGER, last_failure_at INTEGER,
  last_error TEXT, consecutive_failures INTEGER NOT NULL DEFAULT 0, total_failures INTEGER NOT NULL DEFAULT 0,
  retries INTEGER NOT NULL DEFAULT 0, circuit TEXT NOT NULL DEFAULT 'closed', next_attempt_at INTEGER,
  last_receipt_id INTEGER, last_content_hash TEXT, last_latency_ms INTEGER,
  PRIMARY KEY (source_id, environment)
);

-- transactional outbox → Server-Sent Events (id = SSE event id, used for resume)
CREATE TABLE IF NOT EXISTS fabric_stream (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, environment TEXT NOT NULL, type TEXT NOT NULL,
  payload_json TEXT NOT NULL, created_at INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS fabric_alert_rules (
  id TEXT PRIMARY KEY, enabled INTEGER NOT NULL, params_json TEXT NOT NULL,
  muted_until INTEGER, updated_by TEXT, updated_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS fabric_alerts (
  id INTEGER PRIMARY KEY AUTOINCREMENT, environment TEXT NOT NULL, rule_id TEXT NOT NULL,
  alert_type TEXT NOT NULL, level TEXT NOT NULL, evidence_status TEXT NOT NULL,
  title TEXT NOT NULL, explanation TEXT NOT NULL, sections_json TEXT, geography_json TEXT,
  evidence_json TEXT NOT NULL, formula TEXT, baseline_json TEXT, dedup_key TEXT NOT NULL,
  state TEXT NOT NULL DEFAULT 'new', occurrences INTEGER NOT NULL DEFAULT 1,
  created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL,
  UNIQUE (environment, dedup_key)
);

-- tamper-evident audit: each row carries sha256(prev_hash + canonical row)
CREATE TABLE IF NOT EXISTS fabric_audit (
  id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER NOT NULL, environment TEXT NOT NULL,
  actor TEXT NOT NULL, action TEXT NOT NULL, target TEXT, detail_json TEXT,
  prev_hash TEXT NOT NULL, hash TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fabric_crosswalk_overrides (
  id INTEGER PRIMARY KEY AUTOINCREMENT, scheme TEXT NOT NULL, native_label TEXT NOT NULL,
  sections_json TEXT NOT NULL, status TEXT NOT NULL, rationale TEXT NOT NULL,
  version INTEGER NOT NULL, created_by TEXT NOT NULL, created_at INTEGER NOT NULL
);
