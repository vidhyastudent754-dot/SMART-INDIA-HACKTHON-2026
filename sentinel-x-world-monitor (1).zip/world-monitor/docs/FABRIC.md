# Real-Time Verified World Monitor Fabric

This document covers the source coverage matrix, data dictionary, source policy, pipeline, alert rules, API, Replay/Demonstration mode, migration plan and module flags.

World Monitor's Section 0 monitors **real-world signals and official statistics related only to Sections 1–3**. These are the assessment sections containing attack and weakness categories:

- **Section 1:** Individual.
- **Section 2:** Employee & Manager.
- **Section 3:** Company & Organization.

It monitors them for India and internationally. It has **two speeds**, and the UI keeps them visibly separate:

| Layer | What it contains | How fresh | Example sources |
|---|---|---|---|
| **Real-time signal layer** | Exploited-vulnerability reports, new vulnerability disclosures, official advisories | Polled on each source's real cadence; every source shows **live / recent / cached / stale / unavailable** with its measured age | CISA KEV, NVD, CERT-In vulnerability notes |
| **Periodic official baseline** | Complaints, police-registered cases, losses, convictions, enforcement | Published annually or in parliamentary replies; shown with period and publication date, **never labelled live** | NCRB (via MHA Lok Sabha replies), I4C/MHA, FBI IC3 |

> **No verified public source currently provides a complete, real-time, worldwide, PIN-code-level cybercrime incident ledger.** World Monitor does not claim to provide one. A vulnerability feed is not an attack feed, an annual report is not a live feed, and a publication feed is not an incident corpus.

## 1. Source coverage matrix

This was verified on 2026-09-25. The live version, with measured freshness and quality scores, is in the dashboard under **Trust Center**. Each endpoint is registered separately in `lib/fabric/registry.js`.

| Source | Endpoint | Class | Format | Cadence | S1 | S2 | S3 | Country | India | State/UT | District | City | PIN | Decision |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Cybersecurity and Infrastructure Security Agency | `https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json` | near_current_authoritative_feed | JSON | Irregular — CISA adds entries as exploitation evidence is confirmed (typically several times a week) | ✔ | ✔ | ✔ | — | — | — | — | — | — | Ingested — live polling every 1 h |
| National Institute of Standards and Technology | `https://services.nvd.nist.gov/rest/json/cves/2.0` | near_current_authoritative_feed | JSON | Continuously updated database; NIST asks clients to poll incrementally no more often than about every two hours | ✔ | ✔ | ✔ | — | — | — | — | — | — | Ingested — live polling every 2 h |
| Indian Computer Emergency Response Team | `https://www.cert-in.org.in/s2cMainServlet?pageid=VLNLIST02&year={year}` | official_publication_signal | HTML (no API) | Event-driven publications, usually several per working day | ✔ | ✔ | ✔ | ✔ | ✔ | — | — | — | — | Ingested — live polling every 30 min |
| CERT-In, MeitY | `https://www.cert-in.org.in/s2cMainServlet?pageid=PUBADVLIST` | candidate_pending_verification | HTML | Event-driven (expected) | ✔ | ✔ | ✔ | ✔ | ✔ | — | — | — | — | Excluded until verified |
| Have I Been Pwned | `https://haveibeenpwned.com/api/v3/breaches` | secondary_context_only | JSON | Breaches are added days to months after they occur | — | — | ✔ | — | — | — | — | — | — | Adapter built; off by default (FABRIC_HIBP=on) |
| Ministry of Home Affairs | `https://www.mha.gov.in/MHA1/Par2017/pdfs/par2025-pdfs/LS02122025/452.pdf` | official_periodic_dataset | PDF (verified manual entry) | Parliamentary reply; underlying NCRB data annual (latest year 2023) | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | — | — | — | Ingested — verified import |
| NCRB via Open Government Data Platform India | `https://www.data.gov.in/resource/crime-head-wise-and-stateut-wise-cyber-crimes-it-act-cases-during-2023` | official_periodic_dataset | CSV/JSON (data.gov.in API key required) | Annual snapshot | ✔ | ✔ | ✔ | ✔ | ✔ | ✔ | — | — | — | Registered, not ingested |
| I4C via Open Government Data Platform India | `https://www.data.gov.in/resource/stateut-wise-details-statistics-national-cyber-crime-reporting-portal-ncrp-related-cyber` | candidate_pending_verification | unknown until verified | One-off snapshot | ✔ | ✔ | — | ✔ | ✔ | ✔ | — | — | — | Excluded until verified |
| MHA / I4C / NCRB / CERT-In / FBI IC3 / ASD / BKA | `https://www.mha.gov.in/` | official_periodic_dataset | verified manual entry | Annual / per parliamentary reply; each figure carries its own period and source link | ✔ | ✔ | ✔ | ✔ | ✔ | — | — | — | — | Ingested — reference file |
| INTERPOL | `https://ws-public.interpol.int/notices/v1/red` | secondary_context_only | JSON | Continuous | — | — | — | — | — | — | — | — | — | Registered, not ingested |
| European Union Agency for Cybersecurity | `https://euvd.enisa.europa.eu/` | candidate_pending_verification | JSON (to verify) | API + daily dumps (per ENISA; not yet verified here) | ✔ | ✔ | ✔ | — | — | — | — | — | — | Excluded until verified |
| FBI Internet Crime Complaint Center | `https://www.ic3.gov/` | candidate_pending_verification | RSS (to verify) | Event-driven publications | ✔ | ✔ | — | — | — | — | — | — | — | Excluded until verified |
| Ransomware leak-site trackers | `https://www.ransomware.live/` | unverified_secondary_signal | JSON | Minutes | — | — | ✔ | ✔ | — | — | — | — | — | Registered, not ingested |

What each metric family provides:

| Metric family | Complaints | Police cases | Loss | Victims | Prevention |
|---|---|---|---|---|---|
| CISA KEV / NVD / CERT-In notes | — | — | — | — | — |
| MHA USQ 452 (NCRB 2019–2023) | — | ✔ State/UT; fraud lifecycle | — | — | — |
| Observatory reference file | ✔ national (NCRP) | ✔ national | ✔ national reported loss | — | ✔ amounts saved, SIMs/IMEIs/apps blocked |
| HIBP (secondary, optional) | — | — | — | accounts exposed (not people) | — |

**Not published by any verified source** (shown as *Not published by source*, never 0):
- district, city, area or PIN-code cybercrime counts;
- attacker profit;
- pending cases or acquittals by State/UT;
- loss by State/UT;
- population awareness levels;
- worldwide case status;
- a comparable global attack rate;
- victim or attacker location for vulnerabilities.

## 2. Source classes

These are stored per endpoint and returned in every API response:

- `live_authoritative_feed`
- `near_current_authoritative_feed`
- `official_periodic_dataset`
- `official_publication_signal`
- `authorized_restricted_feed`
- `secondary_context_only`
- `unverified_secondary_signal`
- `candidate_pending_verification`
- `unavailable_for_requested_granularity`

A source cannot move from a candidate or secondary class to an authoritative one without a code change. That change is a registry edit, visible in review.

## 3. Freshness states

These apply to sources with an adapter:

| State | Rule |
|---|---|
| `live` | The last validated response is within the source's freshness window, and the last attempt succeeded. |
| `recent` | Valid, but older than the freshness window and younger than the maximum age. |
| `cached` | The most recent attempt failed; the last validated snapshot is being served. |
| `stale` | Older than the maximum acceptable age. |
| `unavailable` | No validated response exists yet. |
| `periodic` | Official periodic publication; freshness is its publication date. |

| Source | Poll interval | Live window | Maximum age |
|---|---|---|---|
| CISA KEV | 1 h | 2 h | 24 h |
| NVD | 2 h (NIST guidance) | 3 h | 12 h |
| CERT-In notes | 30 min | 1 h | 12 h |

## 4. Pipeline

`lib/fabric/index.js` runs each retrieval through these steps:

```
scheduled / manual retrieval
 → SSRF guard: HTTPS only, host on the source's approved list, no credentials in the URL, no redirects
 → fetch with timeout, retry and exponential backoff (network, 429 and 5xx only); circuit opens after 5 consecutive failures
 → immutable receipt: gzip of the raw body + sha256, request URL, timestamps, latency, attempts
 → unchanged content (same hash) → "unchanged": proves freshness, creates nothing
 → schema validation (adapter) ─ fail → whole response quarantined
 → contradictory-revision gate: catalogue shrinks > 1 % → quarantined until an admin accepts it with a note
 → per-record gates: identifier, timestamps (future > 36 h or before 1988), in-response duplicates ─ fail → record quarantined
 → idempotent versioned events: same (source, native id, record hash) = duplicate; changed content = new version, old one superseded, never overwritten
 → one SQLite transaction: events + receipt counts + feed state + audit + outbox
 → Server-Sent Events published from the outbox (exactly once, in order) → alert evaluation → audit
```

Environments are isolated in every table:

- `production`: real sources.
- `replay`: recorded responses.
- `synthetic`: tests only.

Production views read only `production`.

## 5. Data dictionary (fabric tables)

| Table | Purpose | Key fields |
|---|---|---|
| `fabric_sources` | The registry, persisted | `source_class`, `registry_json` (access, cadence, geography, sections, limitations), `approved`, `enabled`, `last_verified_at` |
| `fabric_receipts` | One immutable row per retrieval | `raw_gz`, `content_hash` (sha256), `request_url`, `requested_at`, `received_at`, `http_status`, `outcome` (validated / unchanged / quarantined / failed), `latency_ms`, `attempts`, record counts |
| `fabric_events` | Validated events, versioned | `native_id`, `version`, `record_hash`, `superseded_by`, `receipt_id`, `event_type`, `evidence_status`, `sections_json` (sections, status, rationale, crosswalk version), `event_time` + `event_time_precision` + `source_timezone`, `ingested_at`, `is_backfill`, `geography_json` (victim / reporting organisation / affected asset / jurisdiction / attacker, null = not published), `environment` |
| `fabric_quarantine` | Failed responses and records | `reason`, `record_json`, `proposed_action`, `status` (open / released / rejected), `reviewed_by`, `review_note` |
| `fabric_feed_state` | Per-source health | `first/last_success_at`, `last_failure_at`, `last_error`, `consecutive_failures`, `retries`, `circuit`, `next_attempt_at`, `last_content_hash` |
| `fabric_stream` | Transactional outbox | `seq` (the SSE event id, used for resume), `type`, `payload_json` |
| `fabric_alerts` | Alerts | `level` (informational / watch / elevated / high / critical), `alert_type`, `evidence_status`, `explanation`, `evidence_json` (event ids, URLs, receipt hashes), `formula`, `baseline_json`, `dedup_key`, `state` (new / acknowledged / investigating / resolved / false_positive), `occurrences` |
| `fabric_alert_rules` | Thresholds and mutes | `params_json`, `enabled`, `muted_until` |
| `fabric_audit` | Tamper-evident log | `prev_hash`, `hash` = sha256(prev_hash + row); verified at `/api/v1/admin/audit` |
| `fabric_crosswalk_overrides` | Proposed mappings, versioned | `scheme`, `native_label`, `sections_json`, `status`, `rationale`, `version` |

India State/UT data (`db/fabric/india-ncrb-cybercrime-2019-2023.json`):

- **Geography:** keyed by ISO 3166-2:IN code.
- **Series:** cases registered for 2019–2023, plus the Fraud-head lifecycle (registered, charge-sheeted, trials completed, convicted, conviction rate, persons arrested).
- **Nulls:** `null` means not published (e.g. Ladakh 2019, before the UT existed) or not applicable (conviction rate with no trials).

## 6. Taxonomy crosswalk (`wm-crosswalk-1`)

Every mapping carries one of four statuses:

- **exact:** the CWE is tested by that section's own assessment checks. For example, CWE-79 → S1 via IND-05/06, and CWE-89 → S3 via ORG-06.
- **crosswalked:** the same weakness family.
- **partial:** indirect. This covers memory-safety bugs → S3, CERT-In title keywords, and broad police crime heads.
- **not_comparable:** never forced into a section. This covers CVEs with no CWE yet, "Multiple vulnerabilities in …" titles, and content or harassment offences.

Proposed changes are stored versioned via `POST /api/v1/admin/taxonomy/crosswalk`. The built-in mapping changes only with a released crosswalk version.

## 7. Alert rules (early warning)

| Rule | Type | Level | Trigger |
|---|---|---|---|
| `kev_new_exploited` | source-reported exploitation | high; critical if CISA marks known ransomware use | New validated KEV entry. On first ingestion, only entries added in the last 72 h. |
| `certin_high_impact_note` | official advisory | elevated | New CERT-In note naming RCE, privilege escalation, authentication bypass or injection |
| `section_surge` | statistical anomaly | watch | KEV additions mapped to a Section in 7 days ≥ 3 and > 2 × the weekly baseline of the previous 8 weeks |
| `nvd_volume_anomaly` | statistical anomaly | watch | CVEs in 24 h ≥ 50 and > mean + 3σ of the previous days. Only after 7 days of this instance's own coverage. |
| `source_health` | data availability | watch / elevated | ≥ 3 consecutive failures or stale data; auto-resolves on recovery |

Alerts are deduplicated by key. Thresholds can be edited and rules muted (admin, audited). Lifecycle transitions are validated and audited.

Wording is fixed: source-reported items say what the source reports, and anomalies say "indicates an unusual pattern requiring review". **An alert never claims an attack occurred.**

## 8. API (`/api/v1`, OpenAPI at `/api/v1/openapi.json`)

**Observatory** (any signed-in user):

- `overview`
- `feed` (filters, pagination)
- `events/:id` (provenance and versions)
- `sources`
- `data-quality`
- `india` (`year`, `view=public|analyst`, `level`)
- `geographies`
- `sections/:id`

**Alerts:**

- `alerts`, `alerts/rules` (read, any user)
- `alerts/:id/state`, `alerts/rules/:id` (admin)

**Export** (admin, audited): `export/events.csv|json`, `alerts/export.json`.

**Stream:** Server-Sent Events. The browser resends `Last-Event-ID` on reconnect and receives only what it missed, or a `resync` event if too much history has been trimmed.

**Admin:**

- `admin/ingestion/run`, `admin/ingestion/runs`
- `admin/receipts/:id/raw` (served as `text/plain` in a sandbox, since the content is untrusted)
- `admin/quarantine`, `admin/quarantine/:id` (a review note is required)
- `admin/audit`
- `admin/taxonomy/crosswalk`

## 9. Replay / Demonstration mode

`FABRIC_MODE=replay npm start` replays **recorded** source responses through the unchanged pipeline:

- **Isolated:** the data goes into the `replay` environment.
- **Labelled:** every API response and the dashboard carry **REPLAY / DEMONSTRATION — recorded source responses, not live data**.

Shipped recordings:

- **What:** the CERT-In vulnerability-notes listing retrieved on 2026-09-25, as two steps. Step 1 withholds the four newest notes; step 2 is the full recorded page. The replay therefore shows real notes arriving over SSE.
- **Provenance:** both steps were reconstructed from a text extraction of the page, as recorded in `db/fabric/fixtures/manifest.json`.

Record your own: `npm run fabric:record` saves real CISA KEV, NVD and CERT-In responses, schema-checked, with their sha256, into `db/fabric/fixtures/recorded/`. Run it several times before a demo so the replay shows genuine changes between snapshots.

## 10. Source policy

The fabric follows these rules:

- **Allow-list.** Only registry sources with an adapter are fetched, only over HTTPS, and only to their approved host. Redirects and credentials in URLs are refused.
- **Primary before secondary.** Government documents come first. News articles serve only as `secondary: true` pointers, as some figures in `db/observatory.json` are.
- **Non-government sources are labelled.** Have I Been Pwned is non-government, optional (`FABRIC_HIBP=on`), and never counted in official totals.
- **Contextual sources stay contextual.** INTERPOL Red Notices are context only.
- **Criminal claims are not ingested.** Ransomware leak-site claims are not ingested at all.
- **No personal data is ingested.** The adapters keep product, vulnerability and aggregate fields only.
- **Candidates stay excluded.** A candidate source (the NCRP-fraud dataset on data.gov.in, CERT-In advisories, EUVD, IC3 PSA RSS) stays excluded until its exact URL, fields and access method are verified.
- **Manual verified entries** reconcile against the document's own totals before anything is written (`scripts/import-mha-q452.js`), and keep the verbatim extract and its sha256.

## 11. Module flags

Each module can be disabled independently:

| Flag | Default | Effect |
|---|---|---|
| `FABRIC` | on | Whole fabric module (routes return 404 when off) |
| `FABRIC_POLL` | on | Network polling (off = API and UI only) |
| `FABRIC_ALERTS` | on | Alert module |
| `FABRIC_MODE` | production | `replay` = Replay / Demonstration |
| `FABRIC_HIBP` | off | Optional secondary breach context |
| `OBSERVATORY_ESTIMATES` | on | `off` hides every section-level estimate |

## 12. Migration plan from the earlier observatory

1. **Done (this release).** The fabric runs alongside `/api/observatory/*`, which keeps working. The reference file `db/observatory.json` is registered as a source, and its estimates can be switched off. The live signals formerly fetched by `lib/observatory-cache.js` (NVD count, CERT-In count) are superseded by fabric events. The old cards remain as context.
2. **Next.** Move the reference file's figures into normalised `metrics` rows (source, period, geography, unit, status), each with `source_document` lineage. Serve both shapes for one release, then retire `/api/observatory/*`.
3. **Then.** Add adapters for candidate sources once verified (data.gov.in with an API key, EUVD, IC3 PSA RSS), each through the same registry-class review.

## 13. Scope of this release (reconciled build order)

| Module | Status |
|---|---|
| Real-Time Fabric: registry, adapters, receipts, validation, freshness, events vs aggregates, crosswalk, SSE, feed health | **Implemented** |
| Data Trust: provenance drawers, coverage matrix, quality score, unavailable metrics, audit chain | **Implemented** |
| Alerts: validated-signal alerts, anomalies, lifecycle, thresholds, mutes, export | **Implemented** |
| Analyst Verification (E5): case workspace, corroboration levels | Not started |
| Public/Analyst Access (E6): separate modes, new roles | Partly: public vs analyst view with small-cell suppression on India data; roles are still admin/viewer |
| Accessibility (E7): multilingual, low-bandwidth | Not started |
| Graph (E8) and STIX/TAXII (E10) | Not started |
| Reliability (E9) | Partly: circuit breaker, backoff, isolation, health alerts; no separate health page or load tests yet |
| Copilot | Not started (would send data to an external AI service; needs a separate decision) |
