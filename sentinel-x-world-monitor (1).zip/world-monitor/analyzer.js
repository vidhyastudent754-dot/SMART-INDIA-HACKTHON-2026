/**
 * analyzer.js
 * Email & SMS content analysis engine for SENTINEL-X.
 *
 * Scans message body text for phishing / smishing indicators:
 *   • Urgency & threat language ("24 hours", "account locked")
 *   • Requests for sensitive data ("password", "OTP", "CVV")
 *   • Embedded suspicious URLs (run through heuristicCheckUrl)
 *   • Brand impersonation
 *   • Generic greetings ("Dear Customer")
 *   • Too-good-to-be-true offers
 *   • Common scam patterns (fake delivery, prize, KYC, etc.)
 */

const { heuristicCheckUrl } = require('./heuristics');

/* ── Pattern dictionaries ──────────────────────────────────────── */

const URGENCY_PATTERNS = [
  /\b\d+\s*hours?\b/i,
  /\bimmediately\b/i,
  /\burgent(ly)?\b/i,
  /\bact\s*now\b/i,
  /\bright\s*away\b/i,
  /\bas\s*soon\s*as\s*possible\b/i,
  /\basap\b/i,
  /\bexpir(e|es|ed|ing)\b/i,
  /\bdeadline\b/i,
  /\blast\s*chance\b/i,
  /\bfinal\s*warning\b/i,
  /\btime\s*(is\s*)?running\s*out\b/i,
  /\blimited\s*time\b/i,
  /\bdon'?t\s*(delay|wait|ignore)\b/i,
  /\bfailure\s*to\b/i,
  /\bwithin\s*\d+\s*(hours?|minutes?|days?)\b/i,
  /\bbefore\s*it'?s?\s*too\s*late\b/i,
];

const THREAT_PATTERNS = [
  /\baccount\s*(will\s*be\s*)?(locked|blocked|suspended|closed|deactivated|terminated|disabled|frozen|restricted)\b/i,
  /\b(lock|block|suspend|close|deactivate|terminate|disable|freeze|restrict)\s*(your\s*)?account\b/i,
  /\bunauthori[sz]ed\s*(access|activity|transaction|login)\b/i,
  /\bsuspicious\s*(activity|login|transaction)\b/i,
  /\bverif(y|ication)\s*(required|needed|your|immediately|now)\b/i,
  /\bsecurity\s*alert\b/i,
  /\blegal\s*action\b/i,
  /\bpenalt(y|ies)\b/i,
  /\bpermanently\s*(delete|remove|close)\b/i,
  /\bfraudulent\b/i,
  /\bcompromised\b/i,
  /\bviolat(e|ion|ing)\b/i,
];

const SENSITIVE_DATA_PATTERNS = [
  /\b(enter|provide|confirm|update|verify|submit|share|send)\s*(your\s*)?(password|passcode|pin|otp|cvv|ssn|social\s*security|credit\s*card|debit\s*card|card\s*number|account\s*number|bank\s*details|login\s*credentials|aadhaar|pan\s*card|pan\s*number)\b/i,
  /\bpassword\b/i,
  /\b(one[\s-]*time[\s-]*password|otp)\b/i,
  /\bcvv\b/i,
  /\bssn\b/i,
  /\bcredit\s*card\s*(number|details|info)\b/i,
  /\bdebit\s*card\s*(number|details|info)\b/i,
  /\bbank\s*(account|details|info)\b/i,
  /\baadhaar\b/i,
  /\bpan\s*(card|number)\b/i,
  /\bpin\s*(number|code)\b/i,
  /\bnet\s*banking\s*(id|password|credentials)\b/i,
  /\bupi\s*(pin|id)\b/i,
];

const GENERIC_GREETING_PATTERNS = [
  /\bdear\s*(customer|user|client|member|account\s*holder|sir|madam|valued)\b/i,
  /\bhello\s*(customer|user|client|member)\b/i,
  /\battention\s*(customer|user|account\s*holder)\b/i,
];

const OFFER_PATTERNS = [
  /\b(won|winner|congratulations|congrats)\b/i,
  /\b(prize|reward|bonus|gift\s*card|lottery|jackpot|cashback|refund)\b/i,
  /\b(free|complimentary)\s*(iphone|laptop|gift|prize|money|cash)\b/i,
  /\bclaim\s*(your|now|today|this)\b/i,
  /\b(selected|chosen|lucky)\s*(winner|recipient|customer)\b/i,
  /\bcrore|lakh|million\s*dollar/i,
];

const DELIVERY_SCAM_PATTERNS = [
  /\b(package|parcel|order|shipment|delivery)\s*(is\s*)?(held|pending|failed|undelivered|returned|delayed|waiting)\b/i,
  /\b(reschedule|confirm|update)\s*(your\s*)?(delivery|address|shipment)\b/i,
  /\bdelivery\s*(fee|charge|payment)\b/i,
  /\btracking\s*(number|id|update)\b/i,
  /\bcustoms\s*(fee|duty|clearance)\b/i,
  /\b(cancel|cancell?ation)\s*(your\s*)?(order|subscription)\b/i,
];

const KYC_PATTERNS = [
  /\bkyc\b/i,
  /\b(update|complete|verify)\s*(your\s*)?kyc\b/i,
  /\bknow\s*your\s*customer\b/i,
  /\b(re[\s-]?verification|re[\s-]?validate|re[\s-]?confirm)\b/i,
];

const BRAND_NAMES = [
  'paypal', 'google', 'microsoft', 'apple', 'amazon', 'netflix', 'facebook',
  'instagram', 'whatsapp', 'sbi', 'hdfc', 'icici', 'axis bank', 'axisbank',
  'irctc', 'gpay', 'phonepe', 'paytm', 'flipkart', 'myntra', 'swiggy',
  'zomato', 'razorpay', 'cred', 'bajaj', 'airtel', 'jio', 'vodafone',
  'fedex', 'dhl', 'ups', 'usps', 'india post', 'bluedart',
  'wells fargo', 'chase', 'citibank', 'bank of america',
  'uber', 'ola', 'meesho', 'snapdeal',
];

/* ── URL extraction ────────────────────────────────────────────── */

const URL_REGEX = /https?:\/\/[^\s<>"')\]},;]+/gi;
const DOMAIN_REGEX = /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+(?:com|org|net|in|co\.in|xyz|info|biz|us|uk|io|click|top|online|site|live|link|buzz|tk|ml|ga|cf|gq|club|shop|store|tech|pro|cc|co|ly|me|tv|app|dev|icu|fun|work|one|vip|bid|loan|racing|date|party|science|trade|stream|review|win|download|accountant|cricket|faith|men|webcam)\b/gi;

function extractUrls(text) {
  const urls = new Set();
  const httpMatches = text.match(URL_REGEX) || [];
  httpMatches.forEach(u => urls.add(u.replace(/[.,;:!?)}\]]+$/, '')));

  // Also catch bare domains
  const domainMatches = text.match(DOMAIN_REGEX) || [];
  domainMatches.forEach(d => {
    const cleaned = d.replace(/[.,;:!?)}\]]+$/, '');
    // Only add if not already covered by an http match
    if (![...urls].some(u => u.includes(cleaned))) {
      urls.add('https://' + cleaned);
    }
  });

  return [...urls];
}

/* ── Scoring helpers ───────────────────────────────────────────── */

function matchPatterns(text, patterns) {
  const hits = [];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) hits.push(m[0]);
  }
  return hits;
}

/* ── Main analyzers ────────────────────────────────────────────── */

/**
 * Analyze email body content for phishing indicators.
 * @param {string} body - The full email body text (plain text or pasted HTML)
 * @param {string} [senderEmail] - Optional sender address for extra checks
 * @returns {{ verdict, confidence, riskScore, signals, urlResults, summary }}
 */
function analyzeEmail(body, senderEmail) {
  if (!body || typeof body !== 'string' || body.trim().length < 5) {
    return { ok: false, error: 'Email body is too short to analyze.' };
  }

  const text = body.trim();
  const lower = text.toLowerCase();
  const signals = [];
  let score = 0;

  // 1. Urgency language
  const urgencyHits = matchPatterns(text, URGENCY_PATTERNS);
  if (urgencyHits.length >= 3) {
    score += 25;
    signals.push({ category: 'URGENCY', severity: 'HIGH', detail: `Heavy urgency pressure detected (${urgencyHits.length} patterns): "${urgencyHits.slice(0, 3).join('", "')}"` });
  } else if (urgencyHits.length >= 1) {
    score += 12;
    signals.push({ category: 'URGENCY', severity: 'MEDIUM', detail: `Urgency language found: "${urgencyHits.join('", "')}"` });
  }

  // 2. Threat / fear language
  const threatHits = matchPatterns(text, THREAT_PATTERNS);
  if (threatHits.length >= 2) {
    score += 25;
    signals.push({ category: 'THREAT', severity: 'HIGH', detail: `Multiple threats/warnings detected: "${threatHits.slice(0, 3).join('", "')}"` });
  } else if (threatHits.length >= 1) {
    score += 15;
    signals.push({ category: 'THREAT', severity: 'MEDIUM', detail: `Threat language found: "${threatHits[0]}"` });
  }

  // 3. Request for sensitive data
  const dataHits = matchPatterns(text, SENSITIVE_DATA_PATTERNS);
  if (dataHits.length >= 2) {
    score += 30;
    signals.push({ category: 'DATA_REQUEST', severity: 'CRITICAL', detail: `Asks for sensitive information: "${[...new Set(dataHits)].slice(0, 4).join('", "')}"` });
  } else if (dataHits.length >= 1) {
    score += 18;
    signals.push({ category: 'DATA_REQUEST', severity: 'HIGH', detail: `Requests sensitive data: "${dataHits[0]}"` });
  }

  // 4. Generic greeting
  const greetingHits = matchPatterns(text, GENERIC_GREETING_PATTERNS);
  if (greetingHits.length > 0) {
    score += 8;
    signals.push({ category: 'GENERIC_GREETING', severity: 'LOW', detail: `Uses a generic greeting ("${greetingHits[0]}") instead of your real name - real companies usually know your name.` });
  }

  // 5. Too-good-to-be-true offers
  const offerHits = matchPatterns(text, OFFER_PATTERNS);
  if (offerHits.length >= 2) {
    score += 20;
    signals.push({ category: 'FAKE_OFFER', severity: 'HIGH', detail: `Prize / reward language detected: "${offerHits.slice(0, 3).join('", "')}"` });
  } else if (offerHits.length >= 1) {
    score += 10;
    signals.push({ category: 'FAKE_OFFER', severity: 'MEDIUM', detail: `Possible fake offer: "${offerHits[0]}"` });
  }

  // 6. Delivery / order scam patterns
  const deliveryHits = matchPatterns(text, DELIVERY_SCAM_PATTERNS);
  if (deliveryHits.length >= 1) {
    score += 12;
    signals.push({ category: 'DELIVERY_SCAM', severity: 'MEDIUM', detail: `Delivery / order scam pattern detected: "${deliveryHits.slice(0, 2).join('", "')}"` });
  }

  // 7. KYC scam patterns
  const kycHits = matchPatterns(text, KYC_PATTERNS);
  if (kycHits.length >= 1) {
    score += 15;
    signals.push({ category: 'KYC_SCAM', severity: 'HIGH', detail: `KYC / re-verification scam pattern detected. Banks never ask you to complete KYC through email or SMS links.` });
  }

  // 8. Brand mentions
  const brandHits = BRAND_NAMES.filter(b => lower.includes(b));
  if (brandHits.length > 0 && (threatHits.length > 0 || dataHits.length > 0 || urgencyHits.length > 0)) {
    score += 15;
    signals.push({ category: 'BRAND_IMPERSONATION', severity: 'HIGH', detail: `Mentions brand(s) "${brandHits.join('", "')}" combined with threats or data requests - likely impersonation.` });
  }

  // 9. Suspicious URLs in the email body
  const urls = extractUrls(text);
  const urlResults = [];
  for (const url of urls.slice(0, 10)) {
    const check = heuristicCheckUrl(url);
    if (check.ok) {
      urlResults.push({ url, ...check });
      if (check.verdict === 'MALICIOUS') {
        score += 25;
        signals.push({ category: 'MALICIOUS_LINK', severity: 'CRITICAL', detail: `Contains a malicious link: ${url}` });
      } else if (check.verdict === 'SUSPICIOUS') {
        score += 15;
        signals.push({ category: 'SUSPICIOUS_LINK', severity: 'HIGH', detail: `Contains a suspicious link: ${url}` });
      }
    }
  }

  // 10. Sender email check (if provided)
  if (senderEmail && typeof senderEmail === 'string') {
    const sender = senderEmail.toLowerCase().trim();
    const senderDomain = sender.split('@')[1] || '';

    // Free email provider sending "official" communications
    const freeProviders = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'aol.com', 'protonmail.com', 'yandex.com', 'mail.com'];
    if (freeProviders.includes(senderDomain) && brandHits.length > 0) {
      score += 20;
      signals.push({ category: 'SENDER_MISMATCH', severity: 'HIGH', detail: `Claims to be from "${brandHits[0]}" but sender uses a free email provider (${senderDomain}).` });
    }

    // Sender domain doesn't match claimed brand
    if (brandHits.length > 0 && !brandHits.some(b => senderDomain.includes(b))) {
      score += 10;
      signals.push({ category: 'SENDER_MISMATCH', severity: 'MEDIUM', detail: `Sender domain (${senderDomain}) doesn't match the claimed brand(s).` });
    }
  }

  // Cap score
  score = Math.min(100, score);

  // Determine verdict
  let verdict, confidence;
  if (score >= 55) {
    verdict = 'PHISHING';
    confidence = Math.min(95, 60 + Math.round(score / 4));
  } else if (score >= 25) {
    verdict = 'SUSPICIOUS';
    confidence = Math.min(80, 45 + Math.round(score / 3));
  } else {
    verdict = 'LIKELY_SAFE';
    confidence = 65;
  }

  // Build human-readable summary
  let summary;
  if (verdict === 'PHISHING') {
    summary = '🚫 DO NOT click any links, reply, or share any information. This message shows strong signs of being a phishing attempt. Delete it immediately.';
  } else if (verdict === 'SUSPICIOUS') {
    summary = '⚠️ This message has some red flags. Do not click links or share information until you verify the sender through official channels (visit the real website directly, not through links in this message).';
  } else {
    summary = '✅ No strong phishing indicators detected. However, always exercise caution with unexpected messages asking for personal data.';
  }

  return {
    ok: true,
    type: 'email',
    verdict,
    confidence,
    riskScore: score,
    signals,
    urlResults,
    summary,
    checkedAt: new Date().toISOString(),
  };
}

/**
 * Analyze SMS content for smishing indicators.
 * @param {string} body - The SMS message text
 * @param {string} [sender] - Optional sender number/name
 * @returns {{ verdict, confidence, riskScore, signals, urlResults, summary }}
 */
function analyzeSms(body, sender) {
  if (!body || typeof body !== 'string' || body.trim().length < 3) {
    return { ok: false, error: 'SMS content is too short to analyze.' };
  }

  const text = body.trim();
  const lower = text.toLowerCase();
  const signals = [];
  let score = 0;

  // 1. Urgency
  const urgencyHits = matchPatterns(text, URGENCY_PATTERNS);
  if (urgencyHits.length >= 1) {
    score += 15;
    signals.push({ category: 'URGENCY', severity: 'HIGH', detail: `Urgency pressure: "${urgencyHits.slice(0, 2).join('", "')}"` });
  }

  // 2. Threats
  const threatHits = matchPatterns(text, THREAT_PATTERNS);
  if (threatHits.length >= 1) {
    score += 20;
    signals.push({ category: 'THREAT', severity: 'HIGH', detail: `Threat language: "${threatHits[0]}"` });
  }

  // 3. Sensitive data requests
  const dataHits = matchPatterns(text, SENSITIVE_DATA_PATTERNS);
  if (dataHits.length >= 1) {
    score += 25;
    signals.push({ category: 'DATA_REQUEST', severity: 'CRITICAL', detail: `Asks for sensitive info: "${dataHits[0]}". Legitimate companies never ask for passwords, OTPs, or PINs via SMS.` });
  }

  // 4. Delivery / order scam
  const deliveryHits = matchPatterns(text, DELIVERY_SCAM_PATTERNS);
  if (deliveryHits.length >= 1) {
    score += 15;
    signals.push({ category: 'DELIVERY_SCAM', severity: 'HIGH', detail: `Order / delivery scam pattern: "${deliveryHits[0]}". Verify directly on the retailer's official app or website.` });
  }

  // 5. Prize / reward scam
  const offerHits = matchPatterns(text, OFFER_PATTERNS);
  if (offerHits.length >= 1) {
    score += 20;
    signals.push({ category: 'FAKE_OFFER', severity: 'HIGH', detail: `Prize / reward scam: "${offerHits[0]}". You cannot win a contest you didn't enter.` });
  }

  // 6. KYC scam
  const kycHits = matchPatterns(text, KYC_PATTERNS);
  if (kycHits.length >= 1) {
    score += 20;
    signals.push({ category: 'KYC_SCAM', severity: 'HIGH', detail: `KYC scam pattern detected. Banks never send KYC links via SMS. Visit your bank branch or official app.` });
  }

  // 7. Brand mentions + threats = impersonation
  const brandHits = BRAND_NAMES.filter(b => lower.includes(b));
  if (brandHits.length > 0 && (threatHits.length > 0 || dataHits.length > 0)) {
    score += 15;
    signals.push({ category: 'BRAND_IMPERSONATION', severity: 'HIGH', detail: `Impersonates "${brandHits.join('", "')}" with threats or data requests.` });
  }

  // 8. Suspicious URLs
  const urls = extractUrls(text);
  const urlResults = [];
  for (const url of urls.slice(0, 5)) {
    const check = heuristicCheckUrl(url);
    if (check.ok) {
      urlResults.push({ url, ...check });
      if (check.verdict === 'MALICIOUS') {
        score += 30;
        signals.push({ category: 'MALICIOUS_LINK', severity: 'CRITICAL', detail: `Malicious link detected: ${url}` });
      } else if (check.verdict === 'SUSPICIOUS') {
        score += 18;
        signals.push({ category: 'SUSPICIOUS_LINK', severity: 'HIGH', detail: `Suspicious link: ${url}` });
      }
    }
  }

  // 9. "Call this number" pattern
  const callPatterns = /\b(call|dial|contact|reach)\s*(us\s*)?(at|on|@)?\s*[\+]?\d[\d\s\-]{6,}/i;
  const callMatch = text.match(callPatterns);
  if (callMatch && (threatHits.length > 0 || urgencyHits.length > 0)) {
    score += 12;
    signals.push({ category: 'FAKE_HELPLINE', severity: 'HIGH', detail: `Asks you to call a number urgently. Scammers set up fake helplines. Always look up official numbers from the company's real website.` });
  }

  // 10. Short message with link = classic smishing
  if (text.length < 200 && urls.length > 0 && (urgencyHits.length > 0 || threatHits.length > 0)) {
    score += 10;
    signals.push({ category: 'SMISHING_PATTERN', severity: 'MEDIUM', detail: `Short message + link + urgency is the classic smishing formula.` });
  }

  score = Math.min(100, score);

  let verdict, confidence;
  if (score >= 50) {
    verdict = 'SCAM';
    confidence = Math.min(95, 58 + Math.round(score / 4));
  } else if (score >= 20) {
    verdict = 'SUSPICIOUS';
    confidence = Math.min(80, 42 + Math.round(score / 3));
  } else {
    verdict = 'LIKELY_SAFE';
    confidence = 60;
  }

  let summary;
  if (verdict === 'SCAM') {
    summary = '🚫 DO NOT click any link, call any number, or reply to this SMS. This is very likely a scam. Block the sender and delete the message.';
  } else if (verdict === 'SUSPICIOUS') {
    summary = '⚠️ This SMS looks suspicious. Do not click links. If it claims to be from a company, verify by calling the official number from their website - not the number in this message.';
  } else {
    summary = '✅ No strong scam indicators found. Still, be cautious with any message that asks you to click links or share personal details.';
  }

  return {
    ok: true,
    type: 'sms',
    verdict,
    confidence,
    riskScore: score,
    signals,
    urlResults,
    summary,
    checkedAt: new Date().toISOString(),
  };
}

module.exports = { analyzeEmail, analyzeSms };