# Real-time assessment engine — what changed

All 15 attacks are now **live** (exactly 5 per section). When you type a payload and press **Send to
vulnerable build** / **Send same input to fixed build** (or **Run test** /
**Run all**), the frontend makes a **real `fetch()`** to a real backend endpoint,
and the **verdict is computed from the actual HTTP response** — there are no
hard-coded verdicts anywhere in the frontend.

## Wiring

- **`assessment-api.js`** — Express router factory backed by SQLite. Every
  endpoint honours `X-Assess-Mode: vulnerable | fixed` (or `?mode=`) and runs the
  same path in two real implementations. Mounted in `app.js`:
  ```js
  app.use('/api/assess', createAssessRouter({ db, activity, harness, requireRole }));
  ```
  All `/api/assess/*` routes need a signed-in user; employee (EMP-*) and
  organisation (ORG-*) checks need the **admin** role.
- **Real-app path (EMP-04, EMP-09).** `lib/app-routes.js` defines the app's real
  employee self-service API — `GET /api/records/:id` (ownership-checked) and
  `PATCH /api/profile` (allow-listed fields) — plus *lab twins* with the one
  control removed, reachable only from loopback with a per-process harness
  secret. The harness mints a real employee session through the auth service
  and sends real HTTP to the production route (**fixed**) or the lab twin
  (**vulnerable**); EMP-09 then reads the row back from SQLite to prove what
  persisted, and restores it. With `AUTH_DISABLED=true` these checks fall back
  to the simulated path and the response says `path: "simulated"`.
- **`public/assessments/live-io.js`** — every check registers an `interactive`
  block whose `run(input, mode)` calls the matching endpoint and builds the
  streamed log + request/response evidence + verdict from the real status/body.
- **`public/assessments/engine.js`** — `run()` is now awaited; the top buttons
  and *Run all* / *Apply all fixes* drive the same live path.
- **`individual.js` / `employee-manager.js` / `company-org.js`** — all scripted
  `run(mode)` functions and inline `interactive` blocks were removed; `live-io.js`
  is the single source of live behaviour. Check metadata (CVSS, CWE, remediation,
  impact, etc.) is unchanged.

Run it: `npm install && npm run db:init && npm start` → http://localhost:5175 (sign in as admin).

## How the verdict is computed

Each endpoint returns `{ verdict, httpStatus, request, response, serverLog[] }`
where `verdict` is derived from what actually happened (e.g. an authz endpoint
that returns **200** to a non-owner is `VULNERABLE`; **403** is `SECURE`). The
frontend reads that verdict from the live response — it is never pre-set on the
card. The console shows the real method, URL, `X-Assess-Mode`, real HTTP status,
timing, the server's reasoning lines, and the final `verdict ← computed from live
response`.

## Safety boundary (kept deliberately, per the NTRO/SIH detection-only scope)

Genuinely dangerous classes operate on **sandboxed, synthetic** resources and
never touch real infrastructure:

| Check | Real behaviour | Sandbox |
|-------|----------------|---------|
| ORG-06 SQLi | injection genuinely collapses the WHERE clause and dumps rows | synthetic in-memory table; no real DB |
| ORG-09 Path traversal | naive join genuinely escapes the base vs normalise+block | **virtual** in-memory file map; **no real `fs` read** |
| ORG-10 SSRF | URL is parsed and **classified** internal/metadata/public; block logic is real | **no outbound request is made to the URL** |
| IND-12 Open redirect | the allow/deny decision is real | returned as data; **no live 302** to a user URL |
| IND-05/06 XSS | raw-vs-sanitised output is real and inspectable | returned as **data**; no endpoint serves executable HTML |
| ORG-08 Upload | extension/content-type decision is real | **no file is written** |

Everything else (authn, authz, RBAC, IDOR, JWT alg=none, session/token, CSRF,
validation, headers, cookie flags, rate-limiting, dependency scan, data exposure)
is exercised for real against the app's own state in SQLite.

### URL reputation (real, not simulated)
For public URLs, classify reputation with the existing
`POST /api/security/check-url` (Google Safe Browsing) — the assess layer points
you there rather than fetching attacker-supplied URLs server-side.

## Stateful checks
Reset tokens (IND-04), sessions/logout (IND-03), stored comments (IND-06),
role-change (EMP-07: a real demotion in the `employees` table) and the rate-limit
bucket (ORG-15) are stored in SQLite, so single-use / TTL / throttling are
genuinely enforced **and survive a server restart** (`test/persistence.test.js`
proves this by restarting the app mid-assessment).

## Endpoint map
`login-probe, password-check, session-replay, reset-token, reflect,
store-comment, comment/:id, csrf-action, headers, validate-input, user-record,
session-info, redirect, emp/:id, record/:id, admin-action, rbac-check,
token-check, role-change, jwt-verify, update-profile, manager-action, emp-data,
idle-check, org-endpoint, debug-mode, client-bundle, search, validate-org-input,
upload, file, fetch-preview, deps, transport-check, security-headers, log-entry,
rate-test, data-protection` (all under `/api/assess`).
