# World Monitor — Data Dictionary

## Core tables (`wm_*`)
`wm_sources, wm_source_runs, wm_source_receipts, wm_countries, wm_india_states,
wm_attack_taxonomy, wm_incidents, wm_incident_sources, wm_incident_country,
wm_incident_state, wm_financial_impacts, wm_case_lifecycle, wm_threat_actors,
wm_campaigns, wm_vulnerabilities, wm_incident_vulnerabilities, wm_research_datasets,
wm_research_records, wm_social_sources, wm_social_posts, wm_awareness_events,
wm_metrics, wm_metric_provenance, wm_comparison_snapshots, wm_alerts, wm_audit_log`.

## Metric definitions
| metric | definition | unit | source type | update freq | limitations |
|---|---|---|---|---|---|
| reported_incidents | incidents reported to/confirmed by a source | count | official/intel | per source | reporting ≠ prevalence |
| registered_cases | cases formally registered (e.g. NCRB) | count | official | annual | legal registration, not complaints |
| victims | victims as **published** by a source | count | official | per source | only when published |
| affected_organizations | organizations named by a source | count | official/intel | per source | disclosure-dependent |
| financial_loss | reported monetary loss | INR crore / currency | official | per source | reported, not adjudicated |
| financial_recovered / _blocked / _saved | separate money measures | INR crore | official | per source | never inferred from each other |
| cases_closed / cases_pending | lifecycle stage counts | count | official | per source | `NOT_PUBLISHED` if absent |
| threat_actor_count | distinct attributed actors | count | intel | per source | never derived from campaign count |
| campaign_count | named campaigns | count | intel | per source | attribution-dependent |
| awareness_reach | awareness content reach | count | official/social | per source | not "national awareness" |
| social_mentions | public discussion volume | count | social | per source | not a victim/awareness count |
| research_observations | values from a research dataset | varies | research | per dataset | sample, not official total |

## Evidence types (per record)
`VERIFIED_PRIMARY, VERIFIED_SECONDARY, AUTHORITATIVE_INTELLIGENCE, RESEARCH,
DERIVED, CROSSWALKED, ESTIMATED, INCOMPLETE, UNAVAILABLE, ERROR`.

## Field-level provenance (`wm_metric_provenance`)
`source_id, source_url, source_pub_date, retrieved_at, dataset_version,
calculation, transformation, inputs, notes`. Exposed at
`/api/world/provenance/:metricId` and in the UI "Why this number?" drawer.
