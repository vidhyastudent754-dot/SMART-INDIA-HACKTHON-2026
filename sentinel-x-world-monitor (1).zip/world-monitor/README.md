# World Monitor

**Phishing defence, digital forensics and live security assessment — SIH26163 (NTRO).**
Internal codename: *SENTINEL-X*.

World Monitor is a single web console that:

- **checks links, emails and SMS for phishing** — with a rule engine and a trained ML
  model scoring every message, and both scores shown ([ML.md](ML.md));
- **runs a 15-attack live security assessment (exactly 5 per section) plus a defensive SMS fraud detector** of individual, employee/manager and
  organisation scenarios, sending every attack to a vulnerable and a fixed
  implementation and computing the verdict from the real HTTP response
  ([ASSESSMENT-README.md](ASSESSMENT-README.md));
- **pushes this instance's own activity to the browser the moment a check runs** (SSE),
  next to periodically refreshed external data (CISA KEV, NVD, CERT-In — see
  [Data freshness](#data-freshness)) and clearly-labelled static reference
  statistics (NCRP, NCRB, I4C, FBI IC3).

> **Live instance:** _not deployed yet — see [Deploy](#deploy). Put the URL here once it is up._

---

## Quick start

Requires **Node.js 22 or newer** (22 LTS or 24 recommended). No C++ compiler is
needed: the SQLite driver ships ready-made binaries for Windows, macOS and Linux.

> **npm 11/12 install-script policy:** the SQLite driver needs its install step to
> fetch its pre-built binary. It is pre-approved in `package.json` (`allowScripts`),
> so npm 12 — which blocks unapproved install scripts — still installs it correctly.
> Quick check after installing: `node -e "require('better-sqlite3')(':memory:')"`
> should print nothing. If it errors, run `npm rebuild better-sqlite3`.
>
> **Windows tip:** if `npm install` ever fails with `EPERM … operation not permitted`,
> close VS Code / other terminals using the folder (and pause OneDrive sync if the
> folder is inside it), delete `node_modules`, and run `npm install` again.

```bash
npm install
npm run db:init      # creates data/worldmonitor.db, prints admin + viewer passwords once
npm start            # http://localhost:5175 → sign in
```

To choose the passwords yourself, copy `.env.example` to `.env` and set
`ADMIN_PASSWORD` / `VIEWER_PASSWORD` (12+ characters) **before** the first `db:init`.
To change them later, run `npm run db:init -- --reset-passwords`.

A Google Safe Browsing key is optional. Without one, URL checks run on the server
heuristics, and the UI and `/api/metrics` say so.

### Scripts

| Command | What it does |
|---|---|
| `npm start` | Start the server (creates and seeds the DB on first run if needed) |
| `npm run dev` | Start with auto-reload |
| `npm run db:init` | Create the schema and seed the demo dataset (idempotent; never overwrites passwords) |
| `npm run db:init -- --reset-passwords` | Issue new admin/viewer passwords |
| `npm run db:reset` | Clear assessment state (sessions, tokens, rate buckets) and restore demo employees |
| `npm test` | Unit + integration tests (`node:test`, exits non-zero on failure) |
| `npm run scan` | Black-box security scan of a running instance (set `SCAN_USER`/`SCAN_PASS`) |
| `npm run check:secrets` | Fail if `.env` or anything key-shaped is tracked by git |
| `npm run ml:train` | Re-train the ML models ([ML.md §6](ML.md#6-re-training)) |
| `npm run fabric:record` | Record real CISA/NVD/CERT-In responses for Replay / Demonstration mode |
| `npm run india:import` | Re-import and re-verify the NCRB State/UT tables (MHA USQ 452) |
| `npm run observatory:update` | Re-fetch the observatory's polled signals into `db/observatory.json` and append an audit line ([Observatory](#observatory)) |
| `npm run package` | Build `dist/world-monitor-submission.zip` (source only: no `.env`, `node_modules`, DB or reports) |

---

## Accounts and roles

| Role | Can do |
|---|---|
| **admin** | Everything: the dashboard, all 15 assessment attacks + SMS fraud detection, `/api/metrics.csv` and the activity export |
| **viewer** | The dashboard, phishing checks and the 5 Individual assessment attacks. Employee & Organisation checks return **403** and their tabs show as locked. |
| *employee* | Not a dashboard login. These are the demo directory's own accounts, used by the real employee API (`/api/records/:id`, `PATCH /api/profile`). |

How sessions are protected:

- The session token is an opaque 256-bit value in an `HttpOnly; SameSite=Strict` cookie (plus `Secure` behind TLS). The database stores only its SHA-256 hash.
- Sessions expire after 8 hours absolute or 30 minutes idle. Logout revokes the session on the server.
- The role is re-read from the database on every request.
- Login is rate-limited per IP, locks a username for 15 minutes after 5 failures, and every attempt is logged in `login_attempts`.

---

## What persists

Everything that changes at runtime is stored in **one SQLite file**
(`data/worldmonitor.db`, schema in [db/schema.sql](db/schema.sql)):

- login sessions;
- the assessment's sessions, password-reset tokens, stored comments and rate-limit buckets;
- the employee directory and records;
- live activity counters and login attempts.

Restart the server mid-assessment and a used reset token stays used, a revoked session
stays revoked, a rate-limit window keeps counting, and you stay signed in.
`test/persistence.test.js` checks this by restarting the app against the same file.

---

## API overview

All routes except `/login`, `/api/auth/login` and `/api/health` require a session.

| Route | Role | Purpose |
|---|---|---|
| `POST /api/auth/login` · `POST /api/auth/logout` · `GET /api/auth/me` | — | Session management |
| `POST /api/security/check-url` | admin, viewer | URL heuristics (+ Google Safe Browsing if configured) |
| `POST /api/security/analyze-email` · `analyze-sms` | admin, viewer | Hybrid analysis → `heuristicScore`, `mlScore`, `combinedConfidence` |
| `GET /api/activity` · `/api/activity/stream` (SSE) | admin, viewer | This instance's check counters, pushed to the browser on every check |
| `GET /api/activity/export.csv` · `GET /api/metrics.csv` | admin | CSV exports for reporting |
| `GET /api/metrics` | admin, viewer | Uptime, DB health and latency, Safe Browsing status, your rate-limit headroom, model status, auth health |
| `GET /api/health` | public | Liveness only (no internals) |
| `/api/assess/*` | viewer: individual checks · admin: all | The 15-attack assessment API (exactly 5 per section) |
| `GET /api/records/:id` · `PATCH /api/profile` | employee, admin | The real employee API that EMP-04/EMP-09 attack |

---

## Tests and CI

```bash
npm test
```

There are 66 tests:

- **Unit:** URL heuristics (HTTPS, raw IPv4/IPv6, shorteners, brand collisions, punycode), analyzer patterns, the hybrid blend, ML tokenizer and parity.
- **Integration:** login, RBAC, CSRF, CORS, persistence across restart, and vulnerable-vs-fixed verdicts. This includes EMP-04/EMP-09 against the real routes.
- **Observatory:** auth, slices, section 404, warm cache, a mocked NVD outage (served as cached), rejected garbage responses, computed figures, source-and-date on every reference figure, and no hard-coded numbers in the section-0 HTML.

[`.github/workflows/ci.yml`](.github/workflows/ci.yml) runs on every push: `npm ci`, then the secret check, then `npm test`, then it starts the server and runs `npm run scan` as a regression gate. It also builds and smoke-tests the Docker image.

---

## Verified World Monitor Fabric (periodically polled)

Section 0 is a **periodically polled** World Monitor of Sections 1–3 for India and the world. Collection is on a timer, not continuous; only the push of already-collected events to the browser is real-time (see [Data freshness](#data-freshness)). Full details are in **[docs/FABRIC.md](docs/FABRIC.md)**: coverage matrix, data dictionary, source policy and migration plan.

- **Polled signal layer.** Polls **CISA Known Exploited Vulnerabilities** every 3600 s (`pollIntervalSec: 1 * H`), **NVD CVEs** every 7200 s (`2 * H`, NVD's "no more than once every two hours" guidance) and **CERT-In vulnerability notes** every 1800 s (`0.5 * H`), plus 0–5 % random jitter. After a failure the next attempt is `min(pollIntervalSec, 60 s × 2^(failures−1))`; after 5 consecutive failures the circuit opens and the source is retried every 30 min. Each response becomes an immutable receipt (gzip + sha256). It then passes schema and timestamp gates; failures are quarantined, never dropped. Records become idempotent, versioned events mapped to Sections 1–3 with an explicit status (exact / crosswalked / partial / not comparable), and are pushed to the dashboard over **Server-Sent Events** (`/api/v1/stream`) with `Last-Event-ID` resume the moment they are stored. Every source shows **live / recent / cached / stale / unavailable** with its measured age — "live" here is a freshness label meaning "last successful poll is inside the source's freshness window", not continuous collection.
- **Periodic official baseline.** India **State/UT** police-registered cyber crime cases for 2019–2023, plus the fraud case lifecycle (registered → charge-sheeted → trials → convicted → arrested), from NCRB via MHA Lok Sabha USQ 452. It is imported with `npm run india:import`, which refuses to write unless every column reconciles with the document's own totals. District, city and PIN-code data are shown as **Not published by source**.
- **Alerts:** new exploited vulnerabilities, high-impact CERT-In notes, section surges, CVE volume anomalies and source outages. Each alert carries evidence, formula, baseline and lifecycle, is recorded in a tamper-evident audit, and **never claims an attack happened**.
- **Trust Center:** the coverage matrix, a source-quality score (explicitly the app's own assessment), the quarantine queue, ingestion receipts and audit-chain verification.
- **Replay / Demonstration:** `FABRIC_MODE=replay npm start` replays recorded real responses, clearly labelled and isolated from production. Use `npm run fabric:record` to capture fresh ones before a demo.

> No verified public source provides a complete, real-time, worldwide, PIN-code-level cybercrime incident ledger. World Monitor does not claim one: vulnerability and advisory feeds are signals, not confirmed attacks.


## Design decisions

**Accounts are provisioned out-of-band — there is deliberately no self-service
password reset (Option B).** World Monitor is a small internal console with exactly
two fixed roles (`admin`, `viewer`). Their passwords live in `.env` on the server;
`npm start` syncs the database to `.env` on every start and prints both logins in
the operator's terminal. Rotating a password = edit `.env`, restart. Reasons:

- A public `POST /api/auth/forgot` / `/reset` flow needs an out-of-band channel
  (email/SMS) the deployment does not have; without one, a reset endpoint only adds
  attack surface (token brute force, account enumeration, reset-link phishing).
- Whoever can reset the admin password must already control the server, which is
  exactly who can edit `.env` — so the reset flow would add no capability, only risk.
- The secure reset pattern (short TTL, single use, token stored only as a hash) is
  still implemented and tested — as the IND-04 assessment, where the vulnerable and
  fixed builds are compared over real HTTP — so the project shows it can be built
  correctly without exposing it on the production login.

If the console is ever opened to self-registered users, add a real reset flow that
reuses the IND-04 fixed-build logic.

**Content-Security-Policy has no `unsafe-inline` for scripts.** Every page script
is an external file (`public/js/*.js`, `public/assessments/*.js`); `script-src` is
`'self'` only, `object-src 'none'`. `test/csp.test.js` fails if an inline script,
inline event handler or `unsafe-inline`/`unsafe-eval` in `script-src` ever
returns, and `npm run scan` fails the CI job on the same condition. (Inline
`style` attributes are still allowed by `style-src`.)

**HTTPS.** Set `FORCE_HTTPS=true` for any non-localhost deployment (it is set in
`render.yaml`); it enables the HTTPS redirect, HSTS and `Secure` cookies. When
`NODE_ENV=production` and it is not set, the server prints a loud warning at start.


## Data freshness

External data is **collected on a timer (polling), not continuously**. What is
real-time is the **push**: once a new row is stored, the server sends it to every
open browser over Server-Sent Events. "Real-time" in this project describes
push-to-browser timing only — never how often a source is collected.

| Layer | What it does | Actual refresh interval | Source (real/simulated) |
|---|---|---|---|
| Observatory reference figures (`db/observatory.json`, `db/observatory-data/*.csv`) | Annual / per-report official figures (MHA/I4C, NCRB, CERT-In, FBI IC3, FTC, ACCC, SPF, Eurostat …) | Not polled. Updated by hand when a new report is published (`npm run observatory:update` for the signals below) | Real (official publications, each with a source URL) |
| Observatory polled signals (`lib/observatory-cache.js`) | NVD CVEs in last 7 days, HIBP breach count, INTERPOL Red Notices, CERT-In notes this year | At start, then every `OBSERVATORY_REFRESH_MS`; default **7 200 000 ms (2 h)** = `max(THIRTY_MIN, NVD floor TWO_HOURS)`; override ≥ 2 h only | Real (public APIs / pages); on failure the last recorded value is shown as "cached" |
| Fabric — CISA KEV (`lib/fabric/registry.js`) | Known exploited vulnerabilities → validated, versioned events | Every **3600 s** (`pollIntervalSec: 1 * H`) + 0–5 % jitter; failure backoff `min(3600 s, 60 s × 2^(n−1))`; circuit open after 5 failures → every 1800 s | Real (cisa.gov) |
| Fabric — NVD CVE API 2.0 | New CVEs → events | Every **7200 s** (`2 * H`) + jitter; same backoff | Real (services.nvd.nist.gov) |
| Fabric — CERT-In vulnerability notes | India vulnerability notes (HTML listing) → events | Every **1800 s** (`0.5 * H`) + jitter; same backoff | Real (cert-in.org.in) |
| Fabric — HIBP breaches | Breach catalogue | Every **21600 s** (`6 * H`) — **off by default** (`FABRIC_HIBP=on`) | Real (haveibeenpwned.com) |
| Fabric replay mode | Replays recorded responses for demos | Every **20 s** (`replayIntervalSec`) — only when `FABRIC_MODE=replay` | **Simulated** (recorded real responses, labelled "Replay / Demonstration") |
| Live data feed collector (`lib/live-feed.js`) | CISA KEV (cisa.gov, fallback CISA's GitHub mirror), CVE Program new records, copy of Fabric events → `live_feed` table | 3 s after start, then every **600 000 ms (10 min)** (`TEN_MIN`) | Real |
| Live data feed — admin entries | An admin feeds an official figure with a required source link | Stored immediately on submit | Real (entered by admin, source link required) |
| World source health (`/api/world/sources`) | HTTP reachability + checksum of each registered source | **Only when `npm run world:refresh` is run** — no timer | Real (probe results) |
| NCRB State/UT baseline | 2019–2023 cases + fraud case lifecycle | Imported once (`npm run india:import`) | Real (MHA Lok Sabha USQ 452) |
| **SSE push** — `/api/feed/stream`, `/api/v1/stream`, `/api/activity/stream` | Push newly stored rows to the browser | **Real-time**: sent as soon as the row is committed (no polling delay) | — (delivery only) |
| **SSE push** — `/api/world/stream` | Push `source.updated` / `metric.updated` when world tables change | **Real-time push**, change detected by a DB check every **4000 ms** (≤ 4 s delay) | — (delivery only) |

**Why the Observatory default is 2 hours, not 30 minutes.** Each polled source's
documented limits were checked before shortening the interval:

| Source (signal) | Documented limit | Minimum safe interval |
|---|---|---|
| NVD CVE API 2.0 (`nvdCves7d`) | Public limit 5 requests per rolling 30 s; NVD best practices: automated update requests "no more than once every two hours", sleep 6 s between requests | **2 h** |
| Have I Been Pwned `/breaches` (`hibpBreaches`) | Unauthenticated all-breaches endpoint is not rate limited | none |
| INTERPOL notices API (`interpolRedNotices`) | No limit published | none |
| CERT-In listing page (`certInVulnNotes`) | No API, no automated-access limit published | none |
| CISA KEV JSON (Fabric / live feed, not the Observatory cache) | Static JSON file; no rate limit published | none |

A 30-minute cycle would call NVD 4× per 2 h, against NVD's guidance, so the
longest documented limit — **NVD, 2 hours** — sets both the default and the floor.
Set `OBSERVATORY_REFRESH_MS` to a larger value to poll less often.

## Observatory

The **⦿ World Monitor** tab is a cyber threat observatory backed by
`/api/observatory/*` (auth-protected, viewer role minimum). Nothing in its HTML is
a hard-coded statistic — every number is rendered from the API, and a test fails if
one is ever typed into the markup.

- **Reference data** ([`db/observatory.json`](db/observatory.json)): annual and
  official figures from MHA/I4C (Parliament replies), NCRB, CERT-In, FBI IC3 (2024
  and 2025), ASD (Australia) and BKA (Germany). Every figure carries `source`,
  `sourceUrl`, its year or as-of date, and `retrievedAt`. Figures read from a news
  report of an official release are flagged `secondary` (shown as † in the UI).
  These bodies publish reports, not APIs, so this file is edited by hand when a new
  report comes out. It lives in `db/` (not `data/`) because `data/` is git-ignored
  and is the Docker volume mount point.
- **Polled signals**, fetched server-side at startup and then every
  `OBSERVATORY_REFRESH_MS` (default **7 200 000 ms = 2 h**; values below 2 h are
  raised to 2 h — see [Data freshness](#data-freshness)), 5 s timeout each,
  strictly validated:
  - NVD CVEs published in the last 7 days (NVD API 2.0);
  - breaches catalogued by Have I Been Pwned;
  - public INTERPOL Red Notices;
  - CERT-In vulnerability notes issued this year (page read).

  Each card shows **● Live** (value came from the most recent poll) or **◌ Cached**. On failure the last value recorded by
  `observatory:update` is served as cached; nothing is invented. Set
  `OBSERVATORY_LIVE=off` for air-gapped deployments. PhishTank is not used: it
  closed new API registrations and has no public count endpoint.
- **Estimates** — the per-section victim and loss figures apply an *assumed* split
  (72 / 18 / 10) to the official NCRP totals. MHA publishes no such breakdown. The
  UI marks every estimate with `*` and states the assumption; it lives in
  `estimates.split` in the data file.
- **Update:** `npm run observatory:update` (add `--dry` to preview, `--strict` to
  exit non-zero on any failure for cron alerting) re-fetches the polled signals,
  writes them into the data file, appends an audit line to
  `db/observatory-history.jsonl`, and lists which annual sources to check for new
  releases.
- **Tabs:**
  - *Overview:* KPIs, animated trend charts, live signals, and this instance's own SSE counters.
  - *India:* NCRP table, FIR conversion, I4C actions, the justice pipeline.
  - *Global:* IC3 loss donut, reporting scale by country, live CVE/breach/notice counts.
  - *India vs World:* the three assessment sections compared, with a dual-axis loss chart.
  - *By Attack Section:* attack types mapped to the live checks and their CVSS scores, with a button that opens that assessment.
  - *Enforcement* and *Data Feed.*

  **Export PDF** prints every tab.

## Deploy

**Docker (one command):**

```bash
ADMIN_PASSWORD='choose-a-long-one' VIEWER_PASSWORD='and-another-one' docker compose up --build -d
```

The SQLite file lives on the `wm-data` volume, so it survives container restarts and rebuilds.

**Render.com:** the repo includes [`render.yaml`](render.yaml). Choose New → Blueprint, then set
`ADMIN_PASSWORD` / `VIEWER_PASSWORD` in the dashboard. A persistent disk (needed so the DB
survives redeploys) requires a paid instance type. On the free tier the app still runs,
but the database resets on every redeploy.

**Behind a reverse proxy / TLS:** terminate TLS at the proxy. The app trusts one proxy
hop for `X-Forwarded-Proto`. Set `FORCE_HTTPS=true` only if this process itself should
redirect to HTTPS and send HSTS.

For how this maps onto a ministry or enterprise deployment, see the prepared answer in
[DEMO.md](DEMO.md#judge-questions).

---

## Repository layout

```
server.js                entry point (config, DB, listen)
app.js                   Express app factory: headers, CORS, CSRF, auth gate, routes
analyzer.js heuristics.js    rule engines (email/SMS, URL)
assessment-api.js        40-check assessment router (SQLite-backed)
lib/
  auth.js                sessions, login, RBAC middleware
  db.js  passwords.js    SQLite + scrypt
  ml.js  hybrid.js       in-process model scorer + 60/40 blend
  activity.js            live counters + SSE stream + CSV export
  metrics.js             /api/metrics
  app-routes.js          real employee API + harness-only lab twins
db/schema.sql  db/seed.js
models/*.json            trained model weights (committed)
ml/train.py              training pipeline (data fetched by ml/fetch-data.sh)
public/                  dashboard, login page, assessment consoles
scanner/                 black-box security scanner
test/                    node:test suites
scripts/                 secret check, git hook installer, submission packager
```

## Documents

- [DEMO.md](DEMO.md) — timed demo script and prepared answers to judge questions
- [ML.md](ML.md) — training data, cleaning, features, held-out metrics, limitations
- [ASSESSMENT-README.md](ASSESSMENT-README.md) — the 15 attacks and how to drive them
- [ASSESSMENT-REALTIME.md](ASSESSMENT-REALTIME.md) — how each check reaches the backend
- [scanner/README.md](scanner/README.md) — the automated security scan

## Scope and safety

This is a detection and awareness tool. Every person and record in the demo dataset is
synthetic. Dangerous assessment classes (SQLi, path traversal, SSRF, XSS, open
redirect) run on sandboxed synthetic data and never touch real infrastructure. The
deliberately vulnerable *lab twins* answer only loopback requests that carry a
per-process secret. Set `ASSESS_LAB=off` to not mount them at all.
