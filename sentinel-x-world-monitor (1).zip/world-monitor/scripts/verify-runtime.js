#!/usr/bin/env node
/* =============================================================================
 * scripts/verify-runtime.js - SENTINEL-X runtime verification & evidence.
 *
 * Boots the real server, logs in as a real admin, and exercises every one of
 * the 15 approved attacks over REAL HTTP in BOTH modes (vulnerable → expect
 * VULNERABLE, fixed → expect SECURE), plus the SMS Fraud Detector's scenarios.
 * It also confirms retired attack routes are gone (return UNSUPPORTED/404).
 *
 * Every verdict printed here is COMPUTED by the server from the actual request
 * outcome - this script only asserts the computed verdict matches expectation.
 *
 *   node scripts/verify-runtime.js            # boots its own server
 *   BASE=http://localhost:5175 node scripts/verify-runtime.js   # use a running one
 *
 * Exit code 0 = every check verified; non-zero = at least one mismatch.
 * ===========================================================================*/
'use strict';

const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const REGISTRY = require(path.join(__dirname, '..', 'public', 'assessments', 'registry.js'));

const ADMIN_USER = process.env.WM_ADMIN_USER || 'admin';
const ADMIN_PASS = process.env.ADMIN_PASSWORD || 'Str0ngAdminPass123';
const rid = () => crypto.randomBytes(4).toString('hex');

let cookie = '';
async function api(method, p, { body, headers, mode } = {}) {
  const h = Object.assign({ Cookie: cookie }, headers || {});
  if (body !== undefined) h['Content-Type'] = 'application/json';
  if (mode) h['X-Assess-Mode'] = mode;
  const r = await fetch(BASE + p, { method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined });
  const text = await r.text();
  let json = null; try { json = JSON.parse(text); } catch (e) { /* non-JSON */ }
  return { status: r.status, json, text };
}

/* Each attack: how to drive vulnerable and fixed, and the field to read. */
function attackPlan() {
  const uEMP = { 'X-Assess-User': 'EMP-A' };
  const tok = () => 'tok-' + rid();
  const sess = () => ({ 'X-Assess-Session': 'run-' + rid() });
  return {
    'IND-06': { m: 'POST', p: '/api/assess/store-comment', body: { body: '<script>document.title="xss"</script>' } },
    'IND-10': { m: 'GET',  p: '/api/assess/user-record?id=U-A' },
    'IND-03': { m: 'POST', p: '/api/assess/session-replay', body: () => ({ sid: 'sid-' + rid() }) },
    'IND-01': { m: 'POST', p: '/api/assess/login-probe', body: { email: 'testa@wm.local' } },
    'IND-04': { m: 'POST', p: '/api/assess/reset-token', body: () => ({ token: tok(), elapsedMinutes: 0 }) },
    'EMP-04': { m: 'GET',  p: '/api/assess/record/1002', headers: uEMP },
    'EMP-09': { m: 'POST', p: '/api/assess/update-profile', headers: uEMP, body: { name: 'A', role: 'admin' } },
    'EMP-02': { m: 'POST', p: '/api/assess/admin-action', headers: uEMP, body: { op: 'deleteAllLogs' } },
    'EMP-08': { m: 'POST', p: '/api/assess/jwt-verify', body: {} },
    'EMP-12': { m: 'POST', p: '/api/assess/idle-check', body: { idleMinutes: 60 } },
    'ORG-06': { m: 'POST', p: '/api/assess/search', body: { q: "' OR 1=1--" } },
    'ORG-09': { m: 'GET',  p: '/api/assess/file?path=' + encodeURIComponent('../../etc/passwd') },
    'ORG-15': { m: 'POST', p: '/api/assess/rate-test', body: { requestCount: 8, windowSeconds: 60 }, headers: sess },
    'ORG-16': { m: 'GET',  p: '/api/assess/data-protection' },
    'ORG-11': { m: 'GET',  p: '/api/assess/deps' },
  };
}

async function runAttack(id, plan) {
  const results = {};
  for (const mode of ['vulnerable', 'fixed']) {
    const headers = typeof plan.headers === 'function' ? plan.headers() : (plan.headers || {});
    const body = typeof plan.body === 'function' ? plan.body() : plan.body;
    const r = await api(plan.m, plan.p, { body, headers, mode });
    results[mode] = r.json || {};
  }
  const vVerdict = results.vulnerable.verdict;
  const fVerdict = results.fixed.verdict;
  const ok = vVerdict === 'VULNERABLE' && fVerdict === 'SECURE';
  return { id, ok, vVerdict, fVerdict, path: results.vulnerable.path || results.fixed.path,
    evidence: { vulnerable: results.vulnerable.response, fixed: results.fixed.response } };
}

const SMS_CASES = [
  { label: 'Normal OTP notification', expect: 'SAFE', body: { message: 'EXAMPLEBANK: Your login OTP is 445566. Do not share this OTP with anyone.' } },
  { label: 'Fraudulent OTP disclosure request', expect: 'HIGH_RISK',
    body: { message: 'EXAMPLEBANK SECURITY: Your account will be blocked. Tell the OTP to our support executive to cancel the transaction.', sender: 'UNKNOWN-98321', claimedCompany: 'Example Bank' } },
  { label: 'Debit + phishing link + OTP reply', expect: 'HIGH_RISK',
    body: { message: 'Your account has been debited Rs 25,000. If this was not you, verify immediately: https://suspicious-example.test Reply with your OTP to cancel the transaction.', claimedCompany: 'Example Bank' } },
  { label: 'Company/sender/domain mismatch', expect: 'HIGH_RISK',
    body: { message: 'Your account is suspended. Verify now: https://example-bank-security.example', claimedCompany: 'Example Bank', sender: 'UNKNOWN-98321' } },
  { label: 'Name mismatch alone (must NOT be HIGH_RISK)', expect: 'SAFE',
    body: { message: 'Dear Rahul, your statement is ready.', userName: 'Test User A' } },
  { label: 'Benign delivery note', expect: 'SAFE', body: { message: 'Your Amazon order will arrive today between 4-6pm.' } },
];

const RETIRED = [
  ['GET', '/api/assess/headers'], ['GET', '/api/assess/org-endpoint'], ['GET', '/api/assess/debug-mode'],
  ['POST', '/api/assess/reflect'], ['POST', '/api/assess/rbac-check'], ['POST', '/api/assess/manager-action'],
  ['POST', '/api/assess/fetch-preview'], ['GET', '/api/assess/client-bundle'],
];

async function main() {
  // login
  const login = await fetch(BASE + '/api/auth/login', { method: 'POST',
    headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: ADMIN_USER, password: ADMIN_PASS }) });
  const setc = (login.headers.getSetCookie ? login.headers.getSetCookie() : [login.headers.get('set-cookie')]).filter(Boolean);
  cookie = setc.map((c) => c.split(';')[0]).join('; ');
  if (login.status !== 200) { console.error('LOGIN FAILED', login.status); return false; }

  const ping = (await api('GET', '/api/assess/__ping')).json;

  const line = '─'.repeat(78);
  console.log('\n' + line);
  console.log('  SENTINEL-X RUNTIME VERIFICATION  -  ' + new Date().toISOString());
  console.log(line);
  console.log(`  Registry: ${ping.checks} attacks · valid=${ping.registryValid} · sections=${JSON.stringify(ping.sectionCounts)} · realAppPath=${ping.realAppPath}`);
  console.log(line);

  let pass = 0, fail = 0;
  const plans = attackPlan();

  const sections = { 1: 'SECTION 1 - INDIVIDUAL', 2: 'SECTION 2 - EMPLOYEE & MANAGER', 3: 'SECTION 3 - ORGANIZATION' };
  for (const sec of [1, 2, 3]) {
    console.log('\n  ' + sections[sec]);
    for (const a of REGISTRY.bySection(sec)) {
      const r = await runAttack(a.id, plans[a.id]);
      const mark = r.ok ? '✅' : '❌';
      if (r.ok) pass++; else fail++;
      const p = r.path ? ` [${r.path}]` : '';
      console.log(`   ${mark} ${a.id.padEnd(7)} ${a.title.padEnd(34)} vuln=${String(r.vVerdict).padEnd(10)} fixed=${r.fVerdict}${p}`);
      if (!r.ok) console.log(`        evidence: vuln="${r.evidence.vulnerable}" fixed="${r.evidence.fixed}"`);
    }
  }

  console.log('\n  DEFENSIVE CAPABILITY - SMS FRAUD DETECTION');
  let smsPass = 0, smsFail = 0;
  for (const c of SMS_CASES) {
    const r = await api('POST', '/api/sms/analyze', { body: c.body });
    const got = (r.json && r.json.classification) || '?';
    const ok = got === c.expect;
    if (ok) smsPass++; else smsFail++;
    console.log(`   ${ok ? '✅' : '❌'} ${c.label.padEnd(46)} expect=${c.expect.padEnd(10)} got=${got}` +
      (r.json && r.json.otpDisclosureRequest !== undefined ? `  otpDisclosureRequest=${r.json.otpDisclosureRequest}` : ''));
  }

  console.log('\n  RETIRED ATTACKS - must NOT execute (expect UNSUPPORTED/404/415)');
  let retiredOk = 0, retiredBad = 0;
  for (const [m, p] of RETIRED) {
    const r = await api(m, p, m === 'POST' ? { body: {} } : {});
    const executed = r.json && (r.json.verdict === 'VULNERABLE' || r.json.verdict === 'SECURE');
    const good = !executed && (r.status === 404 || r.status === 415);
    if (good) retiredOk++; else retiredBad++;
    console.log(`   ${good ? '✅' : '❌'} ${m.padEnd(4)} ${p.replace('/api/assess', '')}  → HTTP ${r.status} verdict=${(r.json && r.json.verdict) || '-'}`);
  }

  console.log('\n' + line);
  const allOk = fail === 0 && smsFail === 0 && retiredBad === 0 && ping.registryValid && ping.checks === 15;
  console.log(`  ATTACKS: ${pass}/${pass + fail} verified   SMS: ${smsPass}/${smsPass + smsFail}   RETIRED-BLOCKED: ${retiredOk}/${retiredOk + retiredBad}`);
  console.log(`  RESULT: ${allOk ? 'ALL CHECKS VERIFIED ✅' : 'FAILURES PRESENT ❌'}`);
  console.log(line + '\n');
  return allOk;
}

/* ---- boot our own server unless BASE points at a running one ---- */
let BASE = process.env.BASE || '';
async function waitHealthy(url, ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try { const r = await fetch(url + '/healthz'); if (r.ok) return true; } catch (e) { /* retry */ }
    try { const r = await fetch(url + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); if (r.status) return true; } catch (e) { /* retry */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  return false;
}

(async () => {
  let child = null;
  if (!BASE) {
    const port = process.env.PORT || 5199;
    BASE = `http://localhost:${port}`;
    // Seed a THROWAWAY database with a known admin password so verification does
    // not depend on the developer's .env or a previously-generated password.
    const tmpDb = path.join(os.tmpdir(), `wm-verify-${process.pid}.db`);
    try {
      const { openDb } = require(path.join(__dirname, '..', 'lib', 'db'));
      const { seed } = require(path.join(__dirname, '..', 'db', 'seed'));
      const db = openDb(tmpDb);
      seed(db, { resetPasswords: true, env: { ADMIN_PASSWORD: ADMIN_PASS, VIEWER_PASSWORD: 'Str0ngViewerPass1' } });
      db.close();
    } catch (e) { console.error('could not seed throwaway DB:', e.message); process.exit(2); }
    child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')],
      { cwd: path.join(__dirname, '..'),
        env: Object.assign({}, process.env, { PORT: String(port), DB_PATH: tmpDb,
          ADMIN_PASSWORD: ADMIN_PASS, VIEWER_PASSWORD: 'Str0ngViewerPass1',
          AUTH_DISABLED: 'false', OBSERVATORY_LIVE: 'off', FABRIC: 'off', FABRIC_POLL: 'off', FABRIC_ALERTS: 'off' }),
        stdio: 'ignore' });
    const ok = await waitHealthy(BASE, 15000);
    if (!ok) { console.error('server did not become healthy'); if (child) child.kill(); process.exit(3); }
  }
  let ok = false;
  try { ok = await main(); }
  catch (e) { console.error(e); ok = false; }
  finally { if (child) child.kill(); }
  process.exit(ok ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(4); });
