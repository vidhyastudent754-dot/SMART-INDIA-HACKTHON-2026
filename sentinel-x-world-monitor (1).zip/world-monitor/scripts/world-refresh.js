#!/usr/bin/env node
/* scripts/world-refresh.js - REAL source-health refresh. For each enabled
 * source it performs a real HTTP request to the source's official URL, records
 * a source_run (+ receipt with a checksum) and updates the source status +
 * last_fetch_at. It does NOT fabricate statistics - it only measures whether
 * each official/intelligence source is reachable and how fresh the fetch is.
 *
 *   node scripts/world-refresh.js          # real fetches, writes runs
 *   node scripts/world-refresh.js --dry    # measure but write nothing
 * ===========================================================================*/
'use strict';
require('../lib/proxy').enableProxyFromEnv();
const crypto = require('crypto');
const { openDb } = require('../lib/db');

const DRY = process.argv.includes('--dry');
const TIMEOUT_MS = 8000;

async function probe(url) {
  const t0 = Date.now();
  const ctrl = AbortSignal.timeout(TIMEOUT_MS);
  try {
    // GET (many gov sites reject HEAD); cap body read for the checksum.
    const r = await fetch(url, { method: 'GET', redirect: 'follow', signal: ctrl,
      headers: { 'User-Agent': 'WorldMonitor-SourceHealth/1.0 (+cyber-intel observatory)' } });
    const buf = Buffer.from(await r.arrayBuffer());
    const ms = Date.now() - t0;
    let status;
    if (r.status === 401 || r.status === 403) status = 'AUTH_REQUIRED';
    else if (r.status === 429) status = 'RATE_LIMITED';
    else if (r.status >= 200 && r.status < 400) status = 'LIVE';        // reachable now
    else status = 'UNAVAILABLE';
    return { httpStatus: r.status, ms, status, contentType: r.headers.get('content-type'),
      bytes: buf.length, checksum: crypto.createHash('sha256').update(buf).digest('hex') };
  } catch (e) {
    return { httpStatus: 0, ms: Date.now() - t0, status: 'UNAVAILABLE', error: String(e.message || e) };
  }
}

(async () => {
  const db = openDb();
  const sources = db.prepare('SELECT * FROM wm_sources WHERE enabled = 1 ORDER BY scope DESC, tier').all();
  const insRun = db.prepare(`INSERT INTO wm_source_runs (source_id,started_at,finished_at,http_status,fetch_ms,parser_status,validation,record_count,status,error,dry)
    VALUES (@source_id,@started_at,@finished_at,@http_status,@fetch_ms,@parser_status,@validation,@record_count,@status,@error,@dry)`);
  const insRcpt = db.prepare(`INSERT INTO wm_source_receipts (run_id,source_id,fetched_at,content_type,byte_length,checksum,url)
    VALUES (@run_id,@source_id,@fetched_at,@content_type,@byte_length,@checksum,@url)`);
  const upSrc = db.prepare('UPDATE wm_sources SET status = ?, last_fetch_at = ? WHERE id = ?');

  const results = [];
  for (const s of sources) {
    const started = Date.now();
    const p = await probe(s.url);
    results.push({ id: s.id, url: s.url, status: p.status, http: p.httpStatus, ms: p.ms });
    if (DRY) continue;
    const info = insRun.run({ source_id: s.id, started_at: started, finished_at: Date.now(),
      http_status: p.httpStatus, fetch_ms: p.ms, parser_status: p.error ? 'SKIPPED' : 'OK',
      validation: p.error ? 'INVALID' : 'OK', record_count: null, status: p.status, error: p.error || null, dry: 0 });
    if (p.checksum) insRcpt.run({ run_id: info.lastInsertRowid, source_id: s.id, fetched_at: Date.now(),
      content_type: p.contentType || null, byte_length: p.bytes || null, checksum: p.checksum, url: s.url });
    upSrc.run(p.status, Date.now(), s.id);
  }
  if (!DRY) db.prepare('INSERT INTO wm_audit_log (ts,action,detail,actor) VALUES (?,?,?,?)')
    .run(Date.now(), 'world-refresh', JSON.stringify({ probed: results.length, dry: false }), 'cli');

  const reachable = results.filter((r) => ['LIVE', 'RECENT', 'CACHED'].includes(r.status)).length;
  console.log(`${DRY ? '[DRY] ' : ''}World Monitor source refresh - ${reachable}/${results.length} reachable`);
  for (const r of results) console.log(`  ${r.status.padEnd(13)} HTTP ${String(r.http).padStart(3)}  ${r.ms}ms  ${r.id}  ${r.url}`);
  db.close();
})().catch((e) => { console.error(e); process.exit(1); });
