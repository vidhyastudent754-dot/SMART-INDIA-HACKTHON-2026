#!/usr/bin/env node
/* world-provenance.js - dump provenance for a metric id, or list all metric ids
 * with their source URLs when no id is given. */
'use strict';
const { openDb } = require('../lib/db');
const { createWorldMonitor } = require('../lib/world-monitor');
const db = openDb();
const wm = createWorldMonitor(db);
const id = process.argv[2];
if (id) { console.log(JSON.stringify(wm.provenance(id), null, 2)); }
else {
  const rows = db.prepare('SELECT m.metric_id, m.original_value, m.unit, m.period, p.source_url FROM wm_metrics m JOIN wm_metric_provenance p USING(metric_id) ORDER BY m.metric_id').all();
  console.log(`# ${rows.length} provenance-backed metrics`);
  rows.forEach(r => console.log(`${r.metric_id}\t${r.original_value} ${r.unit||''} (${r.period||''})\t${r.source_url||''}`));
}
db.close();
