#!/usr/bin/env node
/**
 * scripts/update-observatory.js - refresh the observatory's live signals and
 * record them in the reference file, with an append-only audit log.
 *
 *   npm run observatory:update             fetch live signals, update db/observatory.json
 *   npm run observatory:update -- --dry    fetch and report, write nothing
 *   npm run observatory:update -- --strict exit 1 if any signal fails (for CI/cron alerting)
 *
 * What it does NOT do: invent or scrape annual statistics. MHA/I4C, NCRB,
 * CERT-In, FBI IC3, ASD and BKA publish reports and parliamentary replies, not
 * APIs. Those figures are edited by hand in db/observatory.json when a new
 * report is published; this script prints which sources to check.
 *
 * Every run appends one JSON line to db/observatory-history.jsonl (the audit
 * trail: what was fetched, when, and what changed).
 */
'use strict';
require('../lib/proxy').enableProxyFromEnv();

const fs = require('fs');
const path = require('path');
const { SIGNALS, REF_FILE } = require('../lib/observatory-cache');

const HISTORY = path.join(path.dirname(REF_FILE), 'observatory-history.jsonl');
const args = process.argv.slice(2);
const DRY = args.includes('--dry');
const STRICT = args.includes('--strict');

async function main() {
  const ref = JSON.parse(fs.readFileSync(REF_FILE, 'utf8'));
  ref.liveSignals = ref.liveSignals || {};
  const now = Date.now();
  const results = {};

  console.log(`\nWorld Monitor - observatory update${DRY ? ' (dry run)' : ''}\n`);
  await Promise.all(Object.entries(SIGNALS).map(async ([key, def]) => {
    const t0 = Date.now();
    try {
      const { value, extra } = await def.fetch((...a) => fetch(...a), AbortSignal.timeout(15000), now);
      const prev = ref.liveSignals[key] ? ref.liveSignals[key].value : null;
      results[key] = { ok: true, value, previous: prev, ms: Date.now() - t0 };
      ref.liveSignals[key] = { value, extra, fetchedAt: new Date().toISOString(), origin: def.source, sourceUrl: def.sourceUrl };
    } catch (e) {
      results[key] = { ok: false, error: String(e.message || e), ms: Date.now() - t0 };
    }
  }));

  for (const [key, r] of Object.entries(results)) {
    const label = SIGNALS[key].label.padEnd(46);
    if (r.ok) {
      const delta = r.previous == null ? '(first value)' : `(was ${r.previous}, ${r.value - r.previous >= 0 ? '+' : ''}${r.value - r.previous})`;
      console.log(`  ✔ ${label} ${String(r.value).padStart(8)}  ${delta}`);
    } else {
      console.log(`  ✘ ${label} failed - ${r.error} (cached value kept)`);
    }
  }

  const okCount = Object.values(results).filter((r) => r.ok).length;
  const entry = { ranAt: new Date(now).toISOString(), dryRun: DRY, ok: okCount, failed: Object.keys(results).length - okCount, results };

  if (!DRY) {
    if (okCount) {
      ref.liveSignalsUpdated = entry.ranAt;
      fs.writeFileSync(REF_FILE, JSON.stringify(ref, null, 1) + '\n');
      console.log(`\n  Updated ${path.relative(process.cwd(), REF_FILE)} (${okCount} signal${okCount === 1 ? '' : 's'})`);
    } else {
      console.log('\n  No signal succeeded - reference file left unchanged.');
    }
    fs.appendFileSync(HISTORY, JSON.stringify(entry) + '\n');
    console.log(`  Audit line appended to ${path.relative(process.cwd(), HISTORY)}`);
  }

  console.log('\n  Annual figures are maintained by hand. Check these for new releases:');
  for (const s of ref.sources.filter((x) => x.latest !== 'live')) {
    console.log(`   • ${s.name.padEnd(52)} latest in file: ${s.latest}  ${s.url}`);
  }
  console.log(`  Reference data last reviewed: ${ref.lastUpdated}\n`);

  if (STRICT && okCount < Object.keys(results).length) process.exitCode = 1;
}

main().catch((e) => { console.error('observatory:update crashed:', e); process.exitCode = 2; });
