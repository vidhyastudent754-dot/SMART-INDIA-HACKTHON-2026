#!/usr/bin/env node
/* =============================================================================
 * scripts/validate-attacks.js - SENTINEL-X scope gate.
 *
 * Fails (exit 1) unless the project's attack scope is EXACTLY the approved 15:
 *   expected attack count = 15
 *   actual attack count   = 15
 *   duplicate IDs         = 0
 *   unapproved IDs        = 0   (in the operational attack files)
 *   section split         = 5 / 5 / 5
 *
 * It also confirms every approved id is wired end-to-end: a backend route
 * (assessment-api.js), a live-io registration, and a section-file card.
 *
 * Wire into CI / prestart:  node scripts/validate-attacks.js
 * ===========================================================================*/
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const REGISTRY = require(path.join(ROOT, 'public', 'assessments', 'registry.js'));

const read = (p) => { try { return fs.readFileSync(path.join(ROOT, p), 'utf8'); } catch (e) { return ''; } };
const idsIn = (s) => (s.match(/\b(?:IND|EMP|ORG)-\d+\b/g) || []);

let failures = [];
function check(cond, msg) { if (!cond) failures.push(msg); }

/* 1 ── registry self-validation ─────────────────────────────────────────── */
const v = REGISTRY.validate();
check(v.actualCount === 15, `actual attack count = ${v.actualCount} (expected 15)`);
check(v.expectedCount === 15, `expected attack count = ${v.expectedCount} (expected 15)`);
check(v.duplicateCount === 0, `duplicate IDs = ${v.duplicateCount} [${v.duplicates.join(',')}]`);
check(v.sectionCounts[1] === 5, `section 1 count = ${v.sectionCounts[1]} (expected 5)`);
check(v.sectionCounts[2] === 5, `section 2 count = ${v.sectionCounts[2]} (expected 5)`);
check(v.sectionCounts[3] === 5, `section 3 count = ${v.sectionCounts[3]} (expected 5)`);

const APPROVED = new Set(REGISTRY.ids());

/* 2 ── operational files must contain ONLY approved IDs ─────────────────── */
const OPERATIONAL = [
  'assessment-api.js',
  'public/assessments/individual.js',
  'public/assessments/employee-manager.js',
  'public/assessments/company-org.js',
  'public/assessments/live-io.js',
];
for (const f of OPERATIONAL) {
  const found = new Set(idsIn(read(f)));
  for (const id of found) {
    check(APPROVED.has(id), `unapproved attack ID "${id}" present in ${f}`);
  }
}

/* 3 ── every approved ID wired end-to-end ──────────────────────────────── */
const api = read('assessment-api.js');
const liveio = read('public/assessments/live-io.js');
const sectionFiles = {
  1: read('public/assessments/individual.js'),
  2: read('public/assessments/employee-manager.js'),
  3: read('public/assessments/company-org.js'),
};
for (const a of REGISTRY.ATTACKS) {
  const route = a.path.replace(/\/:.*$/, ''); // strip :param
  check(api.includes("'" + route) || api.includes('"' + route) || api.includes(route.replace(/^\//, '')),
    `${a.id}: backend route ${a.path} not found in assessment-api.js`);
  check(liveio.includes("reg('" + a.id + "'"), `${a.id}: no live-io registration`);
  check(sectionFiles[a.section].includes("id: '" + a.id + "'"), `${a.id}: no card in section ${a.section} file`);
}

/* 4 ── report ──────────────────────────────────────────────────────────── */
const line = '─'.repeat(64);
console.log(line);
console.log('  SENTINEL-X ATTACK-SCOPE VALIDATION');
console.log(line);
console.log(`  expected attack count = 15`);
console.log(`  actual attack count   = ${v.actualCount}`);
console.log(`  duplicate IDs         = ${v.duplicateCount}`);
console.log(`  section split         = ${v.sectionCounts[1]}/${v.sectionCounts[2]}/${v.sectionCounts[3]}`);
console.log(`  defensive capability  = SMS Fraud Detection (not counted)`);
console.log(`  approved IDs          = ${REGISTRY.ids().join(', ')}`);
console.log(line);
if (failures.length) {
  console.log('  RESULT: FAILED ❌');
  failures.forEach((f) => console.log('   • ' + f));
  console.log(line);
  process.exit(1);
}
console.log('  RESULT: PASS ✅  (exactly 15 approved attacks, 0 unapproved, all wired)');
console.log(line);
process.exit(0);
