#!/usr/bin/env node
/**
 * scripts/check-secrets.js - blocks secrets from being committed/shipped.
 *   node scripts/check-secrets.js           scan all tracked files (CI)
 *   node scripts/check-secrets.js --staged  scan staged files (pre-commit hook)
 * Fails if a .env file is tracked/staged, or if any file contains something
 * shaped like a live credential.
 */
'use strict';
const { execSync } = require('child_process');
const fs = require('fs');

const staged = process.argv.includes('--staged');
let files;
try {
  files = execSync(staged ? 'git diff --cached --name-only --diff-filter=ACM' : 'git ls-files', { encoding: 'utf8' })
    .split('\n').filter(Boolean);
} catch {
  console.log('check-secrets: not a git repository - skipped.');
  process.exit(0);
}

const PATTERNS = [
  [/AIza[0-9A-Za-z_\-]{35}/, 'Google API key'],
  [/AKIA[0-9A-Z]{16}/, 'AWS access key id'],
  [/-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----/, 'private key'],
  [/sk_live_[0-9A-Za-z]{16,}/, 'Stripe live key'],
  [/gh[pousr]_[0-9A-Za-z]{36}/, 'GitHub token'],
  // built from pieces so this file's own source doesn't match the pattern
  [new RegExp('GOOGLE_SAFE_BROWSING' + '_KEY=(?!your_|$)[^\\s#]{10,}'), 'Safe Browsing key assignment'],
];
// Deliberate, fake demo strings used by the assessment console's ORG-05 check.
const ALLOW = [/AIzaSyDEMO-hardcoded-key/, /sk_demo_do_not_use/, /sk_live_FAKE/];

const problems = [];
for (const f of files) {
  if (/(^|\/)\.env(\..+)?$/.test(f) && !f.endsWith('.env.example')) problems.push(`${f}: .env files must never be committed`);
  if (!fs.existsSync(f) || fs.statSync(f).size > 2_000_000 || /\.(db|png|jpg|zip)$/.test(f)) continue;
  const text = fs.readFileSync(f, 'utf8');
  for (const [re, label] of PATTERNS) {
    const m = text.match(re);
    if (m && !ALLOW.some((a) => a.test(text.slice(Math.max(0, m.index - 5), m.index + 60)))) {
      problems.push(`${f}: looks like a ${label}`);
    }
  }
}
if (problems.length) {
  console.error('✘ Secret check failed:\n  ' + problems.join('\n  '));
  console.error('Remove the secret, rotate it with the provider, and keep it in .env (git-ignored).');
  process.exit(1);
}
console.log(`✔ Secret check passed (${files.length} ${staged ? 'staged' : 'tracked'} files).`);
