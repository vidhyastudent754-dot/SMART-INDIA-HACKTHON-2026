#!/usr/bin/env node
/* scripts/world-validate.js - World Monitor integrity gate. Verifies the data
 * model + registry are sound and that the honesty invariants hold. Exit 1 on
 * failure. Does NOT require network.
 * ===========================================================================*/
'use strict';
const { openDb } = require('../lib/db');
const REGISTRY = require('../public/assessments/registry.js');

const db = openDb();
const fails = [];
const ok = (cond, msg) => { if (!cond) fails.push(msg); };
const one = (sql, ...a) => db.prepare(sql).get(...a);

// Ensure reference data is seeded (idempotent seed if empty).
if (one('SELECT COUNT(*) n FROM wm_sources').n === 0) {
  try { require('../db/world-seed').seedWorld(db); } catch (e) { fails.push('seed failed: ' + e.message); }
}

const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'wm_%'").all().map((r) => r.name);
const REQUIRED = ['wm_sources', 'wm_source_runs', 'wm_source_receipts', 'wm_countries', 'wm_india_states',
  'wm_attack_taxonomy', 'wm_incidents', 'wm_incident_sources', 'wm_incident_country', 'wm_incident_state',
  'wm_financial_impacts', 'wm_case_lifecycle', 'wm_threat_actors', 'wm_campaigns', 'wm_vulnerabilities',
  'wm_incident_vulnerabilities', 'wm_research_datasets', 'wm_research_records', 'wm_social_sources',
  'wm_social_posts', 'wm_awareness_events', 'wm_metrics', 'wm_metric_provenance', 'wm_comparison_snapshots',
  'wm_alerts', 'wm_audit_log'];
for (const t of REQUIRED) ok(tables.includes(t), `missing table ${t}`);

const intl = one("SELECT COUNT(*) n FROM wm_sources WHERE scope != 'IN'").n;
const india = one("SELECT COUNT(*) n FROM wm_sources WHERE scope = 'IN'").n;
ok(intl >= 10, `international sources = ${intl} (need >= 10)`);
ok(india >= 10, `india sources = ${india} (need >= 10)`);
ok(one("SELECT COUNT(*) n FROM wm_sources WHERE url IS NULL OR url = ''").n === 0, 'some sources have no URL');
ok(one("SELECT COUNT(*) n FROM wm_sources WHERE url NOT LIKE 'http%'").n === 0, 'some source URLs are not real http(s) URLs');

const states = one('SELECT COUNT(*) n FROM wm_india_states').n;
ok(states >= 36, `india states = ${states} (need >= 36 states/UTs)`);
ok(one('SELECT COUNT(*) n FROM wm_countries').n >= 30, 'fewer than 30 countries seeded');

const approved = one('SELECT COUNT(*) n FROM wm_attack_taxonomy WHERE approved = 1').n;
ok(approved === 15, `approved taxonomy entries = ${approved} (need exactly 15)`);
for (const id of REGISTRY.ids()) ok(!!one('SELECT 1 x FROM wm_attack_taxonomy WHERE id = ?', id), `taxonomy missing approved attack ${id}`);
ok(one('SELECT COUNT(*) n FROM wm_attack_taxonomy WHERE future = 1').n >= 20, 'future taxonomy families not seeded');

// Honesty invariants: every metric with a value must have a source URL; no fabricated zero rows.
const metricsNoProv = one(`SELECT COUNT(*) n FROM wm_metrics m LEFT JOIN wm_metric_provenance p USING(metric_id)
  WHERE m.value IS NOT NULL AND (p.source_url IS NULL OR p.source_url = '')`).n;
ok(metricsNoProv === 0, `${metricsNoProv} metric(s) have a value but no source URL (provenance required)`);

const line = '─'.repeat(64);
console.log(line);
console.log('  WORLD MONITOR - DATA-MODEL & REGISTRY VALIDATION');
console.log(line);
console.log(`  wm_ tables            = ${tables.length}/${REQUIRED.length} required present`);
console.log(`  international sources = ${intl} (>=10)`);
console.log(`  india sources        = ${india} (>=10)`);
console.log(`  india states/UTs     = ${states}`);
console.log(`  countries            = ${one('SELECT COUNT(*) n FROM wm_countries').n}`);
console.log(`  approved attacks     = ${approved}/15   future families = ${one('SELECT COUNT(*) n FROM wm_attack_taxonomy WHERE future=1').n}`);
console.log(`  metrics w/ provenance= ${one('SELECT COUNT(*) n FROM wm_metrics').n} (all sourced)`);
console.log(line);
if (fails.length) { console.log('  RESULT: FAILED ❌'); fails.forEach((f) => console.log('   • ' + f)); console.log(line); process.exit(1); }
console.log('  RESULT: PASS ✅');
console.log(line);
db.close();
