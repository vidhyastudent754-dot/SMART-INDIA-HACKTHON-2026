#!/usr/bin/env node
/* world-export.js - export provenance-preserving data as JSON (default) or CSV.
 *   node scripts/world-export.js [json|csv] > out.(json|csv)
 * CSV covers the metric table with full provenance columns. */
'use strict';
const { openDb } = require('../lib/db');
const db = openDb();
const fmt = (process.argv[2] || 'json').toLowerCase();
const rows = db.prepare(`SELECT m.metric_id,m.name,m.value,m.original_value,m.unit,m.period,m.country,m.state_code,
  m.attack_category,m.evidence_type,m.confidence,p.source_id,p.source_url,p.source_pub_date,p.retrieved_at,
  p.calculation,p.transformation,p.notes
  FROM wm_metrics m LEFT JOIN wm_metric_provenance p USING(metric_id) ORDER BY m.metric_id`).all();
if (fmt === 'csv') {
  const cols = Object.keys(rows[0] || { metric_id:'' });
  const esc = v => v==null ? '' : /[",\n]/.test(String(v)) ? '"'+String(v).replace(/"/g,'""')+'"' : String(v);
  console.log(cols.join(','));
  rows.forEach(r => console.log(cols.map(c => esc(r[c])).join(',')));
} else {
  console.log(JSON.stringify({ exportedAt: new Date().toISOString(), count: rows.length,
    note: 'Provenance-preserving export. Every value carries its source_url.', metrics: rows }, null, 2));
}
db.close();
