#!/usr/bin/env node
/**
 * scripts/import-mha-q452.js - verified import of MHA Lok Sabha USQ 452
 * (02.12.2025), Annexures I-III (NCRB 'Crime in India' 2019-2023).
 *
 * Source type: manual verified entry of an official document (spec §F.2).
 * Verification gates (the import FAILS, writing nothing, if any gate fails):
 *   1. every state/UT row sums to the document's own TOTAL STATE(S) /
 *      TOTAL UT(S) rows, and those sum to TOTAL (ALL INDIA), for every column;
 *   2. every crime-head row sums to its sub-total (A/B/C) and the grand total;
 *   3. the Annex II all-India totals equal the Annex I grand totals;
 *   4. the Annex III fraud registered-cases totals equal the Annex I 'Fraud' row.
 * A dash in the source is stored as null (not published / not applicable),
 * never as 0.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// optional overrides (used by the test suite to prove a tampered extract is rejected)
const SRC = process.argv[2] || path.join(__dirname, '..', 'db', 'fabric', 'sources', 'mha-lsusq-452-2025-12-02.annexures.txt');
const OUT = process.argv[3] || path.join(__dirname, '..', 'db', 'fabric', 'india-ncrb-cybercrime-2019-2023.json');
const YEARS = [2019, 2020, 2021, 2022, 2023];

// ISO 3166-2:IN subdivision codes (Nov 2023 revision), used as stable geography keys.
const ISO = {
  'Andhra Pradesh': 'IN-AP', 'Arunachal Pradesh': 'IN-AR', Assam: 'IN-AS', Bihar: 'IN-BR', Chhattisgarh: 'IN-CG',
  Goa: 'IN-GA', Gujarat: 'IN-GJ', Haryana: 'IN-HR', 'Himachal Pradesh': 'IN-HP', Jharkhand: 'IN-JH', Karnataka: 'IN-KA',
  Kerala: 'IN-KL', 'Madhya Pradesh': 'IN-MP', Maharashtra: 'IN-MH', Manipur: 'IN-MN', Meghalaya: 'IN-ML', Mizoram: 'IN-MZ',
  Nagaland: 'IN-NL', Odisha: 'IN-OD', Punjab: 'IN-PB', Rajasthan: 'IN-RJ', Sikkim: 'IN-SK', 'Tamil Nadu': 'IN-TN',
  Telangana: 'IN-TG', Tripura: 'IN-TR', 'Uttar Pradesh': 'IN-UP', Uttarakhand: 'IN-UK', 'West Bengal': 'IN-WB',
  'A&N Islands': 'IN-AN', Chandigarh: 'IN-CH', 'D&N Haveli and Daman & Diu': 'IN-DH', Delhi: 'IN-DL',
  'Jammu & Kashmir': 'IN-JK', Ladakh: 'IN-LA', Lakshadweep: 'IN-LD', Puducherry: 'IN-PY',
};
const UTS = new Set(['A&N Islands', 'Chandigarh', 'D&N Haveli and Daman & Diu', 'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Lakshadweep', 'Puducherry']);

function blocks(text) {
  const out = {};
  const re = /@@([A-Z0-9-]+)\n([\s\S]*?)(?=@@)/g;
  let m;
  while ((m = re.exec(text))) out[m[1]] = m[2];
  return out;
}
const num = (t) => (t === '-' ? null : Number(t));
const isVal = (t) => t === '-' || /^\d+(\.\d+)?$/.test(t);

/** Split a block into rows: a row starts at "TOTAL" or at "<n> <Word…>". */
function rows(block) {
  const toks = block.split(/\s+/).filter(Boolean);
  const out = [];
  let cur = null;
  let expected = 1;   // serial numbers run 1,2,3… (98/99 are this importer's markers for unnumbered total rows)
  for (let i = 0; i < toks.length; i++) {
    const t = toks[i];
    const serial = /^\d{1,2}$/.test(t) && (Number(t) === expected || t === '98' || t === '99') &&
      toks[i + 1] && /^[A-Za-z&(]/.test(toks[i + 1]) && toks[i + 1] !== 'TOTAL';
    const startsRow = t === 'TOTAL' || serial;
    if (startsRow) {
      if (serial && t !== '98' && t !== '99') expected = Number(t) + 1;
      cur = { sl: t === 'TOTAL' ? null : Number(t), name: [], vals: [] }; out.push(cur);
      if (t === 'TOTAL') cur.name.push(t);
      continue;
    }
    if (!cur) continue;
    if (isVal(t) && (cur.name.length || cur.vals.length)) cur.vals.push(num(t));
    else if (!cur.vals.length) cur.name.push(t);
  }
  return out.map((r) => ({ ...r, name: r.name.join(' ') }));
}

function fail(msg) { console.error('✘ verification failed: ' + msg); process.exit(1); }
const sum = (arr) => arr.reduce((s, v) => s + (v || 0), 0);

function main() {
  const text = fs.readFileSync(SRC, 'utf8');
  const hash = crypto.createHash('sha256').update(text).digest('hex');
  const b = blocks(text);
  const checks = [];

  /* Annex II - cases registered by State/UT */
  const a2 = rows(b['ANNEX-II']);
  const states = [], uts = [];
  let tS, tU, tAll;
  for (const r of a2) {
    if (r.name === 'TOTAL STATE(S)') tS = r.vals; else if (r.name === 'TOTAL UT(S)') tU = r.vals;
    else if (r.name === 'TOTAL (ALL INDIA)') tAll = r.vals;
    else {
      if (!ISO[r.name]) fail(`unknown State/UT "${r.name}"`);
      let vals = r.vals;
      if (vals.length === 4 && r.name === 'Ladakh') vals = [null, ...vals];   // UT created 31.10.2019: no 2019 figure published
      if (vals.length !== 5) fail(`Annex II ${r.name}: expected 5 values, got ${vals.length}`);
      (UTS.has(r.name) ? uts : states).push({ name: r.name, iso: ISO[r.name], vals });
    }
  }
  if (states.length !== 28 || uts.length !== 8) fail(`expected 28 states + 8 UTs, got ${states.length} + ${uts.length}`);
  YEARS.forEach((y, i) => {
    const s = sum(states.map((x) => x.vals[i])), u = sum(uts.map((x) => x.vals[i]));
    if (s !== tS[i]) fail(`Annex II ${y}: states sum ${s} ≠ TOTAL STATE(S) ${tS[i]}`);
    if (u !== tU[i]) fail(`Annex II ${y}: UTs sum ${u} ≠ TOTAL UT(S) ${tU[i]}`);
    if (s + u !== tAll[i]) fail(`Annex II ${y}: ${s}+${u} ≠ ALL INDIA ${tAll[i]}`);
  });
  checks.push('Annex II: 28 states + 8 UTs reconcile to TOTAL STATE(S), TOTAL UT(S) and TOTAL (ALL INDIA) for all 5 years');

  /* Annex I - crime heads */
  // sub-total rows are lettered (A/B/C) and the grand total is unnumbered: give them row markers
  const a1 = rows(b['ANNEX-I'].replace(/^([ABC]) /gm, '99 $1-').replace(/^Total Cyber Crimes/m, '98 Total Cyber Crimes'));
  const heads = [], sub = {};
  let grand;
  for (const r of a1) {
    if (r.vals.length !== 5) fail(`Annex I "${r.name}": expected 5 values, got ${r.vals.length}`);
    if (/^[ABC]-Total/.test(r.name)) sub[r.name[0]] = r.vals;
    else if (/^Total Cyber Crimes/.test(r.name)) grand = r.vals;
    else heads.push({ sl: r.sl, name: r.name.replace(/\s+/g, ' '), vals: r.vals });
  }
  // grand-total row has no serial number; it attaches to the preceding row in tokenisation - recover it
  if (!grand) {
    const last = heads[heads.length - 1];
    fail('Annex I grand total not found (last row: ' + (last && last.name) + ')');
  }
  const group = (h) => (h.sl <= 9 ? 'A' : h.sl <= 21 ? 'B' : 'C');
  YEARS.forEach((y, i) => {
    for (const g of ['A', 'B', 'C']) {
      const s = sum(heads.filter((h) => group(h) === g).map((h) => h.vals[i]));
      if (s !== sub[g][i]) fail(`Annex I ${y} group ${g}: ${s} ≠ ${sub[g][i]}`);
    }
    if (sub.A[i] + sub.B[i] + sub.C[i] !== grand[i]) fail(`Annex I ${y}: A+B+C ≠ total`);
    if (grand[i] !== tAll[i]) fail(`Annex I total ${grand[i]} ≠ Annex II all-India ${tAll[i]} (${y})`);
  });
  if (heads.length !== 26) fail(`expected 26 crime heads, got ${heads.length}`);
  checks.push('Annex I: 26 crime heads reconcile to IT-Act / IPC / SLL sub-totals and to the all-India total; equals Annex II');

  /* Annex III - fraud lifecycle */
  const F = ['registered', 'chargesheeted', 'trialsCompleted', 'convicted', 'convictionRatePct', 'personsArrested'];
  const life = {};           // name -> {year -> {...}}
  const lifeTotals = {};
  function eat(block, years) {
    for (const r of rows(block)) {
      let vals = r.vals;
      const need = years.length * 6;
      if (vals.length === need - 5 && vals[0] === null) vals = [null, null, null, null, null, null, ...vals.slice(1)]; // year not published (Ladakh 2019)
      if (vals.length !== need) fail(`Annex III "${r.name}": expected ${need} values, got ${vals.length}`);
      const target = r.name.startsWith('TOTAL') ? (lifeTotals[r.name] = lifeTotals[r.name] || {}) : (life[r.name] = life[r.name] || {});
      years.forEach((y, k) => {
        const o = {};
        F.forEach((f, j) => { o[f] = vals[k * 6 + j]; });
        target[y] = o;
      });
    }
  }
  eat(b['ANNEX-III-P1'], [2019, 2020, 2021]);
  eat(b['ANNEX-III-P2'], [2022, 2023]);
  if (Object.keys(life).length !== 36) fail(`Annex III: expected 36 States/UTs, got ${Object.keys(life).length}`);
  for (const y of YEARS) {
    for (const f of ['registered', 'chargesheeted', 'trialsCompleted', 'convicted', 'personsArrested']) {
      const s = sum(Object.keys(life).filter((n) => !UTS.has(n)).map((n) => life[n][y][f]));
      const u = sum(Object.keys(life).filter((n) => UTS.has(n)).map((n) => life[n][y][f]));
      const T = (k) => lifeTotals[k][y][f];
      if (s !== T('TOTAL STATE(S)')) fail(`Annex III ${y} ${f}: states ${s} ≠ ${T('TOTAL STATE(S)')}`);
      if (u !== T('TOTAL UT(S)')) fail(`Annex III ${y} ${f}: UTs ${u} ≠ ${T('TOTAL UT(S)')}`);
      if (s + u !== T('TOTAL (ALL INDIA)')) fail(`Annex III ${y} ${f}: ${s}+${u} ≠ all-India`);
    }
    const fraudHead = heads.find((h) => h.name === 'Fraud').vals[YEARS.indexOf(y)];
    if (lifeTotals['TOTAL (ALL INDIA)'][y].registered !== fraudHead) fail(`Annex III ${y}: registered ≠ Annex I Fraud ${fraudHead}`);
  }
  checks.push('Annex III: every lifecycle column reconciles to state, UT and all-India totals for all 5 years; registered = Annex I "Fraud" head');

  const doc = {
    id: 'mha-lsusq-452-2025-12-02',
    title: 'Lok Sabha Unstarred Question No. 452 - Online fraud and cybercrime (Annexures I-III)',
    publisher: 'Ministry of Home Affairs, Government of India',
    underlyingSource: "National Crime Records Bureau, 'Crime in India' (2019-2023)",
    url: 'https://www.mha.gov.in/MHA1/Par2017/pdfs/par2025-pdfs/LS02122025/452.pdf',
    documentDate: '2025-12-02',
    reportingPeriod: '2019-2023 (calendar years)',
    retrievedAt: '2026-09-25',
    sourceType: 'manual_verified_entry',
    sourceClass: 'official_periodic_dataset',
    extractSha256: hash,
    verification: checks,
    definitions: {
      registered: 'Cases registered by police (NCRB crime head / State-UT). These are police-registered cases, NOT NCRP complaints.',
      lifecycle: 'Annex III covers ONLY the "Fraud" crime head of cyber crimes. Charge-sheeted, trials completed and convicted counts in a year can include cases registered in earlier years.',
      convictionRatePct: 'NCRB conviction rate = convicted ÷ trials completed × 100. Published as "-" (stored null) when no trials were completed.',
      nulls: '"-" in the source is stored as null: not published (e.g. Ladakh 2019, before the UT existed) or not applicable. Never converted to 0.',
      notPublished: ['pending cases', 'acquittals by State/UT', 'district, city or PIN-code breakdowns', 'financial loss by State/UT', 'victim counts'],
    },
    caution: 'NCRB advises that State/UT figures reflect registration practices and should not be compared without methodological context; they are not crime-rate rankings.',
  };
  const out = {
    document: doc,
    years: YEARS,
    crimeHeads: heads.map((h) => ({ sl: h.sl, name: h.name, group: { A: 'IT Act', B: 'IPC', C: 'Special & Local Laws' }[group(h)], values: Object.fromEntries(YEARS.map((y, i) => [y, h.vals[i]])) })),
    totals: Object.fromEntries(YEARS.map((y, i) => [y, { itAct: sub.A[i], ipc: sub.B[i], sll: sub.C[i], all: grand[i], states: tS[i], uts: tU[i] }])),
    geographies: [...states, ...uts].map((g) => ({
      name: g.name, iso: g.iso, type: UTS.has(g.name) ? 'union_territory' : 'state',
      casesRegistered: Object.fromEntries(YEARS.map((y, i) => [y, g.vals[i]])),
      fraudLifecycle: life[g.name],
    })),
    fraudLifecycleTotals: lifeTotals,
  };
  fs.writeFileSync(OUT, JSON.stringify(out, null, 1) + '\n');
  console.log(checks.map((c) => '✔ ' + c).join('\n'));
  console.log(`✔ wrote ${path.relative(process.cwd(), OUT)} (extract sha256 ${hash.slice(0, 16)}…)`);
}
main();
