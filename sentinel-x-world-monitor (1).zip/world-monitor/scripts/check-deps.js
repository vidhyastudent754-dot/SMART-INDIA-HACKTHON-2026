#!/usr/bin/env node
/**
 * scripts/check-deps.js - runs automatically before `npm start`, `npm run dev`,
 * `npm run db:init` and `npm run db:reset` (npm "pre" scripts). Turns a bare
 * "Cannot find module" stack trace into one clear instruction.
 */
'use strict';
const pkg = require('../package.json');

const missing = [];
for (const dep of Object.keys(pkg.dependencies || {})) {
  try { require.resolve(dep); } catch { missing.push(dep); }
}
let nativeProblem = null;
if (!missing.includes('better-sqlite3')) {
  try { new (require('better-sqlite3'))(':memory:').close(); }
  catch (e) { nativeProblem = e.message.split('\n')[0]; }
}

const major = Number(process.versions.node.split('.')[0]);
if (major < 22) {
  console.error(`\n  ✘ Node.js ${process.versions.node} is too old - World Monitor needs Node 22 or newer.\n`);
  process.exit(1);
}
if (missing.length || nativeProblem) {
  console.error('\n  ✘ Dependencies are not installed correctly.');
  if (missing.length) console.error(`    Missing: ${missing.join(', ')}`);
  if (nativeProblem) console.error(`    The SQLite driver did not load: ${nativeProblem}`);
  console.error('\n    Fix:  npm install');
  console.error('    (Windows: if it reports EPERM, close VS Code/other terminals using this folder,');
  console.error('     delete node_modules, and run npm install again.)\n');
  process.exit(1);
}
