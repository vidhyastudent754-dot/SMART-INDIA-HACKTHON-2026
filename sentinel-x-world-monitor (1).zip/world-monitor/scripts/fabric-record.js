#!/usr/bin/env node
/**
 * scripts/fabric-record.js - record REAL responses from the enabled fabric
 * sources for Replay / Demonstration mode. Run it a few times (e.g. morning
 * and evening before a demo) so the replay shows genuine changes between
 * snapshots. Recordings are stored verbatim with their sha256.
 *   npm run fabric:record
 */
'use strict';
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { SOURCES, assertFetchAllowed } = require('../lib/fabric/registry');

const DIR = path.join(__dirname, '..', 'db', 'fabric', 'fixtures', 'recorded');
const ADAPTERS = { 'cisa-kev': require('../lib/fabric/adapters/cisa-kev'), 'nvd-cve': require('../lib/fabric/adapters/nvd-cve'), 'certin-vulnotes': require('../lib/fabric/adapters/certin-vulnotes') };

(async () => {
  fs.mkdirSync(DIR, { recursive: true });
  const mf = path.join(DIR, 'manifest.json');
  const manifest = fs.existsSync(mf) ? JSON.parse(fs.readFileSync(mf, 'utf8')) : { label: 'Recorded real responses (npm run fabric:record) - for REPLAY / DEMONSTRATION only', recordings: [] };
  const now = Date.now();
  for (const s of SOURCES.filter((x) => ADAPTERS[x.id])) {
    const req = ADAPTERS[s.id].request({ now, page: 0 });
    try {
      assertFetchAllowed(s, req.url);
      const r = await fetch(req.url, { headers: { 'User-Agent': 'WorldMonitor-Fabric/1.0 (+SIH26163)', ...(req.headers || {}) }, signal: AbortSignal.timeout(30000) });
      const text = await r.text();
      if (!r.ok) throw new Error(`HTTP ${r.status}`);
      ADAPTERS[s.id].parse(text, { request: req });   // only keep responses that pass schema validation
      const file = `${s.id}-${new Date(now).toISOString().replace(/[:.]/g, '-')}.txt`;
      fs.writeFileSync(path.join(DIR, file), text);
      manifest.recordings.push({ sourceId: s.id, host: new URL(req.url).hostname, file, recordedAt: new Date().toISOString(), url: req.url,
        sha256: crypto.createHash('sha256').update(text).digest('hex'), bytes: Buffer.byteLength(text), provenance: 'Recorded real response' });
      console.log(`  ✔ ${s.id.padEnd(16)} ${(Buffer.byteLength(text) / 1024).toFixed(0).padStart(6)} KB  ${file}`);
    } catch (e) { console.log(`  ✘ ${s.id.padEnd(16)} ${e.message}`); }
  }
  fs.writeFileSync(mf, JSON.stringify(manifest, null, 1) + '\n');
  console.log(`\n  ${manifest.recordings.length} recording(s) in ${path.relative(process.cwd(), mf)}. Start the demo with FABRIC_MODE=replay npm start\n`);
})();
