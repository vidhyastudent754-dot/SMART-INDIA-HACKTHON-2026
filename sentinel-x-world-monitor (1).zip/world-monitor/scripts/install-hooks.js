#!/usr/bin/env node
// Points git at .githooks/ so the pre-commit secret check runs. No-op outside a git repo (e.g. Docker builds).
'use strict';
const { execSync } = require('child_process');
try {
  execSync('git rev-parse --is-inside-work-tree', { stdio: 'ignore' });
  execSync('git config core.hooksPath .githooks');
  console.log('git hooks installed (.githooks/pre-commit)');
} catch { /* not a git checkout */ }
