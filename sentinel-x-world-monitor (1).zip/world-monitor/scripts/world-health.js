#!/usr/bin/env node
/* world-health.js - source-run health summary. */
'use strict';
const { openDb } = require('../lib/db');
const { createWorldMonitor } = require('../lib/world-monitor');
const db = openDb();
const wm = createWorldMonitor(db);
const h = wm.health();
const s = wm.sources();
console.log(JSON.stringify({ health: h, sourcesOnline: s.online + '/' + s.total,
  byStatus: s.sources.reduce((a,x)=>{a[x.freshness.status]=(a[x.freshness.status]||0)+1;return a;},{}) }, null, 2));
db.close();
