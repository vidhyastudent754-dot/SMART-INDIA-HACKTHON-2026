#!/usr/bin/env node
/* scripts/verify-ui.js - headless-browser check that the dashboard renders
 * exactly 5 attack cards per section plus the SMS defensive card, and that the
 * SMS demo calls the real detector. Boots its own server. */
'use strict';
const { spawn } = require('child_process');
const path = require('path');
const os = require('os');
const { chromium } = require('playwright');

const PORT = process.env.PORT || 5198;
const BASE = `http://localhost:${PORT}`;
const USER = 'admin', PASS = process.env.ADMIN_PASSWORD || 'Str0ngAdminPass123';

async function waitHealthy(ms) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try { const r = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' }); if (r.status) return true; } catch (e) {}
    await new Promise((r) => setTimeout(r, 300));
  }
  return false;
}

(async () => {
  // Seed a throwaway DB with a known admin password (independent of any .env).
  const tmpDb = path.join(os.tmpdir(), `wm-verifyui-${process.pid}.db`);
  try {
    const { openDb } = require(path.join(__dirname, '..', 'lib', 'db'));
    const { seed } = require(path.join(__dirname, '..', 'db', 'seed'));
    const db = openDb(tmpDb);
    seed(db, { resetPasswords: true, env: { ADMIN_PASSWORD: PASS, VIEWER_PASSWORD: 'Str0ngViewerPass1' } });
    try { require(path.join(__dirname, '..', 'db', 'world-seed')).seedWorld(db); } catch (e) {}
    db.close();
  } catch (e) { console.error('could not seed throwaway DB:', e.message); process.exit(2); }
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')],
    { cwd: path.join(__dirname, '..'), env: Object.assign({}, process.env, { PORT: String(PORT), DB_PATH: tmpDb,
      ADMIN_PASSWORD: PASS, VIEWER_PASSWORD: 'Str0ngViewerPass1', AUTH_DISABLED: 'false',
      OBSERVATORY_LIVE: 'off', FABRIC: 'off', FABRIC_POLL: 'off', FABRIC_ALERTS: 'off' }), stdio: 'ignore' });
  let ok = true;
  const browser = await (async () => { await waitHealthy(15000); return chromium.launch({ executablePath: '/opt/pw-browsers/chromium/chrome-linux/chrome', args: ['--no-sandbox'] }).catch(() => chromium.launch({ args: ['--no-sandbox'] })); })();
  try {
    const ctx = await browser.newContext();
    const page = await ctx.newPage();
    const errors = [];
    page.on('console', (m) => { if (m.type() === 'error') errors.push(m.text()); });
    page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));

    // login via API, set cookie, then load the SPA
    const lr = await ctx.request.post(BASE + '/api/auth/login', { data: { username: USER, password: PASS } });
    console.log('login status', lr.status());
    await page.goto(BASE + '/index.html', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('#sx-tabbar', { timeout: 15000 });
    await page.waitForTimeout(800);

    async function countCards(sectionSel) {
      return await page.evaluate((sel) => {
        const s = document.querySelector(sel);
        if (!s) return { cards: -1, sms: false };
        return { cards: s.querySelectorAll('.sxa-card').length, sms: !!s.querySelector('[data-role="sms-fraud"]') };
      }, sectionSel);
    }

    // activate each section tab so its mount() runs
    const tabs = { 'section-1': 5, 'section-2': 5, 'section-4': 5 };
    const results = {};
    for (const t of Object.keys(tabs)) {
      await page.evaluate((id) => { const b = document.querySelector('[data-sx-target="' + id + '"]'); if (b) b.click(); }, t);
      await page.waitForTimeout(600);
      results[t] = await countCards('#' + t);
    }
    console.log('section card counts:', JSON.stringify(results));

    // SMS demo: fill the fraud example and analyze, expect HIGH_RISK
    await page.evaluate(() => { const b = document.querySelector('[data-sx-target="section-1"]'); if (b) b.click(); });
    await page.waitForTimeout(400);
    const smsResult = await page.evaluate(async () => {
      const card = document.querySelector('[data-role="sms-fraud"]');
      if (!card) return { ok: false, why: 'no sms card' };
      card.querySelector('[data-role="msg"]').value = 'EXAMPLEBANK SECURITY: Your account will be blocked. Tell the OTP to our support executive to cancel the transaction.';
      card.querySelector('[data-role="sender"]').value = 'UNKNOWN-98321';
      card.querySelector('[data-role="company"]').value = 'Example Bank';
      card.querySelector('[data-role="go"]').click();
      await new Promise((r) => setTimeout(r, 1200));
      const cls = card.querySelector('.sxsms__cls');
      return { ok: true, classification: cls ? cls.textContent.trim() : '(none)' };
    });
    console.log('SMS demo result:', JSON.stringify(smsResult));

    const c1 = results['section-1'], c2 = results['section-2'], c3 = results['section-4'];
    if (!(c1.cards === 5 && c1.sms)) { ok = false; console.log('❌ section-1 expected 5 cards + SMS'); }
    if (!(c2.cards === 5)) { ok = false; console.log('❌ section-2 expected 5 cards'); }
    if (!(c3.cards === 5)) { ok = false; console.log('❌ section-3(org) expected 5 cards'); }
    if (!(smsResult.ok && /HIGH/.test(smsResult.classification))) { ok = false; console.log('❌ SMS demo did not return HIGH_RISK'); }

    // ---- Global & India Cyber Threat Observatory ----
    const nav = await page.evaluate(() => { const n = document.querySelector('#sx-tabbar'); return { obs: !!n.querySelector('a[href="/observatory.html"]'), oldFeed: /Live Threat Feed/.test(n.textContent) }; });
    if (!nav.obs || nav.oldFeed) { ok = false; console.log('❌ nav should link the observatory and not show Live Threat Feed', JSON.stringify(nav)); }
    await page.goto(BASE + '/observatory.html', { waitUntil: 'domcontentloaded' });
    await page.waitForSelector('#kIndia .kpi', { timeout: 15000 });
    await page.waitForSelector('#srcBox table', { timeout: 15000 });
    await page.waitForTimeout(800);
    const obs = await page.evaluate(() => ({
      indiaKpis: document.querySelectorAll('#kIndia .kpi').length,
      globalKpis: document.querySelectorAll('#kGlobal .kpi').length,
      firstIndia: (document.querySelector('#kIndia .kpi .v') || {}).textContent || '',
      attackTabs: document.querySelectorAll('#aTabs .tab').length,
      attackCards: document.querySelectorAll('#aCards .atk').length,
      compareRows: document.querySelectorAll('#cmp tr').length - 1,
      ageBars: document.querySelectorAll('#ageC .bar').length,
      sources: document.querySelectorAll('#srcBox tr').length - 1,
      sourceLinks: document.querySelectorAll('a.src').length,
      notPublished: document.querySelectorAll('.na').length,
    }));
    console.log('observatory:', JSON.stringify(obs));
    if (!(obs.indiaKpis === 6 && obs.globalKpis === 6)) { ok = false; console.log('❌ observatory KPIs'); }
    if (!/22,68,346|2,268,346/.test(obs.firstIndia)) { ok = false; console.log('❌ India NCRP KPI not rendered'); }
    if (!(obs.attackTabs === 4 && obs.attackCards === 8)) { ok = false; console.log('❌ attack categories'); }
    if (obs.compareRows !== 17) { ok = false; console.log('❌ compare rows'); }
    if (obs.ageBars !== 6) { ok = false; console.log('❌ age bars'); }
    if (obs.sources < 20 || obs.sourceLinks < 50) { ok = false; console.log('❌ sources/links'); }
    await page.waitForSelector('#tScam table', { timeout: 15000 });
    const imp = await page.evaluate(() => ({ scam: document.querySelectorAll('#tScam tr').length - 1, app: document.querySelectorAll('#tApp tr').length - 1 }));
    await page.fill('#cSearch', 'Afgh'); await page.press('#cSearch', 'Enter');
    await page.click('.presets button[data-p="asia"]'); await page.waitForTimeout(300);
    const ce = await page.evaluate(() => ({ ranked: document.querySelectorAll('#cRank .rk').length, rows: document.querySelectorAll('#cTable tr').length - 1, verdict: document.querySelector('#cVerdict').textContent, afg: /Afghanistan/.test(document.querySelector('#cTable').textContent) }));
    console.log('impact:', JSON.stringify(imp), 'countries:', JSON.stringify(ce));
    if (imp.scam !== 12 || imp.app !== 15) { ok = false; console.log('❌ attack impact tables'); }
    if (ce.ranked < 15 || !ce.afg || !/most pervasive/.test(ce.verdict)) { ok = false; console.log('❌ country explorer'); }
    if (errors.length) { console.log('⚠ console errors:', errors.slice(0, 8)); }

    console.log(ok ? '\n✅ UI VERIFIED: 5+5+5 attack cards + SMS card + Global & India Cyber Threat Observatory' : '\n❌ UI VERIFICATION FAILED');
  } catch (e) { console.error('UI test error:', e.message); ok = false; }
  finally { await browser.close().catch(() => {}); child.kill(); }
  process.exit(ok ? 0 : 1);
})();
