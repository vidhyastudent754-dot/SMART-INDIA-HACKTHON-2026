#!/usr/bin/env node
/* world-coverage.js - print the World Monitor data-coverage report (not a
 * country risk/safety score). */
'use strict';
const { openDb } = require('../lib/db');
const { createWorldMonitor } = require('../lib/world-monitor');
const db = openDb();
const wm = createWorldMonitor(db);
console.log(JSON.stringify(wm.coverage(), null, 2));
db.close();
