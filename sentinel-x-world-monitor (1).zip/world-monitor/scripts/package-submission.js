#!/usr/bin/env node
/**
 * scripts/package-submission.js - builds dist/world-monitor-submission.zip
 * containing source only: no .env, node_modules, database, training data,
 * scanner reports or editor config. Runs the secret check first.
 */
'use strict';
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const ROOT = path.join(__dirname, '..');
const EXCLUDE = [/^\.env$/, /^\.env\.(?!example$)/, /^node_modules\//, /^data\//, /^dist\//, /^ml\/data\//,
  /^scanner\/reports\//, /^\.vscode\//, /^\.git\//, /\.db(-wal|-shm)?$/, /\.log$/, /__pycache__/, /\.DS_Store$/];

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const abs = path.join(dir, e.name);
    const rel = path.relative(ROOT, abs).split(path.sep).join('/') + (e.isDirectory() ? '/' : '');
    if (EXCLUDE.some((re) => re.test(rel))) continue;
    if (e.isDirectory()) walk(abs, out); else out.push(rel);
  }
  return out;
}

// Secret scan over exactly what will ship.
const files = walk(ROOT);
const leaks = files.filter((f) => {
  const t = fs.readFileSync(path.join(ROOT, f), 'utf8');
  return /AIza[0-9A-Za-z_\-]{35}/.test(t.replace(/AIzaSyDEMO-hardcoded-key-1234567890/g, ''));
});
if (leaks.length) { console.error('Refusing to package - possible API key in: ' + leaks.join(', ')); process.exit(1); }

fs.mkdirSync(path.join(ROOT, 'dist'), { recursive: true });
const zip = path.join(ROOT, 'dist', 'world-monitor-submission.zip');
fs.rmSync(zip, { force: true });
const list = path.join(ROOT, 'dist', '.filelist');
fs.writeFileSync(list, files.map((f) => `world-monitor/${f}`).join('\n'));
// zip from a temp symlink so paths inside the archive start with world-monitor/
const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'wm-'));
try {
  fs.symlinkSync(ROOT, path.join(tmp, 'world-monitor'), 'junction');
  execSync(`cd "${tmp}" && zip -q -X "${zip}" -@ < "${list}"`, { stdio: ['ignore', 'ignore', 'pipe'] });
} catch (e) {
  console.error('Could not build the zip here (this script needs the `zip` command - available on');
  console.error('Linux/macOS and in Git Bash / WSL on Windows). The file list is in dist/.filelist.');
  console.error(String(e.message || e).split('\n')[0]);
  process.exit(1);
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
fs.rmSync(list);
console.log(`✔ ${path.relative(ROOT, zip)}  (${files.length} files, ${(fs.statSync(zip).size / 1024).toFixed(0)} KB)`);
