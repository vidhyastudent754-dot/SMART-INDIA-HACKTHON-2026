/* heuristics.js - URL checker used by the Phishing Analyzer.
 *
 * Works offline from the URL alone. It knows the real domains of the brands
 * scammers copy most (Indian banks, payment apps, big tech, couriers,
 * government), so it can say "this is the official site" for a real link and
 * "this imitates HDFC" for a fake one, instead of only counting hyphens. */
'use strict';

const SHORTENERS = new Set([
  'bit.ly', 'tinyurl.com', 't.co', 'goo.gl', 'ow.ly', 'is.gd', 'buff.ly',
  'rebrand.ly', 'cutt.ly', 'shorte.st', 'adf.ly', 'bl.ink', 'lnkd.in',
  's.id', 'rb.gy', 'tiny.cc', 'shorturl.at', 'v.gd', 'tinyurl.co', 'short.io', 'shrtco.de', 'surl.li', 'u.to', 'qr.ae'
]);

/* brand → its official registrable domains */
const OFFICIAL = {
  google: ['google.com', 'google.co.in', 'gmail.com', 'youtube.com', 'googleusercontent.com', 'gstatic.com', 'g.co', 'withgoogle.com'],
  gpay: ['pay.google.com', 'google.com'],
  microsoft: ['microsoft.com', 'live.com', 'outlook.com', 'office.com', 'office365.com', 'microsoftonline.com', 'bing.com', 'azure.com', 'sharepoint.com', 'xbox.com', 'windows.com', 'skype.com'],
  office365: ['office.com', 'office365.com', 'microsoftonline.com', 'microsoft.com'],
  outlook: ['outlook.com', 'live.com', 'office.com', 'microsoft.com'],
  apple: ['apple.com', 'icloud.com', 'apple.co'],
  appleid: ['apple.com'],
  icloud: ['icloud.com', 'apple.com'],
  amazon: ['amazon.com', 'amazon.in', 'amazon.co.uk', 'amazon.de', 'amazonaws.com', 'amazon.jobs', 'primevideo.com', 'amzn.to', 'a.co'],
  paypal: ['paypal.com', 'paypal.me'],
  netflix: ['netflix.com'],
  facebook: ['facebook.com', 'fb.com', 'meta.com', 'messenger.com', 'fb.me'],
  instagram: ['instagram.com'],
  whatsapp: ['whatsapp.com', 'whatsapp.net', 'wa.me'],
  linkedin: ['linkedin.com', 'lnkd.in'],
  github: ['github.com', 'github.io', 'githubusercontent.com'],
  flipkart: ['flipkart.com'],
  myntra: ['myntra.com'],
  sbi: ['sbi.co.in', 'onlinesbi.sbi', 'onlinesbi.com', 'sbicard.com', 'sbi', 'yonobusiness.sbi', 'bank.sbi'],
  yono: ['sbi.co.in', 'onlinesbi.sbi', 'yonobusiness.sbi', 'bank.sbi'],
  hdfc: ['hdfcbank.com', 'hdfcbank.net', 'hdfc.com', 'hdfclife.com', 'hdfcergo.com'],
  icici: ['icicibank.com', 'icici.com', 'icicidirect.com', 'iciciprulife.com'],
  axisbank: ['axisbank.com', 'axis.bank.in'],
  kotak: ['kotak.com', 'kotak.bank.in'],
  pnb: ['pnbindia.in', 'netpnb.com'],
  bankofbaroda: ['bankofbaroda.in', 'bankofbaroda.com'],
  canarabank: ['canarabank.com', 'canarabank.in'],
  netbanking: [],
  irctc: ['irctc.co.in', 'irctc.com'],
  phonepe: ['phonepe.com'],
  paytm: ['paytm.com', 'paytm.in', 'paytmbank.com', 'paytmmoney.com'],
  bhim: ['bhimupi.org.in', 'npci.org.in'],
  npci: ['npci.org.in'],
  indiapost: ['indiapost.gov.in'],
  dhl: ['dhl.com', 'dhl.co.in'],
  fedex: ['fedex.com'],
  bluedart: ['bluedart.com'],
  delhivery: ['delhivery.com'],
  incometax: ['incometax.gov.in', 'incometaxindia.gov.in'],
  epfo: ['epfindia.gov.in'],
  uidai: ['uidai.gov.in'],
  aadhaar: ['uidai.gov.in', 'myaadhaar.uidai.gov.in'],
  digilocker: ['digilocker.gov.in'],
  jio: ['jio.com'],
  airtel: ['airtel.in', 'airtel.com'],
  vodafone: ['myvi.in', 'vodafone.com'],
  swiggy: ['swiggy.com', 'swiggy.in'],
  zomato: ['zomato.com'],
  zerodha: ['zerodha.com', 'kite.trade'],
  groww: ['groww.in'],
  binance: ['binance.com'],
  coinbase: ['coinbase.com'],
  dropbox: ['dropbox.com'],
  docusign: ['docusign.com', 'docusign.net'],
  adobe: ['adobe.com'],
  zoom: ['zoom.us', 'zoom.com'],
  telegram: ['telegram.org', 't.me'],
};
const BRAND_KEYWORDS = Object.keys(OFFICIAL);
const DISPLAY = { google:'Google', gpay:'Google Pay', microsoft:'Microsoft', office365:'Microsoft 365', outlook:'Outlook', apple:'Apple', appleid:'Apple ID', icloud:'iCloud',
  amazon:'Amazon', paypal:'PayPal', netflix:'Netflix', facebook:'Facebook', instagram:'Instagram', whatsapp:'WhatsApp', linkedin:'LinkedIn', github:'GitHub', flipkart:'Flipkart',
  myntra:'Myntra', sbi:'SBI', yono:'SBI YONO', hdfc:'HDFC Bank', icici:'ICICI Bank', axisbank:'Axis Bank', kotak:'Kotak Bank', pnb:'PNB', bankofbaroda:'Bank of Baroda',
  canarabank:'Canara Bank', irctc:'IRCTC', phonepe:'PhonePe', paytm:'Paytm', bhim:'BHIM UPI', npci:'NPCI', indiapost:'India Post', dhl:'DHL', fedex:'FedEx', bluedart:'Blue Dart',
  delhivery:'Delhivery', incometax:'Income Tax Department', epfo:'EPFO', uidai:'UIDAI (Aadhaar)', aadhaar:'Aadhaar', digilocker:'DigiLocker', jio:'Jio', airtel:'Airtel', vodafone:'Vi',
  swiggy:'Swiggy', zomato:'Zomato', zerodha:'Zerodha', groww:'Groww', binance:'Binance', coinbase:'Coinbase', dropbox:'Dropbox', docusign:'DocuSign', adobe:'Adobe', zoom:'Zoom', telegram:'Telegram' };
const nameOf = (b) => DISPLAY[b] || b;

/* trusted public suffixes that are almost never used for phishing kits */
const TRUSTED_SUFFIX = ['gov.in', 'nic.in', 'gov', 'mil', 'ac.in', 'edu', 'res.in', 'bank.in'];
const MULTI_TLD = ['co.in', 'gov.in', 'nic.in', 'org.in', 'net.in', 'ac.in', 'res.in', 'edu.in', 'firm.in', 'gen.in', 'ind.in', 'bank.in',
  'co.uk', 'org.uk', 'ac.uk', 'gov.uk', 'com.au', 'net.au', 'org.au', 'co.jp', 'com.br', 'com.sg', 'com.my', 'co.za', 'com.pk', 'com.bd', 'co.nz'];
const RISKY_TLD = new Set(['xyz', 'top', 'tk', 'ml', 'ga', 'cf', 'gq', 'buzz', 'click', 'link', 'online', 'site', 'live', 'icu', 'rest', 'cam',
  'work', 'loan', 'win', 'zip', 'mov', 'monster', 'cyou', 'sbs', 'cfd', 'bond', 'lol', 'quest', 'bar', 'fit', 'support', 'help', 'vip', 'shop', 'store', 'info', 'pw', 'cc', 'su', 'ru']);
const BAIT_WORDS = ['login', 'log-in', 'signin', 'sign-in', 'verify', 'verification', 'update', 'kyc', 'secure', 'security', 'account', 'suspend', 'blocked',
  'unlock', 'confirm', 'reward', 'refund', 'claim', 'bonus', 'prize', 'gift', 'wallet', 'recover', 'reset', 'billing', 'payment', 'invoice', 'otp', 'alert', 'support', 'helpdesk', 'webscr', 'auth'];
const DANGER_EXT = /\.(apk|exe|scr|bat|cmd|msi|jar|vbs|js|hta|iso|img|lnk|ps1)(\?|#|$)/i;

function isRawIp(hostname) {
  hostname = String(hostname).replace(/^\[|\]$/g, ''); // URL keeps IPv6 hosts bracketed: [2001:db8::1]
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(hostname)) return hostname.split('.').every(o => Number(o) >= 0 && Number(o) <= 255);
  if (/^[0-9a-fA-F:]+$/.test(hostname) && hostname.includes(':')) return true;
  return false;
}
function countChar(str, ch) { return str.split(ch).length - 1; }

function registrableOf(host) {
  const parts = host.split('.');
  const last2 = parts.slice(-2).join('.');
  if (parts.length >= 3 && MULTI_TLD.includes(last2)) return parts.slice(-3).join('.');
  return last2;
}
const endsWithDomain = (host, d) => host === d || host.endsWith('.' + d);

/* undo the character swaps scammers use: paypa1 → paypal, amaz0n → amazon, rn → m */
function unleet(s) {
  return s.replace(/0/g, 'o').replace(/1/g, 'l').replace(/3/g, 'e').replace(/4/g, 'a').replace(/5/g, 's').replace(/7/g, 't').replace(/\$/g, 's')
    .replace(/rn/g, 'm').replace(/vv/g, 'w');
}
function lev(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 9;
  const d = Array.from({ length: a.length + 1 }, (_, i) => [i]);
  for (let j = 1; j <= b.length; j++) d[0][j] = j;
  for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++)
    d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
  return d[a.length][b.length];
}

/* Which brand is this host official for, if any? */
function officialBrand(host) {
  for (const [brand, list] of Object.entries(OFFICIAL)) if (list.some(d => endsWithDomain(host, d))) return brand;
  return null;
}

/* Which brand does this host try to look like (and isn't)? */
function imitatedBrand(host, registrable) {
  const label = registrable.split('.')[0];
  const flat = unleet(host.replace(/[-.]/g, ''));
  for (const brand of BRAND_KEYWORDS) {
    if (brand.length < 3) continue;
    const official = OFFICIAL[brand];
    if (official.some(d => endsWithDomain(host, d))) continue;
    // brand word inside the domain: sbi-kyc-update.xyz, secure-appleid.apple.com.verify.info
    const word = brand.length <= 4 ? new RegExp('(^|[^a-z])' + brand + '([^a-z]|$)') : new RegExp(brand);
    if (word.test(host) || (brand.length > 4 && flat.includes(brand) && !host.includes(brand))) return { brand, how: host.includes(brand) ? 'name' : 'swap' };
    // one or two letters off: amazom.in, gooogle.com, hdfcbnak.com
    const offBy = official.map(d => d.split('.')[0]).filter(x => x.length >= 5);
    if (offBy.some(o => o !== label && lev(unleet(label), o) <= (o.length >= 8 ? 2 : 1))) return { brand, how: 'typo' };
  }
  return null;
}

function heuristicCheckUrl(rawUrl) {
  let u;
  const input = String(rawUrl).trim().replace(/^<|>$/g, '').replace(/^hxxp/i, 'http').replace(/\[\.\]/g, '.');
  try {
    const candidate = /^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(input) ? input : 'https://' + input;
    u = new URL(candidate);
  } catch {
    return { ok: false, error: 'Could not parse this as a URL.' };
  }
  if (!['http:', 'https:'].includes(u.protocol)) return { ok: false, error: 'Only http:// and https:// links can be checked.' };
  if (!u.hostname || !/[a-z0-9]/i.test(u.hostname)) return { ok: false, error: 'Could not parse this as a URL.' };

  const signals = [], good = [];
  let score = 0;
  const host = u.hostname.toLowerCase().replace(/\.$/, '');
  const registrable = registrableOf(host);
  const tld = host.split('.').pop();
  const pathQ = (u.pathname + u.search).toLowerCase();
  const official = officialBrand(host);
  const trustedSuffix = TRUSTED_SUFFIX.some(s => endsWithDomain(host, s));

  if (u.protocol !== 'https:') { score += 30; signals.push('No HTTPS - traffic to this site is not encrypted.'); }

  const rawIp = isRawIp(host);
  if (rawIp) { score += 35; signals.push('Uses a raw IP address instead of a domain name.'); }

  if (u.username || u.password || /@/.test(input.split('/').slice(0, 3).join('/'))) {
    score += 40; signals.push('Has an "@" before the domain - the part before it is ignored by the browser and is used to disguise the real site.');
  }

  const hyphens = countChar(host, '-');
  const subdomainCount = host.split('.').length - registrable.split('.').length;
  if (!official && (hyphens >= 3 || subdomainCount >= 3)) {
    score += 20; signals.push('Unusually many hyphens or subdomains, a common typosquatting pattern.');
  }

  const isShortener = SHORTENERS.has(host) || SHORTENERS.has(registrable);
  if (isShortener && !official) {
    score += 30; signals.push('This is a link-shortener domain - the final destination cannot be verified from the URL alone. Scam messages use these to hide the real site.');
  }

  if (host.includes('xn--')) { score += 30; signals.push('Punycode domain - may visually impersonate a trusted brand.'); }

  const imit = !official && !rawIp && !trustedSuffix ? imitatedBrand(host, registrable) : null;
  if (imit) {
    score += imit.how === 'name' ? 50 : 60;
    const real = OFFICIAL[imit.brand].slice(0, 2).join(' or ');
    signals.push(imit.how === 'name'
      ? `Uses the name "${nameOf(imit.brand)}" but is not an official ${nameOf(imit.brand)} website${real ? ' (the real one is ' + real + ')' : ''} - a common impersonation trick.`
      : `Looks like a misspelling of ${nameOf(imit.brand)} (${registrable})${real ? ' - the real site is ' + real : ''}. Lookalike domains are a classic phishing trick.`);
  }

  if (!official && !trustedSuffix && RISKY_TLD.has(tld)) {
    score += 20; signals.push(`Ends in ".${tld}" - a cheap domain ending that is heavily used for throwaway scam sites.`);
  }

  if (!official && !trustedSuffix) {
    const bait = [...new Set(BAIT_WORDS.filter(w => host.includes(w) || pathQ.includes(w)))];
    if (bait.length) {
      const pts = Math.min(25, bait.length * (imit ? 10 : 7));
      score += pts;
      signals.push(`Uses words scam pages rely on (${bait.slice(0, 4).join(', ')}) outside an official domain.`);
    }
  }

  if (DANGER_EXT.test(u.pathname)) { score += 40; signals.push('Downloads an app or program file directly (' + u.pathname.split('/').pop() + '). Never install apps from links in messages.'); }
  if (input.length > 180 || (pathQ.match(/%[0-9a-f]{2}/g) || []).length > 12) { score += 10; signals.push('Very long or heavily encoded link, often used to hide where it goes.'); }
  if (/(^|\.)(000webhostapp|weebly|wixsite|blogspot|firebaseapp|web\.app|pages\.dev|netlify\.app|vercel\.app|glitch\.me|ngrok|trycloudflare|herokuapp|r2\.dev|duckdns)\b/.test(host) && !official) {
    score += 15; signals.push('Hosted on a free site builder or tunnelling service - easy for anyone to set up in minutes.');
  }

  if (official) {
    good.push(`This is an official ${nameOf(official)} website (${registrable}).`);
    score = Math.max(0, score - 40);
  } else if (trustedSuffix) {
    good.push(`Registered under ${host.split('.').slice(-2).join('.')}, which only government, education or regulated bodies can use.`);
    score = Math.max(0, score - 25);
  }

  score = Math.min(100, score);
  let verdict, confidence;
  if (score >= 60) { verdict = 'MALICIOUS'; confidence = Math.min(97, 60 + Math.round(score / 3)); }
  else if (score >= 25) { verdict = 'SUSPICIOUS'; confidence = Math.min(88, 50 + Math.round(score / 3)); }
  else { verdict = 'SAFE'; confidence = official || trustedSuffix ? 92 : 70; }

  const explanation = signals.length
    ? signals.join(' ')
    : official || trustedSuffix
      ? good.join(' ') + ' No warning signs found.'
      : 'No known-bad structural patterns were found in this URL. This does not guarantee the destination is safe.';

  return { ok: true, verdict, confidence, score, secure: verdict === 'SAFE', explanation, signals, good, host, registrable, officialBrand: official, imitates: imit && imit.brand };
}

module.exports = { heuristicCheckUrl, nameOf, DISPLAY, SHORTENERS, BRAND_KEYWORDS, OFFICIAL, officialBrand, imitatedBrand, registrableOf, endsWithDomain };
