# World Monitor — Future Scope

These capabilities are **architected** (data model + APIs + docs) but are **not**
presented as implemented. Nothing here fabricates data; empty tables return
`UNAVAILABLE` until real evidence is ingested.

## Global Cyber Attack Atlas
Live global incidents, ransomware leak monitoring, malware/DDoS/zero-day campaign
tracking, supply-chain and cloud compromise, identity/AI-enabled fraud, mobile/
IoT/OT threats. Model: `wm_incidents` + link tables + `wm_attack_taxonomy` families.

## Extensible attack taxonomy
`wm_attack_taxonomy` already carries 35+ future families (ransomware, phishing,
BEC, credential stuffing, DDoS, botnets, infostealers, zero-day, KEV, supply-chain,
cloud, API abuse, identity/OAuth, container/K8s, CI/CD, IoT, mobile, OT/ICS/SCADA,
deepfake fraud, adversarial AI, cryptojacking, …). New families are configuration,
not hard-coded UI logic.

## Threat-actor graph
`Threat Actor → Campaign → Infrastructure → Technique → Vulnerability → Target →
Country → Sector → Impact`. Tables: `wm_threat_actors`, `wm_campaigns`,
`wm_vulnerabilities`, `wm_incident_vulnerabilities`. Relationships only when
evidence-supported.

## CVE / ATT&CK / incident graph
`CVE → ATT&CK technique → campaign → sector/org → country → incident → financial
impact → remediation`, seeded from `wm_vulnerabilities` (NVD) + MITRE ATT&CK.

## Global early warning
`wm_alerts` holds anomaly detections. `EARLY_SIGNAL` is used for unconfirmed
spikes and always exposes trigger, baseline, observed change, source, timestamp
and confidence. No alert is emitted without evidence.

## Full geographic maps
The India state monitor and global map currently render coverage honestly
(tabular + coverage badges). Full interactive GeoJSON choropleths are a UI
enhancement; the underlying per-state/per-country APIs already exist.
