# World Monitor — Social Data Governance

Public social signals are a **separate** layer (Tier C). They are never treated
as confirmed incidents, victim counts, or awareness levels.

## What is allowed
- Only **public** / **authorized** accounts and channels (e.g. official agency
  handles such as CERT-In `@IndianCERT`, MHA `@Cyberdost`, CISA `@CISAgov`).
- Registered in `wm_social_sources` with `authorized` flag and a public URL.
- Metrics stored in `wm_social_posts` are labelled *public discussion volume*,
  *awareness content reach*, or *self-reported public feedback*.

## What is never done
- No private WhatsApp chats or private messages.
- No bypassing authentication, access controls, rate limits, or privacy controls.
- No person-surveillance feature; no retention of unnecessary identifiers.
- Engagement (views/comments/likes) is never interpreted as confirmed victims or
  as a measure of national awareness.

## Keys & terms
Platform credentials/tokens are never committed; they live in environment
variables (`.env`, see `.env.example`). Platform terms of service and rate limits
are respected. Only the minimum necessary public data is retained.

## Status
Social ingestion is **architected** (tables + API `/api/world/social` + governance
rules) with real official handles registered. Live post ingestion is future scope
and is not presented as implemented.
