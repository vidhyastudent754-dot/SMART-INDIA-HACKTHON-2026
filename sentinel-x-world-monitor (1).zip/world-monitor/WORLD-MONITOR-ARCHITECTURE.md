# World Monitor — Architecture

World Monitor is the Global Cyber Intelligence & India Threat Observatory layered
on top of the SENTINEL-X assessment engine. It is **source-aware**: every number
carries provenance and freshness, and missing data is shown as `UNAVAILABLE` /
`NOT_PUBLISHED` — never as a fabricated zero.

## Layers

```
SOURCE ─▶ FETCH ─▶ RAW RECEIPT ─▶ VALIDATION ─▶ NORMALIZATION ─▶ DEDUP ─▶
ENTITY RESOLUTION ─▶ CLASSIFICATION ─▶ SECTION CROSSWALK ─▶ AGGREGATION ─▶
PROVENANCE ─▶ API ─▶ SSE push to UI
```

**Timing, stated precisely.** Collection (SOURCE ─▶ FETCH) is periodic, never
continuous: `/api/world/sources` freshness only changes when
`npm run world:refresh` is run (no timer); the Observatory signals refresh every
`OBSERVATORY_REFRESH_MS` (default 7 200 000 ms, 2 h); Fabric sources poll every
`pollIntervalSec` (CISA KEV 3600 s, NVD 7200 s, CERT-In 1800 s) with backoff on
failure; the live-feed collector runs every 600 000 ms (10 min). Only the last
step is real-time: `/api/world/stream` pushes a change to the browser within
4000 ms of it reaching the database (it checks the DB every 4 s). "Real-time"
here means push-to-browser timing, not collection timing. Full table: README →
*Data freshness*.

- **Data model** — `db/schema.sql` (26 `wm_*` tables, applied idempotently; existing
  SENTINEL-X tables preserved). See `WORLD-MONITOR-DATA-DICTIONARY.md`.
- **Seed / migration** — `db/world-seed.js` seeds the real source registry, ISO
  countries, all 36 India states/UTs, the attack taxonomy (15 approved + future
  families), real research datasets, real official public social handles, and
  migrates every sourced figure in `db/observatory.json` into `wm_metrics` +
  `wm_metric_provenance`. Idempotent; run on every `npm run db:init`.
- **Service** — `lib/world-monitor.js`: read helpers with honest coverage +
  a source-freshness classifier (`LIVE/RECENT/CACHED/STALE/UNAVAILABLE/…`). `LIVE`
  is an age label (last successful fetch < 15 min ago for live-capable sources),
  not a claim of continuous collection.
- **API + SSE** — `lib/world-api.js`, mounted at `/api/world/*` (admin|viewer),
  with `/api/world/stream` emitting `source.updated` / `source.failed` /
  `coverage.updated` / `metric.updated` on real DB change.
- **UI** — `public/observatory.html`: the observatory page (served at `/`).
- **Ingestion** — `scripts/world-refresh.js` performs **real HTTP** source-health
  probes, writing `wm_source_runs` + `wm_source_receipts` (checksums) and updating
  source status. `--dry` measures without writing.

## Boundaries (what is real now vs future scope)

Real & verified: data model, source registry (real URLs), country/state/taxonomy
reference data, migrated India metrics with provenance, source-health probing,
the full `/api/world/*` API + SSE, the observatory UI, `world:*` tooling, tests.

Architected but **future scope** (present as empty tables + docs, never faked as
live): full incident ingestion for every country, threat-actor graph, CVE/ATT&CK
graph, early-warning anomaly engine, full social ingestion, Kaggle import, and
full interactive geographic maps. See `WORLD-MONITOR-FUTURE-SCOPE.md`.

## Do-not-fabricate rule
No dashboard statistic is hard-coded. A figure exists only if a row with a source
URL exists. The frontend renders data from the API; it never manufactures numbers.
