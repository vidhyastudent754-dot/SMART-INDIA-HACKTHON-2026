# World Monitor — demo script (≈10 minutes)

The order is deliberate: open with the strongest, most original feature (the live
vulnerable → fixed assessment against the real app), then the ML story, then the
security of the tool itself, then operations. Leave setup out of the talk.

## Before you go on stage (5 minutes, the night before too)

```bash
npm run db:reset                 # clean assessment state, restore demo employees
npm start                        # or: docker compose up -d
```

- **Browser window A:** signed in as **admin**, on the *World Monitor* tab. The live
  panel should say “server push (SSE)”.
- **Browser window B (private window):** signed in as **viewer**. Keep it minimised.
- **Terminal:** in the repo, with `npm start` running and visible, so you can restart it on cue.
- Zoom the browser to about 125% so the back row can read the console.
- If the venue network is unreliable, run it locally. Nothing in the demo needs the
  internet except the optional Safe Browsing lookup, and the UI labels when that is absent.

---

## Before the demo: record real source responses

Run `npm run fabric:record` twice, a few hours apart, the day before. It saves genuine CISA KEV, NVD and CERT-In responses. With a working network, start normally (`npm start`) and the live layer polls the real sources. On an unreliable venue network, start with `FABRIC_MODE=replay npm start`. The dashboard then shows the amber **REPLAY / DEMONSTRATION** banner. Say so out loud: that label is part of the integrity story.

## Real-time proof (≈90 s, can open the demo)

1. **Overview → "Real-time signal layer".** Point at each source's state badge (● live / ◌ cached …) and its measured age. Then point at **"Periodic official baseline"**: "Complaint and conviction statistics are published yearly, and we label them that way."
2. **Live Feed.** Show the connection line: *Connected (Server-Sent Events) · last event id N*.
   - In replay mode, new CERT-In notes arrive by themselves, highlighted, with no reload.
   - Otherwise, go to **Trust Center → Run now** on CERT-In.
3. **Click Evidence** on a new row. Read out:
   - the source class;
   - the IST date (CERT-In publishes no time);
   - receipt # and sha256;
   - the request URL;
   - the Section mapping (*partial* — title-based, with the reason);
   - victim and attacker location: *Not published by source*.
4. **Alerts.** Open the alert that note produced. Point at the wording: an official warning, *not* a claimed attack. Show the formula and evidence link, then acknowledge it (audited).
5. **India States.** Show the reconciled NCRB table, then switch Level → PIN code: **"Not published by source."**

## 0:00 – 0:30 · One-line framing

> “World Monitor detects phishing and proves security fixes. Everything you'll see
> is computed live by this server, and the only real-time numbers on screen are the
> ones this instance is generating right now.”

The Observatory opens on **Overview**. Point at the three chips under the title:
**Live signals** (green when public feeds like NVD answered), **Reference data** (grey,
always), and the cache window. Then hover a KPI source link: “every number links to
the Lok Sabha reply or report it came from.” Scroll to **This World Monitor instance**:
those counters are zero now, and will move on their own during the demo.

Optional 60-second detour, if judges ask about the statistics: open **India vs World**.
- Walk one panel (a table, a bar chart and a sourced callout).
- Point at the orange `*`: “the per-section split is our stated assumption, because
  MHA doesn't publish it, and we say so on screen.”
- Then click **By Attack Section → ▶ Run Section 2 assessment**. That button is the
  bridge into the live console.

## 0:30 – 4:00 · Live assessment console — lead with this

1. Open the **02 — Employee & Manager** tab and find **EMP-04 · IDOR on record identifier**.
2. The payload is `recordId 1002, as EMP-A`. Say: record 1002 belongs to employee **B**.
3. Click **▶ Send to vulnerable build**. Read the streamed log aloud:
   - *“harness: minted a real session for emp.a … via the auth service”*
   - *“→ GET /api/lab/vulnerable/records/1002 (real HTTP, full middleware stack)”*
   - **HTTP 200**, and employee A has read B's expense claim. **VULNERABLE.**
4. Click **✓ Send same input to fixed build**. The request goes to `/api/records/1002`,
   **the app's own production route**, and gets **HTTP 403**. **SECURE.**
   > “That 403 isn't a simulation. It is our real API refusing a real employee session.
   > The verdict is read from the status code.”
5. **EMP-09 · Mass assignment.** Send `{ name, role: "admin" }` to both builds. In the
   vulnerable run the log shows `SELECT role FROM employees … → "admin"`: the escalation
   actually hit the database, and the harness then restores the row. The fixed run shows
   the role unchanged.
6. **Persistence moment (≈40 s).** Open the **01 — Individual** tab, then **Vulnerability
   Assessment**, then **IND-04 · password-reset token**. Pick the **persisted demo token**
   preset and send it to the **fixed** build: the first use is accepted and the second is
   rejected. **Now stop the server in the terminal (Ctrl-C) and start it again.** Send
   the same token to the fixed build again:
   > “Token loaded from SQLite — used=true. The server restarted and still remembers.
   > And notice I'm still signed in: sessions persist too.”
7. Return to the **World Monitor** tab. **Assessment runs** has gone up by itself, pushed
   over SSE with no reload.

## 4:00 – 6:30 · Phishing analysis with the ML score

1. Go to **01 — Individual**, then **Site Safety & Risk Alerts**. Click **Load sample** under
   email, then **Scan email**. It is verdict **PHISHING**. Point at the three tiles:
   - **Heuristic 100**: the rule engine's signals are listed below (urgency, credential request, SBI brand impersonation, suspicious link).
   - **ML 100**, with the model's cues shown (“account”, “verify”, “click here”).
   - **Combined 100**: the documented 60/40 blend.
2. The one that shows why the hybrid matters. Paste this into the SMS box:
   `Dear user your electricity bill is unpaid. Power will be disconnected tonight at 9.30pm. Contact officer 9123456780 immediately`
   → the heuristic score is **15** (the rules alone say *safe*), the ML score is **74**, and the combined verdict is **SUSPICIOUS**.
   > “No link, no brand, no OTP request, so the rules miss it. The model has seen
   > thousands of pressure scams and catches the language. At 40% weight the model
   > can raise a warning but can never by itself call something a confirmed scam.
   > A human-auditable rule has to agree.”
3. Glance at the **LIVE** panel: **Checks run** and **Threats caught** ticked up.

## 6:30 – 8:00 · The defender is defended (login and roles)

1. Switch to **window B (viewer)**. The **02** and **03** tabs show 🔒. Open one: the page
   says admin is required and that the server returns 403.
2. Optional, if a judge is technical: in window B's dev-tools console run
   `fetch('/api/assess/record/1002',{headers:{'X-Assess-Mode':'fixed'}}).then(r=>r.status)` → `403`.
3. Mention: HttpOnly + SameSite=Strict cookie, server-side logout, 30-minute idle
   timeout, username lockout after 5 failures, every attempt logged.

## 8:00 – 9:00 · Operations

1. In window A, click **Metrics**. It shows uptime, DB health and latency, Safe Browsing
   status, your rate-limit headroom, model status, active sessions and failed logins
   in the last 24 hours.
2. Click **Metrics CSV** and **Activity CSV**: “this is the report for management”.

## 9:00 – 10:00 · Close

> “Secrets out of the repo and blocked by a pre-commit hook. Login and roles in front
> of everything. State in SQLite that survives restarts. A trained, explainable model
> next to the rules. 66 automated tests plus a black-box scanner gating every push in
> CI. One-command Docker deploy. And nothing on screen claims to be live unless it is.”

---

## Judge questions

### “Does this persist? Does it scale?”

- **Persist:** yes. Sessions, reset tokens, the employee directory, rate-limit buckets,
  activity and login attempts are all in SQLite (`db/schema.sql`). We showed a restart
  live; `test/persistence.test.js` checks it on every push.
- **Scale:** SQLite in WAL mode on one node comfortably handles a department-sized
  deployment. The hot paths are indexed single-row reads, and scoring is in-process in
  under a millisecond. Beyond one node, the data layer sits behind one small module
  (`lib/db.js`), and every query is a prepared statement with no SQLite-only features
  beyond `ON CONFLICT`. Moving to PostgreSQL is a driver change, not a redesign. The
  in-memory pieces (the per-user API rate limiter and the SSE fan-out) would move to Redis.
- **Be honest:** we have not load-tested a multi-node deployment.

### “Is this really real-time? Does it show real attacks?”

It is real-time for what the world actually publishes in real time. CISA's KEV catalogue is the authoritative list of vulnerabilities **being exploited in the wild right now**. NVD and CERT-In publish new weaknesses and advisories within hours. We poll each at its real cadence, measure freshness, and push validated changes to the screen over SSE.

What no public source publishes in real time is *who* was attacked, *where* and *for how much*. For India, that comes from NCRB and MHA annually, down to State/UT level. So we show those as periodic figures and say "not published" for districts and PIN codes, instead of inventing a live incident map. The Trust Center shows that coverage matrix source by source.

### “What's the AI here?”

- A TF-IDF (unigram + bigram) → logistic-regression classifier per channel. The email
  model is trained on 36,659 public phishing/spam/ham emails and the SMS model on the
  5,574-message UCI SMS Spam Collection.
- Held-out results (80/20 split): email **F1 0.968** (precision 0.964, recall 0.972);
  SMS **F1 0.969** (precision 0.986, recall 0.953).
- **We made the number go down on purpose.** The first email model scored 98.9% because
  it had learned mailing-list footers. After we removed corpus artifacts it scores 97%
  and learns real cues.
- It is explainable: every score shows the terms that drove it.
- It runs without an ML runtime, as a 150 KB JSON of weights scored in Node. A parity
  test proves it matches scikit-learn to 5 × 10⁻⁷.
- The blend is 60 heuristic / 40 ML, so the model can warn but not convict on its own.
- We also know its limits: 2000s-era English corpora, the Flipkart-notification false
  positive, and no Hinglish. All of this is written up in `ML.md`.

### “How would you deploy this in a real ministry or enterprise?”

- **Today:** `docker compose up`. One container, a volume for the SQLite file, and a
  health check. It runs fully air-gapped: models ship in the image, Safe Browsing is
  optional, and the only external assets are cosmetic (web fonts and awareness-video thumbnails, both with fallbacks).
- **Enterprise shape:**
  - Put it behind the organisation's reverse proxy for TLS (`FORCE_HTTPS=true` if needed).
  - Replace local passwords with the organisation's SSO. The auth module is one file
    exposing `requireRole()`, so an OIDC/SAML provider (e.g. Parichay for government)
    slots in behind the same middleware.
  - Ship logs and `login_attempts` to the SOC's SIEM.
  - Point `/api/metrics` at their monitoring.
- **Governance:**
  - The activity table stores no message content or URLs, only kind, verdict and time.
  - The dangerous assessment classes run on synthetic data only.
  - The vulnerable lab routes answer only loopback requests that carry a per-process
    secret, and `ASSESS_LAB=off` removes them entirely for production.
- **Assurance:** CI runs the tests, a secret scan and our own black-box scanner on every
  change, so a regression that re-exposes the dashboard or weakens a cookie fails the build.

### Other likely questions

- **“Isn't the vulnerable build dangerous?”** It is mounted only for the harness
  (loopback + secret), works on demo data, restores what it changes, and can be switched off.
- **“Is the observatory live?”** Partly, and each card says which. NVD, Have I Been
  Pwned, INTERPOL and CERT-In signals are fetched server-side every 6 hours
  (● Live, or ◌ Cached if the fetch failed). Government annual figures come from
  reports and Parliament replies, which are not APIs; those are ◌ Reference, with the
  source and date on the card.
- **“Are those NCRP/IC3 numbers live?”** No, and the UI says so on every card: static
  reference data with source and year. The live panel above them is the only live data.
- **“What if the server is down?”** The phishing console falls back to the same rule
  engine in the browser and labels the result *Offline analysis — no ML score*.
