/* theme-fx.js - motion layer for the Aurora theme.
 * Purely visual: an animated sky behind the page, cards that rise into view,
 * gentle pointer-tilt on stat tiles, and a 3D globe on the sign-in page.
 * Turns itself off when the OS asks for reduced motion. No dependencies. */
(function () {
  'use strict';
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  function ready(fn) { if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn); }

  ready(function () {
    /* 1. animated sky (three drifting light sources + a faint perspective grid) */
    if (!document.querySelector('.fx-sky')) {
      var sky = document.createElement('div');
      sky.className = 'fx-sky'; sky.setAttribute('aria-hidden', 'true');
      sky.innerHTML = '<span class="fx-orb fx-orb--a"></span><span class="fx-orb fx-orb--b"></span><span class="fx-orb fx-orb--c"></span><span class="fx-grid"></span>';
      document.body.insertBefore(sky, document.body.firstChild);
    }

    /* 2. sign-in page: 3D globe above the product name */
    var intro = document.querySelector('.intro');
    if (intro && !intro.querySelector('.b-orb')) {
      var orb = document.createElement('div');
      orb.className = 'b-orb b-orb--login'; orb.setAttribute('aria-hidden', 'true');
      orb.innerHTML = '<div class="b-globe"><i></i><i></i><i></i><i></i><i></i><i></i><b></b><b></b><b></b></div><div class="b-ring"></div>';
      intro.insertBefore(orb, intro.firstChild);
    }

    if (reduce) return;

    /* 3. cards rise into view as they enter the screen */
    var SEL = '.card, .kpi, .metric, .sxa-card, .sxa-tile, .atk, .vd';
    var io = 'IntersectionObserver' in window ? new IntersectionObserver(function (entries) {
      entries.forEach(function (e) {
        if (e.isIntersecting) { e.target.classList.add('fx-in'); io.unobserve(e.target); }
      });
    }, { threshold: 0.06 }) : null;
    function arm(root) {
      (root || document).querySelectorAll(SEL).forEach(function (el, i) {
        if (el.dataset.fx) return; el.dataset.fx = '1';
        if (!io) return;
        var r = el.getBoundingClientRect();
        if (r.top < innerHeight && r.bottom > 0) { el.style.setProperty('--fx-d', Math.min(i, 8) * 45 + 'ms'); }
        el.classList.add('fx-rise'); io.observe(el);
      });
    }
    arm();
    new MutationObserver(function (m) {
      for (var i = 0; i < m.length; i++) if (m[i].addedNodes.length) { arm(); break; }
    }).observe(document.body, { childList: true, subtree: true });

    /* 4. pointer tilt on stat tiles (small, 6° max) */
    var TILT = '.metric, .kpi, .sxa-tile';
    document.addEventListener('pointermove', function (e) {
      var el = e.target.closest && e.target.closest(TILT);
      if (!el) return;
      var r = el.getBoundingClientRect();
      var x = (e.clientX - r.left) / r.width - 0.5, y = (e.clientY - r.top) / r.height - 0.5;
      el.style.transform = 'perspective(900px) rotateX(' + (-y * 6).toFixed(2) + 'deg) rotateY(' + (x * 6).toFixed(2) + 'deg) translateY(-3px)';
      el.style.setProperty('--fx-gx', (x + 0.5) * 100 + '%'); el.style.setProperty('--fx-gy', (y + 0.5) * 100 + '%');
      el.classList.add('fx-tilt');
    }, { passive: true });
    document.addEventListener('pointerout', function (e) {
      var el = e.target.closest && e.target.closest(TILT);
      if (el && !el.contains(e.relatedTarget)) { el.style.transform = ''; el.classList.remove('fx-tilt'); }
    }, { passive: true });
  });
})();
