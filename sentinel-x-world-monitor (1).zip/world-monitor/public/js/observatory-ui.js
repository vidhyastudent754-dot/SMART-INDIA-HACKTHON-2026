/* =============================================================================
 * observatory-ui.js - ⦿ World Monitor section (section-0).
 * Everything on this page is rendered from /api/observatory/* - the HTML holds
 * no statistics. Charts are inline SVG drawn here (no chart library).
 * ===========================================================================*/
(function () {
  'use strict';
  var root = document.getElementById('section-0');
  if (!root) return;

  /* ------------------------------------------------------------ helpers */
  var $ = function (sel, el) { return (el || root).querySelector(sel); };
  var $$ = function (sel, el) { return Array.prototype.slice.call((el || root).querySelectorAll(sel)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var NF = new Intl.NumberFormat('en-IN');
  var NF2 = new Intl.NumberFormat('en-IN', { maximumFractionDigits: 2 });
  var F = {
    count: function (v) { return v == null ? '-' : NF.format(Math.round(v)); },
    crore: function (v) { return v == null ? '-' : '₹' + NF2.format(v) + ' Cr'; },   // keeps official decimals (₹22,845.73 Cr)
    usd: function (v) {
      if (v == null) return '-';
      if (v >= 1e9) return '$' + (v / 1e9).toFixed(2).replace(/\.?0+$/, '') + ' B';
      if (v >= 1e6) return '$' + Math.round(v / 1e6) + ' M';
      return '$' + NF.format(v);
    },
    pct: function (v) { return v == null ? '' : (v > 0 ? '+' : '') + v.toFixed(1) + '%'; },
    compact: function (v) {
      if (v == null) return '-';
      var a = Math.abs(v);
      if (a >= 1e7) return (v / 1e7).toFixed(a >= 1e8 ? 0 : 1) + ' Cr';
      if (a >= 1e5) return (v / 1e5).toFixed(1).replace(/\.0$/, '') + ' L';
      if (a >= 1e3) return (v / 1e3).toFixed(0) + 'k';
      return String(Math.round(v));
    },
    usdAxis: function (v) { return v >= 1e9 ? '$' + (v / 1e9).toFixed(2).replace(/\.?0+$/, '') + 'B' : v >= 1e6 ? '$' + Math.round(v / 1e6) + 'M' : '$' + v; },
  };
  var byFormat = function (fmt) { return F[fmt] || F.count; };
  var byUnit = function (st) { return st && /USD/.test(st.unit || '') ? F.usd : st && /crore/i.test(st.unit || '') ? F.crore : F.count; };
  var PALETTE = ['#4C8DFF', '#FF7A7A', '#F5A623', '#36B37E', '#8892A0'];

  function period(s) { return s ? (s.year != null ? s.year : (s.asOf || s.period || '')) : ''; }
  function src(s, opt) {
    if (!s) return '';
    opt = opt || {};
    var p = opt.noPeriod ? '' : esc(period(s)) + ' · ';
    return '<div class="O-src">' + p + '<a href="' + esc(s.sourceUrl) + '" target="_blank" rel="noopener">' + esc(s.source) + ' ↗</a>' +
      (s.secondary ? ' <span class="sec" title="Read from a news report of the official release">†</span>' : '') + '</div>';
  }
  function badge(kind) {
    var m = { live: ['live', '● Live'], cached: ['cached', '◌ Cached'], reference: ['reference', '◌ Reference'], est: ['est', '* Estimate'] }[kind] || ['reference', kind];
    return '<span class="O-badge O-badge--' + m[0] + '">' + m[1] + '</span>';
  }
  var star = '<span class="O-star" title="Illustrative estimate - not official data">*</span>';
  function card(title, inner, b) { return '<div class="O-card"><h3>' + esc(title) + (b ? badge(b) : '') + '</h3>' + inner + '</div>'; }
  function statCard(label, s, fmt, extra) {
    extra = extra || {};
    return '<div class="O-kpi' + (extra.live ? ' O-kpi--live' : '') + '">' + badge(extra.badge || 'reference') +
      '<div class="O-kpi__l">' + esc(label) + '</div>' +
      '<div class="O-kpi__v">' + (s && s.value != null ? byFormat(fmt)(s.value) : '-') + (extra.unit ? '<small>' + esc(extra.unit) + '</small>' : '') + '</div>' +
      (extra.sub ? '<div class="O-kpi__d">' + extra.sub + '</div>' : '') + src(s) + '</div>';
  }
  function get(obj, path) { return String(path).split('.').reduce(function (o, k) { return o == null ? undefined : o[k]; }, obj); }

  /* ------------------------------------------------------------ tooltip */
  var tip = $('#obsTip');
  function showTip(html, ev) {
    tip.innerHTML = html; tip.classList.add('on');
    var x = ev.clientX + 14, y = ev.clientY + 14, r = tip.getBoundingClientRect();
    if (x + r.width > window.innerWidth - 8) x = ev.clientX - r.width - 14;
    if (y + r.height > window.innerHeight - 8) y = ev.clientY - r.height - 14;
    tip.style.left = x + 'px'; tip.style.top = y + 'px';
  }
  function hideTip() { tip.classList.remove('on'); }
  function bindTips(el) {
    $$('[data-tip]', el).forEach(function (n) {
      n.addEventListener('mousemove', function (e) { showTip(n.getAttribute('data-tip'), e); });
      n.addEventListener('mouseleave', hideTip);
    });
  }

  /* ------------------------------------------------------------ charts */
  var NS = 'http://www.w3.org/2000/svg';
  function niceStep(v) {
    if (v <= 0) return 1;
    var e = Math.pow(10, Math.floor(Math.log10(v))), f = v / e;
    return (f <= 1 ? 1 : f <= 2 ? 2 : f <= 5 ? 5 : 10) * e;
  }
  // 4 gridlines, each a round number (e.g. 0, 10 L, 20 L, 30 L, 40 L)
  function niceMax(v) { return niceStep(v / 4) * 4; }
  function svgWrap(w, h, inner) { return '<svg viewBox="0 0 ' + w + ' ' + h + '" role="img">' + inner + '</svg>'; }

  // smooth path through points (Catmull-Rom → cubic Bézier, tension 0.5)
  function smooth(pts) {
    if (pts.length < 2) return '';
    var d = 'M' + pts[0][0] + ',' + pts[0][1];
    for (var i = 0; i < pts.length - 1; i++) {
      var p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || p2;
      var c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
      var c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
      d += ' C' + c1[0].toFixed(1) + ',' + c1[1].toFixed(1) + ' ' + c2[0].toFixed(1) + ',' + c2[1].toFixed(1) + ' ' + p2[0].toFixed(1) + ',' + p2[1].toFixed(1);
    }
    return d;
  }

  function lineChart(el, series, o) {
    var W = 600, H = 240, m = { l: 58, r: 20, t: 18, b: 30 };
    var max = niceMax(Math.max.apply(null, series.map(function (p) { return p.value; })) * 1.08);
    var x = function (i) { return m.l + (series.length === 1 ? (W - m.l - m.r) / 2 : i * (W - m.l - m.r) / (series.length - 1)); };
    var y = function (v) { return m.t + (H - m.t - m.b) * (1 - v / max); };
    var pts = series.map(function (p, i) { return [x(i), y(p.value)]; });
    var gid = 'g' + Math.random().toString(36).slice(2, 8);
    var g = '<defs><linearGradient id="' + gid + '" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="' + o.color + '" stop-opacity=".28"/><stop offset="1" stop-color="' + o.color + '" stop-opacity="0"/></linearGradient></defs>';
    g += '<g class="grid">';
    for (var t = 0; t <= 4; t++) {
      var v = max * t / 4, yy = y(v);
      g += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + yy + '" y2="' + yy + '"/><text x="' + (m.l - 8) + '" y="' + (yy + 3) + '" text-anchor="end">' + esc(o.axis(v)) + '</text>';
    }
    g += '</g>';
    var line = smooth(pts);
    g += '<path d="' + line + ' L' + pts[pts.length - 1][0] + ',' + y(0) + ' L' + pts[0][0] + ',' + y(0) + ' Z" fill="url(#' + gid + ')"/>';
    g += '<path class="line" d="' + line + '" fill="none" stroke="' + o.color + '" stroke-width="2.5" stroke-linecap="round"/>';
    series.forEach(function (p, i) {
      var yoy = p.yoyPct != null ? '<br>' + F.pct(p.yoyPct) + ' vs ' + series[i - 1].year : '';
      g += '<text x="' + pts[i][0] + '" y="' + (H - 10) + '" text-anchor="middle">' + esc(p.year) + '</text>';
      g += '<text class="lbl" x="' + pts[i][0] + '" y="' + (pts[i][1] - 12) + '" text-anchor="middle">' + esc(o.label(p.value)) + '</text>';
      g += '<circle class="pt" cx="' + pts[i][0] + '" cy="' + pts[i][1] + '" r="5" fill="#0F1115" stroke="' + o.color + '" stroke-width="2.5" data-tip="' +
        esc('<b>' + p.year + '</b>: ' + o.tip(p.value) + yoy + '<small>' + (p.source || '') + '</small>') + '"/>';
    });
    el.innerHTML = svgWrap(W, H, g);
    var path = el.querySelector('path.line');
    if (path && path.getTotalLength) {
      var len = path.getTotalLength();
      path.style.strokeDasharray = len; path.style.strokeDashoffset = len;
      path.getBoundingClientRect();
      path.classList.add('draw');
      requestAnimationFrame(function () { path.style.strokeDashoffset = 0; });
    }
    bindTips(el);
  }

  function roundTopBar(x, y, w, h, r) {
    r = Math.min(r, w / 2, h);
    return 'M' + x + ',' + (y + h) + ' V' + (y + r) + ' Q' + x + ',' + y + ' ' + (x + r) + ',' + y + ' H' + (x + w - r) + ' Q' + (x + w) + ',' + y + ' ' + (x + w) + ',' + (y + r) + ' V' + (y + h) + ' Z';
  }

  function barChart(el, items, o) {
    var W = 600, H = o.height || 240, m = { l: 58, r: 12, t: 22, b: 40 };
    var max = niceMax(Math.max.apply(null, items.map(function (i) { return i.value; })) * 1.08);
    var bw = (W - m.l - m.r) / items.length, pad = bw * 0.28;
    var y = function (v) { return m.t + (H - m.t - m.b) * (1 - v / max); };
    var g = '<g class="grid">';
    for (var t = 0; t <= 4; t++) { var v = max * t / 4; g += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + y(v) + '" y2="' + y(v) + '"/><text x="' + (m.l - 8) + '" y="' + (y(v) + 3) + '" text-anchor="end">' + esc(o.axis(v)) + '</text>'; }
    g += '</g><g class="bars">';
    items.forEach(function (it, i) {
      var x = m.l + i * bw + pad / 2, w = bw - pad, top = y(it.value), h = y(0) - top;
      g += '<path class="bar grow" style="animation-delay:' + (i * 80) + 'ms" d="' + roundTopBar(x, top, w, Math.max(h, 1), 5) + '" fill="' + (it.color || PALETTE[0]) + '" data-tip="' + esc('<b>' + it.label + '</b>: ' + o.tip(it.value) + (it.note ? '<small>' + it.note + '</small>' : '')) + '"/>';
      g += '<text class="lbl" x="' + (x + w / 2) + '" y="' + (top - 6) + '" text-anchor="middle">' + esc(o.label(it.value)) + '</text>';
      g += '<text x="' + (x + w / 2) + '" y="' + (H - 22) + '" text-anchor="middle">' + esc(it.label) + '</text>';
      if (it.sub) g += '<text x="' + (x + w / 2) + '" y="' + (H - 8) + '" text-anchor="middle" style="font-size:9px">' + esc(it.sub) + '</text>';
    });
    el.innerHTML = svgWrap(W, H, g + '</g>');
    bindTips(el);
  }

  function hbar(el, items, o) {
    var W = 600, rowH = 34, m = { l: 150, r: 110, t: 6 }, H = m.t * 2 + items.length * rowH;
    var max = Math.max.apply(null, items.map(function (i) { return i.value; }));
    var g = '<g class="bars">';
    items.forEach(function (it, i) {
      var y = m.t + i * rowH + 6, w = Math.max(2, (W - m.l - m.r) * it.value / max);
      g += '<text x="' + (m.l - 10) + '" y="' + (y + 15) + '" text-anchor="end" class="lbl">' + esc(it.label) + '</text>';
      g += '<rect class="bar growx" style="animation-delay:' + (i * 90) + 'ms" x="' + m.l + '" y="' + y + '" width="' + w + '" height="20" rx="4" fill="' + (it.color || PALETTE[i]) + '" data-tip="' + esc('<b>' + it.label + '</b>: ' + o.fmt(it.value) + (it.note ? '<small>' + it.note + '</small>' : '')) + '"/>';
      g += '<text x="' + (m.l + w + 8) + '" y="' + (y + 15) + '">' + esc(o.fmt(it.value)) + '</text>';
    });
    el.innerHTML = svgWrap(W, H, g + '</g>');
    bindTips(el);
  }

  function donut(el, parts, o) {
    var total = parts.reduce(function (s, p) { return s + p.value; }, 0), R = 72, C = 2 * Math.PI * R, off = 0;
    var g = '<g transform="translate(110,110) rotate(-90)">';
    parts.forEach(function (p, i) {
      var len = C * p.value / total;
      g += '<circle class="bar" r="' + R + '" fill="none" stroke="' + PALETTE[i % PALETTE.length] + '" stroke-width="30" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) + '" stroke-dashoffset="' + (-off).toFixed(2) + '" data-tip="' +
        esc('<b>' + p.label + '</b>: ' + o.fmt(p.value) + ' (' + (100 * p.value / total).toFixed(1) + '%)' + (p.computed ? '<small>computed remainder</small>' : '')) + '"/>';
      off += len;
    });
    g += '</g><text x="110" y="106" text-anchor="middle" class="lbl" style="font-size:17px">' + esc(o.fmt(total)) + '</text><text x="110" y="124" text-anchor="middle">' + esc(o.center || '') + '</text>';
    el.innerHTML = '<div style="display:flex;gap:16px;align-items:center;flex-wrap:wrap"><div style="width:220px;flex:none">' + svgWrap(220, 220, '<g class="bars">' + g + '</g>') + '</div><div class="O-legend" style="flex-direction:column;gap:6px">' +
      parts.map(function (p, i) { return '<span><i style="background:' + PALETTE[i % PALETTE.length] + '"></i>' + esc(p.label) + ' - <b>' + esc(o.fmt(p.value)) + '</b> (' + (100 * p.value / total).toFixed(0) + '%)</span>'; }).join('') + '</div></div>';
    bindTips(el);
  }

  // grouped bars, two independent y-axes (₹ left, $ right) - no currency conversion
  function groupedDual(el, groups, o) {
    var W = 820, H = 280, m = { l: 70, r: 70, t: 20, b: 44 };
    var maxA = niceMax(Math.max.apply(null, groups.map(function (g) { return g.a; })) * 1.1);
    var maxB = niceMax(Math.max.apply(null, groups.map(function (g) { return g.b; })) * 1.1);
    var yA = function (v) { return m.t + (H - m.t - m.b) * (1 - v / maxA); };
    var yB = function (v) { return m.t + (H - m.t - m.b) * (1 - v / maxB); };
    var gw = (W - m.l - m.r) / groups.length, bw = gw * 0.28;
    var s = '<g class="grid">';
    for (var t = 0; t <= 4; t++) {
      var yy = yA(maxA * t / 4);
      s += '<line x1="' + m.l + '" x2="' + (W - m.r) + '" y1="' + yy + '" y2="' + yy + '"/>';
      s += '<text x="' + (m.l - 8) + '" y="' + (yy + 3) + '" text-anchor="end" style="fill:' + o.aColor + '">' + esc(o.aAxis(maxA * t / 4)) + '</text>';
      s += '<text x="' + (W - m.r + 8) + '" y="' + (yB(maxB * t / 4) + 3) + '" style="fill:' + o.bColor + '">' + esc(o.bAxis(maxB * t / 4)) + '</text>';
    }
    s += '</g><g class="bars">';
    groups.forEach(function (gr, i) {
      var cx = m.l + i * gw + gw / 2;
      var ax = cx - bw - 3, bx = cx + 3;
      s += '<path class="bar grow" d="' + roundTopBar(ax, yA(gr.a), bw, yA(0) - yA(gr.a), 5) + '" fill="' + o.aColor + '" data-tip="' + esc('<b>' + gr.label + '</b><br>' + o.aName + ': ' + o.aFmt(gr.a) + '<small>' + o.aNote + '</small>') + '"/>';
      s += '<path class="bar grow" style="animation-delay:120ms" d="' + roundTopBar(bx, yB(gr.b), bw, yB(0) - yB(gr.b), 5) + '" fill="' + o.bColor + '" data-tip="' + esc('<b>' + gr.label + '</b><br>' + o.bName + ': ' + o.bFmt(gr.b) + '<small>' + (gr.bNote || o.bNote) + '</small>') + '"/>';
      s += '<text class="lbl" x="' + (ax + bw / 2) + '" y="' + (yA(gr.a) - 6) + '" text-anchor="middle" style="font-size:9px">' + esc(o.aFmt(gr.a)) + '</text>';
      s += '<text class="lbl" x="' + (bx + bw / 2) + '" y="' + (yB(gr.b) - 6) + '" text-anchor="middle" style="font-size:9px">' + esc(o.bFmt(gr.b)) + '</text>';
      s += '<text x="' + cx + '" y="' + (H - 24) + '" text-anchor="middle">' + esc(gr.short) + '</text>';
    });
    s += '</g><text x="' + (m.l - 8) + '" y="10" text-anchor="end" style="fill:' + o.aColor + '">₹ Cr</text><text x="' + (W - m.r + 8) + '" y="10" style="fill:' + o.bColor + '">USD</text>';
    el.innerHTML = svgWrap(W, H, s) + '<div class="O-legend"><span><i style="background:' + o.aColor + '"></i>' + esc(o.aName) + ' (left axis)</span><span><i style="background:' + o.bColor + '"></i>' + esc(o.bName) + ' (right axis)</span></div>';
    bindTips(el);
  }

  // funnel on a log scale: the stages span 4+ orders of magnitude
  function funnel(el, stages) {
    var max = Math.log10(stages[0].value);
    el.innerHTML = '<div class="O-funnel">' + stages.map(function (s, i) {
      var w = Math.max(1.5, 100 * Math.log10(Math.max(s.value, 1)) / max);
      var shareOfFirst = i ? ' · ' + (100 * s.value / stages[0].value).toFixed(s.value / stages[0].value < 0.01 ? 3 : 2) + '% of stage 1' : '';
      return '<div class="O-fun"><div class="O-fun__n">' + esc(s.stage) + '<small>' + (s.dataset === 'NCRB' ? 'NCRB dataset' : 'MHA dataset') + (s.note ? ' · ' + esc(s.note) : '') + '</small></div>' +
        '<div><div class="O-fun__bar" style="width:' + w.toFixed(1) + '%;animation-delay:' + (i * 90) + 'ms;background:' + (i === stages.length - 1 ? '#36B37E' : i ? '#4C8DFF' : '#8892A0') + '" data-tip="' + esc('<b>' + s.stage + '</b>: ' + F.count(s.value) + shareOfFirst + '<small>' + s.source + '</small>') + '"></div></div>' +
        '<div class="O-fun__v">' + F.count(s.value) + '</div></div>';
    }).join('') + '</div><div class="O-foot">Bar length uses a logarithmic scale (the stages span four orders of magnitude). Stages 1-2 are MHA figures; stages 3-5 are NCRB 2023 - different datasets, shown together for orientation only.</div>';
    bindTips(el);
  }

  /* ------------------------------------------------------------ renderers */
  var S = null;           // current snapshot
  var rendered = {};
  var sectionCache = null;

  function renderOverview(d) {
    var ref = d.kpis.filter(function (k) { return !k.liveSignal; });
    $('#obsKpis').innerHTML = ref.map(function (k) {
      var sub = k.delta != null ? '<b class="up">' + (k.delta > 0 ? '▲ ' : '▼ ') + F.pct(k.delta) + '</b> vs previous year' : (k.note ? esc(k.note) : '');
      return statCard(k.label, k, k.format, { sub: sub });
    }).join('');
    lineChart($('#obsChartNcrp'), d.india.ncrp.complaints, { color: '#4C8DFF', axis: F.compact, label: F.compact, tip: F.count });
    lineChart($('#obsChartLoss'), d.india.ncrp.financialLossCrore, { color: '#FF7A7A', axis: function (v) { return '₹' + NF.format(v); }, label: function (v) { return '₹' + NF.format(Math.round(v)); }, tip: F.crore });
    $('#obsChartNcrpSrc').innerHTML = src(d.india.ncrp.complaints[0], { noPeriod: true });
    $('#obsChartLossSrc').innerHTML = src(d.india.ncrp.financialLossCrore[0], { noPeriod: true });
    renderLiveSignals(d);
  }

  function liveCard(k) {
    var extra = k.extra || {};
    var sub = k.value == null ? (k.error && !/pending|disabled/.test(k.error) ? 'Last fetch failed (' + esc(k.error) + '); no earlier value recorded' : 'Waiting for the first server-side fetch') :
      (extra.accountsExposed ? F.compact(extra.accountsExposed) + ' accounts exposed · latest: ' + esc(extra.latestBreach) :
        extra.window ? esc(extra.window) : extra.latestId ? 'latest: ' + esc(extra.latestId) + (extra.latestTitle ? ' - ' + esc(extra.latestTitle) + (extra.latestDate ? ' (' + esc(extra.latestDate) + ')' : '') : '') : extra.note ? esc(extra.note) : '');
    var s = { value: k.value, source: k.origin || k.source, sourceUrl: k.sourceUrl, asOf: k.period || (k.fetchedAt ? k.fetchedAt.slice(0, 16).replace('T', ' ') + ' UTC' : 'not fetched yet') };
    return statCard(k.label, s, 'count', { badge: k.badge || k.source, live: (k.badge || k.source) === 'live', sub: sub });
  }
  function renderLiveSignals(d) {
    $('#obsLiveSignals').innerHTML = d.kpis.filter(function (k) { return k.liveSignal; }).map(liveCard).join('');
  }

  function renderIndia(d) {
    var n = d.india;
    var rows = n.table.map(function (r) {
      return '<tr><td><b>' + r.year + '</b></td><td class="num">' + F.count(r.complaints) + '</td><td class="num ' + (r.complaintsYoyPct > 0 ? 'O-up' : '') + '">' + F.pct(r.complaintsYoyPct) + '</td><td class="num">' + (r.lossCrore != null ? F.crore(r.lossCrore) : '<span class="sec">not published</span>') + '</td><td class="num ' + (r.lossYoyPct > 0 ? 'O-up' : '') + '">' + F.pct(r.lossYoyPct) + '</td></tr>';
    }).join('');
    var c = n.conversion;
    var i4 = n.i4c, cf = n.cfcfrms;
    var html =
      '<details class="O-acc" open><summary>A · NCRP &amp; financial overview<span class="meta">MHA replies to Parliament</span></summary><div class="body">' +
        '<div class="O-grid2" style="margin-top:0"><div class="O-card"><h3>Year by year</h3><div class="O-scroll"><table class="Ztbl"><thead><tr><th>Year</th><th class="num">NCRP complaints</th><th class="num">YoY</th><th class="num">Reported loss</th><th class="num">YoY</th></tr></thead><tbody>' + rows + '</tbody></table></div>' + src(n.ncrp.complaints[0], { noPeriod: true }) + src(n.ncrp.financialLossCrore[0], { noPeriod: true }) + '</div>' +
        '<div class="O-card"><h3>Complaint → FIR conversion</h3><div class="O-big" style="color:#F5A623">' + c.firPerComplaintPct + '%</div>' +
          '<div class="O-foot">of NCRP complaints became FIRs - <b>' + F.count(n.ncrp.cumulative.firsRegistered.value) + '</b> FIRs from <b>' + F.count(n.ncrp.cumulative.complaints.value) + '</b> complaints (cumulative to ' + esc(c.asOf) + '). ' + esc(c.basis) + '.</div>' + src(n.ncrp.cumulative.firsRegistered) +
          '<div class="O-foot" style="margin-top:10px">Cross-dataset view: NCRB registered cases in 2023 were <b>' + c.ncrbCasesPerNcrpComplaint2023Pct + '%</b> of NCRP complaints that year. ' + esc(c.crossDatasetCaveat) + '</div></div></div>' +
        '<div class="O-card O-mt"><h3>CERT-In cyber security incidents handled</h3><div class="O-chart" id="obsCertBars"></div>' + src(n.certIn.incidents[0], { noPeriod: true }) + '</div>' +
      '</div></details>' +
      '<details class="O-acc" open><summary>B · I4C action metrics<span class="meta">as of ' + esc(i4.simsBlocked.asOf) + '</span></summary><div class="body"><div class="O-grid">' +
        statCard('SIM cards blocked', i4.simsBlocked, 'count') + statCard('IMEIs blocked', i4.imeiBlocked, 'count') + statCard('Mobile apps blocked', i4.appsBlocked, 'count') +
        statCard('Money saved (CFCFRMS)', cf.moneySavedCrore, 'crore', { sub: 'in ' + F.count(cf.complaintsHandled.value) + ' complaints' }) +
        statCard('Suspect identifiers shared', i4.suspectIdentifiers, 'count', { sub: 'Suspect Registry, with banks' }) + statCard('Transactions declined', i4.declinedTransactionsCrore, 'crore', { sub: 'via the Suspect Registry' }) +
      '</div><div class="O-foot">Links go to the report of the Lok Sabha reply; the portal itself is <a href="https://i4c.mha.gov.in/" target="_blank" rel="noopener" style="color:#4C8DFF">i4c.mha.gov.in ↗</a>.</div></div></details>' +
      '<details class="O-acc" open><summary>C · Criminal-justice pipeline<span class="meta">MHA + NCRB</span></summary><div class="body"><div class="O-grid2" style="margin-top:0">' +
        '<div class="O-card"><h3>From complaint to conviction</h3><div id="obsFunnel"></div></div>' +
        '<div class="O-card"><h3>Conviction outcomes (NCRB 2023)</h3><div class="O-big">' + n.ncrb.convictionPerRegisteredPct + '%</div><div class="O-foot">Convictions in 2023 (' + F.count(n.ncrb.convictions.value) + ') as a share of the cybercrime cases registered that year (' + F.count(n.ncrb.registeredCases[n.ncrb.registeredCases.length - 1].value) + ').</div>' +
          '<div class="O-big" style="font-size:24px;color:#F5A623;margin-top:10px">' + n.ncrb.convictionShareOfDisposalsPct + '%</div><div class="O-foot">of cases that reached a verdict or discharge ended in conviction (' + F.count(n.ncrb.convictions.value) + ' convictions, ' + F.count(n.ncrb.acquittals.value) + ' acquittals, ' + F.count(n.ncrb.discharged.value) + ' discharged).</div>' +
          '<div class="O-callout">' + esc(n.ncrb.note) + '</div>' + src(n.ncrb.convictions) + '</div>' +
      '</div></div></details>';
    $('#z0-in').innerHTML = html;
    barChart($('#obsCertBars'), n.certIn.incidents.map(function (p) { return { label: String(p.year), value: p.value, color: p.secondary ? '#8892A0' : '#4C8DFF', sub: p.secondary ? 'reported †' : F.pct(p.yoyPct), note: p.source }; }), { axis: F.compact, label: F.compact, tip: F.count, height: 220 });
    funnel($('#obsFunnel'), n.pipeline);
    bindTips($('#z0-in'));
  }

  function renderGlobal(d) {
    var g = d.global, a = g.fbiIc3['2024'], b = g.fbiIc3['2025'], L = g.live;
    var html =
      '<div class="Zsh">USA - FBI IC3<span>2024 &amp; 2025 annual reports</span></div>' +
      '<div class="O-grid">' +
        statCard('IC3 complaints 2025', b.complaints, 'count', { sub: F.pct(g.fbiIc3.complaintsYoyPct) + ' vs 2024 (' + F.count(a.complaints.value) + ')' }) +
        statCard('IC3 losses 2025', b.lossesUSD, 'usd', { sub: F.pct(g.fbiIc3.lossesYoyPct) + ' vs 2024 (' + F.usd(a.lossesUSD.value) + ')' }) +
        statCard('Business email compromise 2024', a.becUSD, 'usd', { sub: F.count(a.becComplaints.value) + ' complaints' }) +
        statCard('Investment fraud 2024', a.investmentFraudUSD, 'usd') +
        statCard('Crypto-linked losses 2024', a.cryptoUSD, 'usd', { sub: 'cuts across categories' }) +
        statCard('New ransomware variants 2024', a.newRansomwareVariants, 'count', { sub: F.count(a.ransomwareComplaints.value) + ' ransomware complaints' }) +
        statCard('Funds frozen 2024 (RAT)', a.fundsFrozenUSD, 'usd', { sub: esc(a.fundsFrozenUSD.notes) }) +
        statCard('AI-related complaints 2025', b.aiComplaints, 'count', { sub: 'first year reported' }) +
      '</div>' +
      '<div class="O-grid2">' + card('IC3 2024 losses by category', '<div id="obsDonut"></div><div class="O-foot">' + esc(g.lossMix2024.note) + '</div>' + src(a.lossesUSD)) +
        card('Reporting scale by country (latest year each)', '<div class="O-chart" id="obsCountries"></div><div class="O-foot">' + esc(g.countriesNote) + '</div>' +
          g.countries.map(function (c) { return '<div class="O-foot" style="margin-top:2px">' + c.flag + ' <b>' + esc(c.country) + '</b> - ' + esc(c.measure) + ', ' + esc(period(c)) + ' · <a href="' + esc(c.sourceUrl) + '" target="_blank" rel="noopener" style="color:#4C8DFF">' + esc(c.source) + ' ↗</a></div>'; }).join('')) +
      '</div>' +
      '<div class="Zsh">Vulnerabilities, breaches &amp; notices<span>polled every 2 h where available</span></div><div class="O-grid">' +
        liveCard({ label: L.cves.label, value: L.cves.value, badge: L.cves.source, sourceUrl: L.cves.sourceUrl, extra: L.cves.extra, fetchedAt: L.cves.fetchedAt, error: L.cves.error, origin: L.cves.origin }) +
        liveCard({ label: L.certInNotes.label, value: L.certInNotes.value, badge: L.certInNotes.source, sourceUrl: L.certInNotes.sourceUrl, extra: L.certInNotes.extra, fetchedAt: L.certInNotes.fetchedAt, error: L.certInNotes.error, origin: L.certInNotes.origin }) +
        liveCard({ label: L.breaches.label, value: L.breaches.value, badge: L.breaches.source, sourceUrl: L.breaches.sourceUrl, extra: L.breaches.extra, fetchedAt: L.breaches.fetchedAt, error: L.breaches.error, origin: L.breaches.origin }) +
        statCard('CERT-In incidents (India)', d.india.certIn.incidents.filter(function (x) { return !x.secondary; }).slice(-1)[0], 'count', { sub: 'reported 2025: ' + F.count(d.india.certIn.incidents.slice(-1)[0].value) + ' †' }) +
      '</div>' +
      '<div class="Zsh">INTERPOL &amp; international cooperation<span>India-linked</span></div><div class="O-grid">' +
        liveCard({ label: L.redNotices.label, value: L.redNotices.value, badge: L.redNotices.source, sourceUrl: L.redNotices.sourceUrl, extra: L.redNotices.extra, fetchedAt: L.redNotices.fetchedAt, error: L.redNotices.error, origin: L.redNotices.origin }) +
        d.enforcement.international.map(function (op) { return statCard(op.name, op, 'count', { unit: op.unit, sub: esc(op.summary) }); }).join('') +
        statCard('India among IC3 complainant countries', b.indiaComplainants, 'count', { sub: esc(b.indiaComplainants.notes) }) +
      '</div>';
    $('#z0-gl').innerHTML = html;
    donut($('#obsDonut'), g.lossMix2024.parts, { fmt: F.usd, center: 'IC3 losses 2024' });
    barChart($('#obsCountries'), g.countries.map(function (c, i) { return { label: c.flag + ' ' + c.country, value: c.value, color: i ? PALETTE[i % PALETTE.length] : '#4C8DFF', sub: String(period(c)), note: c.measure + ' - ' + c.source }; }), { axis: F.compact, label: F.compact, tip: F.count, height: 240 });
    bindTips($('#z0-gl'));
  }

  /* India vs World ------------------------------------------------------- */
  function sectionCallout(s, d) {
    var n = d.india, a = d.global.fbiIc3['2024'];
    var e = d.compare.estimates;
    var pct = Math.round(e.split[String(s.id)] * 100);
    var c24 = n.ncrp.complaints[n.ncrp.complaints.length - 1];
    if (s.id === 1) {
      return 'An estimated' + star + ' <b>' + pct + '%</b> of India\'s <b>' + F.count(c24.value) + '</b> NCRP complaints in ' + c24.year + ' were individual / account-level attacks. That assumption is consistent with NCRB 2023, where fraud was the motive in <b>' + (n.ncrb.fraudShare2023.value * 100).toFixed(1) + '%</b> of registered cybercrime cases. In the USA, phishing/spoofing was the most-reported IC3 complaint type (<b>' + F.count(a.phishingComplaints.value) + '</b>).';
    }
    if (s.id === 2) {
      return 'Business email compromise - attackers impersonating managers or finance teams - cost US victims <b>' + F.usd(a.becUSD.value) + '</b> across <b>' + F.count(a.becComplaints.value) + '</b> IC3 complaints in 2024. India does not publish a comparable category, so the India column applies an illustrative ' + pct + '% share' + star + '.';
    }
    var ci = n.certIn.incidents, cLast = ci.filter(function (x) { return !x.secondary; }).slice(-1)[0], cRep = ci[ci.length - 1];
    var cves = d.global.live.cves;
    return 'CERT-In handled <b>' + F.count(cLast.value) + '</b> cyber security incidents in ' + cLast.year + ' (' + F.pct(cLast.yoyPct) + '), with <b>' + F.count(cRep.value) + '</b> reported for ' + cRep.year + ' †. IC3 recorded <b>' + F.count(a.ransomwareComplaints.value) + '</b> ransomware complaints and <b>' + a.newRansomwareVariants.value + '</b> new variants in 2024.' +
      (cves.value != null ? ' ' + (cves.source === 'live' ? 'Live' : 'Last fetched') + ': <b>' + F.count(cves.value) + '</b> new CVEs published in 7 days (NVD).' : '');
  }

  function renderCompare(d) {
    var cmp = d.compare;
    var g = cmp.growth;
    var html = '<div class="O-callout" style="margin-top:0">In 2024 India\'s reported cyber-fraud losses grew <b>' + F.pct(g.indiaLosses2024Pct) + '</b> while complaints grew <b>' + F.pct(g.indiaComplaints2024Pct) + '</b> - losses are rising much faster than reporting (MHA).</div>';
    cmp.sections.forEach(function (s) {
      var wr = s.worldReference;
      var rows = [
        ['Scale (2024)', F.count(s.estimate.victims.value) + star + '<div class="O-foot">' + esc(s.estimate.victims.basis) + '</div>', byUnit(wr[0])(wr[0].value) + '<div class="O-foot">' + esc(wr[0].label) + '</div>'],
        ['Losses (2024)', F.crore(s.estimate.lossCrore.value) + star + '<div class="O-foot">' + esc(s.estimate.lossCrore.basis) + '</div>', F.usd(s.usaLossUSD.value) + '<div class="O-foot">IC3: ' + s.usaLossUSD.parts.map(function (p) { return esc(p.ref.split('.').pop().replace(/USD$/, '').replace(/([A-Z])/g, ' $1').toLowerCase()) + ' ' + F.usd(p.value); }).join(' + ') + (s.usaLossUSD.note ? '<br>' + esc(s.usaLossUSD.note) : '') + '</div>'],
        ['Top attack', esc(s.topAttackIndia), esc(s.global.text)],
        ['Key published figure', esc(s.india.text) + (s.india.stat ? src(Array.isArray(s.india.stat) ? s.india.stat[s.india.stat.length - 1] : s.india.stat) : ''), s.global.stat ? src(s.global.stat) : ''],
      ].concat(wr.slice(1).map(function (w) { return ['World reference', '-', byUnit(w)(w.value) + ' <span class="O-foot">' + esc(w.label) + '</span>']; }));
      html += '<div class="Zsh">' + s.icon + ' Section ' + s.id + ' - ' + esc(s.label) + '<span>' + s.checkCount + ' live checks</span></div>' +
        '<div class="O-grid2" style="margin-top:0"><div class="O-card"><div class="O-scroll"><table class="Ztbl"><thead><tr><th>Metric</th><th>India</th><th>World (USA reference)</th></tr></thead><tbody>' +
        rows.map(function (r) { return '<tr><td><b>' + r[0] + '</b></td><td>' + r[1] + '</td><td>' + r[2] + '</td></tr>'; }).join('') + '</tbody></table></div></div>' +
        '<div class="O-card"><h3>Reported volume ' + badge('est') + '</h3><div class="O-chart" id="obsCmpBar' + s.id + '" style="min-height:0"></div>' +
        '<div class="O-foot">India: estimated' + star + ' share of NCRP complaints. USA: ' + esc(wr[0].label) + '. Different measures on one scale - orientation only.</div>' +
        '<div class="O-callout">' + sectionCallout(s, d) + '</div></div></div>';
    });
    html += '<div class="Zsh">Financial impact by section<span>two axes · no currency conversion</span></div><div class="O-card"><div class="O-chart" id="obsDual"></div>' +
      '<div class="O-foot">' + esc(cmp.currencyNote) + '</div></div>' +
      '<div class="O-foot" style="margin-top:12px"><span class="O-star">*</span> ' + esc(cmp.estimates.disclaimer) + ' Split used: ' +
      Object.keys(cmp.estimates.split).map(function (k) { return 'Section ' + k + ' ' + Math.round(cmp.estimates.split[k] * 100) + '%'; }).join(', ') + '. ' + esc(cmp.estimates.context) + '</div>';
    $('#z0-cmp').innerHTML = html;
    cmp.sections.forEach(function (s) {
      hbar($('#obsCmpBar' + s.id), [
        { label: 'India (est.)', value: s.estimate.victims.value, color: '#4C8DFF', note: s.estimate.victims.basis },
        { label: 'USA (IC3)', value: s.worldReference[0].value, color: '#FF7A7A', note: s.worldReference[0].label },
      ], { fmt: F.count });
    });
    groupedDual($('#obsDual'), cmp.financial.map(function (f) {
      return { label: f.label, short: 'S' + f.id + ' · ' + f.label.split(' / ')[0].split(' ')[0], a: f.indiaLossCrore, b: f.usaLossUSD, bNote: f.usaNote || 'IC3 2024 category losses' };
    }), { aName: 'India, estimated (₹ Cr)', bName: 'USA, IC3 categories ($)', aColor: '#4C8DFF', bColor: '#FF7A7A', aFmt: F.crore, bFmt: F.usd,
      aAxis: function (v) { return NF.format(Math.round(v)); }, bAxis: F.usdAxis, aNote: 'illustrative split of MHA 2024 total', bNote: 'IC3 2024' });
    bindTips($('#z0-cmp'));
  }

  /* By Attack Section ---------------------------------------------------- */
  function sevColor(sev) { return sev === 'Critical' ? '#FF7A7A' : sev === 'High' ? '#F5A623' : sev === 'Medium' ? '#4C8DFF' : '#8892A0'; }
  function agoTxt(iso) {
    if (!iso) return 'no live signal recorded yet';
    var s = Math.round((Date.now() - Date.parse(iso)) / 1000);
    if (s < 90) return s + ' s ago';
    if (s < 5400) return Math.round(s / 60) + ' min ago';
    if (s < 172800) return Math.round(s / 3600) + ' h ago';
    return Math.round(s / 86400) + ' d ago';
  }
  function liveCountsBlock(sec, live) {
    var row = live && live.filter(function (x) { return x.section === sec; })[0];
    if (!row) {
      return '<div class="O-card O-mt"><h3>Polled signals <span class="O-badge O-badge--live" style="margin-left:auto">from latest polls</span></h3>' +
        '<div class="O-foot">Polled count unavailable right now - showing the reference estimate above instead.</div></div>';
    }
    return '<div class="O-card O-mt"><h3>Polled signals - how many affected India vs World <span class="O-badge O-badge--live" style="margin-left:auto">from latest polls</span></h3>' +
      '<div class="O-scroll"><table class="Ztbl"><thead><tr><th></th><th class="num">Last 24 h</th><th class="num">Last 7 days</th><th>Last signal</th></tr></thead><tbody>' +
      '<tr><td>India <span class="O-foot" style="display:inline">(CERT-In)</span></td><td class="num">' + F.count(row.india.signals24h) + '</td><td class="num">' + F.count(row.india.signals7d) + '</td><td>' + esc(agoTxt(row.india.lastSignalAt)) + '</td></tr>' +
      '<tr><td>World <span class="O-foot" style="display:inline">(CISA KEV, NVD)</span></td><td class="num">' + F.count(row.world.signals24h) + '</td><td class="num">' + F.count(row.world.signals7d) + '</td><td>' + esc(agoTxt(row.world.lastSignalAt)) + '</td></tr>' +
      '</tbody></table></div><div class="O-foot">Counts are vulnerability disclosures, exploitation reports and official advisories mapped to Section ' + sec + ' - not confirmed attacks, and India/World are separate feeds so the two columns are not directly comparable as attack volumes.</div></div>';
  }
  function renderSections(d, list, live) {
    var html = '<div class="O-foot" style="margin:0 0 10px">Each panel links the national picture to the live checks that test for it, plus a count of Section-mapped signals from the latest polls (CISA every 1 h, NVD every 2 h, CERT-In every 30 min) for India and the world. Official sources do not publish prevalence per individual attack type for these categories, so prevalence is shown at section level with its source; severity comes from each check\'s CVSS 3.1 score.</div>';
    list.forEach(function (s, idx) {
      html += '<details class="O-acc"' + (idx === 0 ? ' open' : '') + '><summary>' + s.icon + ' Section ' + s.id + ' - ' + esc(s.label) +
        '<span class="meta">' + F.count(s.estimate.victims.value) + ' victims' + star + ' · ' + F.crore(s.estimate.lossCrore.value) + star + ' · ' + s.checkCount + ' checks</span></summary><div class="body">' +
        liveCountsBlock(s.id, live) +
        '<div class="O-grid2" style="margin-top:0"><div class="O-card"><h3>India</h3><div style="font-size:12.5px;color:#E8ECF2">' + esc(s.india.text) + '</div>' + (s.india.stat ? src(Array.isArray(s.india.stat) ? s.india.stat[s.india.stat.length - 1] : s.india.stat) : '<div class="O-foot">Estimate' + star + ': ' + esc(s.estimate.victims.basis) + '</div>') + '</div>' +
        '<div class="O-card"><h3>World</h3><div style="font-size:12.5px;color:#E8ECF2">' + esc(s.global.text) + '</div>' + src(s.global.stat) + '</div></div>' +
        '<div class="O-card O-mt"><div class="O-scroll"><table class="Ztbl"><thead><tr><th>Attack type</th><th>What it is</th><th>Live checks (CVSS 3.1)</th><th class="num">Max CVSS</th></tr></thead><tbody>' +
        s.attackTypes.map(function (a) {
          return '<tr><td><b>' + esc(a.name) + '</b></td><td style="color:#B8BFC9">' + esc(a.what) + '</td><td>' + a.checks.map(function (c) {
            var band = c.cvss >= 9 ? 'Critical' : c.cvss >= 7 ? 'High' : c.cvss >= 4 ? 'Medium' : 'Low';   // CVSS 3.1 qualitative bands
            return '<span class="O-badge" style="color:' + sevColor(band) + ';border:1px solid ' + sevColor(band) + '55;margin:0 4px 4px 0" data-tip="' + esc('<b>' + c.id + '</b> ' + (c.title || '') + '<small>CVSS ' + c.cvss + ' (' + band + ') · ' + (c.cwe || '') + '</small>') + '">' + esc(c.id) + ' · ' + (c.cvss != null ? c.cvss.toFixed(1) : '-') + '</span>';
          }).join('') + '</td><td class="num" style="color:' + sevColor(a.maxCvss >= 9 ? 'Critical' : a.maxCvss >= 7 ? 'High' : 'Medium') + '">' + (a.maxCvss != null ? a.maxCvss.toFixed(1) : '-') + '</td></tr>';
        }).join('') + '</tbody></table></div>' +
        '<button type="button" class="O-run" data-run="' + esc(s.assessmentTab) + '">▶ Run Section ' + s.id + ' assessment</button></div>' +
        '</div></details>';
    });
    $('#z0-sec').innerHTML = html;
    bindTips($('#z0-sec'));
  }
  function loadSections(d) {
    if (sectionCache) return renderSections(d, d.compare.sections, sectionCache);
    fetch('/api/v1/observatory/overview', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function (j) { sectionCache = j.data.bySection; renderSections(d, d.compare.sections, sectionCache); })
      .catch(function () { renderSections(d, d.compare.sections, null); });
  }

  /* Enforcement ---------------------------------------------------------- */
  function renderEnforcement(d) {
    var e = d.enforcement, i4 = e.i4c, cf = e.cfcfrms;
    var html =
      '<div class="Zsh">I4C enforcement actions<span>to ' + esc(i4.simsBlocked.asOf) + '</span></div><div class="O-grid">' +
        statCard('SIM cards blocked', i4.simsBlocked, 'count') + statCard('IMEIs blocked', i4.imeiBlocked, 'count') + statCard('Mobile apps blocked', i4.appsBlocked, 'count', { sub: esc(i4.appsBlocked.notes) }) +
        statCard('Layer-1 mule accounts shared', i4.muleAccountsShared, 'count', { sub: 'Suspect Registry' }) +
      '</div>' +
      '<div class="O-grid2"><div class="O-card"><h3>Criminal-justice pipeline</h3><div id="obsFunnel2"></div></div>' +
      '<div class="O-card"><h3>CFCFRMS - money saved over time</h3><div class="O-chart" id="obsCfcf"></div><div class="O-foot">Cumulative amount prevented from reaching fraudsters since 2021. Each point is a separate reply to Parliament.</div>' + src(cf.history[0], { noPeriod: true }) + '</div></div>' +
      '<div class="Zsh">Recovery &amp; freezing<span>India vs USA</span></div><div class="O-grid">' +
        statCard('India - saved via CFCFRMS (cumulative)', cf.moneySavedCrore, 'crore', { sub: F.count(cf.complaintsHandled.value) + ' complaints' }) +
        statCard('India - amount marked as lien (cumulative)', e.lien, 'crore', { sub: 'of ' + F.crore(e.amountReported.value) + ' reported on NCRP' }) +
        statCard('USA - frozen by IC3 Recovery Asset Team (2024)', e.ic3FundsFrozen, 'usd', { sub: esc(e.ic3FundsFrozen.notes) }) +
      '</div>' +
      '<div class="Zsh">International joint operations<span>CBI · FBI · INTERPOL</span></div><div class="O-grid">' +
        e.international.map(function (op) { return statCard(op.name, op, 'count', { unit: op.unit, sub: esc(op.summary) }); }).join('') +
        statCard('Arrests from IC3-India cooperation (2024)', e.ic3India, 'count', { unit: '× increase', sub: esc(e.ic3India.notes) }) +
      '</div>';
    $('#z0-law').innerHTML = html;
    funnel($('#obsFunnel2'), e.pipeline);
    barChart($('#obsCfcf'), cf.history.map(function (h) { return { label: String(h.asOf), value: h.value, color: '#36B37E', sub: h.notes, note: h.source }; }), { axis: function (v) { return '₹' + NF.format(v); }, label: function (v) { return '₹' + NF.format(v); }, tip: F.crore, height: 220 });
    bindTips($('#z0-law'));
  }

  /* Data feed ------------------------------------------------------------ */
  function renderFeed(d) {
    $('#z0-feed').innerHTML = '<div class="O-card" style="padding:0"><ul class="O-feed">' + d.feed.map(function (f) {
      return '<li><span class="d">' + esc(f.date) + '</span><span>' + f.flag + '</span><span class="s">' + esc(f.source) + '</span><span>' + esc(f.headline) + '</span>' +
        '<span>' + (f.live ? badge('live') : '<span class="O-sev O-sev--' + esc(f.severity) + '">' + esc(f.severity) + '</span>') + '</span>' +
        '<a class="x" href="' + esc(f.url) + '" target="_blank" rel="noopener" style="color:#4C8DFF;font-size:11px">source ↗</a></li>';
    }).join('') + '</ul></div><div class="O-foot">Newest first. Items marked Live were generated from a successful server-side fetch in the current cache window; the rest are published reports.</div>';
  }

  function renderSources(d) {
    var groups = { IN: 'India', US: 'United States', AU: 'Australia', DE: 'Germany', GLOBAL: 'International' };
    var html = '';
    Object.keys(groups).forEach(function (k) {
      var items = d.sources.filter(function (s) { return s.country === k; });
      if (!items.length) return;
      html += '<div class="Zm__g">' + groups[k] + '</div>' + items.map(function (s) {
        return '<div class="Zm__src"><b>' + esc(s.name) + '</b><small>' + esc(s.covers) + ' · latest: ' + esc(s.latest) + '</small><a href="' + esc(s.url) + '" target="_blank" rel="noopener">' + esc(s.url.replace(/^https?:\/\//, '').slice(0, 60)) + '</a></div>';
      }).join('');
    });
    $('#obsSourcesList').innerHTML = html + '<div class="O-foot">Reference file: <code>db/observatory.json</code>, last reviewed ' + esc(S.meta.referenceUpdated) + '. Refresh live signals with <code>npm run observatory:update</code>.</div>';
  }

  /* ------------------------------------------------------------ orchestration */
  var TABS = { ov: renderOverview, in: renderIndia, gl: renderGlobal, cmp: renderCompare, sec: loadSections, law: renderEnforcement, feed: renderFeed };
  function activeTab() { var b = $('#z0t button.on'); return b ? b.getAttribute('data-z') : 'ov'; }
  function render(tab) {
    if (!TABS[tab]) return;               // fabric tabs are rendered by fabric-ui.js
    if (!S || rendered[tab]) return;
    try { TABS[tab](S.data); rendered[tab] = true; }
    catch (e) {
      console.error('[observatory] render ' + tab, e);
      var p = $('#z0-' + tab); if (p) p.innerHTML = '<div class="O-banner">This panel could not be drawn (' + esc(e.message) + ').</div>';
    }
  }
  function renderAll() { Object.keys(TABS).forEach(render); }

  function applyMeta(meta, stale) {
    var chip = $('#obsLiveChip');
    chip.classList.toggle('O-chip--live', !!meta.liveSignals && !stale);
    var live = Object.keys(meta.signals || {}).filter(function (k) { return meta.signals[k].source === 'live'; }).length;
    chip.title = live + ' of ' + Object.keys(meta.signals || {}).length + ' live public signals fetched successfully in the current cache window';
    var t = function (iso) { return iso ? new Date(iso).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', timeZone: 'Asia/Kolkata' }) : '-'; };
    $('#obsCacheChip').innerHTML = '<i></i> Cache ' + t(meta.cachedAt) + ' → next ' + t(meta.nextRefreshAt) + ' IST';
    var banner = $('#obsBanner');
    if (stale) { banner.hidden = false; banner.textContent = 'Observatory data unavailable - showing last cached values from ' + new Date(meta.cachedAt).toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' }) + ' IST.'; }
    else if (meta.referenceError) { banner.hidden = false; banner.textContent = 'Reference data file could not be re-read (' + meta.referenceError + ') - serving the last good copy.'; }
    else banner.hidden = true;
  }

  function load(isRefresh) {
    var btn = $('#obsRefreshBtn');
    if (isRefresh) { btn.disabled = true; btn.innerHTML = '<span class="O-spin"></span> Refreshing'; }
    return fetch('/api/observatory/snapshot', { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
      .then(function (j) {
        S = j; rendered = {}; sectionCache = null;
        try { sessionStorage.setItem('wm-observatory', JSON.stringify(j)); } catch (e) { /* storage full / disabled */ }
        applyMeta(j.meta, false);
        render('ov'); render(activeTab()); renderSources(j.data);
      })
      .catch(function (err) {
        var cached = null;
        try { cached = JSON.parse(sessionStorage.getItem('wm-observatory') || 'null'); } catch (e) { /* ignore */ }
        if (cached && (!S || isRefresh)) {
          S = cached; rendered = {};
          applyMeta(cached.meta, true);
          render('ov'); render(activeTab()); renderSources(cached.data);
        } else if (!S) {
          var b = $('#obsBanner'); b.hidden = false;
          b.textContent = 'Observatory data unavailable (' + err.message + ') and no cached copy in this browser yet. Retry with ↻ Refresh.';
        } else {
          applyMeta(S.meta, true);
        }
      })
      .finally(function () { btn.disabled = false; btn.innerHTML = '&#8635; Refresh'; });
  }

  /* tabs, buttons, clock */
  $$('#z0t button').forEach(function (b) {
    b.addEventListener('click', function () {
      $$('#z0t button').forEach(function (x) { x.classList.toggle('on', x === b); x.setAttribute('aria-selected', x === b); });
      $$('.Zp').forEach(function (p) { p.classList.toggle('on', p.id === 'z0-' + b.getAttribute('data-z')); });
      render(b.getAttribute('data-z'));
    });
  });
  root.addEventListener('click', function (e) {
    var run = e.target.closest('[data-run]');
    if (run) {
      var tab = document.querySelector('#sx-tabbar button[data-sx-target="' + run.getAttribute('data-run') + '"]');
      if (tab) { tab.click(); window.scrollTo({ top: 0, behavior: 'smooth' }); }
    }
  });
  var modal = $('#z0m');
  $('#obsSourcesBtn').addEventListener('click', function () { modal.classList.add('on'); });
  modal.addEventListener('click', function (e) { if (e.target === modal || e.target.hasAttribute('data-close')) modal.classList.remove('on'); });
  $('#obsRefreshBtn').addEventListener('click', function () { load(true); });
  $('#obsPrintBtn').addEventListener('click', function () { renderAll(); setTimeout(function () { window.print(); }, 60); });
  window.addEventListener('beforeprint', renderAll);

  var clockFmt = new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  function tick() { var c = document.getElementById('z0ck'); if (c) c.textContent = clockFmt.format(new Date()) + ' IST'; }
  tick(); setInterval(tick, 1000);

  load(false);
})();
