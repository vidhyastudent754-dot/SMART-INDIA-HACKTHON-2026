/* =============================================================================
 * wm-shell.js - World Monitor application shell.
 *   • signed-in user chip + sign-out + metrics panel in the section tab bar
 *   • role gating: viewers see the Employee and Company assessment tabs locked
 *     (the server enforces this too - this only avoids a confusing UI)
 *   • expired session → back to /login (any same-origin /api call returning 401)
 *   • the LIVE activity panel, fed by Server-Sent Events from /api/activity/stream
 * Loaded first in <body>; does its DOM work on DOMContentLoaded.
 * ===========================================================================*/
(function () {
  'use strict';

  /* ---- 401 anywhere → sign in again ---- */
  var nativeFetch = window.fetch.bind(window);
  window.fetch = function (input, init) {
    return nativeFetch(input, init).then(function (r) {
      try {
        var u = new URL(typeof input === 'string' ? input : input.url, location.href);
        if (r.status === 401 && u.origin === location.origin && u.pathname.indexOf('/api/') === 0 &&
            u.pathname.indexOf('/api/auth/') !== 0) {
          // Some assessment checks return 401 on purpose (e.g. a replayed session
          // correctly rejected). Only leave the page if OUR dashboard session is gone.
          nativeFetch('/api/auth/me', { credentials: 'same-origin' }).then(function (m) {
            if (m.status === 401) location.href = '/login?next=' + encodeURIComponent(location.pathname + location.hash);
          }).catch(function () {});
        }
      } catch (e) { /* ignore */ }
      return r;
    });
  };

  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var fmt = function (n) { return n == null ? '-' : Number(n).toLocaleString('en-IN'); };

  var CSS = [
    '#sx-tabbar{align-items:center}',
    '.wm-user{margin-left:auto;display:flex;align-items:center;gap:8px;font:12px/1 "Segoe UI","Inter",system-ui,sans-serif;color:#9AA3AF;white-space:nowrap}',
    '.wm-user__role{padding:3px 7px;border-radius:3px;font:700 9.5px/1 "JetBrains Mono",monospace;letter-spacing:.06em;text-transform:uppercase}',
    '.wm-user__role--admin{background:rgba(76,141,255,.12);color:#7AAFFF;border:1px solid rgba(76,141,255,.25)}',
    '.wm-user__role--viewer{background:rgba(136,146,160,.1);color:#B8BFC9;border:1px solid rgba(136,146,160,.25)}',
    '#sx-tabbar .wm-user button{padding:5px 10px!important;border:1px solid #333A47!important;border-radius:4px;font-size:11.5px!important;color:#C4CAD3!important;background:transparent}',
    '#sx-tabbar .wm-user button:hover{border-color:#4C8DFF!important;color:#fff!important}',
    '#sx-tabbar button.wm-locked{opacity:.45}',
    '.wm-lock{max-width:560px;margin:80px auto;padding:28px;border:1px solid #282D38;border-radius:8px;background:#161920;color:#C4CAD3;font:14px/1.6 "Segoe UI","Inter",system-ui,sans-serif;text-align:center}',
    '.wm-lock b{color:#F2F4F7}',
    '.wm-viewbar{position:fixed;left:0;right:0;bottom:0;z-index:9999;background:#2a2414;color:#e9d9a8;border-bottom:1px solid #5a4a1e;padding:9px 18px;font:13px/1.5 "Segoe UI",system-ui,sans-serif;text-align:center}',
    '.wm-viewer .sxa-btn[disabled]{opacity:.55;cursor:not-allowed}',
    '.wm-dev{background:#5c3d00;color:#FFCF80;text-align:center;font:600 12px/1 system-ui;padding:6px}',
    /* live panel */
    '#section-0 .wm-live{border:1px solid rgba(54,179,126,.25);border-radius:8px;background:linear-gradient(180deg,rgba(54,179,126,.05),rgba(22,25,32,.6));padding:14px 16px;margin-bottom:6px}',
    '#section-0 .wm-live__h{display:flex;align-items:center;gap:8px;font-size:12.5px;color:#C4CAD3;margin-bottom:12px}',
    '#section-0 .wm-live__h b{color:#5CD99A;letter-spacing:.08em;text-transform:uppercase;font:700 11px/1 "JetBrains Mono",monospace}',
    '#section-0 .wm-live__dot{width:8px;height:8px;border-radius:50%;background:#636B78}',
    '#section-0 .wm-live--on .wm-live__dot{background:#36B37E;box-shadow:0 0 0 0 rgba(54,179,126,.6);animation:wmPulse 1.8s infinite}',
    '@keyframes wmPulse{70%{box-shadow:0 0 0 8px rgba(54,179,126,0)}100%{box-shadow:0 0 0 0 rgba(54,179,126,0)}}',
    '#section-0 .wm-live__src{margin-left:auto;font:10px/1 "JetBrains Mono",monospace;color:#636B78}',
    '#section-0 .wm-live__g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px}',
    '#section-0 .wm-live__c{background:#161920;border:1px solid #282D38;border-left:3px solid #36B37E;border-radius:6px;padding:10px 12px}',
    '#section-0 .wm-live__c--r{border-left-color:#EF5350}#section-0 .wm-live__c--a{border-left-color:#F5A623}#section-0 .wm-live__c--b{border-left-color:#4C8DFF}',
    '#section-0 .wm-live__l{font-size:10.5px;color:#8892A0;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px}',
    '#section-0 .wm-live__v{font:700 24px/1.15 "JetBrains Mono",monospace;color:#F2F4F7;transition:color .4s}',
    '#section-0 .wm-live__v.bump{color:#5CD99A}',
    '#section-0 .wm-live__s{font-size:10.5px;color:#636B78;margin-top:3px}',
    '#section-0 .wm-live__row{display:grid;grid-template-columns:1fr 1.3fr;gap:10px;margin-top:10px}',
    '#section-0 .wm-live__spark,#section-0 .wm-live__feed{background:#161920;border:1px solid #282D38;border-radius:6px;padding:10px 12px}',
    '#section-0 #wmSpark{width:100%;height:44px;display:block}',
    '#section-0 #wmFeed{list-style:none;margin:0;padding:0;font:11px/1.7 "JetBrains Mono",monospace;color:#B8BFC9;max-height:92px;overflow:auto}',
    '#section-0 #wmFeed li{display:flex;gap:8px}#section-0 #wmFeed .t{color:#636B78}',
    '#section-0 .wm-v--bad{color:#FF7A7A}#section-0 .wm-v--mid{color:#FFCF80}#section-0 .wm-v--ok{color:#5CD99A}',
    '#section-0 .wm-live__empty{color:#636B78}',
    '@media(max-width:900px){#section-0 .wm-live__g{grid-template-columns:1fr 1fr}#section-0 .wm-live__row{grid-template-columns:1fr}.wm-user__name{display:none}}',
    /* metrics modal */
    '.wm-modal{position:fixed;inset:0;z-index:100000;background:rgba(5,6,8,.7);display:flex;align-items:flex-start;justify-content:center;padding:6vh 16px;overflow:auto}',
    '.wm-modal__box{width:100%;max-width:760px;background:#161920;border:1px solid #282D38;border-radius:8px;color:#E8ECF2;font:13px/1.55 "Segoe UI","Inter",system-ui,sans-serif}',
    '.wm-modal__h{display:flex;align-items:center;gap:10px;padding:14px 18px;border-bottom:1px solid #282D38}',
    '.wm-modal__h b{font-size:15px}.wm-modal__h a,.wm-modal__h button{margin-left:auto;color:#7AAFFF;background:none;border:0;cursor:pointer;font:inherit}',
    '.wm-modal__h a + a,.wm-modal__h a + button{margin-left:12px}',
    '.wm-kv{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;padding:16px 18px}',
    '.wm-kv div{border:1px solid #282D38;border-radius:6px;padding:10px 12px}',
    '.wm-kv small{display:block;color:#8892A0;font-size:10.5px;text-transform:uppercase;letter-spacing:.05em}',
    '.wm-kv span{font:600 14px/1.4 "JetBrains Mono",monospace}',
    '.wm-ok{color:#5CD99A}.wm-bad{color:#FF7A7A}',
    '.wm-modal pre{margin:0 18px 18px;max-height:260px;overflow:auto;background:#0F1115;border:1px solid #282D38;border-radius:6px;padding:10px;font:11px/1.5 "JetBrains Mono",monospace;color:#B8BFC9}',
  ].join('\n');

  var me = null;

  function injectCss() {
    var st = document.createElement('style');
    st.textContent = CSS;
    document.head.appendChild(st);
  }

  /* ---- user chip ---- */
  function renderUser() {
    var bar = document.getElementById('sx-tabbar');
    if (!bar || !me) return;
    var box = document.createElement('div');
    box.className = 'wm-user';
    box.innerHTML =
      '<span class="wm-user__name">' + esc(me.user.displayName) + '</span>' +
      '<span class="wm-user__role wm-user__role--' + esc(me.user.role) + '">' + esc(me.user.role) + '</span>' +
      '<button type="button" id="wmMetricsBtn">Metrics</button>' +
      (me.authDisabled ? '' : '<button type="button" id="wmLogout">Sign out</button>');
    bar.appendChild(box);
    document.getElementById('wmMetricsBtn').addEventListener('click', openMetrics);
    var lo = document.getElementById('wmLogout');
    if (lo) lo.addEventListener('click', function () {
      nativeFetch('/api/auth/logout', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: '{}' })
        .finally(function () { location.href = '/login'; });
    });
    if (me.authDisabled) {
      var d = document.createElement('div');
      d.className = 'wm-dev';
      d.textContent = 'Authentication is DISABLED on this instance (AUTH_DISABLED=true). Development only.';
      document.body.insertBefore(d, document.body.firstChild);
    }
  }

  /* ---- role gating (viewer) ---- */
  function gateViewer() {
    if (!me || me.user.role === 'admin') return;
    /* View-only account: everything stays visible, but no attack can be run.
     * The server enforces the same rule (HTTP 403 on /api/assess/* for viewers). */
    document.body.classList.add('wm-viewer');
    var bar = document.createElement('div');
    bar.className = 'wm-viewbar';
    bar.innerHTML = '<b>View-only account.</b> You can read every attack, its evidence format and the fix, but running tests is limited to the admin account.';
    var tabbar = document.getElementById('sx-tabbar');
    document.body.appendChild(bar); void tabbar;
    var ATTACK = '.sxa-btn--attack, .sxa-btn--fix';
    function lock(root) {
      (root || document).querySelectorAll(ATTACK).forEach(function (b) {
        b.disabled = true; b.title = 'Admin only - you are signed in as a viewer';
        if (!b.dataset.wmLocked) { b.dataset.wmLocked = '1'; b.textContent = b.textContent.replace(/^[▶✓]\s*/, '') + ' (admin only)'; }
      });
    }
    lock();
    new MutationObserver(function () { lock(); }).observe(document.body, { childList: true, subtree: true });
    document.addEventListener('click', function (e) {
      var b = e.target.closest && e.target.closest(ATTACK);
      if (b) { e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
  }

  /* ---- metrics panel ---- */
  function openMetrics() {
    var wrap = document.createElement('div');
    wrap.className = 'wm-modal';
    wrap.innerHTML = '<div class="wm-modal__box"><div class="wm-modal__h"><b>Instance metrics</b>' +
      (me && me.user.role === 'admin' ? '<a href="/api/metrics.csv">Metrics CSV</a><a href="/api/activity/export.csv">Activity CSV</a>' : '') +
      '<button type="button" data-x>Close</button></div><div id="wmMx">Loading…</div></div>';
    wrap.addEventListener('click', function (e) { if (e.target === wrap || e.target.hasAttribute('data-x')) wrap.remove(); });
    document.body.appendChild(wrap);
    fetch('/api/metrics', { credentials: 'same-origin' }).then(function (r) { return r.json(); }).then(function (m) {
      var ok = function (b) { return b ? '<span class="wm-ok">OK</span>' : '<span class="wm-bad">Down</span>'; };
      var up = m.uptime.seconds, h = Math.floor(up / 3600), mi = Math.floor((up % 3600) / 60);
      var rl = m.rateLimit['check-url'] || {};
      var kv = [
        ['Uptime', h + 'h ' + mi + 'm'],
        ['Database', ok(m.database.ok) + ' ' + (m.database.latencyMs != null ? m.database.latencyMs + ' ms' : '')],
        ['Google Safe Browsing', m.threatIntel.googleSafeBrowsing.configured ? 'configured · ' + m.threatIntel.googleSafeBrowsing.calls + ' calls' : 'not configured (heuristic-only)'],
        ['Rate-limit headroom (URL checks)', (rl.remaining != null ? rl.remaining : '-') + ' / ' + (rl.limitPerMinute || '-') + ' per min'],
        ['ML models', 'email ' + (m.models.email.loaded ? 'loaded' : 'missing') + ', SMS ' + (m.models.sms.loaded ? 'loaded' : 'missing')],
        ['Active sessions', fmt(m.database.activeSessions)],
        ['Failed logins (24 h)', fmt(m.database.failedLogins24h)],
        ['Real-app assessment path', m.assessment.realAppPath ? '<span class="wm-ok">enabled</span>' : 'simulated fallback'],
      ];
      document.getElementById('wmMx').innerHTML = '<div class="wm-kv">' + kv.map(function (p) {
        return '<div><small>' + esc(p[0]) + '</small><span>' + p[1] + '</span></div>';
      }).join('') + '</div><pre>' + esc(JSON.stringify(m, null, 2)) + '</pre>';
    }).catch(function (e) { document.getElementById('wmMx').textContent = 'Could not load metrics: ' + e.message; });
  }

  /* ---- live panel ---- */
  var last = {};
  function setNum(id, v) {
    var el = document.getElementById(id);
    if (!el) return;
    if (last[id] != null && v > last[id]) { el.classList.add('bump'); setTimeout(function () { el.classList.remove('bump'); }, 900); }
    last[id] = v;
    el.textContent = fmt(v);
  }
  function vClass(v) {
    return /MALICIOUS|PHISHING|SCAM|VULNERABLE/.test(v) ? 'wm-v--bad' : /SUSPICIOUS/.test(v) ? 'wm-v--mid' : 'wm-v--ok';
  }
  function renderLive(s) {
    var t = s.totals, k = s.byKind;
    setNum('wmChecks', t.checks); setNum('wmThreats', t.threats); setNum('wmSusp', t.suspicious); setNum('wmAssess', t.assessments);
    var set = function (id, txt) { var el = document.getElementById(id); if (el) el.textContent = txt; };
    set('wmChecksSplit', 'URL ' + fmt(k.url) + ', email ' + fmt(k.email) + ', SMS ' + fmt(k.sms));
    set('wmThreats24', 'last 24 h: ' + fmt(s.last24h.threats) + ' of ' + fmt(s.last24h.checks) + ' checks');
    set('wmSafe', 'safe: ' + fmt(t.safe));
    set('wmAssessSplit', 'vulnerable ' + fmt(s.assessment.VULNERABLE) + ' · secure ' + fmt(s.assessment.SECURE));
    var spark = document.getElementById('wmSpark');
    if (spark) {
      var d = s.lastHalfHour, max = Math.max.apply(null, d.concat([1])), w = 300 / d.length;
      spark.innerHTML = d.map(function (n, i) {
        var h = Math.max(n ? 3 : 1, (n / max) * 38);
        return '<rect x="' + (i * w + 1).toFixed(1) + '" y="' + (40 - h).toFixed(1) + '" width="' + (w - 2).toFixed(1) +
          '" height="' + h.toFixed(1) + '" fill="' + (n ? '#36B37E' : '#282D38') + '"><title>' + n + ' events</title></rect>';
      }).join('');
    }
    var feed = document.getElementById('wmFeed');
    if (feed) {
      feed.innerHTML = s.recent.length ? s.recent.map(function (r) {
        return '<li><span class="t">' + esc(new Date(r.ts).toLocaleTimeString()) + '</span><span>' + esc(r.kind) +
          '</span><span class="' + vClass(r.verdict) + '">' + esc(r.verdict.replace('_', ' ')) + '</span><span class="t">' + esc(r.source || '') + '</span></li>';
      }).join('') : '<li class="wm-live__empty">No checks yet - run one in the phishing console.</li>';
    }
  }
  function liveStatus(on, text) {
    var p = document.getElementById('wm-live'); if (p) p.classList.toggle('wm-live--on', on);
    var src = document.getElementById('wmLiveSrc'); if (src) src.textContent = text;
    var ol = document.getElementById('wmOnline'); if (ol) ol.textContent = on ? 'Live' : 'Reconnecting';
  }
  function startLive() {
    if (!document.getElementById('wm-live')) return;
    var pollTimer = null;
    function poll() {
      fetch('/api/activity', { credentials: 'same-origin' }).then(function (r) { return r.json(); })
        .then(function (s) { renderLive(s); liveStatus(true, 'polling every 10 s · ' + new Date().toLocaleTimeString()); })
        .catch(function () { liveStatus(false, 'offline'); });
    }
    if (!window.EventSource) { poll(); pollTimer = setInterval(poll, 10000); return; }
    var es = new EventSource('/api/activity/stream');
    var errors = 0;
    es.addEventListener('summary', function (ev) {
      errors = 0;
      renderLive(JSON.parse(ev.data));
      liveStatus(true, 'server push (SSE) · updated ' + new Date().toLocaleTimeString());
    });
    es.onerror = function () {
      errors++;
      liveStatus(false, 'reconnecting…');
      if (errors > 3 && !pollTimer) { es.close(); poll(); pollTimer = setInterval(poll, 10000); }
    };
  }

  document.addEventListener('DOMContentLoaded', function () {
    injectCss();
    nativeFetch('/api/auth/me', { credentials: 'same-origin' })
      .then(function (r) {
        if (r.status === 401) { location.href = '/login'; throw new Error('signed out'); }
        return r.json();
      })
      .then(function (j) { me = j; window.WM_USER = j.user; renderUser(); gateViewer(); startLive(); })
      .catch(function () { /* redirecting */ });
  });
})();
