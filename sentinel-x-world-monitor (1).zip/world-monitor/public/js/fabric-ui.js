/* =============================================================================
 * fabric-ui.js - Real-Time Verified Fabric views in the ⦿ World Monitor section.
 *   Overview "two speeds" panel · Live Feed (SSE + resume) · Alerts · India
 *   States · Trust Center. Every value comes from /api/v1; nothing is animated
 *   or counted client-side to look live.
 * ===========================================================================*/
(function () {
  'use strict';
  var root = document.getElementById('section-0');
  if (!root) return;
  var $ = function (s, el) { return (el || root).querySelector(s); };
  var $$ = function (s, el) { return Array.prototype.slice.call((el || root).querySelectorAll(s)); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var NF = new Intl.NumberFormat('en-IN');
  var num = function (v) { return v == null ? '-' : NF.format(v); };
  var isAdmin = function () { return window.WM_USER && window.WM_USER.role === 'admin'; };
  function ago(iso) {
    if (!iso) return '-';
    var s = Math.round((Date.now() - Date.parse(iso)) / 1000);
    if (s < 90) return s + ' s ago'; if (s < 5400) return Math.round(s / 60) + ' min ago';
    if (s < 172800) return Math.round(s / 3600) + ' h ago'; return Math.round(s / 86400) + ' d ago';
  }
  function dur(sec) { return sec == null ? '-' : sec < 3600 ? Math.round(sec / 60) + ' min' : (sec / 3600).toFixed(sec % 3600 ? 1 : 0) + ' h'; }
  function get(url) { return fetch(url, { credentials: 'same-origin', cache: 'no-store' }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || r.status); return j; }); }); }
  function send(method, url, body) { return fetch(url, { method: method, credentials: 'same-origin', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) }).then(function (r) { return r.json().then(function (j) { if (!r.ok) throw new Error(j.error || r.status); return j; }); }); }

  /* ---------------------------------------------------------------- styles */
  var st = document.createElement('style');
  st.textContent = [
    '#section-0 .F-disclaimer{font-size:11px;color:#8892A0;border:1px solid #282D38;border-radius:6px;padding:7px 12px;margin:0 0 12px;background:#161920}',
    '#section-0 #fabBanner{background:rgba(245,166,35,.12);border-color:#F5A623;color:#F5A623;font-weight:700;letter-spacing:.02em;text-align:center}',
    '#section-0 .F-st{display:inline-flex;align-items:center;gap:5px;padding:1px 7px;border-radius:3px;font:700 9px/1.6 "JetBrains Mono",monospace;text-transform:uppercase;letter-spacing:.04em;white-space:nowrap;border:1px solid}',
    '#section-0 .F-st--live{color:#36B37E;border-color:rgba(54,179,126,.4);background:rgba(54,179,126,.08)}',
    '#section-0 .F-st--recent{color:#4C8DFF;border-color:rgba(76,141,255,.4)}',
    '#section-0 .F-st--cached{color:#F5A623;border-color:rgba(245,166,35,.4)}',
    '#section-0 .F-st--stale,#section-0 .F-st--unavailable{color:#FF7A7A;border-color:rgba(255,122,122,.4)}',
    '#section-0 .F-st--periodic,#section-0 .F-st--disabled{color:#8892A0;border-color:#333A47}',
    '#section-0 .F-cls{font:600 9.5px "JetBrains Mono",monospace;color:#8892A0}',
    '#section-0 .F-two{display:grid;grid-template-columns:1.25fr 1fr;gap:12px;margin-bottom:14px}',
    '#section-0 .F-row{display:grid;grid-template-columns:1fr auto;gap:4px 10px;padding:8px 0;border-bottom:1px solid #282D38;font-size:12px}',
    '#section-0 .F-row:last-child{border-bottom:0}',
    '#section-0 .F-row small{color:#8892A0;font-size:10.5px}',
    '#section-0 .F-conn{display:inline-flex;align-items:center;gap:6px;font:600 11px "JetBrains Mono",monospace}',
    '#section-0 .F-conn i{width:8px;height:8px;border-radius:50%;background:#636B78}',
    '#section-0 .F-conn--live i{background:#36B37E}#section-0 .F-conn--reconnecting i{background:#F5A623}#section-0 .F-conn--snapshot i{background:#FF7A7A}',
    '#section-0 .F-bar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px}',
    '#section-0 .F-bar select,#section-0 .F-bar input{background:#0F1115;border:1px solid #333A47;color:#E8ECF2;border-radius:4px;padding:5px 8px;font:12px inherit}',
    '#section-0 .F-btn{padding:5px 10px;border:1px solid #333A47;border-radius:4px;background:#161920;color:#B8BFC9;font-size:11.5px;font-weight:600;cursor:pointer}',
    '#section-0 .F-btn:hover{border-color:#4C8DFF;color:#4C8DFF}',
    '#section-0 .F-ev{display:grid;grid-template-columns:100px 1fr auto;gap:10px;padding:9px 12px;border-bottom:1px solid #282D38;font-size:12px;align-items:start}',
    '#section-0 .F-ev.new{background:rgba(76,141,255,.06)}',
    '#section-0 .F-ev .t{font:11px "JetBrains Mono",monospace;color:#8892A0}',
    '#section-0 .F-ev .ti{color:#E8ECF2;font-weight:600}',
    '#section-0 .F-ev .m{margin-top:4px;display:flex;flex-wrap:wrap;gap:5px;align-items:center}',
    '#section-0 .F-sec{font:700 9px "JetBrains Mono",monospace;padding:1px 6px;border-radius:3px;border:1px solid rgba(76,141,255,.4);color:#7AAFFF}',
    '#section-0 .F-sec--partial,#section-0 .F-sec--crosswalked{border-style:dashed}',
    '#section-0 .F-sec--none{color:#636B78;border-color:#333A47}',
    '#section-0 .F-sev--critical{color:#FF7A7A}#section-0 .F-sev--high{color:#F5A623}#section-0 .F-sev--elevated{color:#F5A623}#section-0 .F-sev--watch{color:#4C8DFF}',
    '#section-0 .F-drawer{margin:0 12px 10px;padding:10px 12px;background:#0F1115;border:1px solid #282D38;border-radius:6px;font-size:11.5px;color:#B8BFC9}',
    '#section-0 .F-drawer table{width:100%;border-collapse:collapse}#section-0 .F-drawer td{padding:3px 6px;border-bottom:1px solid #1F232C;vertical-align:top}',
    '#section-0 .F-drawer td:first-child{color:#8892A0;width:180px}',
    '#section-0 .F-mono{font-family:"JetBrains Mono",monospace;font-size:10.5px;word-break:break-all}',
    '#section-0 .F-alert{border:1px solid #282D38;border-left:3px solid #636B78;border-radius:6px;padding:10px 12px;margin-bottom:8px;background:#161920}',
    '#section-0 .F-alert--critical{border-left-color:#FF7A7A}#section-0 .F-alert--high,#section-0 .F-alert--elevated{border-left-color:#F5A623}#section-0 .F-alert--watch{border-left-color:#4C8DFF}',
    '#section-0 .F-np{color:#8892A0;font-style:italic}',
    '#section-0 .F-ok{color:#36B37E}#section-0 .F-no{color:#636B78}',
    '#section-0 #fabAlertBadge{display:inline-block;min-width:14px;font:700 9px "JetBrains Mono",monospace;color:#0F1115;background:#F5A623;border-radius:7px;padding:0 4px;margin-left:4px}',
    '#section-0 #fabAlertBadge:empty{display:none}',
    '@media(max-width:1100px){#section-0 .F-two{grid-template-columns:1fr}#section-0 .F-ev{grid-template-columns:1fr}}',
  ].join('\n');
  document.head.appendChild(st);

  var META = null;
  function badge(state) { return '<span class="F-st F-st--' + esc(state) + '">' + esc({ live: '● live', recent: '◐ recent', cached: '◌ cached', stale: '✕ stale', unavailable: '✕ unavailable', periodic: 'periodic', disabled: 'off' }[state] || state) + '</span>'; }
  function banner(meta) {
    META = meta;
    var b = $('#fabBanner');
    if (meta && meta.banner) { b.hidden = false; b.textContent = '' + meta.banner; } else b.hidden = true;
  }
  function secChips(m) {
    if (!m || !m.sections || !m.sections.length) return '<span class="F-sec F-sec--none" title="' + esc(m && m.rationale) + '">not mapped</span>';
    return m.sections.map(function (s) { return '<span class="F-sec F-sec--' + esc(m.status) + '" title="' + esc(m.status + ' - ' + m.rationale) + '">S' + s + ' · ' + esc(m.status) + '</span>'; }).join('');
  }

  /* ---------------------------------------------------------------- overview: two speeds */
  function renderTwoSpeed() {
    return get('/api/v1/observatory/overview').then(function (j) {
      banner(j.meta);
      var d = j.data;
      var live = d.liveLayer.map(function (s) {
        var f = s.freshness;
        return '<div class="F-row"><div><b>' + esc(s.organization.split(' (')[0]) + '</b> - ' + esc(s.title.split(' - ')[0]) +
          '<br><small>' + esc(s.cadence.split('.')[0]) + '. Live window ' + dur(s.freshnessWindowSec) + '.</small></div>' +
          '<div style="text-align:right">' + badge(f.state) + '<br><small>' + (f.lastSuccessAt ? 'validated ' + ago(f.lastSuccessAt) : 'no validated response yet') + '</small>' +
          '<br><small>' + num(s.newSinceMonitoring24h) + ' new in 24 h · ' + num(s.publishedLast7d) + ' published in 7 d</small></div></div>';
      }).join('');
      var per = d.periodicBaseline.map(function (s) {
        return '<div class="F-row"><div><b>' + esc(s.title.split(' - ')[0].slice(0, 90)) + '</b><br><small>' + esc(s.organization) + '</small></div><div style="text-align:right">' + badge('periodic') +
          '<br><small>' + esc(s.cadence.split(';')[0].split('.')[0]) + '</small></div></div>';
      }).join('');
      var secTable = '<div class="O-scroll"><table class="Ztbl" style="margin-top:8px"><thead><tr><th>Section</th><th class="num">India - 24h</th><th class="num">India - 7d</th><th class="num">World - 24h</th><th class="num">World - 7d</th></tr></thead><tbody>' +
        d.bySection.map(function (x) {
          return '<tr><td><b>S' + x.section + '</b> ' + esc(x.label) + '</td><td class="num">' + num(x.india.signals24h) + '</td><td class="num">' + num(x.india.signals7d) +
            '</td><td class="num">' + num(x.world.signals24h) + '</td><td class="num">' + num(x.world.signals7d) + '</td></tr>';
        }).join('') + '</tbody></table></div>';
      $('#fabTwoSpeed').innerHTML = '<div class="F-two"><div class="O-card"><h3>Polled signal layer <span class="O-badge O-badge--live" style="margin-left:auto">CISA 1 h · NVD 2 h · CERT-In 30 min</span></h3>' + live +
        '<div class="O-foot">These are vulnerability, exploitation and advisory publications mapped to Sections 1-3, not confirmed attacks.</div></div>' +
        '<div class="O-card"><h3>Periodic official baseline <span class="O-badge O-badge--reference" style="margin-left:auto">not live</span></h3>' + per +
        '<div class="O-foot">Complaints, police cases, losses and convictions are published periodically; each figure shows its period and source.</div></div></div>' +
        '<div class="O-card"><h3>How many, by Section - India vs World <span class="O-badge O-badge--live" style="margin-left:auto">count from latest polls</span></h3>' + secTable +
        '<div class="O-foot">India = CERT-In vulnerability notes (national jurisdiction). World = CISA KEV + NVD (global feeds, not India-specific). Separate feeds - never added together as one attack total. See the <b>By Attack Section</b> tab for detail per section.</div></div>';
    }).catch(function (e) { $('#fabTwoSpeed').innerHTML = '<div class="O-banner">Signal fabric unavailable: ' + esc(e.message) + '</div>'; });
  }

  /* ---------------------------------------------------------------- live feed */
  var feed = { items: [], seen: {}, lastEventId: null, state: 'connecting', es: null, errors: 0, poll: null };
  function filters() {
    var p = new URLSearchParams();
    var s = $('#fabFSec'), so = $('#fabFSrc'), q = $('#fabFQ');
    if (s && s.value) p.set('section', s.value);
    if (so && so.value) p.set('source', so.value);
    if (q && q.value.trim()) p.set('q', q.value.trim());
    if ($('#fabFSecondary') && $('#fabFSecondary').checked) p.set('includeSecondary', 'true');
    p.set('pageSize', '60');
    return p;
  }
  function evRow(e, isNew) {
    return '<div class="F-ev' + (isNew ? ' new' : '') + '" data-ev="' + e.id + '"><div class="t">' + esc(e.eventTime) + (e.eventTimePrecision === 'date' ? '<br>(date only)' : '') +
      '<br>ingested ' + esc(ago(e.ingestedAt)) + '</div><div><div class="ti">' + (e.severity ? '<span class="F-sev--' + esc(e.severity) + '">■</span> ' : '') + esc(e.title) + '</div>' +
      '<div class="m"><span class="F-cls">' + esc(e.organization ? e.organization.split(' (')[0].split(',')[0] : e.sourceId) + ' · ' + esc(e.sourceClass) + '</span>' + secChips(e.mapping) +
      '<span class="F-cls">evidence: ' + esc(e.evidenceStatus) + '</span>' + (e.version > 1 ? '<span class="F-cls">corrected v' + e.version + '</span>' : '') + '</div></div>' +
      '<div><button class="F-btn" data-evidence="' + e.id + '">Evidence</button> <a class="F-btn" href="' + esc(e.url) + '" target="_blank" rel="noopener">Source ↗</a></div></div>';
  }
  function renderFeedList() {
    var list = $('#fabFeedList');
    if (!list) return;
    list.innerHTML = feed.items.length ? feed.items.map(function (x) { return evRow(x.e, x.isNew); }).join('') :
      '<div class="O-foot" style="padding:14px">No validated events match. Nothing is shown until a source responds and its data passes validation.</div>';
  }
  function connState(state, detail) {
    feed.state = state;
    var el = $('#fabConn');
    if (el) el.innerHTML = '<span class="F-conn F-conn--' + state + '"><i></i>' + esc({ connecting: 'Connecting…', live: 'Connected (Server-Sent Events)', reconnecting: 'Reconnecting…', snapshot: 'Snapshot mode - live delivery unavailable' }[state]) + '</span>' +
      ' <span class="F-cls">last event id: ' + esc(feed.lastEventId == null ? '-' : feed.lastEventId) + (detail ? ' · ' + esc(detail) : '') + '</span>';
  }
  function loadFeed() {
    return get('/api/v1/observatory/feed?' + filters().toString()).then(function (j) {
      banner(j.meta);
      feed.items = j.data.map(function (e) { feed.seen[e.id] = true; return { e: e, isNew: false }; });
      feed.total = j.meta.pagination.total; feed.warning = j.meta.warnings[0];
      $('#fabFeedMeta').textContent = num(feed.total) + ' validated events · ' + feed.warning;
      renderFeedList();
    });
  }
  function matches(e) {
    var p = filters();
    if (p.get('section') && e.mapping.sections.indexOf(Number(p.get('section'))) < 0) return false;
    if (p.get('source') && e.sourceId !== p.get('source')) return false;
    if (!p.get('includeSecondary') && e.sourceId === 'hibp-breaches') return false;
    if (p.get('q') && (e.title + e.nativeId).toLowerCase().indexOf(p.get('q').toLowerCase()) < 0) return false;
    return true;
  }
  function connect() {
    if (feed.es || !window.EventSource) { if (!window.EventSource) snapshotMode(); return; }
    connState('connecting');
    var es = new EventSource('/api/v1/stream');          // the browser re-sends Last-Event-ID on reconnect
    feed.es = es;
    es.addEventListener('hello', function (m) { feed.errors = 0; connState('live', 'server head ' + JSON.parse(m.data).headSeq); });
    es.addEventListener('event.new', function (m) {
      feed.lastEventId = m.lastEventId; connState('live');
      var p = JSON.parse(m.data);
      if (feed.seen[p.id]) return;                          // never render twice
      feed.seen[p.id] = true;
      get('/api/v1/observatory/events/' + p.id).then(function (j) {
        var e = j.data.event;
        if (!matches(e)) return;
        feed.items.unshift({ e: e, isNew: true });
        feed.total = (feed.total || 0) + 1;
        var fm = $('#fabFeedMeta'); if (fm) fm.textContent = num(feed.total) + ' validated events (live) · ' + (feed.warning || '');
        feed.items = feed.items.slice(0, 200);
        renderFeedList();
      });
    });
    es.addEventListener('event.corrected', function (m) { feed.lastEventId = m.lastEventId; loadFeed(); });
    es.addEventListener('feed.health', function (m) { feed.lastEventId = m.lastEventId; connState('live'); renderTwoSpeed(); });
    es.addEventListener('ingestion.batch', function (m) { feed.lastEventId = m.lastEventId; connState('live', 'last batch: ' + JSON.parse(m.data).sourceId); });
    es.addEventListener('alert.new', function (m) { feed.lastEventId = m.lastEventId; refreshAlertBadge(); if ($('#z0-alerts').classList.contains('on')) renderAlerts(); });
    es.addEventListener('alert.updated', function (m) { feed.lastEventId = m.lastEventId; refreshAlertBadge(); });
    es.addEventListener('resync', function () { loadFeed(); });
    es.onerror = function () {
      feed.errors++;
      connState('reconnecting', 'attempt ' + feed.errors);
      if (feed.errors > 5) { es.close(); feed.es = null; snapshotMode(); }
    };
  }
  function snapshotMode() {
    connState('snapshot', 'refreshing every 60 s');
    if (!feed.poll) feed.poll = setInterval(function () { loadFeed().then(function () { connState('snapshot', 'snapshot loaded ' + new Date().toLocaleTimeString()); }).catch(function () {}); }, 60000);
  }
  function evidence(id, host) {
    get('/api/v1/observatory/events/' + id).then(function (j) {
      var e = j.data.event, s = j.data.source, p = e.provenance, g = e.geography;
      var loc = function (v) { return v == null ? '<span class="F-np">Not published by source</span>' : esc(v); };
      host.insertAdjacentHTML('afterend', '<div class="F-drawer" data-drawer="' + id + '"><b>Why this record exists</b><table>' +
        '<tr><td>Source</td><td>' + esc(s.organization) + ' - <a href="' + esc(s.landing) + '" target="_blank" rel="noopener" style="color:#4C8DFF">' + esc(s.title) + ' ↗</a></td></tr>' +
        '<tr><td>Source class · freshness</td><td>' + esc(s.sourceClass) + ' · ' + badge(s.freshness.state) + '</td></tr>' +
        '<tr><td>Native identifier · version</td><td class="F-mono">' + esc(e.nativeId) + ' · v' + e.version + ' (' + j.data.versions.length + ' version(s))</td></tr>' +
        '<tr><td>Event time (source)</td><td>' + esc(e.eventTime) + ' · ' + esc(e.eventTimePrecision) + ' · ' + esc(e.sourceTimezone) + '</td></tr>' +
        '<tr><td>Retrieved · ingested</td><td>' + esc(p.retrievedAt) + ' · ' + esc(e.ingestedAt) + (p.latencyMs != null ? ' · fetch ' + p.latencyMs + ' ms' : '') + '</td></tr>' +
        '<tr><td>Raw receipt</td><td class="F-mono">#' + esc(p.receiptId) + ' sha256 ' + esc(p.contentHash) + (isAdmin() ? ' · <a href="/api/v1/admin/receipts/' + p.receiptId + '/raw" target="_blank" rel="noopener" style="color:#4C8DFF">view raw ↗</a>' : '') + '</td></tr>' +
        '<tr><td>Request</td><td class="F-mono">' + esc(p.requestUrl) + '</td></tr>' +
        '<tr><td>Section mapping</td><td>' + secChips(e.mapping) + '<br>' + esc(e.mapping.rationale) + ' <span class="F-cls">(' + esc(e.mapping.version) + ')</span></td></tr>' +
        '<tr><td>CWE · CVSS</td><td>' + esc((e.cwes || []).join(', ') || 'Not published by source') + ' · ' + esc(e.cvss == null ? 'Not published' : e.cvss) + '</td></tr>' +
        '<tr><td>Victim location</td><td>' + loc(g.victim) + '</td></tr><tr><td>Affected asset location</td><td>' + loc(g.affectedAsset) + '</td></tr>' +
        '<tr><td>Jurisdiction / reporter</td><td>' + loc(g.jurisdiction) + ' · ' + loc(g.reportingOrganisation) + '</td></tr><tr><td>Suspected attacker location</td><td>' + loc(g.attacker) + '</td></tr>' +
        '<tr><td>Limitations</td><td>' + esc(s.limitations) + '</td></tr></table></div>');
    }).catch(function (err) { host.insertAdjacentHTML('afterend', '<div class="F-drawer">Could not load evidence: ' + esc(err.message) + '</div>'); });
  }
  function renderLive() {
    var p = $('#z0-live');
    p.innerHTML = '<div class="F-bar"><span id="fabConn"></span></div>' +
      '<div class="F-bar"><select id="fabFSec" aria-label="Section"><option value="">All sections</option><option value="1">Section 1 - Individual</option><option value="2">Section 2 - Employee &amp; Manager</option><option value="3">Section 3 - Company &amp; Organization</option></select>' +
      '<select id="fabFSrc" aria-label="Source"><option value="">All sources</option><option value="cisa-kev">CISA KEV (exploited)</option><option value="nvd-cve">NVD CVEs</option><option value="certin-vulnotes">CERT-In notes</option></select>' +
      '<input id="fabFQ" placeholder="Search CVE / title" aria-label="Search">' +
      '<label class="F-cls"><input type="checkbox" id="fabFSecondary"> include secondary (non-government)</label>' +
      (isAdmin() ? '<a class="F-btn" id="fabExpCsv" href="#">Export CSV</a><a class="F-btn" id="fabExpJson" href="#">Export JSON</a>' : '') + '</div>' +
      '<div class="O-foot" id="fabFeedMeta" style="margin-bottom:6px"></div><div class="O-card" style="padding:0" id="fabFeedList"></div>';
    ['#fabFSec', '#fabFSrc', '#fabFSecondary'].forEach(function (s) { $(s).addEventListener('change', loadFeed); });
    var t; $('#fabFQ').addEventListener('input', function () { clearTimeout(t); t = setTimeout(loadFeed, 300); });
    if (isAdmin()) {
      $('#fabExpCsv').addEventListener('click', function (ev) { ev.preventDefault(); location.href = '/api/v1/export/events.csv?' + filters().toString(); });
      $('#fabExpJson').addEventListener('click', function (ev) { ev.preventDefault(); location.href = '/api/v1/export/events.json?' + filters().toString(); });
    }
    $('#fabFeedList').addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-evidence]');
      if (!b) return;
      var row = b.closest('.F-ev'), open = row.nextElementSibling;
      if (open && open.hasAttribute('data-drawer')) { open.remove(); return; }
      evidence(b.getAttribute('data-evidence'), row);
    });
    connState(feed.state);
    loadFeed().catch(function (e) { $('#fabFeedList').innerHTML = '<div class="O-banner">' + esc(e.message) + '</div>'; });
  }

  /* ---------------------------------------------------------------- alerts */
  function refreshAlertBadge() {
    get('/api/v1/alerts?state=new&limit=500').then(function (j) { $('#fabAlertBadge').textContent = j.data.length ? j.data.length : ''; }).catch(function () {});
  }
  var NEXT = { new: ['acknowledged', 'investigating', 'resolved', 'false_positive'], acknowledged: ['investigating', 'resolved', 'false_positive'], investigating: ['resolved', 'false_positive'], resolved: ['investigating'], false_positive: ['investigating'] };
  function renderAlerts() {
    var p = $('#z0-alerts');
    Promise.all([get('/api/v1/alerts?limit=200'), get('/api/v1/alerts/rules')]).then(function (r) {
      banner(r[0].meta);
      var alerts = r[0].data, rules = r[1].data;
      var list = alerts.length ? alerts.map(function (a) {
        var ev = (a.evidence.events || []).map(function (e) { return '<a href="' + esc(e.url) + '" target="_blank" rel="noopener" style="color:#4C8DFF">' + esc(e.nativeId) + ' ↗</a> <span class="F-mono">receipt #' + esc(e.receiptId) + ' ' + esc((e.contentHash || '').slice(0, 16)) + '…</span>'; }).join('<br>');
        return '<div class="F-alert F-alert--' + esc(a.level) + '"><div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><b class="F-sev--' + esc(a.level) + '">' + esc(a.level.toUpperCase()) + '</b>' +
          '<span class="F-cls">' + esc(a.type) + ' · evidence: ' + esc(a.evidenceStatus) + ' · ' + esc(a.state) + (a.occurrences > 1 ? ' · seen ×' + a.occurrences : '') + '</span>' +
          (a.sections.length ? a.sections.map(function (s) { return '<span class="F-sec">S' + s + '</span>'; }).join('') : '') +
          '<span class="F-cls" style="margin-left:auto">' + esc(a.createdAt.replace('T', ' ').slice(0, 16)) + ' UTC</span></div>' +
          '<div style="margin:6px 0;color:#E8ECF2;font-weight:600">' + esc(a.title) + '</div><div style="font-size:12px;color:#B8BFC9;line-height:1.6">' + esc(a.explanation) + '</div>' +
          '<div class="O-foot">Formula: ' + esc(a.formula || '-') + (a.baseline ? ' · Baseline: ' + esc(JSON.stringify(a.baseline)) : '') + (ev ? '<br>Evidence: ' + ev : '') + '</div>' +
          (isAdmin() ? '<div class="F-bar" style="margin:8px 0 0">' + (NEXT[a.state] || []).map(function (s) { return '<button class="F-btn" data-alert="' + a.id + '" data-to="' + s + '">→ ' + s.replace('_', ' ') + '</button>'; }).join('') + '</div>' : '') + '</div>';
      }).join('') : '<div class="O-foot">No alerts. Alerts are created only from validated source data - nothing is generated to fill this list.</div>';
      var rtab = '<table class="Ztbl"><thead><tr><th>Rule</th><th>What it detects</th><th>Parameters</th><th>State</th>' + (isAdmin() ? '<th></th>' : '') + '</tr></thead><tbody>' +
        rules.map(function (r) {
          return '<tr><td class="F-mono">' + esc(r.id) + '</td><td>' + esc(r.describe) + '</td><td class="F-mono">' + esc(JSON.stringify(r.params)) + '</td><td>' + (r.enabled ? 'enabled' : 'disabled') + (r.mutedUntil ? '<br>muted until ' + esc(r.mutedUntil.slice(0, 16)) : '') + '</td>' +
            (isAdmin() ? '<td><button class="F-btn" data-rule="' + esc(r.id) + '" data-mute="' + (r.mutedUntil ? 0 : 24) + '">' + (r.mutedUntil ? 'Unmute' : 'Mute 24 h') + '</button> <button class="F-btn" data-rule="' + esc(r.id) + '" data-enable="' + (r.enabled ? 0 : 1) + '">' + (r.enabled ? 'Disable' : 'Enable') + '</button></td>' : '') + '</tr>';
        }).join('') + '</tbody></table>';
      p.innerHTML = '<div class="O-callout" style="margin-top:0">Alerts never claim an attack happened. Source-reported items say what the source reports; statistical findings indicate an unusual pattern requiring review. Every alert links to its evidence and receipt hash.</div>' +
        (isAdmin() ? '<div class="F-bar" style="margin-top:10px"><a class="F-btn" href="/api/v1/alerts/export.json">Export alert report (JSON)</a></div>' : '') +
        '<div class="O-mt">' + list + '</div><div class="Zsh">Detection rules<span>thresholds · mutes · audited</span></div><div class="O-card O-scroll" style="padding:0">' + rtab + '</div>';
    }).catch(function (e) { p.innerHTML = '<div class="O-banner">' + esc(e.message) + '</div>'; });
  }
  root.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-alert]');
    if (b) {
      var note = b.getAttribute('data-to') === 'false_positive' || b.getAttribute('data-to') === 'resolved' ? window.prompt('Review note (recorded in the audit trail):', '') : '';
      if (note === null) return;
      send('POST', '/api/v1/alerts/' + b.getAttribute('data-alert') + '/state', { state: b.getAttribute('data-to'), note: note }).then(function () { renderAlerts(); refreshAlertBadge(); }).catch(function (e) { alert(e.message); });
      return;
    }
    var r = ev.target.closest('[data-rule]');
    if (r) {
      var body = r.hasAttribute('data-mute') ? { muteHours: Number(r.getAttribute('data-mute')) } : { enabled: r.getAttribute('data-enable') === '1' };
      send('PUT', '/api/v1/alerts/rules/' + r.getAttribute('data-rule'), body).then(renderAlerts).catch(function (e) { alert(e.message); });
      return;
    }
    var q = ev.target.closest('[data-quar]');
    if (q) {
      var n = window.prompt('Review note (required, audited):', '');
      if (!n) return;
      send('POST', '/api/v1/admin/quarantine/' + q.getAttribute('data-quar'), { action: q.getAttribute('data-act'), note: n }).then(renderTrust).catch(function (e) { alert(e.message); });
      return;
    }
    var run = ev.target.closest('[data-run-src]');
    if (run) {
      run.disabled = true; run.textContent = 'Running…';
      send('POST', '/api/v1/admin/ingestion/run', { sourceId: run.getAttribute('data-run-src') }).then(function (j) { alert(run.getAttribute('data-run-src') + ': ' + j.data.outcome + (j.data.error ? ' - ' + j.data.error : '') + (j.data.created != null ? ' · ' + j.data.created + ' new' : '')); renderTrust(); renderTwoSpeed(); })
        .catch(function (e) { alert(e.message); run.disabled = false; });
    }
  });

  /* ---------------------------------------------------------------- India states */
  var stateSort = { key: 'cases', dir: -1 };
  function cell(c) {
    if (!c) return '<span class="F-np">-</span>';
    if (c.suppressed) return '<span class="F-np" title="Suppressed small cell (public view)">' + esc(c.display) + '</span>';
    if (c.value == null) return '<span class="F-np" title="' + esc(c.reason || c.availability) + '">' + (c.availability === 'not_applicable' ? 'n/a' : 'Not published') + '</span>';
    return num(c.value);
  }
  function renderStates(year, view, level) {
    var p = $('#z0-states');
    var qs = new URLSearchParams({ year: year || '2023', level: level || 'state' });
    if (view) qs.set('view', view);
    get('/api/v1/observatory/india?' + qs).then(function (j) {
      var d = j.data, doc = d.document;
      var controls = '<div class="F-bar"><label class="F-cls">Year <select id="fabYear">' + (d.years || [2019, 2020, 2021, 2022, 2023]).map(function (y) { return '<option' + (String(y) === String(d.year || year) ? ' selected' : '') + '>' + y + '</option>'; }).join('') + '</select></label>' +
        '<label class="F-cls">Level <select id="fabLevel"><option value="state">State / UT</option><option value="district"' + (level === 'district' ? ' selected' : '') + '>District</option><option value="city"' + (level === 'city' ? ' selected' : '') + '>City</option><option value="pin"' + (level === 'pin' ? ' selected' : '') + '>PIN code</option></select></label>' +
        (isAdmin() ? '<label class="F-cls">View <select id="fabView"><option value="analyst"' + (d.view !== 'public' ? ' selected' : '') + '>Analyst (exact)</option><option value="public"' + (d.view === 'public' ? ' selected' : '') + '>Public (suppressed)</option></select></label>' : '<span class="F-cls">Public view · values below ' + esc(d.smallCellK || 3) + ' suppressed</span>') + '</div>';
      if (d.availability === 'not_published') {
        p.innerHTML = controls + '<div class="O-card"><h3>' + esc(level) + ' level ' + badge('unavailable') + '</h3><p style="font-size:13px;color:#E8ECF2">Not published by source.</p><div class="O-foot">' + esc(j.meta.warnings[0]) + '</div></div>';
        bindStates(d.year, d.view);
        return;
      }
      var rows = d.rows.slice();
      var key = { name: function (r) { return r.name; }, cases: function (r) { return r.casesRegistered.value == null ? -1 : r.casesRegistered.value; }, fraud: function (r) { return r.fraud.registered && r.fraud.registered.value != null ? r.fraud.registered.value : -1; },
        conv: function (r) { return r.fraud.convicted && r.fraud.convicted.value != null ? r.fraud.convicted.value : -1; } }[stateSort.key];
      rows.sort(function (a, b) { var x = key(a), y = key(b); return (x > y ? 1 : x < y ? -1 : 0) * stateSort.dir; });
      var th = function (k, label) { return '<th class="num" data-sort="' + k + '" style="cursor:pointer" aria-sort="' + (stateSort.key === k ? (stateSort.dir > 0 ? 'ascending' : 'descending') : 'none') + '">' + label + (stateSort.key === k ? (stateSort.dir > 0 ? ' ▲' : ' ▼') : '') + '</th>'; };
      var table = '<table class="Ztbl"><caption class="O-foot" style="text-align:left;caption-side:top;padding-bottom:6px">State/UT-wise police-registered cyber crime cases and the Fraud-head case lifecycle, ' + esc(d.year) + '. Source: ' + esc(doc.publisher) + ', ' + esc(doc.underlyingSource) + '.</caption>' +
        '<thead><tr><th data-sort="name" style="cursor:pointer">State / UT</th><th>ISO</th>' + th('cases', 'All cyber crime cases') + th('fraud', 'Fraud: registered') + '<th class="num">Charge-sheeted</th><th class="num">Trials completed</th>' + th('conv', 'Convicted') + '<th class="num">Conviction rate</th><th class="num">Persons arrested</th></tr></thead><tbody>' +
        rows.map(function (r) {
          var f = r.fraud;
          return '<tr><td><b>' + esc(r.name) + '</b>' + (r.type === 'union_territory' ? ' <span class="F-cls">UT</span>' : '') + '</td><td class="F-mono">' + esc(r.iso) + '</td><td class="num">' + cell(r.casesRegistered) + '</td><td class="num">' + cell(f.registered) +
            '</td><td class="num">' + cell(f.chargesheeted) + '</td><td class="num">' + cell(f.trialsCompleted) + '</td><td class="num">' + cell(f.convicted) + '</td><td class="num">' + (f.convictionRatePct && f.convictionRatePct.value != null ? f.convictionRatePct.value.toFixed(1) + '%' : cell(f.convictionRatePct)) + '</td><td class="num">' + cell(f.personsArrested) + '</td></tr>';
        }).join('') + '<tr style="border-top:2px solid #333A47"><td><b>All India (published total)</b></td><td class="F-mono">IN</td><td class="num"><b>' + num(d.totals.all) + '</b></td><td class="num">' + num(d.fraudTotals.registered) + '</td><td class="num">' + num(d.fraudTotals.chargesheeted) +
        '</td><td class="num">' + num(d.fraudTotals.trialsCompleted) + '</td><td class="num">' + num(d.fraudTotals.convicted) + '</td><td class="num">' + (d.fraudTotals.convictionRatePct != null ? d.fraudTotals.convictionRatePct.toFixed(1) + '%' : '-') + '</td><td class="num">' + num(d.fraudTotals.personsArrested) + '</td></tr></tbody></table>';
      var heads = '<table class="Ztbl"><thead><tr><th>NCRB crime head</th><th>Law</th><th class="num">Cases ' + esc(d.year) + '</th><th>Section mapping</th></tr></thead><tbody>' + d.crimeHeads.map(function (h) {
        return '<tr><td>' + esc(h.name) + '</td><td class="F-cls">' + esc(h.group) + '</td><td class="num">' + num(h.value) + '</td><td>' + secChips(h.mapping) + '<div class="O-foot" style="margin-top:2px">' + esc(h.mapping.rationale) + '</div></td></tr>';
      }).join('') + '</tbody></table>';
      p.innerHTML = controls +
        '<div class="O-card"><h3>Source ' + badge('periodic') + '</h3><div style="font-size:12.5px;color:#E8ECF2">' + esc(doc.title) + '</div><div class="O-foot">' + esc(doc.publisher) + ' · document ' + esc(doc.documentDate) + ' · period ' + esc(doc.reportingPeriod) +
        ' · <a href="' + esc(doc.url) + '" target="_blank" rel="noopener" style="color:#4C8DFF">official PDF ↗</a> · extract sha256 <span class="F-mono">' + esc(doc.extractSha256.slice(0, 16)) + '…</span><br>Verification: ' + doc.verification.map(esc).join(' · ') + '</div></div>' +
        '<div class="O-callout">' + esc(doc.caution) + ' ' + esc(doc.definitions.registered) + ' ' + esc(doc.definitions.lifecycle) + '</div>' +
        '<div class="O-card O-mt O-scroll" style="padding:0">' + table + '</div>' +
        '<div class="Zsh">Crime heads and their Section 1-3 mapping<span>' + esc(d.year) + ' · crosswalk</span></div><div class="O-card O-scroll" style="padding:0">' + heads + '</div>' +
        '<div class="Zsh">Not published by these sources<span>shown, never filled with 0</span></div><div class="O-card">' + d.notPublished.map(function (n) { return '<div class="F-row"><div><b>' + esc(n.metric) + '</b><br><small>' + esc(n.reason) + '</small></div><div>' + badge('unavailable') + '</div></div>'; }).join('') + '</div>';
      bindStates(d.year, d.view);
    }).catch(function (e) { p.innerHTML = '<div class="O-banner">' + esc(e.message) + '</div>'; });
  }
  function bindStates(year, view) {
    var y = $('#fabYear'), l = $('#fabLevel'), v = $('#fabView');
    var go = function () { renderStates(y.value, v ? v.value : null, l.value); };
    y.addEventListener('change', go); l.addEventListener('change', go); if (v) v.addEventListener('change', go);
    $$('#z0-states [data-sort]').forEach(function (h) {
      h.addEventListener('click', function () { var k = h.getAttribute('data-sort'); stateSort = { key: k, dir: stateSort.key === k ? -stateSort.dir : (k === 'name' ? 1 : -1) }; renderStates(year, v ? v.value : view, 'state'); });
    });
  }

  /* ---------------------------------------------------------------- trust center */
  function renderTrust() {
    var p = $('#z0-trust');
    var calls = [get('/api/v1/observatory/data-quality')];
    if (isAdmin()) calls.push(get('/api/v1/admin/quarantine'), get('/api/v1/admin/ingestion/runs?pageSize=15'));
    Promise.all(calls).then(function (r) {
      var d = r[0].data;
      var yes = function (b) { return b ? '<span class="F-ok">✔</span>' : '<span class="F-no">-</span>'; };
      var q = {}; d.quality.forEach(function (x) { q[x.sourceId] = x; });
      var matrix = '<table class="Ztbl"><thead><tr><th>Source endpoint</th><th>Class</th><th>Cadence</th><th>State</th><th>S1</th><th>S2</th><th>S3</th><th>Country</th><th>India</th><th>State/UT</th><th>District</th><th>City</th><th>PIN</th><th>Quality*</th><th>Decision</th></tr></thead><tbody>' +
        d.coverageMatrix.map(function (m) {
          var s = d.sources.find(function (x) { return x.id === m.sourceId; });
          return '<tr><td><b>' + esc(m.organization.split(' (')[0]) + '</b><br><a class="F-mono" href="' + esc(m.url) + '" target="_blank" rel="noopener" style="color:#4C8DFF">' + esc(m.url.replace('https://', '').slice(0, 60)) + '</a></td><td class="F-cls">' + esc(m.sourceClass) + '</td><td style="font-size:11px">' + esc((m.cadence || '').split('.')[0]) + '</td><td>' + badge(s.freshness.state) +
            (s.freshness.ageSec != null ? '<br><span class="F-cls">age ' + dur(s.freshness.ageSec) + ' / window ' + dur(s.freshness.freshnessWindowSec) + '</span>' : '') + (s.freshness.consecutiveFailures ? '<br><span class="F-sev--critical F-cls">' + s.freshness.consecutiveFailures + ' failure(s): ' + esc(s.freshness.lastError) + '</span>' : '') +
            '</td><td>' + yes(m.section1) + '</td><td>' + yes(m.section2) + '</td><td>' + yes(m.section3) + '</td><td>' + yes(m.country) + '</td><td>' + yes(m.india) + '</td><td>' + yes(m.stateUT) + '</td><td>' + yes(m.district) + '</td><td>' + yes(m.city) + '</td><td>' + yes(m.pin) +
            '</td><td class="num">' + (q[m.sourceId] ? q[m.sourceId].score : '-') + '</td><td style="font-size:11px">' + esc(m.decision) + (isAdmin() && s.hasAdapter && s.enabled ? '<br><button class="F-btn" data-run-src="' + esc(m.sourceId) + '">Run now</button>' : '') + '</td></tr>';
        }).join('') + '</tbody></table>';
      var html = '<div class="O-callout" style="margin-top:0"><b>No verified public source currently provides a complete, real-time, worldwide, PIN-code-level cybercrime incident ledger.</b> World Monitor combines near-current vulnerability and advisory feeds (measured freshness) with periodic official statistics, and shows which is which.</div>' +
        '<div class="Zsh">Source coverage matrix<span>one row per endpoint · verified ' + esc(d.sources[0].lastVerifiedAt) + '</span></div><div class="O-card O-scroll" style="padding:0">' + matrix + '</div><div class="O-foot">* ' + esc(d.qualityScoreNote) + '</div>' +
        '<div class="O-grid2"><div class="O-card"><h3>Unavailable metrics</h3>' + d.notPublished.map(function (n) { return '<div class="F-row"><div><b>' + esc(n.metric) + '</b><br><small>' + esc(n.reason) + '</small></div><div>' + badge('unavailable') + '</div></div>'; }).join('') + '</div>' +
        '<div class="O-card"><h3>Taxonomy &amp; estimation policy</h3><div style="font-size:12px;color:#B8BFC9;line-height:1.7">Crosswalk <span class="F-mono">' + esc(d.taxonomy.version) + '</span> · statuses: ' + d.taxonomy.statuses.map(esc).join(', ') + '<br>' + d.taxonomy.limitations.map(esc).join('<br>') +
        '<br><br>Estimates: <b>' + (d.estimationPolicy.enabled ? 'enabled (always marked *)' : 'disabled') + '</b> - ' + esc(d.estimationPolicy.switch) + '<br>' + esc(d.estimationPolicy.note) + '</div>' +
        '<h3 style="margin-top:12px">Tamper-evident audit</h3><div style="font-size:12px">' + (d.audit.ok ? '<span class="F-ok">✔ chain intact</span> · ' + num(d.audit.checked) + ' entries · head <span class="F-mono">' + esc((d.audit.head || '').slice(0, 16)) + '…</span>' : '<span class="F-sev--critical">✕ chain broken at entry ' + esc(d.audit.brokenAt) + '</span>') + '</div></div></div>';
      if (isAdmin()) {
        var qu = r[1].data, runs = r[2].data;
        html += '<div class="Zsh">Quarantine review queue<span>' + qu.length + ' open · nothing is silently dropped</span></div><div class="O-card O-scroll" style="padding:0"><table class="Ztbl"><thead><tr><th>#</th><th>Source</th><th>Record</th><th>Validation failure</th><th>Proposed action</th><th></th></tr></thead><tbody>' +
          (qu.length ? qu.map(function (x) { return '<tr><td>' + x.id + '</td><td class="F-mono">' + esc(x.source_id) + '<br>receipt #' + esc(x.receipt_id) + '</td><td class="F-mono">' + esc(x.native_id || '(whole response)') + '</td><td>' + esc(x.reason) + '</td><td style="font-size:11px">' + esc(x.proposed_action) + '</td><td>' +
            (x.native_id ? '' : '<button class="F-btn" data-quar="' + x.id + '" data-act="release">Accept change</button> ') + '<button class="F-btn" data-quar="' + x.id + '" data-act="reject">Reject</button></td></tr>'; }).join('') : '<tr><td colspan="6" class="O-foot">Queue empty.</td></tr>') + '</tbody></table></div>' +
          '<div class="Zsh">Recent ingestion runs<span>immutable receipts</span></div><div class="O-card O-scroll" style="padding:0"><table class="Ztbl"><thead><tr><th>#</th><th>Source</th><th>Requested (UTC)</th><th>Outcome</th><th class="num">Latency</th><th class="num">Seen / new / corrected / quarantined</th><th>sha256</th></tr></thead><tbody>' +
          runs.map(function (x) { return '<tr><td>' + x.id + '</td><td class="F-mono">' + esc(x.source_id) + '<br><span class="F-cls">' + esc(x.trigger) + '</span></td><td class="F-mono">' + esc((x.requested_at || '').replace('T', ' ').slice(0, 19)) + '</td><td>' + esc(x.outcome) + (x.error ? '<br><span class="F-cls">' + esc(x.error) + '</span>' : '') + '</td><td class="num">' + (x.latency_ms != null ? x.latency_ms + ' ms' : '-') +
            '</td><td class="num">' + [x.records_seen, x.records_new, x.records_corrected, x.records_quarantined].join(' / ') + '</td><td class="F-mono">' + esc((x.content_hash || '').slice(0, 12)) + (x.content_hash ? '…' : '') + (x.outcome === 'validated' ? ' <a href="/api/v1/admin/receipts/' + x.id + '/raw" target="_blank" rel="noopener" style="color:#4C8DFF">raw ↗</a>' : '') + '</td></tr>'; }).join('') + '</tbody></table></div>';
      }
      p.innerHTML = html;
    }).catch(function (e) { p.innerHTML = '<div class="O-banner">' + esc(e.message) + '</div>'; });
  }

  /* ---------------------------------------------------------------- wiring */
  var R = { live: renderLive, states: function () { renderStates('2023', null, 'state'); }, alerts: renderAlerts, trust: renderTrust };
  $$('#z0t button').forEach(function (b) {
    b.addEventListener('click', function () { var z = b.getAttribute('data-z'); if (R[z]) R[z](); });
  });
  function boot() {
    renderTwoSpeed();
    refreshAlertBadge();
    connect();
  }
  if (window.WM_USER) boot();
  else { var tries = 0, t = setInterval(function () { if (window.WM_USER || ++tries > 50) { clearInterval(t); boot(); } }, 100); }
})();
