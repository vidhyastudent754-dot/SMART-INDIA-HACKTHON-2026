/* Moved out of index.html so the page runs under a CSP without 'unsafe-inline'. */
(function(){
  const tabs = Array.from(document.querySelectorAll('#sx-tabbar button'));
  const secs = Array.from(document.querySelectorAll('.sx-section'));
  function activate(id){
    tabs.forEach(t => t.classList.toggle('is-active', t.dataset.sxTarget === id));
    secs.forEach(s => s.classList.toggle('is-active', s.id === id));
    window.dispatchEvent(new CustomEvent('sx:section', { detail: id }));
  }
  // friendly addresses (#individual …) so the browser never jumps to a section anchor
  const NAME = { 'section-1': 'individual', 'section-2': 'employee', 'section-4': 'organisation', 'section-3': 'awareness' };
  const fromHash = (h) => Object.keys(NAME).find(k => NAME[k] === h || k === h);
  tabs.forEach(t => t.addEventListener('click', () => { history.replaceState(null, '', '#' + NAME[t.dataset.sxTarget]); activate(t.dataset.sxTarget); window.scrollTo(0, 0); }));
  window.addEventListener('hashchange', () => { const id = fromHash(location.hash.slice(1)); if (id) { activate(id); window.scrollTo(0, 0); } });
  activate(fromHash(location.hash.slice(1)) || 'section-1');
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  window.addEventListener('load', () => setTimeout(() => window.scrollTo(0, 0), 0));
  setTimeout(() => window.scrollTo(0, 0), 0);
})();
