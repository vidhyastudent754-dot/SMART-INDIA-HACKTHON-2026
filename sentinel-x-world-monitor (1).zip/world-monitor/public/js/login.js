/* Moved out of login.html so the page runs under a CSP without 'unsafe-inline'. */
(function () {
  var f = document.getElementById('f'), b = document.getElementById('b'), e = document.getElementById('e'), p = document.getElementById('p');
  document.getElementById('show').addEventListener('click', function () {
    var hidden = p.type === 'password'; p.type = hidden ? 'text' : 'password'; this.textContent = hidden ? 'Hide' : 'Show'; p.focus();
  });
  // only allow same-site relative redirects (no //evil.com, no javascript:)
  var next = new URLSearchParams(location.search).get('next') || '/';
  if (!/^\/(?!\/)/.test(next) || next.indexOf('/login') === 0) next = '/';
  f.addEventListener('submit', async function (ev) {
    ev.preventDefault();
    if (!f.username.value.trim() || !f.password.value) { e.textContent = 'Enter your username and password.'; return; }
    e.textContent = ''; b.disabled = true; b.textContent = 'Signing in…';
    try {
      var r = await fetch('/api/auth/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, credentials: 'same-origin',
        body: JSON.stringify({ username: f.username.value.trim(), password: f.password.value })
      });
      var j = await r.json().catch(function () { return {}; });
      if (r.ok) { location.replace(next); return; }
      e.textContent = r.status === 429 ? 'Too many attempts. Wait a few minutes and try again.'
        : r.status === 401 ? 'That username and password don\'t match. Check the terminal where you ran npm start.'
        : (j.error || 'Sign-in failed (HTTP ' + r.status + ').');
      f.password.value = ''; f.password.focus();
    } catch (err) {
      e.textContent = 'Can\'t reach the server. Is npm start still running?';
    } finally { b.disabled = false; b.textContent = 'Sign in'; }
  });
})();
