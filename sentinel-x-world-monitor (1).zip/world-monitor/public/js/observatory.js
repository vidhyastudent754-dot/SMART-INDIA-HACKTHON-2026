/* Moved out of observatory.html so the page runs under a CSP without 'unsafe-inline'. */
'use strict';
const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const api=p=>fetch('/api/gio'+p,{credentials:'same-origin'}).then(r=>{if(!r.ok)throw new Error(p+' '+r.status);return r.json();});
const FACTS={}; const reg=f=>{if(f&&f.id)FACTS[f.id]=f;return f;};
const NA='<span class="na">Not published</span>';
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('on');clearTimeout(toast.t);toast.t=setTimeout(()=>t.classList.remove('on'),4200);}
function ago(iso){ if(!iso) return ''; const s=Math.max(0,(Date.now()-Date.parse(iso))/1000);
  if(s<60) return 'just now'; if(s<3600) return Math.round(s/60)+' min ago'; if(s<86400) return Math.round(s/3600)+' h ago'; return Math.round(s/86400)+' days ago'; }

/* numbers: Indian grouping, money in words, crore kept as crore */
function fmt(f){ if(!f) return '-'; const n=f.numeric; if(n==null) return esc(f.value);
  const u=String(f.unit||'');
  if(/crore|lakh/i.test(u)) return Number(n).toLocaleString('en-IN',{maximumFractionDigits:2});
  const money=/USD|SGD|INR|EUR|GBP/i.test(u);
  if(money&&Math.abs(n)>=1e12) return (n/1e12).toFixed(1).replace(/\.0$/,'')+' trillion';
  if(money&&Math.abs(n)>=1e9) return (n/1e9).toFixed(2).replace(/\.?0+$/,'')+' billion';
  if(money&&Math.abs(n)>=1e6) return (n/1e6).toFixed(1).replace(/\.0$/,'')+' million';
  return Number(n).toLocaleString('en-IN',{maximumFractionDigits:2}); }
function unit(f){ const u=String(f&&f.unit||''); if(/crore INR|INR crore/i.test(u)) return '₹ crore'; if(/^USD$/i.test(u)) return 'USD'; return u; }
function srcLink(f,label){ return f&&f.sourceUrl?'<a class="src" href="'+esc(f.sourceUrl)+'" target="_blank" rel="noopener" title="'+esc(f.sourceName)+'">'+(label||'Source')+'</a>':''; }
function cell(f,opt){ if(!f||f.status==='NOT_PUBLISHED') return NA; reg(f);
  return '<span data-f="'+esc(f.id)+'" style="cursor:pointer"><b style="font-weight:500">'+fmt(f)+'</b> '+(opt&&opt.nounit?'':'<span class="muted">'+esc(unit(f))+'</span>')+'</span>'+
    (opt&&opt.meta?'<span class="u muted">'+esc([f.period,f.geography].filter(Boolean).join(', '))+'</span>':'')+srcLink(f); }
function badge(f){ if(!f) return ''; if(/^EST-/.test(f.id)) return '<span class="tag est">Forecast</span>'; if(/survey|yubico/i.test(f.sourceId)) return '<span class="tag">Survey</span>'; return ''; }

/* ---------------------------------------------------------------- charts */
function kpi(f,cls){ const c=document.createElement('div'); c.className='sx-card kpi2 '+cls;
  if(!f||f.status==='NOT_PUBLISHED'){ c.innerHTML='<div class="kpi2__l">'+esc(f&&f.label)+'</div><div class="kpi2__v">'+NA+'</div>'; return c; }
  reg(f); c.dataset.f=f.id;
  c.innerHTML='<div class="kpi2__l">'+esc(f.label)+badge(f)+'</div><div class="kpi2__v">'+fmt(f)+'<small>'+esc(unit(f))+'</small></div>'+
    '<div class="kpi2__m">'+esc(f.period)+', '+esc(f.geography)+'<br><a href="'+esc(f.sourceUrl)+'" target="_blank" rel="noopener">'+esc(f.sourceName)+'</a></div>'; return c; }
function cols(host,list,labelFn){ list=list.filter(f=>f&&f.numeric!=null); if(!list.length){host.innerHTML=NA;return;}
  const max=Math.max(...list.map(f=>f.numeric));
  host.innerHTML='<div class="cols">'+list.map(f=>{reg(f); return '<div class="col" data-f="'+esc(f.id)+'" title="'+esc(f.metric)+'"><div class="col__v">'+short(f)+'</div><div class="col__bar" style="height:'+Math.max(2,86*f.numeric/max)+'%"></div><div class="col__l">'+esc(labelFn?labelFn(f):f.period)+'</div></div>';}).join('')+'</div>'+
    '<div style="margin-top:12px">'+srcLink(list[list.length-1],'Source: '+esc(list[list.length-1].sourceName))+'</div>'; }
function short(f){ const n=f.numeric; if(/crore/i.test(f.unit)) return Number(n).toLocaleString('en-IN',{maximumFractionDigits:0});
  if(n>=1e7) return (n/1e7).toFixed(2).replace(/\.?0+$/,'')+' Cr'; if(n>=1e5) return (n/1e5).toFixed(1).replace(/\.0$/,'')+' L'; return Number(n).toLocaleString('en-IN'); }
function hbars(host,list,opts){ opts=opts||{}; list=list.filter(f=>f&&f.numeric!=null); if(!list.length){host.innerHTML=NA;return;}
  const max=Math.max(...list.map(f=>f.numeric));
  host.innerHTML='<div class="hb">'+list.map(f=>{reg(f); const lab=opts.label?opts.label(f):f.period;
    return '<div class="hb__r'+(opts.me&&opts.me(f)?' me':'')+'" data-f="'+esc(f.id)+'"><span class="hb__l" title="'+esc(lab)+'">'+esc(lab)+'</span><div class="hb__t"><div class="hb__f'+(opts.india||(opts.me&&opts.me(f))?' in':'')+'" style="width:'+Math.max(1.5,100*f.numeric/max)+'%"></div></div><span class="hb__v">'+fmt(f)+'</span></div>';}).join('')+'</div>'+
    (opts.nosrc?'':'<div style="margin-top:12px">'+srcLink(list[0],'Source: '+esc(list[0].sourceName))+'</div>'); }
function factList(list){ return '<ul class="fl">'+list.map(f=>{reg(f);return '<li data-f="'+esc(f.id)+'"><span>'+esc(cap(f.metric))+(f.category&&f.category!=='age-band'?' <small>'+esc(f.category)+'</small>':'')+'<small>'+esc([f.period,f.geography].filter(Boolean).join(', '))+'</small></span><b>'+fmt(f)+' <span class="muted" style="font-weight:400">'+esc(unit(f))+'</span>'+srcLink(f)+'</b></li>';}).join('')+'</ul>'; }
function table(host,list,colsDef){ host.innerHTML='<table class="ob"><thead><tr>'+colsDef.map(c=>'<th>'+esc(c.h)+'</th>').join('')+'</tr></thead><tbody>'+list.map(r=>'<tr>'+colsDef.map(c=>'<td'+(c.n?' class="n"':'')+'>'+c.v(r)+'</td>').join('')+'</tr>').join('')+'</tbody></table>'; }
const cap=s=>String(s||'').charAt(0).toUpperCase()+String(s||'').slice(1);

/* ---------------------------------------------------------------- views */
const VIEWS=$$('.ob-view').map(v=>v.id.slice(2));
function show(v){ if(!VIEWS.includes(v)) v='ov';
  $$('#obTabs .tab').forEach(t=>t.classList.toggle('on',t.dataset.v===v));
  $$('.ob-view').forEach(s=>s.classList.toggle('on',s.id==='v-'+v));
  if(location.hash.slice(1)!==v) history.replaceState(null,'','#'+v); }
$('#obTabs').addEventListener('click',e=>{const t=e.target.closest('.tab'); if(t){show(t.dataset.v); window.scrollTo({top:0});}});
document.addEventListener('click',e=>{const g=e.target.closest('[data-go]'); if(g){show(g.dataset.go); window.scrollTo({top:0});}});
window.addEventListener('hashchange',()=>show(location.hash.slice(1)));
show(location.hash.slice(1)||'ov');
setInterval(()=>{$('#utc').textContent=new Date().toISOString().slice(11,19);},1000);

/* ---------------------------------------------------------------- loaders */
async function loadSummary(){ const s=await api('/summary'); SUM=s; setTimeout(paintBand,0); $('#nFacts').textContent=s.factCount; $('#nSrc').textContent=s.sourceCount;
  $('#kIndia').replaceChildren(...s.india.slice(2).map(f=>kpi(f,'in'))); /* first two are in the headline band */ $('#kGlobal').replaceChildren(...s.global.map(f=>kpi(f,'gl'))); }

async function loadIndia(){ const d=await api('/india'); window.__india=d;
  cols($('#ovTrend'),d.ncrpComplaints); cols($('#chComplaints'),d.ncrpComplaints); cols($('#chLoss'),d.ncrpLoss); cols($('#chCases'),d.ncrbCases);
  hbars($('#lifecycle'),d.fraudLifecycle2023.filter(f=>!/rate/.test(f.metric)),{india:1,label:f=>cap(f.metric.replace('Fraud ','').replace(/^registered cases$/,'registered'))});
  const rate=d.fraudLifecycle2023.find(f=>/rate/.test(f.metric)); if(rate) $('#lifecycle').insertAdjacentHTML('beforeend','<p style="margin:14px 0 0;font-size:13.5px">Conviction rate: '+cell(rate)+'</p>');
  $('#pendingNote').innerHTML='Pending cases are not published - '+esc(d.pending.reason);
  $('#convictions').innerHTML=factList(d.convictions);
  const y24=Object.fromEntries(d.certIn.y2024.map(f=>[f.category||f.metric,f])), y23=Object.fromEntries(d.certIn.y2023.map(f=>[f.category||f.metric,f]));
  const keys=Object.keys(y24).filter(k=>k!=='security incidents handled');
  table($('#certin'),keys,[{h:'Incident type',v:k=>esc(cap(k))},{h:'2023',n:1,v:k=>cell(y23[k],{nounit:1})},{h:'2024',n:1,v:k=>cell(y24[k],{nounit:1})}]);
  $('#cfcfrms').innerHTML=factList(d.cfcfrms); $('#rbi').innerHTML='<p class="muted" style="font-size:12.5px;margin:0 0 4px">RBI - frauds of ₹1 lakh and above, card and internet</p>'+factList(d.rbi);
  hbars($('#heads'),d.ncrb2023Heads.filter(f=>!/^Total/.test(f.category)),{india:1,label:f=>cap(f.category)});
  hbars($('#states'),d.states,{india:1,label:f=>f.geography}); }

async function loadGlobal(){ const g=await api('/global');
  const byCat={}; g.ic3CrimeTypes.forEach(f=>{const k=f.category;(byCat[k]=byCat[k]||{})[/loss/.test(f.id)?'loss':'count']=f;});
  const list=Object.entries(byCat).map(([k,v])=>({k,...v})).sort((a,b)=>((b.loss&&b.loss.numeric)||0)-((a.loss&&a.loss.numeric)||0));
  table($('#ic3'),list,[{h:'Crime type',v:r=>esc(cap(r.k))},{h:'Complaints',n:1,v:r=>cell(r.count,{nounit:1})},{h:'Money lost (USD)',n:1,v:r=>cell(r.loss,{nounit:1})}]);
  hbars($('#apwg'),g.apwg.filter(f=>/^APWG-Q/.test(f.id)),{nosrc:1});
  hbars($('#sectors'),g.apwg.filter(f=>/sector/.test(f.id)),{label:f=>f.note.replace('Sector: ','')});
  $('#ftc').innerHTML=factList(g.ftc); $('#dbir').innerHTML=factList(g.dbir);
  $('#vulns').innerHTML=factList(g.vulnerabilities.filter(f=>!/NVD-CWE/.test(f.id))); }

let CATS=[];
async function loadAttacks(){ const d=await api('/categories'); CATS=d.categories;
  const groups=[...new Set(CATS.map(c=>c.group))];
  $('#aTabs').innerHTML=groups.map((g,i)=>'<button class="tab'+(i?'':' on')+'" data-g="'+esc(g)+'">'+esc(g)+' <span class="muted">'+CATS.filter(c=>c.group===g).length+'</span></button>').join('');
  $('#aTabs').onclick=e=>{const t=e.target.closest('.tab');if(!t)return;$$('#aTabs .tab').forEach(x=>x.classList.toggle('on',x===t));renderCats(t.dataset.g);};
  renderCats(groups[0]); }
function renderCats(g){ $('#aCards').innerHTML=CATS.filter(c=>c.group===g).map(c=>{
  const req=Object.entries(c.requestedFields).map(([k,v])=>{const ok=v&&v.status!=='NOT_PUBLISHED';if(ok)reg(v);
    return '<div class="'+(ok?'yes':'')+'" '+(ok?'data-f="'+esc(v.id)+'"':'title="'+esc(v&&v.reason)+'"')+'><span class="k">'+esc(cap(k))+'</span>'+(ok?'<b style="font-weight:500">'+fmt(v)+'</b> '+esc(unit(v)):'<span class="na">Not published</span>')+'</div>';}).join('');
  return '<div class="sx-card atk"><div class="h"><span class="id">'+esc(c.id)+'</span><span class="t">'+esc(c.title)+'</span></div>'+
    (c.note?'<p class="muted" style="margin:0 0 6px;font-size:12.5px">'+esc(c.note)+'</p>':'')+factList(c.facts)+'<div class="req">'+req+'</div></div>';}).join(''); }

function ageCell(a){ if(!a) return NA; return '<b style="font-weight:500">'+esc(a.group)+'</b><span class="u muted">'+esc(a.summary)+'</span>'+(a.sourceUrl?srcLink({sourceUrl:a.sourceUrl,sourceName:'Source'}):''); }
async function loadImpact(){ const d=await api('/attack-tables');
  table($('#tScam'),d.scams,[{h:'Scam',v:r=>'<b style="font-weight:500">'+esc(r.attack)+'</b>'},{h:'People affected / complaints',v:r=>cell(r.peopleAffected,{meta:1})},{h:'Cases filed',v:r=>cell(r.casesFiled,{meta:1})},{h:'Arrests',v:r=>cell(r.arrests,{meta:1})},{h:'Money lost',v:r=>cell(r.moneyLost,{meta:1})},{h:'India',v:r=>cell(r.india,{meta:1})},{h:'Age most targeted',v:r=>ageCell(r.ageTarget)}]);
  table($('#tApp'),d.application,[{h:'Attack',v:r=>'<b style="font-weight:500">'+esc(r.attack)+'</b><span class="u muted">'+esc(r.id)+', '+esc(r.section)+'</span>'},{h:'Weakness',v:r=>esc(r.weakness)},{h:'Vulnerable products (NVD)',v:r=>cell(r.vulnerableSoftware,{meta:1})},{h:'Apps affected (OWASP)',v:r=>cell(r.appsAffected,{meta:1})},{h:'Bug-bounty rank',v:r=>cell(r.bountyRank,{meta:1})},{h:'Age most targeted',v:r=>ageCell(r.ageTarget)},{h:'Police cases',v:r=>cell(r.realWorldCases)}]); }

async function loadAge(){ const a=await api('/age');
  const lab=f=>f.metric.replace(/^(complaints|reported losses) by complainant age /,'');
  hbars($('#ageC'),a.ic3.filter(f=>/count/.test(f.id)),{label:lab,me:f=>/60/.test(f.metric)});
  hbars($('#ageL'),a.ic3.filter(f=>/loss/.test(f.id)),{label:lab,me:f=>/60/.test(f.metric)});
  hbars($('#ovAge'),a.ic3.filter(f=>/loss/.test(f.id)),{label:lab,me:f=>/60/.test(f.metric)});
  $('#ageNote').innerHTML=esc(a.note)+(a.singapore&&a.singapore.length?' Singapore: '+a.singapore.map(f=>esc(f.metric)+' '+cell(f)).join(', '):''); }

async function loadCompare(){ const c=await api('/compare');
  table($('#cmp'),c.rows,[{h:'Country',v:r=>'<b style="font-weight:500">'+esc(r.country)+'</b>'},{h:'Complaints to FBI IC3 (2024)',n:1,v:r=>cell(r.ic3Complaints,{nounit:1})},
    {h:'World Cybercrime Index rank',n:1,v:r=>r.wciRank.status?'<span class="na">Not ranked</span>':cell(r.wciRank,{nounit:1})},
    {h:'ITU GCI 2024 tier',v:r=>r.gciTier.status?NA:cell(r.gciTier,{nounit:1})},
    {h:'National cases',n:1,v:r=>cell(r.nationalCases)},{h:'National loss',n:1,v:r=>cell(r.nationalLoss)}]);
  $('#cmpNote').textContent=c.methodology; }

async function loadEnf(){ const e=await api('/enforcement'); $('#enfList').innerHTML=factList(e.facts);
  $('#teams').innerHTML='<div class="gapc"><b style="font-weight:500">Attacker groups</b> - not published<span>'+esc(e.attackerTeams.reason)+'</span></div><div class="gapc"><b style="font-weight:500">Red teams formed</b> - not published<span>'+esc(e.redTeams.reason)+'</span></div>'; }
async function loadAware(){ const d=window.__india||await api('/india');
  $('#awareBox').innerHTML=factList(d.awareness)+'<p class="muted" style="font-size:12.5px;margin:12px 0 0">These come from surveys of a sample, not the whole population. No official national awareness percentage is published.</p>'; }
async function loadDatasets(){ const d=await api('/datasets');
  table($('#dsBox'),d.datasets,[{h:'Dataset',v:r=>'<a href="'+esc(r.url)+'" target="_blank" rel="noopener">'+esc(r.name)+'</a>'},{h:'Key numbers',v:r=>r.facts.length?r.facts.map(f=>cell(f)).join('<br>'):'<span class="muted">See the dataset</span>'},{h:'Licence',v:r=>esc(r.license)}]); }
async function loadGaps(){ const g=await api('/gaps'); $('#gapBox').innerHTML=g.requestedButNotPublished.map(x=>'<div class="gapc"><b style="font-weight:500">'+esc(x.item)+'</b><span>'+esc(x.why)+'</span></div>').join(''); }
async function loadSources(){ const s=await api('/sources');
  table($('#srcBox'),s.sources,[{h:'Source',v:r=>'<b style="font-weight:500">'+esc(r.source_name)+'</b><span class="u muted">'+esc(String(r.coverage||'').slice(0,160))+'</span>'},{h:'Link',v:r=>'<a href="'+esc((r.official_url||'').split(' ')[0])+'" target="_blank" rel="noopener" style="word-break:break-all">'+esc((r.official_url||'').split(' ')[0].replace(/^https?:\/\//,'').slice(0,60))+'</a>'},{h:'Limitations',v:r=>'<span class="muted">'+esc(String(r.limitations||'').slice(0,200))+'</span>'}]); }

/* ---------------------------------------------------------------- countries */
let CTRY=[],SEL=new Set(['India','Pakistan','China','Russia','United States','Singapore']);
const PRE={south:['India','Pakistan','Afghanistan','Bangladesh','Sri Lanka','Nepal','China','Myanmar'],gulf:['Saudi Arabia','United Arab Emirates','Iran','Iraq','Qatar','Kuwait','Oman','India']};
const scoreOf=c=>c.cyberScore&&c.cyberScore.numeric!=null?c.cyberScore.numeric:null;
async function loadCountries(){ const d=await api('/countries'); CTRY=d.countries; $('#cHow').textContent=d.howToRead||'';
  const top=CTRY.filter(c=>scoreOf(c)!=null).sort((a,b)=>scoreOf(b)-scoreOf(a)).slice(0,9); const india=CTRY.find(c=>c.country==='India');
  if(india&&!top.includes(india)) top.push(india);
  hbars($('#ovCountries'),top.map(c=>Object.assign({},c.cyberScore,{geography:c.country})),{label:f=>f.geography,me:f=>f.geography==='India',nosrc:1});
  $$('.presets button').forEach(b=>b.onclick=()=>{const p=b.dataset.p; SEL=new Set(p==='clear'?[]:p==='asia'?CTRY.filter(c=>c.region==='Asia'&&scoreOf(c)!=null).map(c=>c.country):p==='all'?CTRY.filter(c=>scoreOf(c)!=null).map(c=>c.country):PRE[p].filter(n=>CTRY.some(c=>c.country===n))); drawC();});
  $('#cSearch').oninput=drawChips; $('#cSearch').onkeydown=e=>{if(e.key==='Enter'){const m=match()[0]; if(m){SEL.add(m.country);$('#cSearch').value='';drawC();}}};
  $('#cExport').onclick=exportSel; drawC(); }
function match(){const q=$('#cSearch').value.trim().toLowerCase(); return q?CTRY.filter(c=>c.country.toLowerCase().includes(q)):[];}
function drawChips(){ const m=match(); $('#cChips').innerHTML=m.slice(0,40).map(c=>'<button data-c="'+esc(c.country)+'" class="'+(SEL.has(c.country)?'on':'')+'">'+esc(c.country)+'</button>').join('');
  $$('#cChips button').forEach(b=>b.onclick=()=>{const n=b.dataset.c; SEL.has(n)?SEL.delete(n):SEL.add(n); drawC();}); }
function drawC(){ drawChips(); const list=CTRY.filter(c=>SEL.has(c.country));
  $('#cSel').innerHTML=list.length?list.map(c=>'<button class="on" data-x="'+esc(c.country)+'" title="Remove">'+esc(c.country)+' &times;</button>').join(''):'<span class="muted" style="font-size:13px">Nothing selected - search above or pick a group.</span>';
  $$('#cSel button').forEach(b=>b.onclick=()=>{SEL.delete(b.dataset.x);drawC();});
  const scored=list.filter(c=>scoreOf(c)!=null).sort((a,b)=>scoreOf(b)-scoreOf(a));
  if(scored.length){const top=scoreOf(scored[0]); const lead=scored.filter(c=>scoreOf(c)===top).map(c=>c.country); const low=scored[scored.length-1];
    $('#cVerdict').innerHTML='Of the '+scored.length+' countries selected, <b>'+esc(lead.join(', '))+'</b> '+(lead.length>1?'have':'has')+' the most pervasive cyber crime (score '+top+' out of 10)'+(scored.length>1?' and <b>'+esc(low.country)+'</b> the least ('+scoreOf(low)+')':'')+'. The global average is 4.65.'+srcLink({sourceUrl:'https://ocindex.net/',sourceName:'GI-TOC'},'GI-TOC Organized Crime Index 2025');}
  else $('#cVerdict').textContent=list.length?'None of the selected countries has a GI-TOC cyber-crime score.':'';
  hbars($('#cRank'),scored.map(c=>Object.assign({},c.cyberScore,{geography:c.country})),{label:f=>f.geography,me:f=>f.geography==='India',nosrc:1});
  const ord=[...scored,...list.filter(c=>scoreOf(c)==null)];
  table($('#cTable'),ord,[{h:'Country',v:c=>'<b style="font-weight:500">'+esc(c.country)+'</b><span class="u muted">'+esc(c.region||'IC3 data only')+'</span>'},{h:'Cyber-crime score',v:c=>cell(c.cyberScore,{nounit:1})},{h:'Financial-crime score',v:c=>cell(c.financialScore,{nounit:1})},
    {h:'Official cases',v:c=>cell(c.cases,{meta:1})},{h:'Arrests',v:c=>cell(c.arrests,{meta:1})},{h:'Money lost',v:c=>cell(c.moneyLost,{meta:1})},{h:'Complaints to FBI IC3',v:c=>cell(c.ic3Complaints,{nounit:1})},{h:'Cybercrime Index rank',v:c=>cell(c.wciRank,{nounit:1})},{h:'ITU GCI tier',v:c=>cell(c.gciTier,{nounit:1})}]); }
function exportSel(){ const K=['cyberScore','financialScore','criminality','cases','arrests','convicted','moneyLost','ic3Complaints','wciRank','gciTier'];
  const q=v=>'"'+String(v==null?'':v).replace(/"/g,'""')+'"'; const lines=[['country','region'].concat(K.flatMap(k=>[k,k+'_unit',k+'_period',k+'_source_url'])).join(',')];
  CTRY.filter(c=>SEL.has(c.country)).forEach(c=>lines.push([c.country,c.region||''].concat(K.flatMap(k=>{const f=c[k]; return !f||f.status?['NOT_PUBLISHED','','','']:[f.value,f.unit,f.period,f.sourceUrl];})).map(q).join(',')));
  const a=document.createElement('a'); a.href=URL.createObjectURL(new Blob([lines.join('\n')],{type:'text/csv'})); a.download='country-selection.csv'; a.click(); }

/* ---------------------------------------------------------------- victim age per attack */
function bandChart(p){ const max=Math.max(...p.bands.map(b=>b.numeric||0))||1;
  return '<div class="hb">'+p.bands.map(b=>{reg(b); return '<div class="hb__r'+(b.band===p.mostAffected?' me':'')+'" data-f="'+esc(b.id)+'"><span class="hb__l">'+esc(b.band)+'</span><div class="hb__t"><div class="hb__f'+(b.band===p.mostAffected?' in':'')+'" style="width:'+Math.max(1.5,100*(b.numeric||0)/max)+'%"></div></div><span class="hb__v">'+fmt(b)+(/percent/.test(p.unit)?'%':'')+'</span></div>';}).join('')+'</div>'; }
function panelTitle(p){ return cap(p.measure.replace(/^%\s*of\s*/i,'share of ').replace(/^Scamwatch /,'')); }
async function loadVictimAge(){ const d=await api('/victim-age'); let html='', grp='';
  for(const r of d.rows){
    if(r.group!==grp){ grp=r.group; html+='<div class="ag-group">'+esc(grp)+'</div>'; }
    const panels=r.panels.filter(p=>p.bands.length>1).slice(0,2);
    const top=r.mostAffected?'<div class="ag__top">Most affected<b>'+esc(r.mostAffected.band)+'</b>Highest on: '+esc(panelTitle({measure:r.mostAffected.measure}).toLowerCase())+' ('+esc(r.mostAffected.source)+', '+esc(r.mostAffected.year)+')</div>':'<div class="ag__top">Most affected<b style="color:var(--sx-faint)">Not published</b></div>';
    html+='<div class="sx-card ag"><div><div class="ag__id">'+esc(r.id)+'</div><div class="ag__n">'+esc(r.name)+'</div>'+top+(r.note?'<div class="ag__note">'+esc(r.note)+'</div>':'')+'</div>'+
      '<div class="ag__panels">'+(panels.length?panels.map(p=>'<div class="ag__p"><h4>'+esc(panelTitle(p))+'</h4><p class="sub">'+esc(p.source)+', '+esc(p.geography)+', '+esc(p.year)+'<br><a class="src" style="margin:0" href="'+esc(p.sourceUrl)+'" target="_blank" rel="noopener">Source</a></p>'+bandChart(p)+'</div>').join(''):'<p class="na" style="align-self:center">No official age breakdown exists for this attack.</p>')+
      (r.older?'<div class="ag__older">People aged 60+ filed <b style="font-weight:500">'+fmt(r.older.count)+'</b> of these complaints to the FBI in 2024, which is '+esc(r.older.share)+'% of the total'+(r.older.shareLoss!=null&&r.older.shareLoss<=100?', and '+esc(r.older.shareLoss)+'% of the money lost':'')+'. <a class="src" href="'+esc(r.older.sourceUrl)+'" target="_blank" rel="noopener">FBI IC3 2024</a></div>':'')+'</div></div>';
  }
  $('#ageRows').innerHTML=html; $('#ageNote').textContent=d.note;
  $('#ovAgeByAttack').innerHTML='<ul class="fl">'+d.rows.filter(r=>/^PA-/.test(r.id)).map(r=>'<li data-go="age"><span>'+esc(r.name)+'<small>'+esc(r.id)+(r.mostAffected?', '+esc(r.mostAffected.source)+' '+esc(r.mostAffected.year):'')+'</small></span><b>'+(r.mostAffected?esc(r.mostAffected.band):'<span class="na">Not published</span>')+'</b></li>').join('')+'</ul>'; }

/* ---------------------------------------------------------------- people's awareness */
function awFact(f){ reg(f); return '<div class="aw__f" data-f="'+esc(f.id)+'"><b>'+fmt(f)+(/percent/.test(f.unit)?'%':' '+esc(unit(f)))+'</b> '+esc(f.metric)+'<small>'+esc(f.geography)+', '+esc(f.period)+', '+esc(f.sourceName)+'</small></div>'; }
function awCol(list,why){ return list&&list.length?list.slice(0,4).map(awFact).join('')+(list.length>4?'<div class="muted" style="font-size:12px">+'+(list.length-4)+' more</div>':''):'<span class="na">'+esc(why||'Not published by any authority')+'</span>'; }
async function loadAwareness(){ const d=await api('/awareness');
  $('#awareAttacks').innerHTML='<div class="sx-card" style="padding:0"><div class="aw-head"><span>Attack</span><span>India</span><span>World</span></div>'+d.byAttack.map(r=>'<div class="aw"><div><span class="aw__id">'+esc(r.id)+'</span><span class="aw__n">'+esc(r.name)+'</span></div><div class="aw__col">'+awCol(r.india,'India publishes no awareness figure for this attack')+'</div><div class="aw__col">'+awCol(r.world)+'</div></div>').join('')+'</div>';
  table($('#awareApps'),d.applicationAttacks,[{h:'ID',v:r=>'<span class="mono">'+esc(r.id)+'</span>'},{h:'Attack',v:r=>'<b style="font-weight:500">'+esc(r.name)+'</b><span class="u muted">'+esc(r.section)+' Security Assessment</span>'},{h:'India',v:r=>'<span class="na">'+esc(r.india.reason)+'</span>'},{h:'World',v:r=>'<span class="na">'+esc(r.world.reason)+'</span>'}]);
  $('#awareBasicIn').innerHTML=d.basic.india.map(awFact).join('')||NA; $('#awareBasicW').innerHTML=d.basic.world.map(awFact).join('')||NA;
  $('#awareSocIn').innerHTML=d.social.india.map(awFact).join('')||NA; $('#awareSocW').innerHTML=d.social.world.map(awFact).join('')||NA;
  $('#awareNote').textContent=d.note;
  const pick=(id)=>{ for(const r of d.byAttack) for(const f of r.india.concat(r.world)) if(f.id===id) return f; for(const f of d.basic.india.concat(d.basic.world,d.social.india,d.social.world)) if(f.id===id) return f; return null; };
  const snap=[['AWR-016','know what phishing is'],['AWR-018','could tell every phishing message from a real one'],['AWR-010','of UK businesses train staff in cyber security'],['AWR-023','use two-factor login on all accounts'],['AWR-063',''],['SOC-001','']].map(([id,t])=>{ const f=pick(id); if(!f) return ''; reg(f);
    return '<li data-f="'+esc(f.id)+'"><span>'+esc(t?cap(t):f.metric)+'<small>'+esc(f.geography)+', '+esc(f.period)+', '+esc(f.sourceName)+'</small></span><b>'+fmt(f)+(/percent/.test(f.unit)?'%':' <span class="muted" style="font-weight:400">'+esc(unit(f))+'</span>')+'</b></li>'; }).join('');
  $('#ovAware').innerHTML='<ul class="fl">'+snap+'</ul>'; }

/* ---------------------------------------------------------------- official sources */
async function loadOfficial(){ const d=await api('/official-sources'); window.__official=d; setTimeout(paintBand,0);
  const row=o=>'<div class="os"><div class="os__n"><a href="'+esc(o.url)+'" target="_blank" rel="noopener">'+esc(o.name)+'</a></div><span class="os__c">'+(o.factsUsed?o.factsUsed+(o.factsUsed===1?' figure':' figures')+' on this page':'Listed for reference')+'</span><div class="os__b">'+esc(o.body)+'</div><div class="os__p">'+esc(o.provides)+'</div></div>';
  $('#osIn').innerHTML='<div class="os-list">'+d.india.map(row).join('')+'</div>'; $('#osW').innerHTML='<div class="os-list">'+d.world.map(row).join('')+'</div>';
  $('#osInN').textContent=d.india.length+' government sources'; $('#osWN').textContent=d.world.length+' official sources'; }

/* ---------------------------------------------------------------- live data feed */
const SRC_NAMES={'cisa-kev':'CISA - Known Exploited Vulnerabilities','nvd-cve':'NIST - National Vulnerability Database','certin-vulnotes':'CERT-In - Vulnerability notes','hibp-breaches':'Have I Been Pwned - Breaches','cve-program':'CVE Program - new CVE records'};
let LIVE=null, isAdmin=false, ATTACKS={}, FEED=[], SEEN={}, FILTER={g:'',k:'',a:''}, FEEDTOTAL=0, streamOn=false;
function paintStatus(st){ LIVE=st;
  const ok=st.sources.filter(s=>s.lastSuccessAt); const newest=ok.map(s=>s.lastSuccessAt).sort().pop();
  const liveSig=st.signals.filter(s=>s.live).length;
  const dot=$('#liveDot'), lbl=$('#liveLbl');
  if(!st.liveEnabled){ dot.className='ob-dot warn'; lbl.textContent='Automatic collection is off'; $('#liveWhen').textContent='Admin-fed data still works. '+(st.howToEnable||''); }
  else if(ok.length||liveSig){ dot.className='ob-dot on'; lbl.textContent=ok.length+' of '+st.sources.length+' sources responding'; $('#liveWhen').textContent=(newest?'Last collected '+ago(newest):'Connected')+'. Collected every 10 min, signals every 2 h'; }
  else { dot.className='ob-dot warn'; lbl.textContent='Connecting to sources'; const p=st.sources.find(s=>s.problem); $('#liveWhen').textContent=p?p.problem:'Waiting for the first response (up to a minute after start).'; }
  $('#liveSources').innerHTML=st.sources.map(s=>{ const on=!!s.lastSuccessAt, stale=/stale|cached/.test(s.state);
    return '<div class="lv-src"><span class="ob-dot '+(on&&!stale?'on':on?'warn':s.enabled?'warn':'')+'"></span><span class="lv-src__n">'+esc(SRC_NAMES[s.id]||s.name)+'</span><span class="lv-src__s">'+(on?esc(Number(s.events||0).toLocaleString('en-IN'))+' saved':s.enabled?'Waiting':'Off')+'</span>'+
      '<span class="lv-src__m">'+(on?'Collected '+esc(ago(s.lastSuccessAt))+(s.via&&s.via!=='database'?' via '+esc(s.via):''):s.lastAttemptAt?'Last tried '+esc(ago(s.lastAttemptAt)):'Not tried yet')+(s.url?'. <a href="'+esc(s.url)+'" target="_blank" rel="noopener">Open source</a>':'')+'</span>'+
      (s.problem&&!on?'<span class="lv-src__p">'+esc(s.problem)+'</span>':'')+'</div>';}).join('');
  $('#liveSignals').innerHTML='<ul class="fl">'+st.signals.map(s=>'<li><span>'+esc(s.label)+'<small>'+(s.live?'Latest poll, '+esc(ago(s.fetchedAt)):s.fetchedAt?'Last known value from '+esc(String(s.fetchedAt).slice(0,10)):'Not fetched yet')+'</small></span><b>'+(s.value!=null?Number(s.value).toLocaleString('en-IN'):'-')+(s.live?'<span class="tag live">Latest poll</span>':'')+(s.sourceUrl?'<a class="src" href="'+esc(s.sourceUrl)+'" target="_blank" rel="noopener">Source</a>':'')+'</b></li>').join('')+'</ul>'; }

function fdRow(e,isNew){
  const when=e.publishedAt?String(e.publishedAt).slice(0,10):'';
  return '<div class="fd'+(isNew?' new':'')+'"><span class="sev '+esc(e.severity||'')+'"></span><div class="fd__t"><a href="'+esc(e.sourceUrl)+'" target="_blank" rel="noopener">'+esc(e.title)+'</a>'+(e.value!=null?' <span class="fd__v">'+Number(e.value).toLocaleString('en-IN')+(e.unit?' '+esc(e.unit):'')+'</span>':'')+'</div>'+
    '<div class="fd__m"><span>'+esc(e.sourceName||e.sourceId)+'</span>'+(when?'<span>'+esc(when)+'</span>':'')+'<span>'+esc(e.geography)+'</span>'+(e.attackId?'<span class="chipx me">'+esc(e.attackId)+' '+esc(e.attackName||'')+'</span>':'')+(e.kind==='manual'?'<span class="chipx">Fed by '+esc(e.author||'admin')+'</span>':'')+
    (isAdmin&&e.kind==='manual'?'<button class="sx-btn btn--sm" data-del="'+e.id+'" style="height:24px!important;padding:0 8px!important">Remove</button>':'')+'</div>'+
    (e.summary?'<div class="fd__s">'+esc(String(e.summary).slice(0,220))+'</div>':'')+'</div>'; }
function feedQuery(){ const q=new URLSearchParams({limit:'60'}); if(FILTER.g) q.set('geography',FILTER.g); if(FILTER.k) q.set('kind',FILTER.k); if(FILTER.a) q.set('attack',FILTER.a); return q.toString(); }
function matches(e){ return (!FILTER.g||e.geography===FILTER.g)&&(!FILTER.k||e.kind===FILTER.k)&&(!FILTER.a||e.attackId===FILTER.a); }
async function loadFeed(){
  try{ const j=await (await fetch('/api/feed?'+feedQuery(),{credentials:'same-origin'})).json();
    FEED=j.items||[]; FEED.forEach(e=>SEEN[e.id]=1); FEEDTOTAL=j.total||0;
    if(j.attacks&&!Object.keys(ATTACKS).length){ ATTACKS=j.attacks; const opts=Object.entries(ATTACKS).map(([k,v])=>'<option value="'+esc(k)+'">'+esc(k+' - '+v)+'</option>').join('');
      $('#feedAttack').insertAdjacentHTML('beforeend',opts); $('#feedFormAttack').insertAdjacentHTML('beforeend',opts); } }
  catch(e){ FEED=[]; }
  paintFeed(); loadFeedStats(); }
function paintFeed(newId){
  const empty='<div class="empty-live">Nothing here yet. Items appear automatically as the server collects them from official sources'+(isAdmin?', or you can feed a data point on the right.':'.')+'</div>';
  $('#liveFeed').innerHTML=FEED.length?FEED.map(e=>fdRow(e,e.id===newId)).join(''):empty;
  const top=FEED.slice(0,5);
  if(!FILTER.g&&!FILTER.k&&!FILTER.a) $('#ovLive').innerHTML=top.length?top.map(e=>fdRow(e,e.id===newId)).join(''):empty; }
async function loadFeedStats(){ try{ const s=await (await fetch('/api/feed/stats',{credentials:'same-origin'})).json(); window.__feedStats=s;
  const tile=(v,l)=>'<div class="sx-card fst"><div class="fst__v">'+Number(v).toLocaleString('en-IN')+'</div><div class="fst__l">'+l+'</div></div>';
  const topA=s.byAttack[0];
  $('#feedStats').innerHTML=tile(s.total,'Items saved on the server')+tile(s.last24h,'Collected in the last 24 hours')+tile(s.last7d,'Collected in the last 7 days')+
    '<div class="sx-card fst"><div class="fst__v" style="font-size:18px;line-height:1.3">'+(topA?esc(topA.id+' '+topA.name):'-')+'</div><div class="fst__l">'+(topA?'Most frequent attack type ('+topA.n+' items)':'No attack-type matches yet')+'</div></div>';
  paintBand(); }catch(e){} }
function setPill(on){ ['#feedPill','#ovLivePill'].forEach(sel=>{ const p=$(sel); if(!p) return; p.classList.toggle('on',on); p.lastChild.textContent=on?'Streaming':'Reconnecting'; }); }
function stream(){ if(!window.EventSource) return; let es;
  try{ es=new EventSource('/api/feed/stream'); }catch(e){ return; }
  es.addEventListener('hello',()=>{ streamOn=true; setPill(true); });
  es.addEventListener('item',m=>{ const e=JSON.parse(m.data); if(SEEN[e.id]) return; SEEN[e.id]=1; FEEDTOTAL++;
    if(matches(e)){ FEED.unshift(e); FEED=FEED.slice(0,80); paintFeed(e.id); }
    else if(!FILTER.g&&!FILTER.k&&!FILTER.a){ paintFeed(e.id); }
    clearTimeout(stream.t); stream.t=setTimeout(()=>{loadFeedStats();loadLive();},1500); });
  es.onerror=()=>{ setPill(false); }; }
$('#feedGeo').addEventListener('click',e=>{ const b=e.target.closest('button'); if(!b) return; $$('#feedGeo button').forEach(x=>x.classList.toggle('on',x===b)); FILTER.g=b.dataset.g||''; FILTER.k=b.dataset.k||''; loadFeed(); });
$('#feedAttack').addEventListener('change',e=>{ FILTER.a=e.target.value; loadFeed(); });
$('#liveFeed').addEventListener('click',async e=>{ const b=e.target.closest('[data-del]'); if(!b) return;
  if(!confirm('Remove this data point from the live feed?')) return;
  const r=await fetch('/api/feed/'+b.dataset.del,{method:'DELETE',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'}); if(r.ok){ toast('Removed.'); loadFeed(); } else toast('Could not remove it.'); });
$('#feedForm').addEventListener('submit',async e=>{ e.preventDefault();
  if(!isAdmin){ toast('Only the admin account can feed data.'); return; }
  const f=new FormData(e.target), body=Object.fromEntries(f.entries()); const msg=$('#feedFormMsg'); msg.textContent='Saving…';
  try{ const r=await fetch('/api/feed',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)}); const j=await r.json();
    if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); e.target.reset(); msg.textContent='Added - everyone can see it now.'; setTimeout(()=>msg.textContent='',4000);
    if(!SEEN[j.item.id]){ SEEN[j.item.id]=1; if(matches(j.item)){ FEED.unshift(j.item); paintFeed(j.item.id); } loadFeedStats(); } }
  catch(err){ msg.textContent=err.message; } });
async function loadLive(){ try{ const r=await fetch('/api/live/status',{credentials:'same-origin'}); if(r.ok) paintStatus(await r.json()); }catch(e){} }
$('#btnRefresh').onclick=async()=>{
  if(!isAdmin){ toast('Only the admin account can start a refresh. The feed is collected automatically every 10 minutes.'); return; }
  const b=$('#btnRefresh'); b.disabled=true; b.textContent='Collecting…'; const before=FEEDTOTAL;
  try{ const r=await fetch('/api/live/refresh',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:'{}'}); const j=await r.json();
    if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); paintStatus(j); await loadFeed();
    const ok=j.sources.filter(s=>s.lastSuccessAt).length; const added=Math.max(0,FEEDTOTAL-before);
    toast(!ok?'Could not reach the live sources: '+((j.sources.find(s=>s.problem)||{}).problem||'network error'):added?added+' new items collected and saved.':'Up to date - nothing new since the last collection.'); }
  catch(e){ toast('Refresh failed: '+e.message); }
  finally{ b.disabled=false; b.textContent='Refresh now'; } };

/* ---------------------------------------------------------------- overview band + snapshots */
let SUM=null;
function paintBand(){ if(!SUM) return; const k=(id)=>SUM.india.concat(SUM.global).find(f=>f.id===id); const fs=window.__feedStats||{};
  const cell=(f,label)=>f?'<div class="ob-band__i" data-f="'+esc(f.id)+'"><div class="ob-band__l">'+esc(label)+'</div><div class="ob-band__v">'+fmt(f)+'<small>'+esc(unit(f))+'</small></div><div class="ob-band__m">'+esc(f.period)+', '+esc(f.sourceName.split(/[,(]/)[0].trim())+'</div></div>':'';
  const inC=SUM.india[0], inL=SUM.india[1], os=window.__official;
  const srcCell=os?'<div class="ob-band__i" data-go="data"><div class="ob-band__l">Official sources behind these figures</div><div class="ob-band__v">'+(os.india.length+os.world.length)+'<small>bodies</small></div><div class="ob-band__m">'+os.india.length+' Indian government, '+os.world.length+' international</div></div>':'';
  $('#ovBand').innerHTML=cell(inC,'Cyber-crime complaints in India')+cell(inL,'Money reported lost in India')+srcCell+
    '<div class="ob-band__i" data-go="live"><div class="ob-band__l">Feed items collected</div><div class="ob-band__v">'+Number(fs.total||0).toLocaleString('en-IN')+'<small>saved</small></div><div class="ob-band__m">'+Number(fs.last24h||0).toLocaleString('en-IN')+' in the last 24 hours</div></div>'; }

/* ---------------------------------------------------------------- provenance drawer */
document.addEventListener('click',e=>{const el=e.target.closest('[data-f]'); if(!el||e.target.closest('a'))return; const f=FACTS[el.dataset.f]; if(!f)return;
  $('#dT').textContent='Where this number comes from'; const row=(k,v)=>'<div><div class="k">'+k+'</div><div class="v">'+v+'</div></div>';
  $('#dB').innerHTML=row('Value','<b style="font-size:20px;font-weight:500">'+fmt(f)+'</b> '+esc(unit(f)))+row('What it measures',esc(cap(f.metric)))+(f.category?row('Category',esc(f.category)):'')+row('Period',esc(f.period))+row('Geography',esc(f.geography))+
    row('Scope',esc(f.scope))+row('Published by',esc(f.sourceName))+row('Link','<a href="'+esc(f.sourceUrl)+'" target="_blank" rel="noopener">'+esc(f.sourceUrl)+'</a>')+row('Verification note',esc(f.note||'-'))+row('Record ID','<span class="mono">'+esc(f.id)+'</span>');
  $('#drawer').classList.add('on'); $('#scrim').classList.add('on'); });
const close=()=>{$('#drawer').classList.remove('on');$('#scrim').classList.remove('on');}; $('#dX').onclick=close; $('#scrim').onclick=close;
document.addEventListener('keydown',e=>{if(e.key==='Escape')close();});

(async()=>{
  fetch('/api/auth/me',{credentials:'same-origin'}).then(r=>r.ok?r.json():null).then(j=>{ const u=j&&(j.user||j); isAdmin=!!u&&u.role==='admin'; if(!isAdmin){ $('#btnRefresh').title='Admin only'; $$('#feedForm input,#feedForm select,#feedForm button').forEach(x=>x.disabled=true); $('#feedFormCard .sub').textContent='Only the admin account can feed data. You can see everything that is fed here.'; } paintFeed(); }).catch(()=>{});
  loadLive(); loadFeed(); stream(); setInterval(()=>{loadLive();},30000); setInterval(()=>{ if(!streamOn) loadFeed(); },60000);
  try{ await loadSummary(); await Promise.all([loadIndia(),loadGlobal(),loadAttacks(),loadImpact(),loadCountries(),loadAge(),loadCompare(),loadEnf(),loadDatasets(),loadGaps(),loadSources(),loadVictimAge(),loadAwareness(),loadOfficial()]); await loadAware(); }
  catch(e){ $('.sx-page').insertAdjacentHTML('afterbegin','<div class="note note--crit" style="margin-bottom:24px">Could not load the observatory data ('+esc(e.message)+'). Sign in again and reload the page.</div>'); }
})();
