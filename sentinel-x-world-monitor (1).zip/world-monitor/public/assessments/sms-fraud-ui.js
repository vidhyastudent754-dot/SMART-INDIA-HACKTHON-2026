/* sms-fraud-ui.js - SECTION 1 · DEFENSIVE capability card: Real-Time SMS Fraud
 * Detection. This is NOT an attack and is NOT part of the count of 15. It
 * appends one clearly-labelled card AFTER the five attack cards in Section 1
 * and calls the REAL detector at POST /api/sms/analyze. Every value shown is
 * produced by the server-side detector (lib/sms-fraud.js). */
(function () {
  'use strict';

  const BASE = (window.SXA_ASSESS_BASE || '');
  const ENDPOINT = BASE + '/api/sms/analyze';

  const EXAMPLES = [
    { label: 'Normal OTP (safe)',
      v: { message: 'EXAMPLEBANK: Your login OTP is 445566. Do not share this OTP with anyone.' } },
    { label: 'Fraud: OTP disclosure request',
      v: { message: 'EXAMPLEBANK SECURITY: Your account will be blocked. Tell the OTP to our support executive to cancel the transaction.', sender: 'UNKNOWN-98321', claimedCompany: 'Example Bank' } },
    { label: 'Fraud: debit + phishing link',
      v: { message: 'Your account has been debited Rs 25,000. If this was not you, verify immediately: https://suspicious-example.test Reply with your OTP to cancel the transaction.', claimedCompany: 'Example Bank', sender: 'TX-EXBANK' } },
    { label: 'Fraud: fake KYC / suspension',
      v: { message: 'Dear customer, your account is suspended. Complete KYC now: https://example-bank-security.example', claimedCompany: 'Example Bank', sender: 'UNKNOWN-98321' } },
  ];

  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

  function injectStyles() {
    if (document.getElementById('sxsms-style')) return;
    const s = document.createElement('style');
    s.id = 'sxsms-style';
    s.textContent = [
      '.sxsms{border:1px solid var(--line,#26324a);border-radius:12px;background:var(--panel,#141b29);margin-top:14px;overflow:hidden}',
      '.sxsms__head{display:flex;align-items:center;gap:10px;padding:12px 14px;border-bottom:1px solid var(--line,#26324a);flex-wrap:wrap}',
      '.sxsms__id{font-family:ui-monospace,Menlo,monospace;font-size:11px;letter-spacing:.04em;color:#8fd6a9;border:1px solid #2f6b46;background:rgba(60,180,110,.08);padding:2px 7px;border-radius:6px}',
      '.sxsms__title{font-weight:600;font-size:14px;color:var(--text,#e6e9ee)}',
      '.sxsms__badge{margin-left:auto;font-family:ui-monospace,monospace;font-size:10px;letter-spacing:.06em;color:#8fd6a9;border:1px solid #2f6b46;padding:3px 8px;border-radius:20px;text-transform:uppercase}',
      '.sxsms__body{padding:14px;display:grid;gap:10px}',
      '.sxsms__row{display:grid;grid-template-columns:1fr 1fr;gap:10px}',
      '.sxsms label{display:block;font-size:11px;color:var(--faint,#8a97ad);margin-bottom:4px;text-transform:uppercase;letter-spacing:.04em}',
      '.sxsms textarea,.sxsms input{width:100%;box-sizing:border-box;background:var(--ink,#0c111b);border:1px solid var(--line2,#2b3a55);color:var(--text,#e6e9ee);border-radius:8px;padding:9px 10px;font:inherit;font-size:13px}',
      '.sxsms textarea{min-height:74px;resize:vertical;font-family:ui-monospace,monospace}',
      '.sxsms__ex{display:flex;flex-wrap:wrap;gap:6px}',
      '.sxsms__ex button{font-size:11px;padding:5px 9px;border-radius:16px;border:1px solid var(--line2,#2b3a55);background:var(--panel2,#1a2334);color:var(--text2,#c3ccda);cursor:pointer}',
      '.sxsms__ex button:hover{border-color:var(--accent,#4c8dff)}',
      '.sxsms__go{justify-self:start;padding:9px 16px;border-radius:8px;border:1px solid #2f6b46;background:linear-gradient(180deg,#1f7a48,#186139);color:#eafff2;font-weight:600;cursor:pointer}',
      '.sxsms__go:disabled{opacity:.6;cursor:wait}',
      '.sxsms__out{display:none;border-top:1px solid var(--line,#26324a);padding:14px;gap:10px}',
      '.sxsms__out.is-on{display:grid}',
      '.sxsms__verdict{display:flex;align-items:center;gap:10px;flex-wrap:wrap}',
      '.sxsms__cls{font-weight:700;font-size:15px;padding:4px 12px;border-radius:8px;letter-spacing:.03em}',
      '.cls-SAFE{background:rgba(60,180,110,.14);color:#8fd6a9;border:1px solid #2f6b46}',
      '.cls-SUSPICIOUS{background:rgba(224,168,72,.14);color:#e7c07a;border:1px solid #7a5f2f}',
      '.cls-HIGH_RISK{background:rgba(217,83,79,.16);color:#f19a97;border:1px solid #7a3230}',
      '.cls-ANALYSIS_ERROR{background:rgba(140,150,170,.14);color:#aab4c5;border:1px solid #3a4560}',
      '.sxsms__meter{flex:1;min-width:120px;height:8px;border-radius:5px;background:var(--ink,#0c111b);border:1px solid var(--line2,#2b3a55);overflow:hidden}',
      '.sxsms__meter > i{display:block;height:100%;background:linear-gradient(90deg,#3cb46e,#e0a848,#d9534f)}',
      '.sxsms__chips{display:flex;flex-wrap:wrap;gap:6px}',
      '.sxsms__chip{font-size:11px;padding:3px 9px;border-radius:14px;border:1px solid var(--line2,#2b3a55);color:var(--faint,#8a97ad)}',
      '.sxsms__chip.on{color:#f19a97;border-color:#7a3230;background:rgba(217,83,79,.10)}',
      '.sxsms__chip.info{color:#8fb4f0;border-color:#2f4b7a;background:rgba(76,141,255,.08)}',
      '.sxsms__reasons{margin:0;padding-left:18px;font-size:13px;color:var(--text2,#c3ccda);display:grid;gap:3px}',
      '.sxsms__act{font-size:13px;color:var(--text,#e6e9ee);background:var(--panel2,#1a2334);border:1px solid var(--line2,#2b3a55);border-radius:8px;padding:10px}',
      '.sxsms__foot{font-size:11px;color:var(--faint,#8a97ad);font-family:ui-monospace,monospace}',
    ].join('');
    document.head.appendChild(s);
  }

  function chip(label, on, cls) {
    return '<span class="sxsms__chip ' + (on ? (cls || 'on') : '') + '">' + esc(label) + ': ' + (on ? 'YES' : 'no') + '</span>';
  }

  function render(out, r) {
    if (!r || r.classification === undefined) { out.innerHTML = '<div class="sxsms__act">No response from detector.</div>'; out.classList.add('is-on'); return; }
    if (r.classification === 'ANALYSIS_ERROR') {
      out.innerHTML = '<div class="sxsms__verdict"><span class="sxsms__cls cls-ANALYSIS_ERROR">ANALYSIS_ERROR</span></div>' +
        '<div class="sxsms__act">' + esc(r.error || 'The message could not be analysed.') + '</div>';
      out.classList.add('is-on'); return;
    }
    const reasons = (r.reasons || []).map((x) => '<li>' + esc(x) + '</li>').join('') || '<li>No suspicious indicators detected by the configured checks.</li>';
    out.innerHTML =
      '<div class="sxsms__verdict">' +
        '<span class="sxsms__cls cls-' + esc(r.classification) + '">' + esc(r.classification.replace('_', ' ')) + '</span>' +
        '<span class="sxsms__meter"><i style="width:' + Math.max(3, Math.min(100, r.riskScore || 0)) + '%"></i></span>' +
        '<span class="sxsms__foot">risk score ' + esc(r.riskScore) + '/100</span>' +
      '</div>' +
      '<div class="sxsms__chips">' +
        chip('OTP detected', r.otpDetected, 'info') +
        chip('OTP disclosure request', r.otpDisclosureRequest) +
        chip('Credential request', r.credentialRequest) +
        chip('Phishing link', r.phishingLink) +
        chip('Transaction alert', r.transactionAlert, 'info') +
        chip('Security alert', r.securityAlert, 'info') +
        chip('Urgency', r.urgentLanguage) +
        chip('Sender mismatch', r.senderMismatch) +
        chip('Company/domain mismatch', r.companyDomainMismatch) +
      '</div>' +
      '<ul class="sxsms__reasons">' + reasons + '</ul>' +
      '<div class="sxsms__act"><b>Recommended action:</b> ' + esc(r.recommendedAction || '') + '</div>' +
      '<div class="sxsms__foot">OTP value: ' + esc(r.otpValue || 'not present') + ', secret never stored, analysed ' + esc(r.checkedAt || '') + '</div>';
    out.classList.add('is-on');
  }

  function buildCard() {
    const wrap = document.createElement('div');
    wrap.className = 'sxsms';
    wrap.setAttribute('data-role', 'sms-fraud');
    wrap.innerHTML =
      '<div class="sxsms__head">' +
        '<span class="sxsms__id">SMS-FRAUD</span>' +
        '<span class="sxsms__title">SMS Fraud Detection</span>' +
        '<span class="sxsms__badge">Defensive capability · not an attack</span>' +
      '</div>' +
      '<div class="sxsms__body">' +
        '<div class="sxsms__ex" data-role="ex"></div>' +
        '<div><label>SMS message</label><textarea data-role="msg" placeholder="Paste the SMS text here…"></textarea></div>' +
        '<div class="sxsms__row">' +
          '<div><label>Sender (optional)</label><input data-role="sender" placeholder="e.g. TX-EXBANK / UNKNOWN-98321"></div>' +
          '<div><label>Claimed company (optional)</label><input data-role="company" placeholder="e.g. Example Bank"></div>' +
        '</div>' +
        '<div class="sxsms__row">' +
          '<div><label>Your name (optional)</label><input data-role="name" placeholder="e.g. Test User A"></div>' +
          '<div><label>&nbsp;</label><button class="sxsms__go" data-role="go">Analyze SMS</button></div>' +
        '</div>' +
      '</div>' +
      '<div class="sxsms__out" data-role="out"></div>';

    const exWrap = wrap.querySelector('[data-role="ex"]');
    EXAMPLES.forEach((ex) => {
      const b = document.createElement('button');
      b.textContent = ex.label;
      b.addEventListener('click', () => {
        wrap.querySelector('[data-role="msg"]').value = ex.v.message || '';
        wrap.querySelector('[data-role="sender"]').value = ex.v.sender || '';
        wrap.querySelector('[data-role="company"]').value = ex.v.claimedCompany || '';
        wrap.querySelector('[data-role="name"]').value = ex.v.userName || '';
      });
      exWrap.appendChild(b);
    });

    const go = wrap.querySelector('[data-role="go"]');
    const out = wrap.querySelector('[data-role="out"]');
    go.addEventListener('click', async () => {
      const payload = {
        message: wrap.querySelector('[data-role="msg"]').value,
        sender: wrap.querySelector('[data-role="sender"]').value,
        claimedCompany: wrap.querySelector('[data-role="company"]').value,
        userName: wrap.querySelector('[data-role="name"]').value,
      };
      go.disabled = true; go.textContent = 'Analyzing…';
      try {
        const res = await fetch(ENDPOINT, { method: 'POST', credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        const j = await res.json();
        render(out, j);
      } catch (e) {
        render(out, { classification: 'ANALYSIS_ERROR', error: 'Could not reach the detector: ' + e.message });
      } finally {
        go.disabled = false; go.textContent = 'Analyze SMS';
      }
    });

    return wrap;
  }

  const SXSMS = (window.SXSMS = window.SXSMS || {});
  SXSMS.mount = function (host) {
    try {
      injectStyles();
      const cards = host.querySelector('[data-role="cards"]') || host;
      if (cards.querySelector('[data-role="sms-fraud"]')) return; // idempotent
      cards.appendChild(buildCard());
    } catch (e) { /* non-fatal - the attacks still render */ }
  };
})();
