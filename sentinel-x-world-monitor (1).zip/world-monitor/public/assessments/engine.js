/* =====================================================================
 * engine.js - SENTINEL-X / World Monitor  ·  Assessment Engine (SXA)
 * ---------------------------------------------------------------------
 * Shared runtime used by the three assessment consoles:
 *   · Section 1 - Individual Security Assessment      (individual.js)
 *   · Section 2 - Employee & Manager Security Assessment (employee-manager.js)
 *   · Section 3 - Company & Organization Security Assessment (company-org.js)
 *
 * SAFETY MODEL (SIH26163 / NTRO)
 *   Every "attack" below runs entirely against an in-memory model of the
 *   World Monitor application inside this browser tab. There is NO network
 *   egress, no request is ever sent to any real host, and no real user
 *   data is touched. Each check demonstrates:
 *       vulnerable build  →  the weakness is proven (Confirmed)
 *       apply fix + retest →  the same attack is now blocked (Not Found)
 *   This makes the whole thing safe to run live in front of judges while
 *   still showing a real, working attack AND its real, working fix.
 *
 * LIVE I/O (this build)
 *   · Console output now streams character-by-character in real time with
 *     per-line timestamps and a blinking cursor (feels like a live shell).
 *   · Checks may declare an `interactive` block. When present the card
 *     shows a payload box: the operator/judge types the attack input and
 *     the in-memory model computes the response LIVE from that exact input,
 *     for both the vulnerable and the fixed build. Still zero egress.
 * ===================================================================== */
(function () {
  'use strict';

  const SXA = (window.SXA = window.SXA || {});

  /* ---------- tiny utilities ---------- */
  const esc = (s) =>
    String(s == null ? '' : s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])
    );
  const nowISO = () => new Date().toISOString().replace('T', ' ').slice(0, 19) + 'Z';
  const uid = (p) => p + '-' + Math.random().toString(36).slice(2, 8).toUpperCase();
  const el = (html) => {
    const t = document.createElement('template');
    t.innerHTML = html.trim();
    return t.content.firstElementChild;
  };
  const L = (text, kind) => ({ text, kind: kind || 'info' });
  SXA.util = { esc, nowISO, uid, el, L };

  /* ---------- classification vocab ---------- */
  const STATUS = {
    CONFIRMED: 'Confirmed',
    SUSPECTED: 'Suspected',
    NOTFOUND: 'Not Found',
    NOTTESTED: 'Not Tested',
    NA: 'Not Applicable',
  };
  SXA.STATUS = STATUS;

  const sevClass = (sev) =>
    ({ Critical: 'crit', High: 'high', Medium: 'med', Low: 'low', Informational: 'info' }[sev] ||
      'info');
  const statusClass = (st) =>
    ({
      Confirmed: 'fail',
      Suspected: 'partial',
      'Not Found': 'pass',
      'Not Tested': 'na',
      'Not Applicable': 'na',
    }[st] || 'na');
  SXA.sevClass = sevClass;
  SXA.statusClass = statusClass;

  /* ---------- shared, deliberately-mockable primitives ----------
   * Small building blocks several checks reuse. All pure functions on
   * in-memory data - never touch the DOM, network, or storage.        */
  SXA.mock = {
    // ---- fake, unsigned-vs-signed token model (JWT-like) ----
    b64u(obj) {
      return btoa(JSON.stringify(obj)).replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
    },
    makeToken(payload, mode) {
      // vulnerable build: alg "none" accepted / no real signature
      const header = { alg: mode === 'fixed' ? 'HS256' : 'none', typ: 'JWT' };
      const sig = mode === 'fixed' ? 'v3r1f13d-hmac-signature' : '';
      return this.b64u(header) + '.' + this.b64u(payload) + '.' + sig;
    },
    verifyToken(token, mode, expected) {
      const parts = String(token).split('.');
      if (parts.length !== 3) return { valid: false, reason: 'Malformed token' };
      let header, payload;
      try {
        header = JSON.parse(atob(parts[0].replace(/-/g, '+').replace(/_/g, '/')));
        payload = JSON.parse(atob(parts[1].replace(/-/g, '+').replace(/_/g, '/')));
      } catch (e) {
        return { valid: false, reason: 'Undecodable token' };
      }
      if (mode === 'fixed') {
        if (header.alg === 'none' || !parts[2])
          return { valid: false, reason: 'alg=none / unsigned token rejected' };
        if (expected && expected.iss && payload.iss !== expected.iss)
          return { valid: false, reason: 'Issuer (iss) mismatch' };
        if (payload.exp && payload.exp < Math.floor(Date.now() / 1000))
          return { valid: false, reason: 'Token expired' };
        return { valid: true, payload };
      }
      // vulnerable: accept anything decodable, trust claims verbatim
      return { valid: true, payload };
    },
    // ---- fake SQL layer: string-concat (vuln) vs parameterized (fixed) ----
    sqlQuery(userInput, mode) {
      const looksInjection = /('|--|;|\bOR\b|\bUNION\b|=\s*'?1'?\s*=\s*'?1|sleep\(|xp_)/i.test(
        userInput
      );
      if (mode === 'fixed') {
        // parameterized: input is data, never code
        return {
          sql: 'SELECT id,title FROM reports WHERE title = ?  -- param: [' + userInput + ']',
          rows: userInput === 'India Cyber Report' ? [{ id: 'RPT-1', title: 'India Cyber Report' }] : [],
          injected: false,
        };
      }
      // vulnerable: naive concatenation
      const sql = "SELECT id,title FROM reports WHERE title = '" + userInput + "'";
      return {
        sql,
        rows: looksInjection
          ? [
              { id: 'RPT-1', title: 'India Cyber Report' },
              { id: 'RPT-2', title: 'CONFIDENTIAL - internal' },
              { id: 'USR-ADMIN', title: 'admin@worldmonitor.local' },
            ]
          : [{ id: 'RPT-1', title: userInput }],
        injected: looksInjection,
      };
    },
  };

  /* State for the live checks is NOT kept in the browser. Sessions, reset
   * tokens, the employee directory, comments and rate-limit buckets live in
   * the server's SQLite store (db/schema.sql) and survive restarts; every
   * check round-trips through /api/assess (see live-io.js). */

  /* ---- normalize a path against a base (fake, no real fs) ---- */
  SXA.normalizePath = function (p) {
    const parts = String(p).split('/');
    const out = [];
    for (const seg of parts) {
      if (seg === '' || seg === '.') continue;
      if (seg === '..') out.pop();
      else out.push(seg);
    }
    return '/' + out.join('/');
  };

  /* ---- classify a URL host for SSRF (fake, never requested) ---- */
  SXA.classifyUrl = function (raw) {
    let host = '';
    try { host = new URL(String(raw)).hostname; } catch (e) { return { ok: false, reason: 'unparseable URL', host: '' }; }
    const isPrivate =
      host === 'localhost' || host === '127.0.0.1' || host === '169.254.169.254' ||
      /^10\./.test(host) || /^192\.168\./.test(host) ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host) || /\.internal$/.test(host);
    return { ok: !isPrivate, host, isMetadata: host === '169.254.169.254', isPrivate };
  };

  /* ---- allow-list projector ---- */
  SXA.pick = function (obj, keys) {
    const o = {};
    keys.forEach((k) => { if (obj && k in obj) o[k] = obj[k]; });
    return o;
  };

  /* ---- redact sensitive keys before logging ---- */
  SXA.redact = function (obj, keys) {
    const drop = new Set(keys);
    const walk = (v) => {
      if (Array.isArray(v)) return v.map(walk);
      if (v && typeof v === 'object') {
        const o = {};
        for (const k of Object.keys(v)) o[k] = drop.has(k.toLowerCase()) ? '[REDACTED]' : walk(v[k]);
        return o;
      }
      return v;
    };
    return walk(obj);
  };

  /* ---- default input for a check (used when the judge types nothing) ---- */
  SXA.defaultInput = function (c) {
    const it = c && c.interactive;
    if (!it) return null;
    if (it.type === 'fields' && Array.isArray(it.fields)) {
      const o = {};
      it.fields.forEach((f) => { o[f.key] = f.value == null ? '' : f.value; });
      return o;
    }
    return it.value == null ? '' : it.value;
  };
  const inputToStr = (input) =>
    input == null ? '(default)' : typeof input === 'string' ? input : JSON.stringify(input);
  SXA.inputToStr = inputToStr;

  /* =====================================================================
   * CHECK CARD - the interactive unit judges walk through.
   * A "check" is a plain object with metadata + run(mode) -> result.
   * Optionally a check declares `interactive` (see makeCard) to expose a
   * live payload box wired to the same in-memory model.
   * ===================================================================== */
  function metaRow(k, v, cls) {
    return (
      '<div class="sxa-k">' + esc(k) + '</div><div class="sxa-v ' + (cls || '') + '">' + v + '</div>'
    );
  }

  function pill(text, cls) {
    return '<span class="sxa-pill sxa-pill--' + cls + '">' + esc(text) + '</span>';
  }

  // Build the classification table required by all three sections' report specs.
  /* Age targeting comes from the observatory dataset (FBI IC3 age data where it
   * exists; otherwise a plain statement that no agency publishes it). */
  let AGE_P = null;
  function fillAge(el) {
    if (!el) return;
    AGE_P = AGE_P || fetch('/api/gio/attack-tables', { credentials: 'same-origin' }).then((r) => (r.ok ? r.json() : null)).catch(() => null);
    AGE_P.then((d) => {
      const row = d && d.application.find((x) => x.id === el.dataset.ageId);
      if (!row) { el.innerHTML = '<b>Age targeted:</b> not published'; return; }
      const a = row.ageTarget;
      el.innerHTML = '<b>Age targeted:</b> ' + esc(a.group) + '<span class="sxa-age__n">' + esc(a.summary) +
        (a.sourceUrl ? ' <a href="' + esc(a.sourceUrl) + '" target="_blank" rel="noopener">Source</a>' : '') + '</span>';
    });
  }

  function classificationGrid(c) {
    const cia = c.cia || {};
    return (
      '<div class="sxa-grid2">' +
      metaRow('Vulnerability ID', esc(c.id)) +
      metaRow('Category', esc(c.category)) +
      metaRow('Attack vector', esc(c.attackVector || '-')) +
      metaRow('Affected component', esc(c.affectedComponent || '-')) +
      metaRow('Affected endpoint / page', '<code>' + esc(c.endpoint || '-') + '</code>') +
      metaRow('Affected party', esc(c.affectedParty || '-')) +
      metaRow('Difficulty', esc(c.difficulty || '-')) +
      metaRow('Impact size', esc(c.impactSize || '-')) +
      metaRow(
        'CIA impact',
        'C:' + esc(cia.c || '-') + ', I:' + esc(cia.i || '-') + ', A:' + esc(cia.a || '-')
      ) +
      metaRow('Severity', pill(c.severity, sevClass(c.severity))) +
      metaRow(
        'CVSS',
        c.cvss ? '<code>' + esc(c.cvss.score) + ' / ' + esc(c.cvss.vector) + '</code>' : '-'
      ) +
      metaRow('CWE', esc(c.cwe || '-')) +
      '</div>'
    );
  }

  /* ---------- LIVE console streamer ----------
   * Streams an array of {text, kind} lines into `consoleEl`.
   *   live=true  → types char-by-char with jitter + blinking cursor (single manual/interactive runs)
   *   live=false → reveals whole lines quickly (used by Run-all / Fix-all batch)
   * Each call bumps a run-token so a newer run instantly cancels an older
   * one still typing into the same console. Returns a Promise.
   */
  function tsNow() {
    const d = new Date();
    const p = (n, w) => String(n).padStart(w || 2, '0');
    return p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + '.' + p(d.getMilliseconds(), 3);
  }

  function streamLines(consoleEl, lines, opts) {
    opts = opts || {};
    const live = opts.live !== false;
    const token = (consoleEl._sxaRun = (consoleEl._sxaRun || 0) + 1);
    consoleEl.innerHTML = '';
    consoleEl.classList.add('is-streaming');
    lines = lines && lines.length ? lines : [L('(no output)', 'muted')];

    return new Promise((resolve) => {
      const cursor = document.createElement('span');
      cursor.className = 'sxa-cursor';
      cursor.textContent = '▋';
      let li = 0;

      const finish = () => {
        if (cursor.parentNode) cursor.remove();
        consoleEl.classList.remove('is-streaming');
        resolve();
      };

      function nextLine() {
        if (consoleEl._sxaRun !== token) return; // superseded
        if (li >= lines.length) return finish();
        const ln = lines[li];
        const row = document.createElement('div');
        row.className = 'sxa-line sxa-line--' + (ln.kind || 'info');
        const tstamp = document.createElement('span');
        tstamp.className = 'sxa-ts';
        tstamp.textContent = '[' + tsNow() + '] ';
        const body = document.createElement('span');
        body.className = 'sxa-linebody';
        row.appendChild(tstamp);
        row.appendChild(body);
        row.appendChild(cursor);
        consoleEl.appendChild(row);
        consoleEl.scrollTop = consoleEl.scrollHeight;

        // results appear straight away (no typewriter effect) - a short gap keeps the order readable
        body.textContent = ln.text || '';
        consoleEl.scrollTop = consoleEl.scrollHeight;
        li++;
        setTimeout(nextLine, live ? 18 : (opts.lineDelay || 10));
      }
      nextLine();
    });
  }
  SXA.streamLines = streamLines;

  function evidenceBlock(res, mode) {
    const verdictCls = res.verdict === 'SECURE' ? 'pass' : 'fail';
    let html =
      '<div class="sxa-verdict sxa-verdict--' +
      verdictCls +
      '">' +
      (mode === 'fixed' ? 'After fix: ' : 'Vulnerable build: ') +
      esc(res.verdict) +
      '</div>';
    if (res.request)
      html +=
        '<div class="sxa-ev"><div class="sxa-ev__l">Request / action</div><pre class="sxa-code"><code>' +
        esc(res.request) +
        '</code></pre></div>';
    if (res.response)
      html +=
        '<div class="sxa-ev"><div class="sxa-ev__l">Response / observed behaviour</div><pre class="sxa-code"><code>' +
        esc(res.response) +
        '</code></pre></div>';
    if (res.http) {
      const hs = Object.entries(res.http.headers || {}).map(([k, v]) => k + ': ' + v).join('\n');
      html +=
        '<div class="sxa-ev"><div class="sxa-ev__l">Raw HTTP response - status ' + esc(res.http.status) + ' · ' + esc(res.http.ms) + ' ms</div><pre class="sxa-code"><code>' +
        esc('HTTP ' + res.http.status + '\n' + hs + '\n\n' + (res.http.body.length > 2000 ? res.http.body.slice(0, 2000) + '\n… (' + res.http.body.length + ' bytes)' : res.http.body)) +
        '</code></pre></div>';
    }
    if (res.note) html += '<div class="sxa-note">' + esc(res.note) + '</div>';
    return html;
  }

  /* ---------- live interactive input row ----------
   * Rendered only when a check declares `interactive`:
   *   interactive: {
   *     label, hint,
   *     type: 'text' | 'fields',
   *     placeholder,                 // for type:'text'
   *     fields: [{key,label,placeholder,value}],   // for type:'fields'
   *     presets: [{ label, value | values }],      // quick-fill chips
   *     run(input, mode) -> { log, request, response, verdict, note, status }
   *   }
   * `input` is a string (type:'text') or an object keyed by field (type:'fields').
   */
  function buildInteractive(c) {
    const it = c.interactive;
    const isFields = it.type === 'fields' && Array.isArray(it.fields);
    let inputsHtml = '';
    if (isFields) {
      inputsHtml =
        '<div class="sxa-live__fields">' +
        it.fields
          .map(
            (f) =>
              '<label class="sxa-live__field"><span>' +
              esc(f.label) +
              '</span><input class="sxa-live__input" data-fkey="' +
              esc(f.key) +
              '" type="text" value="' +
              esc(f.value == null ? '' : f.value) +
              '" placeholder="' +
              esc(f.placeholder || '') +
              '" spellcheck="false" autocomplete="off"></label>'
          )
          .join('') +
        '</div>';
    } else {
      inputsHtml =
        '<input class="sxa-live__input sxa-live__input--single" data-role="live-input" type="text" value="' +
        esc(it.value == null ? '' : it.value) +
        '" placeholder="' +
        esc(it.placeholder || 'Type an attack payload…') +
        '" spellcheck="false" autocomplete="off">';
    }

    const presets = (it.presets || [])
      .map(
        (p, i) =>
          '<button type="button" class="sxa-preset" data-pi="' +
          i +
          '">' +
          esc(p.label) +
          '</button>'
      )
      .join('');

    const wrap = el(
      '<div class="sxa-live" data-role="live">' +
        '<div class="sxa-live__bar">' +
        '<span class="sxa-live__tag">LIVE INPUT</span>' +
        '<span class="sxa-live__label">' +
        esc(it.label || 'Attack payload') +
        '</span>' +
        '</div>' +
        (it.hint ? '<div class="sxa-live__hint">' + esc(it.hint) + '</div>' : '') +
        '<div class="sxa-live__row">' +
        inputsHtml +
        '</div>' +
        (presets ? '<div class="sxa-live__presets">' + presets + '</div>' : '') +
        '<div class="sxa-live__btns">' +
        '<button type="button" class="sxa-btn sxa-btn--attack" data-act="live-vuln">Send to vulnerable build</button>' +
        '<button type="button" class="sxa-btn sxa-btn--fix" data-act="live-fixed">Send same input to fixed build</button>' +
        '<label class="sxa-live__auto"><input type="checkbox" data-role="autorun" checked> Run as I type</label>' +
        '</div>' +
        '</div>'
    );

    function read() {
      if (isFields) {
        const o = {};
        wrap.querySelectorAll('.sxa-live__input').forEach((inp) => {
          o[inp.dataset.fkey] = inp.value;
        });
        return o;
      }
      return wrap.querySelector('[data-role="live-input"]').value;
    }
    function fill(preset) {
      if (isFields && preset.values) {
        wrap.querySelectorAll('.sxa-live__input').forEach((inp) => {
          if (preset.values[inp.dataset.fkey] != null) inp.value = preset.values[inp.dataset.fkey];
        });
      } else if (!isFields) {
        wrap.querySelector('[data-role="live-input"]').value =
          preset.value != null ? preset.value : '';
      }
    }
    wrap.querySelectorAll('.sxa-preset').forEach((b) => {
      b.addEventListener('click', (e) => {
        e.stopPropagation();
        fill(it.presets[+b.dataset.pi]);
      });
    });

    return { wrap, read };
  }

  SXA.makeCard = function (c) {
    // Live-I/O augmentation: attach a typed-payload block + report fields for
    // checks whose definition file kept them scripted-only. Never clobbers an
    // interactive block a check already declares inline.
    if (SXA.LIVE && SXA.LIVE[c.id]) {
      const add = SXA.LIVE[c.id];
      if (add.interactive && !c.interactive) c.interactive = add.interactive;
      if (add.references && !c.references) c.references = add.references;
      if (add.retestNotes && !c.retestNotes) c.retestNotes = add.retestNotes;
    }
    const hasLive = !!c.interactive && typeof c.interactive.run === 'function';

    const card = el(
      '<div class="sxa-card' +
        (hasLive ? ' sxa-card--live' : '') +
        '" data-status="' +
        STATUS.NOTTESTED +
        '" data-cat="' +
        esc(c.category) +
        '" data-sev="' +
        esc(c.severity) +
        '" data-diff="' +
        esc(c.difficulty || '') +
        '" data-impact="' +
        esc(c.impactSize || '') +
        '" data-role-party="' +
        esc(c.affectedParty || '') +
        '">' +
        '<div class="sxa-card__head">' +
        '<span class="sxa-id">' +
        esc(c.id) +
        '</span>' +
        '<span class="sxa-title">' +
        esc(c.title) +
        '</span>' +
        '<span class="sxa-card__meta">' +
        (hasLive ? '<span class="sxa-livebadge">Live input</span>' : '') +
        pill(c.severity, sevClass(c.severity)) +
        '<span class="sxa-status" data-role="status">' +
        pill(STATUS.NOTTESTED, 'na') +
        '</span>' +
        '</span>' +
        '<span class="sxa-chev">▸</span>' +
        '</div>' +
        '<div class="sxa-card__body">' +
        '<p class="sxa-desc">' +
        esc(c.description) +
        '</p>' +
        '<div class="sxa-age" data-age-id="' + esc(c.id) + '"><b>Age targeted:</b> loading…</div>' +
        '<div class="sxa-live-mount" data-role="live-mount"></div>' +
        '<div class="sxa-actions">' +
        '<button class="sxa-btn sxa-btn--attack" data-act="attack">Run test on vulnerable build</button>' +
        '<button class="sxa-btn sxa-btn--fix" data-act="fix" disabled>Apply fix and re-test</button>' +
        '<button class="sxa-btn sxa-btn--ghost" data-act="reset">Reset</button>' +
        '</div>' +
        '<div class="sxa-io__label">Live console output</div>' +
        '<div class="sxa-console" data-role="console"><div class="sxa-line sxa-line--muted">Idle - press “Run test”' +
        (hasLive ? ', or type a payload above and send it,' : '') +
        ' to demonstrate the attack against the in-memory World Monitor model.</div></div>' +
        '<div class="sxa-evwrap" data-role="evidence"></div>' +
        '<details class="sxa-fold"><summary>Remediation &amp; secure code</summary>' +
        '<div class="sxa-remed"><p>' +
        esc(c.remediation || '') +
        '</p>' +
        (c.remediationCode
          ? '<pre class="sxa-code"><code>' + esc(c.remediationCode) + '</code></pre>'
          : '') +
        '</div></details>' +
        '<details class="sxa-fold"><summary>Full classification (report fields)</summary>' +
        classificationGrid(c) +
        (c.technicalImpact
          ? '<div class="sxa-imp"><b>Technical impact.</b> ' + esc(c.technicalImpact) + '</div>'
          : '') +
        (c.partyImpact
          ? '<div class="sxa-imp"><b>' +
            esc(c.partyImpactLabel || 'Impact on affected party') +
            '.</b> ' +
            esc(c.partyImpact) +
            '</div>'
          : '') +
        (c.orgImpact
          ? '<div class="sxa-imp"><b>Organizational / business impact.</b> ' +
            esc(c.orgImpact) +
            '</div>'
          : '') +
        '</details>' +
        '</div>' +
        '</div>'
    );

    const head = card.querySelector('.sxa-card__head');
    const consoleEl = card.querySelector('[data-role="console"]');
    const evEl = card.querySelector('[data-role="evidence"]');
    const statusEl = card.querySelector('[data-role="status"]');
    const fixBtn = card.querySelector('[data-act="fix"]');
    const liveMount = card.querySelector('[data-role="live-mount"]');
    fillAge(card.querySelector('[data-age-id]'));

    let liveIO = null;
    if (hasLive) {
      liveIO = buildInteractive(c);
      liveMount.appendChild(liveIO.wrap);
    }

    head.addEventListener('click', () => card.classList.toggle('is-open'));

    function setStatus(st) {
      card.dataset.status = st;
      statusEl.innerHTML = pill(st, statusClass(st));
      c._status = st;
      card.dispatchEvent(
        new CustomEvent('sxa:status', { bubbles: true, detail: { id: c.id, status: st } })
      );
    }

    // Render one real result (from a live fetch or, as a fallback, a scripted
    // run) into the console + evidence, and set the status from its verdict.
    function applyResult(res, mode, opts) {
      return streamLines(consoleEl, res.log || [L('(no output)', 'muted')], {
        live: !(opts && opts.batch),
      }).then(() => {
        if (c._lastInput == null) c._lastInput = SXA.defaultInput(c);
        if (mode === 'fixed') {
          evEl.innerHTML =
            (c._lastVuln ? evidenceBlock(c._lastVuln, 'vuln') : '') + evidenceBlock(res, 'fixed');
          // status comes from the fixed build's real response - never assumed
          setStatus(res.verdict === 'SECURE' ? STATUS.NOTFOUND : STATUS.CONFIRMED);
          c._lastFixed = res;
        } else {
          evEl.innerHTML = evidenceBlock(res, 'vuln');
          setStatus(res.status || (res.verdict === 'SECURE' ? STATUS.NOTFOUND : STATUS.CONFIRMED));
          fixBtn.disabled = false;
          c._lastVuln = res;
        }
      });
    }

    // ---- live interactive run: sends the operator's typed input to the real
    // backend and builds the verdict from the actual response ----
    async function runLive(mode, opts) {
      if (!(opts && opts.batch)) card.classList.add('is-open');
      const input = liveIO.read();
      c._lastInput = input;
      let res;
      try {
        res = await c.interactive.run(input, mode); // real fetch(); await the response
      } catch (err) {
        res = {
          log: [
            L('Request failed before a verdict could be computed:', 'bad'),
            L(String((err && err.message) || err), 'bad'),
          ],
          request: typeof input === 'string' ? input : JSON.stringify(input),
          response: 'No response (request threw).',
          verdict: 'VULNERABLE',
        };
      }
      await applyResult(res, mode, opts);
    }

    // ---- scripted fallback (only reached by a check with no live block) ----
    async function runScripted(mode, opts) {
      if (typeof c.run !== 'function') {
        await streamLines(consoleEl, [L('This check has no runnable test.', 'warn')], {
          live: !(opts && opts.batch),
        });
        return;
      }
      const res = await c.run(mode);
      await applyResult(res, mode, opts);
    }

    const drive = (mode, opts) => (hasLive ? runLive(mode, opts) : runScripted(mode, opts));

    // exposed so the panel's Run-all / Fix-all can drive cards without .click()
    card._sxaAttack = (opts) => drive('vuln', opts);
    card._sxaFix = (opts) => (fixBtn.disabled ? Promise.resolve() : drive('fixed', opts));

    card.querySelector('[data-act="attack"]').addEventListener('click', (e) => {
      e.stopPropagation();
      card.classList.add('is-open');
      drive('vuln');
    });
    fixBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      drive('fixed');
    });
    card.querySelector('[data-act="reset"]').addEventListener('click', (e) => {
      e.stopPropagation();
      consoleEl._sxaRun = (consoleEl._sxaRun || 0) + 1; // cancel any in-flight stream
      consoleEl.classList.remove('is-streaming');
      consoleEl.innerHTML =
        '<div class="sxa-line sxa-line--muted">Idle - press “Run test”' +
        (hasLive ? ', or type a payload above and send it,' : '') +
        ' to demonstrate the attack.</div>';
      evEl.innerHTML = '';
      fixBtn.disabled = true;
      c._lastVuln = null;
      c._lastFixed = null;
      c._lastInput = null;
      setStatus(STATUS.NOTTESTED);
    });

    // ---- wire the live payload box buttons to the real-fetch runner ----
    if (hasLive) {
      liveIO.wrap.querySelector('[data-act="live-vuln"]').addEventListener('click', (e) => {
        e.stopPropagation();
        runLive('vuln');
      });
      liveIO.wrap.querySelector('[data-act="live-fixed"]').addEventListener('click', (e) => {
        e.stopPropagation();
        runLive('fixed');
      });
      // Real time: as the admin types, re-send the input to the vulnerable build
      // and then to the fixed build (debounced; never for view-only accounts).
      let autoT = null, autoBusy = false;
      liveIO.wrap.addEventListener('input', (e) => {
        if (!e.target.classList.contains('sxa-live__input')) return;
        const auto = liveIO.wrap.querySelector('[data-role="autorun"]');
        if (!auto || !auto.checked) return;
        if (!window.WM_USER || window.WM_USER.role !== 'admin') return;
        clearTimeout(autoT);
        autoT = setTimeout(async () => {
          if (autoBusy) return; autoBusy = true;
          try { await runLive('vuln'); await runLive('fixed'); } finally { autoBusy = false; }
        }, 900);
      });
      liveIO.wrap.querySelectorAll('.sxa-preset').forEach((b) => b.addEventListener('click', () => {
        const auto = liveIO.wrap.querySelector('[data-role="autorun"]');
        if (auto && auto.checked && window.WM_USER && window.WM_USER.role === 'admin') setTimeout(async () => { await runLive('vuln'); await runLive('fixed'); }, 50);
      }));
      // Enter in a single-input box → run vulnerable build
      const single = liveIO.wrap.querySelector('[data-role="live-input"]');
      if (single)
        single.addEventListener('keydown', (e) => {
          if (e.key === 'Enter') {
            e.preventDefault();
            runLive('vuln');
          }
        });
    }

    c._status = STATUS.NOTTESTED;
    return card;
  };

  /* =====================================================================
   * PANEL - dashboard + filter bar + stacked check cards + report.
   * Used identically by all three sections for a consistent demo flow.
   * ===================================================================== */
  SXA.mountPanel = function (container, cfg) {
    container.classList.add('sxa');
    container.innerHTML =
      '<div class="sxa-head">' +
      '<div class="sxa-head__title">' +
      esc(cfg.title) +
      '</div>' +
      '<div class="sxa-head__sub">' +
      esc(cfg.subtitle || '') +
      '</div>' +
      '<div class="sxa-safe">Every test sends real HTTP requests to this server\'s own test routes and test accounts. No outside systems, real users or real data are touched. ' +
      'Authorized test identities and synthetic data only, per SIH26163 / NTRO scope.</div>' +
      (cfg.extraTop || '') +
      '</div>' +
      '<div class="sxa-dash" data-role="dash"></div>' +
      '<div class="sxa-toolbar">' +
      '<div class="sxa-filters" data-role="filters"></div>' +
      '<div class="sxa-runall">' +
      '<button class="sxa-btn sxa-btn--attack" data-role="runall">Run all tests</button>' +
      '<button class="sxa-btn sxa-btn--fix" data-role="fixall">Apply all fixes</button>' +
      '<button class="sxa-btn sxa-btn--ghost" data-role="dl-md">Download report</button>' +
      '<button class="sxa-btn sxa-btn--ghost" data-role="dl-json">Download evidence</button>' +
      '</div>' +
      '</div>' +
      (cfg.extraMid || '') +
      '<div class="sxa-cards" data-role="cards"></div>' +
      '<div class="sxa-report" data-role="report"></div>';

    const cardsWrap = container.querySelector('[data-role="cards"]');
    const dashEl = container.querySelector('[data-role="dash"]');
    const filtersEl = container.querySelector('[data-role="filters"]');
    const cards = [];

    cfg.checks.forEach((c) => {
      const card = SXA.makeCard(c);
      cards.push({ c, card });
      cardsWrap.appendChild(card);
    });

    function updateDash() {
      const counts = { total: cfg.checks.length };
      const byStatus = {};
      const bySev = {};
      cfg.checks.forEach((c) => {
        const st = c._status || STATUS.NOTTESTED;
        byStatus[st] = (byStatus[st] || 0) + 1;
        bySev[c.severity] = (bySev[c.severity] || 0) + 1;
      });
      const tile = (label, val, cls) =>
        '<div class="sxa-tile ' +
        (cls || '') +
        '"><div class="sxa-tile__v">' +
        val +
        '</div><div class="sxa-tile__l">' +
        esc(label) +
        '</div></div>';
      let html = tile('Total checks', counts.total, '');
      html += tile('Confirmed', byStatus[STATUS.CONFIRMED] || 0, 'sxa-tile--fail');
      html += tile('Not found (fixed)', byStatus[STATUS.NOTFOUND] || 0, 'sxa-tile--pass');
      html += tile('Suspected', byStatus[STATUS.SUSPECTED] || 0, 'sxa-tile--partial');
      html += tile('Not tested', byStatus[STATUS.NOTTESTED] || 0, 'sxa-tile--na');
      const sevs = ['Critical', 'High', 'Medium', 'Low', 'Informational'];
      html +=
        '<div class="sxa-tile sxa-tile--wide"><div class="sxa-tile__l">By severity</div><div class="sxa-sevbar">' +
        sevs
          .map(
            (s) =>
              '<span class="sxa-sevchip sxa-pill--' +
              sevClass(s) +
              '">' +
              s +
              ' <b style="margin-left:4px">' +
              (bySev[s] || 0) +
              '</b></span>'
          )
          .join('') +
        '</div></div>';
      dashEl.innerHTML = html;
    }

    const cats = Array.from(new Set(cfg.checks.map((c) => c.category)));
    const filterDefs = [{ key: 'all', label: 'All' }]
      .concat([
        { key: 'st:' + STATUS.CONFIRMED, label: 'Confirmed' },
        { key: 'st:' + STATUS.NOTFOUND, label: 'Fixed' },
        { key: 'st:' + STATUS.NOTTESTED, label: 'Not tested' },
      ])
      .concat(cats.map((c) => ({ key: 'cat:' + c, label: c })));
    filtersEl.innerHTML = filterDefs
      .map(
        (f, i) =>
          '<button class="sxa-chip' +
          (i === 0 ? ' is-on' : '') +
          '" data-f="' +
          esc(f.key) +
          '">' +
          esc(f.label) +
          '</button>'
      )
      .join('');
    filtersEl.addEventListener('click', (e) => {
      const b = e.target.closest('.sxa-chip');
      if (!b) return;
      filtersEl.querySelectorAll('.sxa-chip').forEach((x) => x.classList.toggle('is-on', x === b));
      const f = b.dataset.f;
      cards.forEach(({ c, card }) => {
        let show = true;
        if (f.startsWith('st:')) show = (c._status || STATUS.NOTTESTED) === f.slice(3);
        else if (f.startsWith('cat:')) show = c.category === f.slice(4);
        card.style.display = show ? '' : 'none';
      });
    });

    container.addEventListener('sxa:status', updateDash);

    container.querySelector('[data-role="runall"]').addEventListener('click', () => {
      cards.forEach(({ card }, i) => setTimeout(() => card._sxaAttack({ batch: true }), i * 80));
    });
    container.querySelector('[data-role="fixall"]').addEventListener('click', () => {
      cards.forEach(({ card }, i) => setTimeout(() => card._sxaFix({ batch: true }), i * 80));
    });

    /* ---- shared evidence/retest shapers (used by both .md and .json) ---- */
    function evidenceOf(res) {
      if (!res) return null;
      return {
        request: res.request || null,
        response: res.response || null,
        verdict: res.verdict || null,
        note: res.note || null,
        log: (res.log || []).map((l) => l.text),
      };
    }
    function verdictBeforeOf(c) {
      if (c._status === STATUS.CONFIRMED) return 'Confirmed';
      if (c._status === STATUS.SUSPECTED) return 'Suspected';
      return c._lastVuln ? 'Confirmed' : 'Not Tested';
    }
    function verdictAfterOf(c) {
      return c._lastFixed ? 'Not Found' : 'Not Tested';
    }
    function retestOf(c) {
      const inp = c._lastInput != null ? c._lastInput : SXA.defaultInput(c);
      const inpStr = SXA.inputToStr(inp);
      if (c._lastFixed) {
        return (
          'Re-tested against the fixed build with the same input ' +
          (inp == null ? '(default payload)' : '(' + inpStr + ')') +
          ' → ' + (c._lastFixed.verdict || 'SECURE') + ' / Not Found. ' +
          (c.retestNotes || 'Attack blocked after remediation.')
        );
      }
      if (c._lastVuln) return 'Vulnerable build confirmed; fix not yet applied in this run.';
      return 'Not retested in this run.';
    }

    function buildReport() {
      const now = nowISO();
      let md = '# ' + cfg.title + ' - Assessment Report\n\n';
      md += '**Target:** World Monitor application (SENTINEL-X)  \n';
      md += '**Generated:** ' + now + '  \n';
      md += '**Mode:** Real HTTP requests to this server\'s own test routes (no outside systems contacted)  \n\n';
      const confirmed = cfg.checks.filter((c) => c._status === STATUS.CONFIRMED);
      const fixed = cfg.checks.filter((c) => c._status === STATUS.NOTFOUND);
      md +=
        '**Summary:** ' +
        cfg.checks.length +
        ' checks · ' +
        confirmed.length +
        ' confirmed · ' +
        fixed.length +
        ' remediated (Not Found after fix).\n\n---\n\n';
      const evBlock = (label, res) => {
        if (!res) return '';
        let s = '**' + label + '**\n\n```\n';
        (res.log || []).forEach((l) => (s += l.text + '\n'));
        if (res.request) s += '\nRequest: ' + res.request + '\n';
        if (res.response) s += 'Response: ' + res.response + '\n';
        if (res.note) s += 'Note: ' + res.note + '\n';
        return s + '```\n\n';
      };
      cfg.checks.forEach((c) => {
        const inp = c._lastInput != null ? c._lastInput : SXA.defaultInput(c);
        md += '## ' + c.id + ' - ' + c.title + '\n\n';
        md += '- **Status:** ' + (c._status || STATUS.NOTTESTED) + '\n';
        md += '- **Category:** ' + c.category + '\n';
        md += '- **Attack vector:** ' + (c.attackVector || '-') + '\n';
        md += '- **Affected component:** ' + (c.affectedComponent || '-') + '\n';
        md += '- **Affected endpoint/page:** ' + (c.endpoint || '-') + '\n';
        md += '- **Affected party:** ' + (c.affectedParty || '-') + '\n';
        md += '- **Difficulty:** ' + (c.difficulty || '-') + ' · **Impact size:** ' + (c.impactSize || '-') + '\n';
        if (c.cia) md += '- **CIA:** C=' + c.cia.c + ' I=' + c.cia.i + ' A=' + c.cia.a + '\n';
        md += '- **Severity:** ' + c.severity + '\n';
        if (c.cvss) md += '- **CVSS:** ' + c.cvss.score + ' (' + c.cvss.vector + ')\n';
        if (c.cwe) md += '- **CWE:** ' + c.cwe + '\n';
        if (c.references && c.references.length)
          md += '- **References:** ' + c.references.join(', ') + '\n';
        md += '- **Input (payload tested):** `' + SXA.inputToStr(inp) + '`\n';
        md += '- **Verdict before:** ' + verdictBeforeOf(c) + ' · **Verdict after:** ' + verdictAfterOf(c) + '\n';
        md += '\n**Description.** ' + c.description + '\n\n';
        md += evBlock('Vulnerable evidence (request / response / log).', c._lastVuln);
        md += evBlock('Fixed evidence (same input, after remediation).', c._lastFixed);
        if (c.technicalImpact) md += '**Technical impact.** ' + c.technicalImpact + '\n\n';
        if (c.partyImpact)
          md += '**' + (c.partyImpactLabel || 'Impact') + '.** ' + c.partyImpact + '\n\n';
        if (c.orgImpact) md += '**Business impact.** ' + c.orgImpact + '\n\n';
        md += '**Remediation (summary).** ' + (c.remediation || '') + '\n\n';
        if (c.remediationCode) md += '```js\n' + c.remediationCode + '\n```\n\n';
        md += '**Retest.** ' + retestOf(c) + '\n\n---\n\n';
      });
      return md;
    }

    function download(name, text, type) {
      const blob = new Blob([text], { type: type || 'text/plain' });
      const a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = name;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        URL.revokeObjectURL(a.href);
        a.remove();
      }, 1000);
    }

    container.querySelector('[data-role="dl-md"]').addEventListener('click', () => {
      download(cfg.slug + '-report-' + Date.now() + '.md', buildReport(), 'text/markdown');
    });
    container.querySelector('[data-role="dl-json"]').addEventListener('click', () => {
      const data = cfg.checks.map((c) => {
        const inp = c._lastInput != null ? c._lastInput : SXA.defaultInput(c);
        return {
          id: c.id,
          title: c.title,
          category: c.category,
          status: c._status || STATUS.NOTTESTED,
          severity: c.severity,
          cvss: c.cvss
            ? { vector: c.cvss.vector, score: c.cvss.score, severity: c.severity }
            : null,
          affectedParty: c.affectedParty,
          endpoint: c.endpoint,
          input: inp,
          vulnerableEvidence: evidenceOf(c._lastVuln),
          fixedEvidence: evidenceOf(c._lastFixed),
          verdictBefore: verdictBeforeOf(c),
          verdictAfter: verdictAfterOf(c),
          remediation: { summary: c.remediation || '', code: c.remediationCode || '' },
          references: c.references || (c.cwe ? [c.cwe] : []),
          retestNotes: retestOf(c),
        };
      });
      download(
        cfg.slug + '-evidence-' + Date.now() + '.json',
        JSON.stringify({ target: 'World Monitor', generated: nowISO(), findings: data }, null, 2),
        'application/json'
      );
    });

    updateDash();
    return { cards, updateDash, buildReport };
  };
})();
