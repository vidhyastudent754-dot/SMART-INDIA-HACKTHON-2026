/* =============================================================================
 * live-io.js - REAL-TIME LIVE I/O layer for the SENTINEL-X assessment consoles.
 * ---------------------------------------------------------------------------
 * Loaded AFTER engine.js and BEFORE the three section files. It attaches an
 * `interactive` block (label + inputs + presets + run) to EACH of the 15
 * approved checks, keyed by id. Each `run(input, mode)` makes a REAL fetch() to
 * the backend router (assessment-api.js, mounted at /api/assess) with header
 * `X-Assess-Mode: vulnerable|fixed`, then builds the streamed console log, the
 * request/response evidence and the VERDICT from the ACTUAL HTTP status + body
 * - nothing is hard-coded. The user may type ANY input; the backend computes
 * the outcome.
 *
 * FINAL SCOPE - exactly the 15 registrations below (see registry.js). All
 * retired attack registrations have been removed; the backend also returns 404
 * UNSUPPORTED for their old routes.
 * ===========================================================================*/
(function () {
  'use strict';
  var SXA = (window.SXA = window.SXA || {});
  var L = function (text, kind) { return { text: text, kind: kind || 'info' }; };
  var LIVE = (SXA.LIVE = SXA.LIVE || {});

  // Same-origin by default; override with window.SXA_ASSESS_BASE if hosted apart.
  var BASE = (window.SXA_ASSESS_BASE || '') + '/api/assess';

  var fmt = function (v) {
    if (v == null) return '';
    return typeof v === 'string' ? v : JSON.stringify(v);
  };

  /* ---- the one real network call every check funnels through ---- */
  async function apiCall(path, opt) {
    opt = opt || {};
    var qs = opt.query ? '?' + new URLSearchParams(opt.query).toString() : '';
    var url = BASE + path + qs;
    var headers = Object.assign({ 'X-Assess-Mode': opt.mode }, opt.headers || {});
    var sentHeaders = Object.assign({}, headers);
    var init = { method: opt.method || 'GET', headers: headers, credentials: 'same-origin' };
    // The server only accepts JSON for state-changing requests (CSRF defence),
    // so every non-GET carries a JSON body, even an empty one.
    if (opt.body != null || (init.method !== 'GET' && init.method !== 'HEAD')) {
      headers['Content-Type'] = 'application/json';
      init.body = JSON.stringify(opt.body != null ? opt.body : {});
    }
    var clock = (typeof performance !== 'undefined' && performance.now) ? performance : Date;
    var t0 = clock.now();
    var resp = null, text = '', json = null, netErr = null, headers = {};
    try {
      resp = await fetch(url, init);
      resp.headers.forEach(function (v, k) { headers[k] = v; });   // every header the browser exposes
      text = await resp.text();
      try { json = JSON.parse(text); } catch (e) { /* non-JSON body */ }
    } catch (e) {
      netErr = String((e && e.message) || e);
    }
    var ms = (clock.now() - t0).toFixed(1);
    return {
      url: url, method: init.method,
      httpStatus: resp ? resp.status : 0,
      ok: resp ? resp.ok : false,
      text: text || '', json: json, ms: ms, netErr: netErr, headers: headers, mode: opt.mode, sentHeaders: sentHeaders,
    };
  }

  // headers worth showing in the console (the browser hides Set-Cookie from JS by design)
  function relevantHeaders(h) {
    if (!h) return '';
    return ['content-type', 'cache-control', 'retry-after', 'ratelimit-limit', 'ratelimit-remaining', 'x-ratelimit-limit', 'x-ratelimit-remaining', 'x-assess-mode', 'x-assess-verdict', 'content-security-policy', 'x-content-type-options', 'x-frame-options']
      .filter(function (k) { return h[k]; }).map(function (k) { return k + ': ' + (k === 'content-security-policy' ? h[k].slice(0, 60) + '…' : h[k]); }).join(' · ');
  }

  // pick a colour for a server log line consistent with the computed verdict
  function lineKind(s, verdict) {
    if (verdict === 'VULNERABLE' &&
      /vulnerab|leak|escap|inject|exposed|accept|bypass|dumped|reachable|forged|stale|unlimited|no ownership|no auth|not check|no rate|open redirect|cleartext|hard-?coded|frameable/i.test(s))
      return 'bad';
    if (verdict === 'SECURE' &&
      /secure|blocked|enforc|reject|redact|mask|patched|not observable|authoris|inert|revoked|throttl|confin|normalis/i.test(s))
      return 'good';
    return 'info';
  }

  /* ---- turn a real HTTP response into the {log,request,response,verdict} the
   *      engine renders. Verdict is READ from the live response, never fixed. */
  function buildResult(r, payloadShown) {
    if (r.netErr) {
      return {
        log: [
          L('$ ' + r.method + ' ' + r.url, 'cmd'),
          L('✗ network error: ' + r.netErr, 'bad'),
          L('Backend unreachable. Start it with:  npm start  (→ http://localhost:5175)', 'warn'),
        ],
        request: r.method + ' ' + r.url + (payloadShown != null ? '  ' + fmt(payloadShown) : ''),
        response: 'network error - no response (' + r.netErr + ')',
        verdict: 'VULNERABLE',
        note: 'Could not reach /api/assess. Ensure the server is running and the router is mounted.',
      };
    }
    var j = r.json || {};
    // A retired/unsupported route no longer executes - surface it plainly.
    if (j.verdict === 'UNSUPPORTED' || (r.httpStatus === 404 && j.approvedAttackIds)) {
      return { log: [L('$ ' + r.method + ' ' + r.url, 'cmd'), L('← HTTP 404 · ' + (j.error || 'unsupported'), 'warn')],
        request: r.method + ' ' + r.url, response: 'HTTP 404 · retired/unsupported attack route', verdict: 'SECURE',
        note: 'SENTINEL-X supports exactly 15 attacks; this route has been removed.' };
    }
    var verdict = j.verdict === 'SECURE' ? 'SECURE' : (j.verdict === 'ASSESSMENT_ERROR' ? 'ASSESSMENT_ERROR' : 'VULNERABLE');
    var okKind = r.httpStatus < 400 ? 'good' : 'bad';
    var lines = [];
    lines.push(L('$ ' + r.method + ' ' + r.url, 'cmd'));
    if (payloadShown != null) lines.push(L('→ payload: ' + fmt(payloadShown), 'muted'));
    lines.push(L('← HTTP ' + r.httpStatus + '   (' + r.ms + ' ms)', okKind));
    var hdrs = relevantHeaders(r.headers);
    if (hdrs) lines.push(L('← headers: ' + hdrs, 'muted'));
    lines.push(L('← body: ' + (r.text.length > 600 ? r.text.slice(0, 600) + '… (' + r.text.length + ' bytes)' : r.text), 'muted'));
    if (r.httpStatus === 403 && !j.verdict) {
      lines.push(L('✗ ' + (j.error || 'forbidden') + ' - your role cannot run this check.', 'bad'));
      return { log: lines, request: r.method + ' ' + r.url, response: 'HTTP 403 · ' + (j.error || ''), verdict: 'VULNERABLE',
        note: 'Blocked by role-based access control: employee/organisation checks require the admin role.' };
    }
    if (j.path === 'real') lines.push(L('path: REAL APP - live session + real HTTP to the production route / lab twin', 'good'));
    else if (j.path === 'simulated') lines.push(L('path: simulated fallback' + (j.note ? ' - ' + j.note : ''), 'warn'));
    (j.serverLog || []).forEach(function (s) { lines.push(L(String(s), lineKind(String(s), verdict))); });
    lines.push(L('verdict ← computed from live response: ' + verdict, verdict === 'SECURE' ? 'good' : (verdict === 'ASSESSMENT_ERROR' ? 'warn' : 'bad')));
    return {
      log: lines,
      request: r.method + ' ' + r.url + (payloadShown != null ? '  ' + fmt(payloadShown) : ''),
      response: 'HTTP ' + r.httpStatus + '  ·  ' + (j.response || r.text.slice(0, 240)),
      verdict: verdict,
      note: j.note || undefined,
      // the raw exchange, exactly as the browser received it (shown in Evidence + exported)
      http: { method: r.method, url: r.url, status: r.httpStatus, ms: Number(r.ms), headers: r.headers || {}, body: r.text,
        requestHeaders: r.sentHeaders || { 'X-Assess-Mode': r.mode }, requestBody: payloadShown != null ? payloadShown : null },
    };
  }

  /* ---- register helper: cfg → SXA.LIVE[id] with a real-fetch run() ---- */
  function reg(id, cfg) {
    var interactive = {
      label: cfg.label,
      hint: cfg.hint,
      type: cfg.fields ? 'fields' : 'text',
      fields: cfg.fields,
      placeholder: cfg.placeholder,
      value: cfg.value,
      presets: cfg.presets,
      run: async function (input, mode) {
        var spec;
        try { spec = cfg.build(input, mode) || {}; }
        catch (e) {
          return {
            log: [L('Input rejected before dispatch: ' + ((e && e.message) || e), 'bad')],
            request: fmt(input), response: 'not sent - malformed input', verdict: 'VULNERABLE',
          };
        }
        var path = typeof cfg.path === 'function' ? cfg.path(input, mode) : cfg.path;
        var r = await apiCall(path, {
          mode: mode, method: cfg.method || 'GET',
          body: spec.body, query: spec.query, headers: spec.headers,
        });
        var shown = spec.payloadShown != null ? spec.payloadShown : (spec.body || spec.query || null);
        return buildResult(r, shown);
      },
    };
    LIVE[id] = { interactive: interactive, references: cfg.references, retestNotes: cfg.retestNotes };
  }

  /* =========================================================================
   * SECTION 1 - INDIVIDUAL (IND-06, IND-10, IND-03, IND-01, IND-04)
   * =======================================================================*/

  reg('IND-06', {
    label: 'Comment / display name to store (stored-XSS test)',
    hint: 'Stored in SQLite then served back. Vuln serves it raw (executes in a browser); fixed sanitises it.',
    placeholder: '<script>steal()</script>', value: '<script>document.title="xss"</script>',
    presets: [
      { label: '<script>…</script>', value: '<script>document.title="xss"</script>' },
      { label: '<img onerror>', value: '<img src=x onerror=alert(1)>' },
      { label: 'plain comment', value: 'Great dashboard!' },
    ],
    method: 'POST', path: '/store-comment',
    build: function (b) { return { body: { body: String(b == null ? '' : b) }, payloadShown: { body: String(b == null ? '' : b) } }; },
    references: ['OWASP A03:2021', 'CWE-79', 'CWE-116'],
    retestNotes: 'Fixed build strips tags and escapes the stored value on retrieval (see /comment/:id?render=1).',
  });

  reg('IND-10', {
    label: 'Account id to fetch (over-exposure test)',
    hint: 'Vuln returns the full internal record (hash, ssn, internal id); fixed returns a projection.',
    placeholder: 'U-A', value: 'U-A',
    presets: [{ label: 'U-A', value: 'U-A' }, { label: 'U-B', value: 'U-B' }],
    method: 'GET', path: '/user-record',
    build: function (id) { return { query: { id: String(id || 'U-A') }, payloadShown: { id: String(id || 'U-A') } }; },
    references: ['OWASP A01:2021', 'CWE-213', 'API3:2023'],
    retestNotes: 'Fixed build returns only allow-listed fields.',
  });

  reg('IND-03', {
    label: 'Session id to log out then replay',
    hint: 'The backend creates the session, logs it out, then replays this sid. Fixed revokes server-side.',
    placeholder: 'sid-A-legit', value: 'sid-A-legit',
    presets: [{ label: 'sid-A-legit', value: 'sid-A-legit' }],
    method: 'POST', path: '/session-replay',
    build: function (sid) { return { body: { sid: String(sid || '') }, payloadShown: { sid: String(sid || '') } }; },
    references: ['OWASP A07:2021', 'CWE-613', 'CWE-614'],
    retestNotes: 'Fixed build invalidates the session server-side on logout; replay returns 401.',
  });

  reg('IND-01', {
    label: 'Email to probe (real POST /api/assess/login-probe)',
    hint: 'Type any email. The backend probes it AND a control address and compares the two real responses.',
    placeholder: 'testa@wm.local', value: 'testa@wm.local',
    presets: [
      { label: 'known: testa@wm.local', value: 'testa@wm.local' },
      { label: 'unknown: ghost@wm.local', value: 'ghost@wm.local' },
    ],
    method: 'POST', path: '/login-probe',
    build: function (email) { return { body: { email: String(email || '') }, payloadShown: { email: String(email || '') } }; },
    references: ['OWASP A07:2021', 'CWE-204', 'WSTG-IDNT-04'],
    retestNotes: 'Fixed build returns an identical response for known and unknown accounts.',
  });

  reg('IND-04', {
    label: 'Reset token + age (real TTL + single-use)',
    hint: 'Tokens are stored in SQLite and attempted twice. Fixed enforces a 15-min TTL and single use. Re-run the same token (even after a server restart) and it stays used.',
    fields: [
      { key: 'token', label: 'token', placeholder: 'reset-abc123', value: 'reset-' + Math.random().toString(36).slice(2, 8) },
      { key: 'elapsedMinutes', label: 'elapsedMinutes (age when first issued)', placeholder: '0', value: '0' },
    ],
    presets: [
      { label: 'new token (0 min)', values: { token: 'reset-' + Math.random().toString(36).slice(2, 8), elapsedMinutes: '0' } },
      { label: 'expired token (issued 20 min ago)', values: { token: 'reset-old-' + Math.random().toString(36).slice(2, 6), elapsedMinutes: '20' } },
      { label: 'persisted demo token', values: { token: 'reset-demo-persist', elapsedMinutes: '0' } },
    ],
    method: 'POST', path: '/reset-token',
    build: function (o) {
      o = o || {};
      var body = { token: String(o.token || ''), elapsedMinutes: Number(o.elapsedMinutes || 0) };
      return { body: body, payloadShown: body };
    },
    references: ['OWASP A07:2021', 'CWE-640', 'CWE-613'],
    retestNotes: 'Fixed build rejects reused or expired tokens on the second attempt.',
  });

  /* =========================================================================
   * SECTION 2 - EMPLOYEE & MANAGER (EMP-04, EMP-09, EMP-02, EMP-08, EMP-12)
   * Caller identity travels in X-Assess-User (EMP-A|EMP-B|MGR-1|ADM-1).
   * =======================================================================*/

  reg('EMP-04', {
    label: 'Record id to read (IDOR / BOLA)',
    hint: 'Runs against the REAL app: a live employee session sends real HTTP to /api/records/:id (fixed) or its lab twin without the ownership check (vulnerable).',
    fields: [
      { key: 'recordId', label: 'recordId', placeholder: '1002', value: '1002' },
      { key: 'as', label: 'as', placeholder: 'EMP-A', value: 'EMP-A' },
    ],
    presets: [
      { label: 'EMP-A → 1002 (B’s)', values: { recordId: '1002', as: 'EMP-A' } },
      { label: 'EMP-A → 1001 (own)', values: { recordId: '1001', as: 'EMP-A' } },
    ],
    method: 'GET',
    path: function (o) { o = o || {}; return '/record/' + encodeURIComponent(o.recordId || '1002'); },
    build: function (o) { o = o || {}; return { headers: { 'X-Assess-User': String(o.as || 'EMP-A') }, payloadShown: { recordId: o.recordId, as: o.as } }; },
    references: ['OWASP A01:2021', 'CWE-639', 'API1:2023'],
    retestNotes: 'Fixed build ties every object reference to an ownership check.',
  });

  reg('EMP-09', {
    label: 'Profile update body (mass assignment)',
    hint: 'Runs against the REAL app: PATCH /api/profile (allow-list) vs the lab twin (assigns the whole body). The DB row is read back to prove what persisted.',
    fields: [
      { key: 'name', label: 'name', placeholder: 'A. Employee', value: 'A. Employee' },
      { key: 'role', label: 'role', placeholder: 'admin', value: 'admin' },
    ],
    presets: [
      { label: 'name + role:admin', values: { name: 'A. Employee', role: 'admin' } },
      { label: 'name only', values: { name: 'A. Employee', role: '' } },
    ],
    method: 'POST', path: '/update-profile',
    build: function (o) {
      o = o || {};
      var body = { name: String(o.name || '') };
      if (o.role) body.role = String(o.role);
      return { body: body, payloadShown: body };
    },
    references: ['OWASP A08:2021', 'CWE-915', 'API6:2023'],
    retestNotes: 'Fixed build strips protected fields; role cannot be self-assigned.',
  });

  reg('EMP-02', {
    label: 'Call an admin-only action (vertical escalation)',
    hint: 'Send as an employee. Vuln performs it; fixed requires role=admin → 403. Role is looked up server-side.',
    placeholder: 'EMP-A', value: 'EMP-A',
    presets: [{ label: 'as EMP-A', value: 'EMP-A' }, { label: 'as ADM-1', value: 'ADM-1' }],
    method: 'POST', path: '/admin-action',
    build: function (as) { return { headers: { 'X-Assess-User': String(as || 'EMP-A') }, body: { op: 'deleteAllLogs' }, payloadShown: { as: String(as || 'EMP-A'), op: 'deleteAllLogs' } }; },
    references: ['OWASP A01:2021', 'CWE-269', 'API5:2023'],
    retestNotes: 'Fixed build restricts the action to admins.',
  });

  reg('EMP-08', {
    label: 'JWT to verify (alg=none / signature)',
    hint: 'Paste a JWT, or leave blank to have the backend forge an alg=none admin token. Fixed verifies HS256.',
    placeholder: 'eyJhbGciOiJub25lI…  (blank = forge one)', value: '',
    presets: [{ label: 'forge alg=none admin', value: '' }],
    method: 'POST', path: '/jwt-verify',
    build: function (jwt) { return { body: { jwt: String(jwt || '') }, payloadShown: { jwt: jwt ? String(jwt).slice(0, 24) + '…' : '(server forges alg=none)' } }; },
    references: ['OWASP A02:2021', 'CWE-347', 'CWE-345'],
    retestNotes: 'Fixed build pins alg=HS256 and verifies the signature; forged tokens are rejected.',
  });

  reg('EMP-12', {
    label: 'Idle minutes (session timeout test)',
    hint: 'Type an idle duration (controlled clock). Vuln keeps the session alive forever; fixed expires it after 15 min.',
    placeholder: '60', value: '60',
    presets: [{ label: '60 min', value: '60' }, { label: '5 min', value: '5' }],
    method: 'POST', path: '/idle-check',
    build: function (v) { return { body: { idleMinutes: Number(v || 0) }, payloadShown: { idleMinutes: Number(v || 0) } }; },
    references: ['OWASP A07:2021', 'CWE-613'],
    retestNotes: 'Fixed build enforces an idle timeout and revokes the API session on logout.',
  });

  /* =========================================================================
   * SECTION 3 - ORGANIZATION (ORG-06, ORG-09, ORG-15, ORG-16, ORG-11)
   * =======================================================================*/

  reg('ORG-06', {
    label: 'Search term (SQL injection, synthetic table)',
    hint: 'Type a search term or an injection like \' OR \'1\'=\'1. Vuln concatenates; fixed parameterises.',
    placeholder: "' OR '1'='1", value: "' OR '1'='1",
    presets: [
      { label: "' OR '1'='1", value: "' OR '1'='1" },
      { label: "'; --", value: "admin'; --" },
      { label: 'legit: alice', value: 'alice' },
    ],
    method: 'POST', path: '/search',
    build: function (q) { return { body: { q: String(q == null ? '' : q) }, payloadShown: { q: String(q == null ? '' : q) } }; },
    references: ['OWASP A03:2021', 'CWE-89', 'WSTG-INPV-05'],
    retestNotes: 'Fixed build uses a parameterised query; injection returns only literal matches.',
  });

  reg('ORG-09', {
    label: 'File path (path traversal, virtual FS)',
    hint: 'Type ../../etc/passwd. Vuln escapes the base within a VIRTUAL map; fixed normalises + blocks.',
    placeholder: '../../etc/passwd', value: '../../etc/passwd',
    presets: [
      { label: '../../etc/passwd', value: '../../etc/passwd' },
      { label: '../config/secrets.env', value: '../config/secrets.env' },
      { label: 'index.html (legit)', value: 'index.html' },
    ],
    method: 'GET', path: '/file',
    build: function (p) { return { query: { path: String(p == null ? '' : p) }, payloadShown: { path: String(p == null ? '' : p) } }; },
    references: ['OWASP A01:2021', 'CWE-22', 'WSTG-ATHZ-01'],
    retestNotes: 'Fixed build normalises the path and confines it to the base directory.',
  });

  reg('ORG-15', {
    label: 'Requests + window (rate-limit test)',
    hint: 'Fire N requests into a window against a REAL stateful counter. Fixed returns 429 after 5.',
    fields: [
      { key: 'requestCount', label: 'requestCount', placeholder: '8', value: '8' },
      { key: 'windowSeconds', label: 'windowSeconds', placeholder: '60', value: '60' },
    ],
    presets: [
      { label: '8 / 60s', values: { requestCount: '8', windowSeconds: '60' } },
      { label: '3 / 60s', values: { requestCount: '3', windowSeconds: '60' } },
    ],
    method: 'POST', path: '/rate-test',
    build: function (o) { o = o || {}; var body = { requestCount: Number(o.requestCount || 0), windowSeconds: Number(o.windowSeconds || 60) }; return { body: body, payloadShown: body }; },
    references: ['OWASP A04:2021', 'CWE-770', 'API4:2023'],
    retestNotes: 'Fixed build throttles excess requests with HTTP 429.',
  });

  reg('ORG-16', {
    label: 'Data-protection / PII masking check',
    hint: 'No payload - press send. Vuln returns card/SSN in cleartext; fixed masks + encrypts at rest.',
    placeholder: '(press send)', value: '',
    presets: [{ label: 'run data-protection check', value: '' }],
    method: 'GET', path: '/data-protection',
    build: function () { return {}; },
    references: ['OWASP A02:2021', 'CWE-311', 'CWE-312'],
    retestNotes: 'Fixed build masks PII in transit and encrypts it at rest.',
  });

  reg('ORG-11', {
    label: 'Real npm audit of the dependency lockfile',
    hint: 'No payload - press send. The backend runs a REAL `npm audit --json`: fixed audits the project’s clean lockfile, vulnerable audits a deliberately-outdated fixture. CVEs come from the live advisory DB.',
    placeholder: '(press send)', value: '',
    presets: [{ label: 'run npm audit', value: '' }],
    method: 'GET', path: '/deps',
    build: function () { return {}; },
    references: ['OWASP A06:2021', 'CWE-1104', 'CWE-937'],
    retestNotes: 'Fixed build audits the real, current lockfile - a live npm audit returns no findings.',
  });
})();
