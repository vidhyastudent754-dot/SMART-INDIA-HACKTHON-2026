/* individual.js - SECTION 1 · Individual User Security Assessment
 * FINAL SCOPE: exactly 5 attacks (IND-06, IND-10, IND-03, IND-01, IND-04),
 * derived from the authoritative registry (registry.js), plus one DEFENSIVE
 * capability - SMS Fraud Detection - rendered as a clearly-labelled non-attack
 * card. Mounts into #page-vuln inside #section-1. */
(function () {
  'use strict';
  const A = 'Test User A';
  const B = 'Test User B';

  const checks = [
    /* 1 ── IND-06 Stored XSS ───────────────────────────────────────── */
    {
      id: 'IND-06',
      title: 'Stored XSS in profile / comment field',
      category: 'Client-side',
      difficulty: 'Medium',
      impactSize: 'Medium',
      affectedParty: 'Individual',
      cia: { c: 'High', i: 'High', a: 'Low' },
      severity: 'High',
      cvss: { score: '6.5', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:C/C:L/I:L/A:N' },
      cwe: 'CWE-79 (Stored XSS)',
      description:
        'User-controlled content (display name / comment) is saved and later rendered without sanitisation, so the payload runs for anyone who views it.',
      affectedComponent: 'Profile & comments - content renderer',
      endpoint: 'POST /api/assess/store-comment · GET /api/assess/comment/:id',
      attackVector: 'Web (persisted payload)',
      technicalImpact: 'Payload executes for every viewer of the stored content.',
      partyImpactLabel: 'Individual-user impact',
      partyImpact: 'One user’s stored payload can hit other users who open the profile/comment.',
      remediation: 'Sanitise on output (allow-list), encode HTML, and apply CSP.',
      remediationCode:
        "// store raw, but sanitise on render\nconst clean = DOMPurify.sanitize(profile.displayName, { ALLOWED_TAGS: [] });\nnameEl.textContent = clean; // textContent, not innerHTML",
    },

    /* 2 ── IND-10 Sensitive Data Over-Exposed ──────────────────────── */
    {
      id: 'IND-10',
      title: 'Sensitive data over-exposed in user response',
      category: 'Data handling',
      difficulty: 'Easy',
      impactSize: 'Medium',
      affectedParty: 'Individual',
      cia: { c: 'High', i: 'Low', a: 'Low' },
      severity: 'Medium',
      cvss: { score: '5.3', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:N/A:N' },
      cwe: 'CWE-213 / CWE-200 (Exposure of Sensitive Information)',
      description:
        'The account API returns fields the client never needs - password hash, internal IDs, tokens - leaking sensitive metadata to the user’s browser.',
      affectedComponent: 'Account API - response serializer',
      endpoint: 'GET /api/assess/user-record',
      attackVector: 'Web / API (authenticated)',
      technicalImpact: 'Secrets and internal structure disclosed in the response body.',
      partyImpactLabel: 'Individual-user impact',
      partyImpact: 'The user’s (and system’s) sensitive fields are exposed to anything reading the response.',
      remediation: 'Return an explicit allow-list of safe fields; never serialize the whole record.',
      remediationCode:
        "res.json({ id: u.publicId, name: u.name, email: u.email }); // allow-list only\n// never: res.json(u)",
    },

    /* 3 ── IND-03 Session Valid After Logout ───────────────────────── */
    {
      id: 'IND-03',
      title: 'Session valid after logout (insecure session)',
      category: 'Session',
      difficulty: 'Medium',
      impactSize: 'Medium',
      affectedParty: 'Individual',
      cia: { c: 'High', i: 'Medium', a: 'Low' },
      severity: 'High',
      cvss: { score: '7.1', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:R/S:U/C:H/I:L/A:N' },
      cwe: 'CWE-613 / CWE-614 (Insufficient Session Expiration / Sensitive Cookie without flags)',
      description:
        'The session ID stays valid after logout, and the cookie is set without HttpOnly / Secure / SameSite - so a stolen or copied session keeps working.',
      affectedComponent: 'Session infrastructure - cookie flags & invalidation',
      endpoint: 'POST /api/assess/session-replay',
      attackVector: 'Web / XSS-assisted',
      technicalImpact: 'Session theft; logout does not end the server-side session.',
      partyImpactLabel: 'Individual-user impact',
      partyImpact: 'An attacker who obtains the cookie stays logged in as the user even after the user logs out.',
      remediation:
        'Set HttpOnly, Secure, SameSite=Lax/Strict; regenerate the ID on login; delete the server-side session on logout.',
      remediationCode:
        "res.cookie('sid', id, { httpOnly:true, secure:true, sameSite:'strict' });\napp.post('/logout', (req,res)=>{ sessionStore.destroy(req.sid); res.clearCookie('sid'); res.sendStatus(204); });",
    },

    /* 4 ── IND-01 Account Enumeration ──────────────────────────────── */
    {
      id: 'IND-01',
      title: 'Account enumeration on login / password reset',
      category: 'Authentication',
      difficulty: 'Easy',
      impactSize: 'Small',
      affectedParty: 'Individual',
      cia: { c: 'Medium', i: 'Low', a: 'Low' },
      severity: 'Medium',
      cvss: { score: '5.3', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:N/A:N' },
      cwe: 'CWE-204 (Observable Response Discrepancy)',
      description:
        'The login / password-recovery responses differ for accounts that exist versus accounts that do not, letting an attacker confirm which emails are registered.',
      affectedComponent: 'Authentication service - login & password-reset responses',
      endpoint: 'POST /api/assess/login-probe',
      attackVector: 'Web (unauthenticated)',
      technicalImpact: 'Distinct status/body reveals valid usernames, enabling targeted phishing/credential-stuffing.',
      partyImpactLabel: 'Individual-user impact',
      partyImpact: 'A specific person can be confirmed as a user and then targeted with tailored phishing.',
      remediation: 'Return one generic message and identical status/timing for existing and non-existing accounts.',
      remediationCode:
        "// Uniform response regardless of account existence\nreturn res.status(200).json({\n  message: 'If an account exists, a reset link has been sent.'\n});",
    },

    /* 5 ── IND-04 Password Reset Token Reusable ────────────────────── */
    {
      id: 'IND-04',
      title: 'Password-reset token reusable & long-lived',
      category: 'Authentication',
      difficulty: 'Medium',
      impactSize: 'Medium',
      affectedParty: 'Individual',
      cia: { c: 'High', i: 'High', a: 'Low' },
      severity: 'High',
      cvss: { score: '7.5', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N' },
      cwe: 'CWE-640 (Weak Password Recovery Mechanism)',
      description:
        'A reset token remains valid after it has been used and does not expire, so a token captured once can reset the password again later.',
      affectedComponent: 'Authentication service - reset-token lifecycle',
      endpoint: 'POST /api/assess/reset-token',
      attackVector: 'Web (token replay)',
      technicalImpact: 'Single-use assumption broken → account takeover from a leaked/old link.',
      partyImpactLabel: 'Individual-user impact',
      partyImpact: 'A reset link that leaks (browser history, proxy log) can hijack the account days later.',
      remediation: 'Make tokens single-use, short-lived (≤15 min), high-entropy, and invalidate all others on use.',
      remediationCode:
        "const t = tokens.get(token);\nif (!t || t.used || t.expires < Date.now()) return res.status(400).json({error:'Invalid or expired token'});\nt.used = true; // consume\nawait setPassword(t.userId, newPw);",
    },
  ];

  function mount() {
    const host = document.querySelector('#section-1 #page-vuln');
    if (!host || host.dataset.mounted) return;
    host.dataset.mounted = '1';
    window.SXA.mountPanel(host, {
      title: 'Individual Security Assessment',
      slug: 'individual',
      subtitle:
        'White-hat checks for the 5 approved vulnerabilities affecting one user account, browser session, or user-owned data. Test identities: ' +
        A + ' / ' + B +
        '. Each check proves the weakness on a vulnerable build, then shows the same attack blocked after the fix.',
      checks,
    });
    // Defensive capability (SMS Fraud Detection) appends itself after the attack
    // cards via sms-fraud-ui.js - it is NOT an attack and is NOT counted.
    if (window.SXSMS && typeof window.SXSMS.mount === 'function') window.SXSMS.mount(host);
  }

  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
