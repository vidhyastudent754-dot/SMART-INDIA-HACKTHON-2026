/* =============================================================================
 * registry.js - SINGLE AUTHORITATIVE ATTACK REGISTRY for SENTINEL-X.
 *
 * This is the one source of truth for the assessment scope. The backend
 * (assessment-api.js, validate-attacks.js, verify-runtime.js), the frontend
 * (individual.js / employee-manager.js / company-org.js / live-io.js) and the
 * tests all derive their attack list from here.
 *
 * FINAL SCOPE - exactly 15 attacks + 1 defensive capability:
 *
 *   SECTION 1 - INDIVIDUAL USER          SECTION 2 - EMPLOYEE & MANAGER
 *     IND-06  Stored XSS                   EMP-04  IDOR (real production route)
 *     IND-10  Sensitive Data Over-Exposed  EMP-09  Mass Assignment (real route)
 *     IND-03  Session Valid After Logout   EMP-02  Vertical Privilege Escalation
 *     IND-01  Account Enumeration          EMP-08  Forged JWT (alg=none)
 *     IND-04  Password Reset Token Reusable EMP-12 No Idle Session Timeout
 *     + SMS FRAUD DETECTION [defensive]
 *
 *   SECTION 3 - ORGANIZATION
 *     ORG-06  SQL Injection
 *     ORG-09  Path Traversal
 *     ORG-15  No Rate Limiting
 *     ORG-16  PII in Cleartext
 *     ORG-11  Vulnerable Dependencies (real package-lock.json scan)
 *
 * The SMS Fraud Detector is a DEFENSIVE capability. It is NOT an attack, is NOT
 * numbered, and is NOT part of the count of 15.
 *
 * This file is loadable in both Node (module.exports) and the browser
 * (window.SX_REGISTRY) so the same object is the truth everywhere.
 * ===========================================================================*/
(function () {
  'use strict';

  /* Each entry: id, section (1|2|3), title, method, path (backend route under
   * /api/assess), and a short note. `path` is the canonical runtime endpoint;
   * where the id maps to more than one route the primary is listed and extras
   * are in `aux`.                                                             */
  var ATTACKS = [
    /* ---- SECTION 1 - INDIVIDUAL (order per spec) ---- */
    { id: 'IND-06', section: 1, title: 'Stored XSS',                     method: 'POST', path: '/store-comment', aux: ['/comment/:id'], cwe: 'CWE-79',  severity: 'High' },
    { id: 'IND-10', section: 1, title: 'Sensitive Data Over-Exposed',    method: 'GET',  path: '/user-record',                          cwe: 'CWE-213', severity: 'Medium' },
    { id: 'IND-03', section: 1, title: 'Session Valid After Logout',     method: 'POST', path: '/session-replay',                       cwe: 'CWE-613', severity: 'High' },
    { id: 'IND-01', section: 1, title: 'Account Enumeration',            method: 'POST', path: '/login-probe',                          cwe: 'CWE-204', severity: 'Medium' },
    { id: 'IND-04', section: 1, title: 'Password Reset Token Reusable',  method: 'POST', path: '/reset-token',                          cwe: 'CWE-640', severity: 'High' },

    /* ---- SECTION 2 - EMPLOYEE & MANAGER ---- */
    { id: 'EMP-04', section: 2, title: 'IDOR on Real Production Route',            method: 'GET',  path: '/record/:id',     cwe: 'CWE-639', severity: 'High' },
    { id: 'EMP-09', section: 2, title: 'Mass Assignment on Real Production Route', method: 'POST', path: '/update-profile', cwe: 'CWE-915', severity: 'High' },
    { id: 'EMP-02', section: 2, title: 'Vertical Privilege Escalation',           method: 'POST', path: '/admin-action',   cwe: 'CWE-269', severity: 'High' },
    { id: 'EMP-08', section: 2, title: 'Forged JWT (alg=none)',                   method: 'POST', path: '/jwt-verify',     cwe: 'CWE-347', severity: 'Critical' },
    { id: 'EMP-12', section: 2, title: 'No Idle Session Timeout',                 method: 'POST', path: '/idle-check',     cwe: 'CWE-613', severity: 'Medium' },

    /* ---- SECTION 3 - ORGANIZATION ---- */
    { id: 'ORG-06', section: 3, title: 'SQL Injection',            method: 'POST', path: '/search',          cwe: 'CWE-89',  severity: 'Critical' },
    { id: 'ORG-09', section: 3, title: 'Path Traversal',           method: 'GET',  path: '/file',            cwe: 'CWE-22',  severity: 'High' },
    { id: 'ORG-15', section: 3, title: 'No Rate Limiting',         method: 'POST', path: '/rate-test',       cwe: 'CWE-770', severity: 'Medium' },
    { id: 'ORG-16', section: 3, title: 'PII in Cleartext',         method: 'GET',  path: '/data-protection', cwe: 'CWE-311', severity: 'High' },
    { id: 'ORG-11', section: 3, title: 'Vulnerable Dependencies',  method: 'GET',  path: '/deps',            cwe: 'CWE-1104', severity: 'High' },
  ];

  /* The defensive capability - deliberately OUTSIDE the attack list/count. */
  var DEFENSIVE = [
    { id: 'SMS-FRAUD', kind: 'defensive', section: 1, title: 'SMS Fraud Detection',
      method: 'POST', path: '/api/sms/analyze',
      note: 'Real-time smishing / OTP-disclosure / phishing detector. Not an attack; not counted.' },
  ];

  var EXPECTED_COUNT = 15;

  var SECTION_NAMES = { 1: 'Individual User', 2: 'Employee & Manager', 3: 'Organization' };

  function ids() { return ATTACKS.map(function (a) { return a.id; }); }
  function idSet() { var s = {}; ids().forEach(function (i) { s[i] = true; }); return s; }
  function bySection(n) { return ATTACKS.filter(function (a) { return a.section === n; }); }
  function get(id) { return ATTACKS.filter(function (a) { return a.id === id; })[0] || null; }
  function isApproved(id) { return !!get(id); }

  /* Self-validation used by validate-attacks.js and the tests. Returns a report
   * object; `ok` is true only when the scope is exactly the approved 15.       */
  function validate() {
    var list = ids();
    var seen = {}, duplicates = [];
    list.forEach(function (id) { if (seen[id]) duplicates.push(id); seen[id] = true; });
    var report = {
      expectedCount: EXPECTED_COUNT,
      actualCount: list.length,
      duplicates: duplicates,
      duplicateCount: duplicates.length,
      sectionCounts: { 1: bySection(1).length, 2: bySection(2).length, 3: bySection(3).length },
      defensiveCount: DEFENSIVE.length,
    };
    report.ok = report.actualCount === EXPECTED_COUNT &&
      report.duplicateCount === 0 &&
      report.sectionCounts[1] === 5 && report.sectionCounts[2] === 5 && report.sectionCounts[3] === 5;
    return report;
  }

  var REGISTRY = {
    ATTACKS: ATTACKS,
    DEFENSIVE: DEFENSIVE,
    EXPECTED_COUNT: EXPECTED_COUNT,
    SECTION_NAMES: SECTION_NAMES,
    ids: ids,
    idSet: idSet,
    bySection: bySection,
    get: get,
    isApproved: isApproved,
    validate: validate,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = REGISTRY;
  if (typeof window !== 'undefined') window.SX_REGISTRY = REGISTRY;
})();
