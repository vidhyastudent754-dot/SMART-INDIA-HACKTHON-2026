/* employee-manager.js - SECTION 2 · Employee & Manager Security Assessment
 * FINAL SCOPE: exactly 5 attacks (EMP-04, EMP-09, EMP-02, EMP-08, EMP-12),
 * derived from the authoritative registry (registry.js). Authorization,
 * authentication, session and business logic across a test role hierarchy
 * (Employee → Manager → Administrator). Mounts into #section-2. */
(function () {
  'use strict';

  const checks = [
    /* 1 ── EMP-04 IDOR on a real production route ──────────────────── */
    {
      id: 'EMP-04',
      title: 'IDOR / BOLA on real production route',
      category: 'Authorization',
      difficulty: 'Easy',
      impactSize: 'Medium',
      affectedParty: 'Multiple Employees',
      cia: { c: 'High', i: 'High', a: 'Low' },
      severity: 'High',
      cvss: { score: '8.1', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:N' },
      cwe: 'CWE-639 / OWASP API1:2023 (Broken Object Level Authorization)',
      description:
        'Changing an object ID in the URL returns records belonging to other users, because object-level authorization is missing. Tested over REAL HTTP against the production route vs a vulnerable lab twin, with a live employee session.',
      affectedComponent: 'Records API - object-level authz',
      endpoint: 'GET /api/records/:id (production) vs /api/lab/vulnerable/records/:id',
      attackVector: 'API (authenticated employee)',
      technicalImpact: 'Read across arbitrary objects by ID enumeration.',
      partyImpactLabel: 'Employee / manager impact',
      partyImpact: 'Any employee can read other employees’ records by guessing IDs.',
      orgImpact: 'Mass data exposure by ID enumeration; confidentiality breach.',
      remediation: 'Check object ownership/scope on every verb; use unguessable IDs as defence-in-depth.',
      remediationCode:
        "async function authzObject(req,res,next){\n  const rec = await Records.get(req.params.id);\n  if (!rec || !canAccess(req.user, rec)) return res.status(403).json({error:'Forbidden'});\n  req.rec = rec; next();\n}\nrouter.get('/api/records/:id', authzObject, read);",
    },

    /* 2 ── EMP-09 Mass assignment on a real production route ────────── */
    {
      id: 'EMP-09',
      title: 'Mass assignment sets protected role field (real route)',
      category: 'Business Logic',
      difficulty: 'Medium',
      impactSize: 'Critical',
      affectedParty: 'Administrator',
      cia: { c: 'High', i: 'High', a: 'Low' },
      severity: 'Critical',
      cvss: { score: '8.8', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H' },
      cwe: 'CWE-915 (Improperly Controlled Modification of Object Attributes)',
      description:
        'A profile-update endpoint binds the whole request body to the record, so sending an extra "role" field lets an ordinary employee promote themselves. Tested over REAL HTTP, then the DB row is read back to prove what persisted.',
      affectedComponent: 'Profile update - object binding',
      endpoint: 'PATCH /api/profile (production) vs /api/lab/vulnerable/profile',
      attackVector: 'API (extra fields)',
      technicalImpact: 'Protected attributes (role, ownership) are client-writable.',
      partyImpactLabel: 'Employee / manager impact',
      partyImpact: 'An employee elevates to administrator by adding one field to a normal update.',
      orgImpact: 'Privilege escalation through the update path; authorization model bypassed.',
      remediation: 'Bind only an explicit allow-list of editable fields; never spread the raw body.',
      remediationCode:
        "const { name, email } = req.body;          // allow-list ONLY\nawait Users.update(req.user.id, { name, email });\n// role / permissions / status are never accepted from the client",
    },

    /* 3 ── EMP-02 Vertical privilege escalation ────────────────────── */
    {
      id: 'EMP-02',
      title: 'Vertical privilege escalation - Employee hits Admin function',
      category: 'Authorization',
      difficulty: 'Medium',
      impactSize: 'Critical',
      affectedParty: 'Administrator',
      cia: { c: 'High', i: 'High', a: 'Medium' },
      severity: 'Critical',
      cvss: { score: '8.8', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:N/S:U/C:H/I:H/A:H' },
      cwe: 'CWE-269 (Improper Privilege Management)',
      description:
        'A lower-privileged employee can call an admin-only function because the backend relies on the UI to hide the button rather than enforcing the role. Role is looked up server-side from the directory, never trusted from the request.',
      affectedComponent: 'Admin API - role enforcement',
      endpoint: 'POST /api/assess/admin-action',
      attackVector: 'API (authenticated employee)',
      technicalImpact: 'Role boundary broken; privileged operations reachable by non-privileged users.',
      partyImpactLabel: 'Employee / manager impact',
      partyImpact: 'An ordinary employee performs administrator actions.',
      orgImpact: 'Authorization-model failure - an employee can act as admin.',
      remediation: 'Enforce the required role on the server for every privileged route (deny by default).',
      remediationCode:
        "function requireRole(role){ return (req,res,next)=>\n  req.user.role === role || req.user.role === 'admin' ? next() : res.status(403).json({error:'Insufficient role'}); }\napp.post('/api/admin/action', requireRole('admin'), doAdmin);",
    },

    /* 4 ── EMP-08 Forged JWT (alg=none) ────────────────────────────── */
    {
      id: 'EMP-08',
      title: 'JWT accepts alg=none / unverified role claim',
      category: 'Authentication',
      difficulty: 'Medium',
      impactSize: 'Critical',
      affectedParty: 'Administrator',
      cia: { c: 'High', i: 'High', a: 'Low' },
      severity: 'Critical',
      cvss: { score: '9.1', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:N' },
      cwe: 'CWE-347 (Improper Verification of Cryptographic Signature)',
      description:
        'The token verifier trusts an unsigned (alg=none) token and reads the role claim without validating the signature, so anyone can mint an admin token. The fixed path runs the real HS256 verification.',
      affectedComponent: 'Token verification',
      endpoint: 'POST /api/assess/jwt-verify',
      attackVector: 'API (forged token)',
      technicalImpact: 'Any claim (including role=admin) can be forged.',
      partyImpactLabel: 'Employee / manager impact',
      partyImpact: 'A user can hand-craft a token claiming to be an administrator.',
      orgImpact: 'Complete authentication bypass - attacker becomes any role at will.',
      remediation: 'Reject alg=none, verify HMAC/RSA signature, and validate iss/aud/exp before trusting claims.',
      remediationCode:
        "jwt.verify(token, SECRET, { algorithms:['HS256'], issuer:'world-monitor', audience:'wm-api' });\n// library throws on alg=none, bad signature, wrong iss/aud, or expiry",
    },

    /* 5 ── EMP-12 No idle session timeout ──────────────────────────── */
    {
      id: 'EMP-12',
      title: 'No idle timeout; logout does not revoke API session',
      category: 'Session',
      difficulty: 'Easy',
      impactSize: 'Medium',
      affectedParty: 'Multiple Employees',
      cia: { c: 'High', i: 'Low', a: 'Low' },
      severity: 'Medium',
      cvss: { score: '5.4', vector: 'CVSS:3.1/AV:N/AC:L/PR:L/UI:R/S:U/C:H/I:L/A:N' },
      cwe: 'CWE-613 (Insufficient Session Expiration)',
      description:
        'Sessions never expire from inactivity and remain valid at the API after logout. Verified with a controlled/testable clock (idleMinutes) rather than waiting 60 real minutes.',
      affectedComponent: 'Session lifecycle',
      endpoint: 'POST /api/assess/idle-check',
      attackVector: 'Session (reuse)',
      technicalImpact: 'Sessions outlive their intended lifetime.',
      partyImpactLabel: 'Employee / manager impact',
      partyImpact: 'A shared-machine or logged-out employee session stays usable by whoever has the token.',
      orgImpact: 'Increased window for session hijack across staff on shared devices.',
      remediation: 'Add absolute + idle timeouts and destroy the server-side session on logout.',
      remediationCode:
        "session.cookie.maxAge = 15*60*1000;         // idle timeout\napp.post('/api/auth/logout', (req,res)=>{ req.session.destroy(()=>res.sendStatus(204)); });",
    },
  ];

  /* ---- role hierarchy panel (intended boundaries the checks verify) ---- */
  const matrixHTML =
    '<div class="sxa-panelbox"><h3>Role hierarchy (intended boundaries)</h3>' +
    '<div class="sxa-roles">' +
    '<div class="sxa-role"><b>Test Employee</b> - own records</div>' +
    '<div class="sxa-role-arrow">→</div>' +
    '<div class="sxa-role"><b>Test Manager</b> - team records + approvals</div>' +
    '<div class="sxa-role-arrow">→</div>' +
    '<div class="sxa-role"><b>Test Administrator</b> - full control</div>' +
    '</div>' +
    '<p style="font-size:11px;color:#7C8593;margin-top:8px">The 5 checks below verify whether the <b>actual</b> backend behaviour respects these boundaries. The backend is the authoritative boundary; EMP-04 and EMP-09 run against real production routes over real HTTP.</p></div>';

  function mount() {
    const section = document.getElementById('section-2');
    if (!section) return;
    const host = section.querySelector('#emp-root');
    if (!host || host.dataset.mounted) return;
    host.dataset.mounted = '1';
    window.SXA.mountPanel(host, {
      title: 'Employee and Manager Security Assessment',
      slug: 'employee-manager',
      subtitle:
        'White-hat checks for the 5 approved vulnerabilities across a test role hierarchy (Employee → Manager → Administrator). EMP-04 and EMP-09 are exercised over real HTTP against production routes vs vulnerable lab twins.',
      extraMid: matrixHTML,
      checks,
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
