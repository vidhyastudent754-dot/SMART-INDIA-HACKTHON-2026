/* company-org.js - SECTION 3 · Company / Organization Security Assessment
 * FINAL SCOPE: exactly 5 attacks (ORG-06, ORG-09, ORG-15, ORG-16, ORG-11),
 * derived from the authoritative registry (registry.js). Mounts into
 * #section-4 (labelled "03"). Dangerous classes are sandboxed/synthetic;
 * ORG-11 runs a REAL npm audit. */
(function () {
  'use strict';
  const ORG = 'Organization';

  const checks = [
    /* 1 ── ORG-06 SQL Injection ────────────────────────────────────── */
    {
      id: 'ORG-06', title: 'SQL injection (non-destructive detection)', category: 'Input',
      difficulty: 'Medium', impactSize: 'Critical', affectedParty: ORG,
      cia: { c: 'High', i: 'High', a: 'Medium' }, severity: 'Critical',
      cvss: { score: '9.8', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H' },
      cwe: 'CWE-89 (SQL Injection)',
      description: 'A database-backed input is concatenated into a query. A benign probe collapses the WHERE clause and dumps the whole (synthetic) table, proving injection. Runs against a synthetic in-memory table - no real DB engine.',
      affectedComponent: 'Data layer - query builder', endpoint: 'POST /api/assess/search',
      attackVector: 'API/Web input',
      technicalImpact: 'Query logic controllable by input → data read/modify potential.',
      orgImpact: 'Potential full database compromise if present on a real query path.',
      remediation: 'Use parameterized queries / prepared statements everywhere; validate input types.',
      remediationCode: "db.prepare('SELECT id,user,role FROM users WHERE user = ?').all(title); // parameterized",
    },

    /* 2 ── ORG-09 Path Traversal ───────────────────────────────────── */
    {
      id: 'ORG-09', title: 'Path traversal in file/resource parameter', category: 'Input',
      difficulty: 'Medium', impactSize: 'Large', affectedParty: ORG,
      cia: { c: 'High', i: 'Low', a: 'Low' }, severity: 'High',
      cvss: { score: '7.5', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:N/A:N' },
      cwe: 'CWE-22 (Improper Limitation of a Pathname to a Restricted Directory)',
      description: 'A file parameter is used to build a path without normalisation, so "../" sequences escape the intended directory. Tested against a synthetic in-memory virtual filesystem - no real files are read.',
      affectedComponent: 'File download handler', endpoint: 'GET /api/assess/file?path=',
      attackVector: 'Web/API',
      technicalImpact: 'Read of files outside the intended directory.',
      orgImpact: 'Disclosure of server configuration/secrets across the org host.',
      remediation: 'Resolve + verify the path stays within a base dir; reject "..", use an ID→path map.',
      remediationCode: "const base='/srv/files';\nconst p=path.resolve(base, path.normalize(name));\nif(!p.startsWith(base+path.sep)) return res.status(400).json({error:'Invalid path'});",
    },

    /* 3 ── ORG-15 No Rate Limiting ─────────────────────────────────── */
    {
      id: 'ORG-15', title: 'No rate limiting (availability)', category: 'Availability',
      difficulty: 'Easy', impactSize: 'Medium', affectedParty: ORG,
      cia: { c: 'Low', i: 'Low', a: 'Medium' }, severity: 'Medium',
      cvss: { score: '5.3', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:N/I:N/A:L' },
      cwe: 'CWE-770 (Allocation of Resources Without Limits or Throttling)',
      description: 'An endpoint has no rate limit, so a configured burst is served without throttling. The fixed path uses a REAL stateful counter (SQLite) and returns genuine HTTP 429 once the limit is exceeded.',
      affectedComponent: 'API - throttling', endpoint: 'POST /api/assess/rate-test',
      attackVector: 'Network (request flood)',
      technicalImpact: 'Resource exhaustion / brute-force / quota burn.',
      orgImpact: 'Service degradation and cost abuse; basic availability risk.',
      remediation: 'Apply per-route rate limits tuned for light vs heavy endpoints.',
      remediationCode: "const limiter = rateLimit({ windowMs:60000, max:5 });\napp.post('/api/endpoint', limiter, handler); // 429 after the limit",
    },

    /* 4 ── ORG-16 PII in Cleartext ─────────────────────────────────── */
    {
      id: 'ORG-16', title: 'PII in cleartext (weak data-protection controls)', category: 'Data',
      difficulty: 'Medium', impactSize: 'Large', affectedParty: ORG,
      cia: { c: 'High', i: 'Medium', a: 'Low' }, severity: 'High',
      cvss: { score: '7.4', vector: 'CVSS:3.1/AV:N/AC:H/PR:L/UI:N/S:U/C:H/I:H/A:N' },
      cwe: 'CWE-311 / CWE-312 (Missing / Cleartext Storage of Sensitive Data)',
      description: 'Sensitive fields (card, SSN) are returned/stored in cleartext instead of masked/encrypted. Uses controlled synthetic PII - not real people.',
      affectedComponent: 'Database / data model', endpoint: 'GET /api/assess/data-protection',
      attackVector: 'Data-at-rest / in-transit',
      technicalImpact: 'A DB compromise directly yields plaintext sensitive data.',
      orgImpact: 'Large-scale data exposure; retention/compliance and least-privilege failures.',
      remediation: 'Mask in responses, encrypt sensitive columns at rest, set retention windows, least-privilege DB roles.',
      remediationCode: "return { card:'**** **** **** '+card.slice(-4), ssn:'***-**-'+ssn.slice(-4) };\n// encrypt PII columns at rest; scheduled purge for retention window",
    },

    /* 5 ── ORG-11 Vulnerable Dependencies (real npm audit) ─────────── */
    {
      id: 'ORG-11', title: 'Vulnerable / outdated dependencies (real npm audit)', category: 'Configuration',
      difficulty: 'Easy', impactSize: 'Medium', affectedParty: ORG,
      cia: { c: 'Medium', i: 'Medium', a: 'Medium' }, severity: 'Medium',
      cvss: { score: '6.9', vector: 'CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:L/I:L/A:L' },
      cwe: 'CWE-1104 (Use of Unmaintained Third-Party Components)',
      description: 'Runs a REAL `npm audit --json` - the fixed path audits the project’s actual clean package-lock.json; the vulnerable path audits a deliberately-outdated lockfile fixture. Package names, versions and CVEs come from the live npm advisory database - nothing is hard-coded.',
      affectedComponent: 'package.json / lockfile', endpoint: 'GET /api/assess/deps',
      attackVector: 'Supply chain',
      technicalImpact: 'Known CVEs inherited from outdated libraries.',
      orgImpact: 'Exploitable known issues across the stack; audit + upgrade needed.',
      remediation: 'Run npm audit / SCA in CI; pin and upgrade; track advisories.',
      remediationCode: "// CI gate\nnpm audit --audit-level=high || exit 1\n// upgrade flagged packages, re-test",
    },
  ];

  const assetHTML =
    '<div class="sxa-panelbox"><h3>Organization assets in scope</h3>' +
    '<div class="sxa-roles">' +
    ['Data layer / DB', 'File handling', 'API throttling', 'Data protection', 'Dependencies / supply chain']
      .map((a) => '<div class="sxa-role">' + a + '</div>').join('') +
    '</div>' +
    '<p style="font-size:11px;color:#7C8593;margin-top:6px">Each of the 5 findings maps: <b>Vulnerability → Affected asset → Technical severity → Organizational impact → Evidence → Remediation → Retest.</b> ORG-06/09 are sandboxed; ORG-11 runs a real npm audit.</p></div>';

  function mount() {
    const host = document.querySelector('#section-4 #org-root');
    if (!host || host.dataset.mounted) return;
    host.dataset.mounted = '1';
    window.SXA.mountPanel(host, {
      title: 'Company and Organization Security Assessment',
      slug: 'company-org',
      subtitle:
        'White-hat checks for the 5 approved organization-level vulnerabilities: data layer, file handling, throttling, data protection and dependencies. Dangerous classes are sandboxed/synthetic; ORG-11 runs a real npm audit.',
      extraMid: assetHTML,
      checks,
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', mount);
  else mount();
})();
